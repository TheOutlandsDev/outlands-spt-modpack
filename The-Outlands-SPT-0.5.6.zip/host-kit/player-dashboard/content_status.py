"""Bounded, read-only player projection of the server's startup content calendar."""
from datetime import datetime, timezone
import json
import re

MAPS = frozenset(('bigmap', 'woods', 'shoreline', 'interchange', 'rezervbase', 'lighthouse',
                  'tarkovstreets', 'sandbox', 'sandbox_high', 'laboratory', 'factory4_day', 'factory4_night'))
THEMES = frozenset(('Supply lanes', 'Patrol surge', 'Containment patrol', 'Smuggler routes',
                    'Boss sightings', 'Outbreak hunt', 'Recovery runs'))


def timestamp(value):
    if not isinstance(value, str):
        raise ValueError("Invalid timestamp")
    parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
    if parsed.tzinfo is None:
        raise ValueError('Missing timezone')
    return parsed.astimezone(timezone.utc)


def day_plan(data):
    if not isinstance(data, dict) or data.get('Theme') not in THEMES:
        raise ValueError('Unknown theme')
    day = data.get('Day', '')
    if not isinstance(day, str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}', day):
        raise ValueError('Invalid calendar day')
    datetime.strptime(day, '%Y-%m-%d')
    maps = data.get('Hotspots')
    if not isinstance(maps, list) or len(maps) != 2 or len(set(maps)) != 2 or not all(m in MAPS for m in maps):
        raise ValueError('Invalid hotspots')
    return {'date': day, 'theme': data['Theme'], 'hotspots': maps}


def sanitize(data, now=None):
    now = datetime.now(timezone.utc) if now is None else now
    if not isinstance(data, dict) or data.get('schemaVersion') != 1:
        raise ValueError('Unknown calendar schema')
    if data.get('timezone') != 'America/New_York' or data.get('rolloverHour') != 5:
        raise ValueError('Unexpected schedule')
    since = timestamp(data['activeSinceUtc'])
    if since > now.replace(microsecond=0) and (since - now).total_seconds() > 30:
        raise ValueError('Future activation')
    result = {'schemaVersion': 1, 'available': True, 'checkedAtUtc': now.isoformat(),
              'activeSinceUtc': since.isoformat(), 'day': day_plan(data['day']),
              'timezone': 'America/New_York', 'rolloverHour': 5,
              'message': 'Themes change after the 5 AM Eastern restart, once all raids finish.',
              'maps': {}, 'nextSevenDays': []}
    maps = data.get('maps', {})
    if not isinstance(maps, dict) or len(maps) > len(MAPS):
        raise ValueError('Invalid map status')
    for name, row in maps.items():
        if name not in MAPS or not isinstance(row, dict):
            raise ValueError('Unexpected map')
        rate = row.get('infection')
        if type(rate) is not int or not 0 <= rate <= 75 or type(row.get('hotspot')) is not bool:
            raise ValueError('Invalid map values')
        result['maps'][name] = {'infection': rate, 'hotspot': row['hotspot']}
    future = data.get('nextSevenDays', [])
    if not isinstance(future, list) or len(future) != 7:
        raise ValueError('Missing seven-day schedule')
    result['nextSevenDays'] = [day_plan(day) for day in future]
    return result


def unavailable():
    return {'schemaVersion': 1, 'available': False, 'message': 'The content calendar is not available yet.'}
