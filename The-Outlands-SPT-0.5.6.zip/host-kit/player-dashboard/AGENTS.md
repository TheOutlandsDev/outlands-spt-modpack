# Player dashboard maintenance

This app runs on node-01 and reads the existing SPT 4.0.13 / Fika Server 2.2.4
installation. Keep it read-only. Preserve the vanilla JS and Python standard
library deployment unless a dependency has a concrete benefit.

After source changes, run the meaningful backend tests and inspect the live UI.
Publish the reviewed source allowlist to the owner's private
`TheOutlandsDev/OUTLANDS-DEV-LAB` repository under
`systems/node-01/home/node-01/Desktop/SPT-ON-NODE/player-dashboard/`, preserving
history and unrelated repository content. Update its bounded source manifest
and verify remote hashes. The owner requested GitHub to remain current as this
app changes. Use the connected GitHub tools; do not save GitHub credentials here.

Never publish deployment/, .env, logs, player/profile records, the Fika API key,
game files, Wine prefixes, Docker/Dockhand databases, or installed dependencies.
Do not add the parent game workspace to Git. Source and tests are separate from
live operational evidence, which remains local.

Only the dashboard's read-only API may be reachable through its private
Tailscale HTTPS proxy. Dockhand remains loopback-only. Keep the scoped Tailscale
input policy enabled while ShieldsUp is false. Do not expand tailnet access or
enable public Funnel as part of app maintenance.
