"""Synthetic scheduling/adapter checks. Never contact or stop the live game host."""
from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
import tempfile
import unittest
from unittest.mock import patch

import engine
import worker
import install


def moment(text="2026-10-24T09:00:00+00:00"):
    return datetime.fromisoformat(text)


def ack(at, lease=None, inflight=0):
    return {"schemaVersion": 1, "loaded": True, "checkedAtUtc": engine.iso(at),
            "leaseId": lease, "draining": lease is not None, "inFlightAdmissions": inflight}


def observation(at, idle=True):
    return {"idle": idle, "atUtc": engine.iso(at), "reason": "Synthetic fixture"}


def draining(at):
    state = engine.initial()
    state.update(phase="draining", cycleDate="2026-10-24", targetAtUtc=engine.iso(at), leaseId="fixture-lease")
    return state


class ScheduleTests(unittest.TestCase):
    def test_eastern_schedule_follows_dst(self):
        self.assertEqual(engine.target_on(moment("2026-10-31T00:00:00+00:00").date()).hour, 9)
        self.assertEqual(engine.target_on(moment("2026-11-01T00:00:00+00:00").date()).hour, 10)
        self.assertEqual(engine.target_on(moment("2027-03-14T00:00:00+00:00").date()).hour, 9)

    def test_no_guard_means_activation_required_without_actions(self):
        for at in (moment() - timedelta(hours=2), moment() - timedelta(minutes=10), moment()):
            state, action = engine.decide(at, engine.initial(), None)
            self.assertEqual(state["phase"], "activation_required")
            self.assertEqual(action["kind"], "blocked")

    def test_notices_require_ack_and_delivery_does_not_get_assumed(self):
        at = moment() - timedelta(minutes=30)
        state, action = engine.decide(at, engine.initial(), ack(at))
        self.assertEqual((action["kind"], action["minutes"]), ("notify", 30))
        self.assertEqual(state["sentWarnings"], [])
        same, again = engine.decide(at + timedelta(seconds=15), state, ack(at))
        self.assertEqual(again["kind"], "notify")
        state = engine.notice_sent(same, 30)
        _, action = engine.decide(at + timedelta(seconds=20), state, ack(at))
        self.assertEqual(action["kind"], "wait")

    def test_late_arrival_sends_only_latest_warning(self):
        at = moment() - timedelta(minutes=4)
        state, action = engine.decide(at, engine.initial(), ack(at))
        self.assertEqual(action["minutes"], 5)
        state = engine.notice_sent(state, 5)
        self.assertEqual(state["sentWarnings"], [30, 15, 5])
        at = moment() - timedelta(seconds=45)
        _, action = engine.decide(at, state, ack(at))
        self.assertEqual(action["minutes"], 1)

    def test_boot_never_creates_unannounced_catchup(self):
        for at in (moment(), moment() + timedelta(minutes=1), moment() + timedelta(hours=5)):
            state, action = engine.decide(at, engine.initial(), ack(at))
            self.assertEqual((state["phase"], action["kind"]), ("skipped", "skip"))

    def test_overdue_announced_but_undrained_cycle_is_skipped(self):
        state, _ = engine.decide(moment() - timedelta(minutes=30), engine.initial(), ack(moment() - timedelta(minutes=30)))
        state = engine.notice_sent(state, 30)
        at = moment() + timedelta(minutes=2)
        state, action = engine.decide(at, state, ack(at))
        self.assertEqual(action["kind"], "skip")

    def test_delayed_prior_cycle_does_not_restart_twice_on_one_local_day(self):
        at = moment() - timedelta(minutes=1)
        state = engine.initial()
        state.update(cycleDate="2026-10-23", phase="complete", lastRestartAtUtc=engine.iso(at - timedelta(minutes=2)))
        state, action = engine.decide(at, state, ack(at))
        self.assertEqual(action["kind"], "idle")
        self.assertEqual(engine.next_target(at, state), moment() + timedelta(days=1))

    def test_due_announced_cycle_enters_drain_without_stopping_yet(self):
        state, _ = engine.decide(moment() - timedelta(minutes=1), engine.initial(), ack(moment() - timedelta(minutes=1)))
        state = engine.notice_sent(state, 1)
        state, action = engine.decide(moment(), state, ack(moment()))
        self.assertEqual((state["phase"], action["kind"]), ("draining", "begin_drain"))

    def test_drain_waits_indefinitely_for_every_raid(self):
        state = draining(moment())
        for days in (0, 1, 10):
            at = moment() + timedelta(days=days)
            state, action = engine.decide(at, state, ack(at, state["leaseId"]), observation(at, False))
            self.assertEqual((state["phase"], action["kind"], state["idleSamples"]), ("draining", "wait", 0))
        self.assertEqual(state["cycleDate"], "2026-10-24")

    def test_fresh_same_lease_zero_inflight_and_stable_idle_required(self):
        state = draining(moment())
        for seconds in (0, 15, 30):
            at = moment() + timedelta(seconds=seconds)
            state, action = engine.decide(at, state, ack(at, state["leaseId"]), observation(at))
            self.assertEqual(action["kind"], "restart" if seconds == 30 else "wait")

    def test_inflight_missing_wrong_stale_and_unknown_block_restart(self):
        for update in ({"schemaVersion": True}, {"inFlightAdmissions": 1}, {"inFlightAdmissions": None},
                       {"inFlightAdmissions": False}, {"leaseId": "other"}, {"draining": False},
                       {"checkedAtUtc": engine.iso(moment() - timedelta(seconds=31))}):
            state = draining(moment())
            state.update(idleSamples=3, idleSinceUtc=engine.iso(moment() - timedelta(minutes=1)),
                         idleLastUtc=engine.iso(moment() - timedelta(seconds=15)))
            data = ack(moment(), state["leaseId"])
            data.update(update)
            state, action = engine.decide(moment(), state, data, observation(moment()))
            self.assertEqual((action["kind"], state["idleSamples"]), ("wait", 0))

    def test_idle_observation_gap_or_busy_resets_stability(self):
        state = draining(moment())
        state, _ = engine.decide(moment(), state, ack(moment(), state["leaseId"]), observation(moment()))
        at = moment() + timedelta(seconds=60)
        state, action = engine.decide(at, state, ack(at, state["leaseId"]), observation(at))
        self.assertEqual((action["kind"], state["idleSamples"]), ("wait", 1))
        at += timedelta(seconds=15)
        state, _ = engine.decide(at, state, ack(at, state["leaseId"]), observation(at, False))
        self.assertIsNone(state["idleSinceUtc"])

    def test_recovery_requires_own_intent_and_cannot_require_live_api(self):
        for phase in ("restarting", "recovering"):
            state = engine.initial()
            state["phase"] = phase
            _, action = engine.decide(moment(), state, None, None)
            self.assertEqual(action["kind"], "recover")
        _, action = engine.decide(moment() - timedelta(hours=2), engine.initial(), None, None)
        self.assertNotEqual(action["kind"], "recover")

    def test_public_projection_is_bounded_and_excludes_private_state(self):
        state = draining(moment())
        state.update(containerIdentity={"private": "id"}, backupPath="private/path", secret="not-public")
        result = engine.public_status(moment(), state, "Waiting")
        self.assertEqual(result["nextRestartAtUtc"], state["targetAtUtc"])
        self.assertEqual(result["warningMinutes"], [30, 15, 5, 1])
        self.assertNotIn("private", json.dumps(result))
        self.assertNotIn("secret", result)
        self.assertLess(len(json.dumps(result)), 16384)


class ObservationTests(unittest.TestCase):
    def setUp(self):
        self.headless = {"headlesses": {"expected": {"WebSocket": {"State": 2}, "State": 1,
            "Players": [], "RequesterSessionID": None, "HasNotifiedRequester": None}}}
    def observed(self, headless=None, presence=None, raids=None):
        return engine.idle_observation(self.headless if headless is None else headless,
            [] if presence is None else presence, [] if raids is None else raids, "expected", moment())
    def test_empty_presence_and_ready_host_is_idle(self):
        self.assertTrue(self.observed()["idle"])
        self.assertTrue(self.observed(presence=[{"activity": 0}, {"activity": 2}])["idle"])
    def test_every_unknown_or_busy_source_fails_closed(self):
        for host_change in ({"State": True}, {"State": 2}, {"State": 0}, {"Players": ["player"]},
                            {"Players": None}, {"CurrentMatch": "match"}, {"WebSocket": {"State": 6}},
                            {"RequesterSessionID": "requester"}, {"HasNotifiedRequester": False}):
            data = deepcopy(self.headless)
            data["headlesses"]["expected"].update(host_change)
            self.assertFalse(self.observed(headless=data)["idle"])
        for missing in ("RequesterSessionID", "HasNotifiedRequester"):
            data = deepcopy(self.headless)
            del data["headlesses"]["expected"][missing]
            self.assertTrue(self.observed(headless=data)["idle"])
        for data in ({}, {"headlesses": {}}, {"headlesses": []}):
            self.assertFalse(self.observed(headless=data)["idle"])
        for data in ([{"activity": 1}], [{}], ["player"], [{"activity": None}]):
            self.assertFalse(self.observed(presence=data)["idle"])
        for data in ({}, [{"status": 0}], [{"status": 2}]):
            self.assertFalse(self.observed(raids=data)["idle"])


class TransactionTests(unittest.TestCase):
    def setUp(self):
        notifications = patch.object(worker, "notify")
        self.notifications = notifications.start()
        self.addCleanup(notifications.stop)

    def rows(self, stopped=False):
        return {name: {"Id": name + "-id", "Image": "sha256:fixture",
                "State": {"Running": not stopped, "Status": "exited" if stopped else "running",
                          "ExitCode": 0, "OOMKilled": False, "Health": {"Status": "healthy"}}}
                for name in worker.NAMES}

    @contextmanager
    def fake_lease(self, state):
        yield []

    def test_no_stop_without_final_ack_and_idle(self):
        state = draining(moment())
        with patch.object(worker, "read_ack", return_value={}), patch.object(worker, "save"), \
             patch.object(worker, "docker") as command:
            worker.transaction(state)
            command.assert_not_called()

    def test_intent_precedes_stops_backup_and_same_container_start(self):
        state = draining(moment())
        order = []
        def save(value, message):
            order.append(("save", value["phase"]))
        with patch.object(worker, "now", return_value=moment()), \
             patch.object(worker, "read_ack", return_value=ack(moment(), state["leaseId"])), \
             patch.object(worker, "observe", return_value=observation(moment())), \
             patch.object(worker, "inspect", return_value=self.rows()), patch.object(worker, "save", side_effect=save), \
             patch.object(worker, "lease_pump", self.fake_lease), \
             patch.object(worker, "docker", side_effect=lambda *args, **kwargs: order.append(args)), \
             patch.object(worker, "backup", side_effect=lambda value: order.append(("backup",)) or "/private/backup"), \
             patch.object(worker, "start_same", side_effect=lambda value: order.append(("start_same",))), \
             patch.object(worker, "release_lease", side_effect=lambda value: order.append(("release",))):
            worker.transaction(state)
        self.assertEqual(order[0], ("save", "restarting"))
        self.assertEqual(order[1:4], [("stop", "--time", "45", worker.NAMES[1] + "-id"),
                                    ("stop", "--time", "90", worker.NAMES[0] + "-id"), ("backup",)])
        self.assertEqual(state["phase"], "complete")
        self.assertEqual(order[-1], ("release",))

    def test_admission_becoming_inflight_at_final_boundary_defers_without_stop(self):
        state = draining(moment())
        acknowledgements = [ack(moment(), state["leaseId"]), ack(moment(), state["leaseId"], 1)]
        with patch.object(worker, "now", return_value=moment()), \
             patch.object(worker, "read_ack", side_effect=acknowledgements), \
             patch.object(worker, "observe", return_value=observation(moment())), \
             patch.object(worker, "inspect", return_value=self.rows()), patch.object(worker, "save"), \
             patch.object(worker, "lease_pump", self.fake_lease), patch.object(worker, "docker") as command, \
             patch.object(worker, "release_lease") as release:
            worker.transaction(state)
            command.assert_not_called()
            release.assert_not_called()
        self.assertEqual(state["phase"], "draining")

    def test_final_notice_failure_defers_but_completion_notice_failure_is_not_a_restart_failure(self):
        state = draining(moment())
        self.notifications.side_effect = RuntimeError("fixture notification failed")
        with patch.object(worker, "now", return_value=moment()), \
             patch.object(worker, "read_ack", return_value=ack(moment(), state["leaseId"])), \
             patch.object(worker, "observe", return_value=observation(moment())), \
             patch.object(worker, "inspect", return_value=self.rows()), patch.object(worker, "save"), \
             patch.object(worker, "lease_pump", self.fake_lease), patch.object(worker, "docker") as command:
            worker.transaction(state)
            command.assert_not_called()
        self.assertEqual(state["phase"], "draining")
        state["containerIdentity"] = worker.identity(self.rows())
        with patch.object(worker, "save"), patch.object(worker, "lease_pump", self.fake_lease), \
             patch.object(worker, "start_same"), patch.object(worker, "release_lease"):
            worker.transaction(state, recovery=True)
        self.assertEqual(state["phase"], "failed")

    def test_failed_backup_is_durable_and_recovery_never_claims_completion(self):
        state = draining(moment())
        with patch.object(worker, "now", return_value=moment()), \
             patch.object(worker, "read_ack", return_value=ack(moment(), state["leaseId"])), \
             patch.object(worker, "observe", return_value=observation(moment())), \
             patch.object(worker, "inspect", return_value=self.rows()), patch.object(worker, "save"), \
             patch.object(worker, "lease_pump", self.fake_lease), patch.object(worker, "docker"), \
             patch.object(worker, "backup", side_effect=RuntimeError("fixture backup failed")), \
             patch.object(worker, "release_lease") as release:
            with self.assertRaises(RuntimeError):
                worker.transaction(state)
            self.assertEqual(state["phase"], "recovering")
            release.assert_not_called()
        with patch.object(worker, "save"), patch.object(worker, "lease_pump", self.fake_lease), \
             patch.object(worker, "start_same"), patch.object(worker, "release_lease"):
            worker.transaction(state, recovery=True)
        self.assertEqual(state["phase"], "failed")
        self.assertIsNone(state["lastRestartAtUtc"])

    def test_quiescent_archive_contains_state_but_no_game_assets(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            data = {"runtime/SPT/user/profiles/profile.json": b'{"fixture":true}',
                    "runtime/SPT/SPT_Data/configs/weather.json": b'{}',
                    "runtime/BepInEx/config/fixture.cfg": b'fixture',
                    "runtime/HeadlessConfig.json": b'{}', "linux/version-lock.json": b'{}',
                    "containers/stacks/spt-fika/compose.yaml": b'fixture',
                    "runtime/EscapeFromTarkov_Data/Managed/Assembly-CSharp.dll": b'VENDOR-EXCLUDED'}
            for relative, contents in data.items():
                path = root / relative
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(contents)
            (root / "runtime/SPT/user/mods").mkdir(parents=True)
            state = {"containerIdentity": worker.identity(self.rows(stopped=True))}
            with patch.object(worker, "ROOT", root), patch.object(worker, "inspect", return_value=self.rows(stopped=True)):
                destination = Path(worker.backup(state))
            manifest = json.loads((destination / "manifest.json").read_text())
            self.assertNotIn("runtime/EscapeFromTarkov_Data/Managed/Assembly-CSharp.dll", manifest["files"])
            with tarfile.open(destination / "state.tar.gz") as archive:
                self.assertEqual(set(archive.getnames()), set(manifest["files"]))
                for name in archive.getnames():
                    self.assertEqual(hashlib.sha256(archive.extractfile(name).read()).hexdigest(), manifest["files"][name]["sha256"])
            self.assertEqual((destination / "state.tar.gz").stat().st_mode & 0o777, 0o600)

    def test_force_kill_or_oom_is_not_a_quiescent_backup(self):
        rows = self.rows(stopped=True)
        self.assertTrue(worker.stopped(rows))
        rows[worker.NAMES[1]]["State"]["ExitCode"] = 137
        self.assertFalse(worker.stopped(rows))
        rows[worker.NAMES[1]]["State"].update(ExitCode=0, OOMKilled=True)
        self.assertFalse(worker.stopped(rows))

    def test_readiness_rejects_adjacent_spt_version(self):
        expected = worker.identity(self.rows())
        with patch.object(worker, "inspect", return_value=self.rows()), \
             patch.object(worker, "observe", return_value=observation(moment())):
            for version in ("SPT 4.0.13", "SPT 4.0.13 - 2891fd", "SPT 4.0.130", "SPT 4.0.14"):
                with patch.object(worker, "api", return_value={"Version": version}):
                    self.assertEqual(worker.ready(expected), version in ("SPT 4.0.13", "SPT 4.0.13 - 2891fd"))


class UnitTests(unittest.TestCase):
    @unittest.skipUnless(shutil.which("systemd-analyze"), "systemd-analyze is unavailable")
    def test_real_systemd_parser_accepts_generated_units_without_activation(self):
        with tempfile.TemporaryDirectory() as temporary:
            paths = []
            units = install.unit_contents()
            for name, content in units.items():
                path = Path(temporary) / name
                path.write_text(content)
                paths.append(str(path))
            result = subprocess.run(["systemd-analyze", "--user", "verify", *paths],
                                    capture_output=True, text=True, timeout=20)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("WorkingDirectory=" + str(install.SOURCE.parents[1]) + "\n", units["node01-spt-maintenance.service"])


if __name__ == "__main__":
    unittest.main()
