#!/usr/bin/env python3
"""Apply or restore node-01's Halloween/autumn settings while both game containers are stopped."""
import argparse
import copy
import hashlib
import json
import os
import stat
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path


WORKSPACE = Path(__file__).resolve().parents[2]
FILES = ("seasonalevents.json", "weather.json")
CONTAINERS = ("node01-spt-backend", "node01-fika-headless")


class Refused(RuntimeError):
    pass


def document(raw, name):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise Refused("Duplicate JSON field in " + name)
            result[key] = value
        return result

    try:
        return json.loads(raw, object_pairs_hook=unique)
    except (ValueError, UnicodeError):
        raise Refused("Invalid JSON in " + name) from None


def read_file(path):
    if path.is_symlink() or not path.is_file():
        raise Refused("Expected ordinary file: " + str(path))
    return path.read_bytes(), stat.S_IMODE(path.stat().st_mode)


def require_stopped(workspace):
    wrapper = workspace / "containers/docker.sh"
    try:
        result = subprocess.run([str(wrapper), "inspect", "--format", "{{json .State}}", *CONTAINERS],
                                capture_output=True, text=True, timeout=30, check=True)
        states = [json.loads(line) for line in result.stdout.splitlines() if line.strip()]
    except (OSError, ValueError, subprocess.SubprocessError):
        raise Refused("Cannot inspect both game containers through " + str(wrapper)) from None
    if len(states) != len(CONTAINERS):
        raise Refused("Both named game containers must exist and be stopped")
    for name, state in zip(CONTAINERS, states):
        if (not isinstance(state, dict) or state.get("Running") is not False or
                state.get("Status") not in ("created", "exited") or
                any(state.get(flag) for flag in ("Paused", "Restarting", "Dead"))):
            raise Refused("Container must be stopped: " + name)


def verify_version(workspace):
    path = workspace / "linux/version-lock.json"
    raw, _ = read_file(path)
    lock = document(raw, path.name)
    if not isinstance(lock, dict) or lock.get("versions", {}).get("SPT") != "4.0.13":
        raise Refused("This helper requires linux/version-lock.json with SPT 4.0.13")


def desired(seasonal, weather):
    seasonal, weather = copy.deepcopy(seasonal), copy.deepcopy(weather)
    try:
        events = seasonal["events"]
        if not isinstance(events, list) or not all(isinstance(event, dict) for event in events):
            raise TypeError
        matches = [event for event in events if event.get("type") == "HALLOWEEN"]
        if len(matches) != 1:
            raise Refused("Expected exactly one HALLOWEEN event entry")
        halloween = matches[0]
        settings = halloween["settings"]
        zombies = settings["zombieSettings"]
        infection = zombies["mapInfectionAmount"]
        if not isinstance(infection, dict) or "overrideSeason" not in weather:
            raise TypeError
        seasonal["enableSeasonalEventDetection"] = True
        for event in events:
            event["enabled"] = event is halloween
        halloween.update(startDay="1", startMonth="1", endDay="31", endMonth="12")
        settings["enableSummoning"] = True
        settings["replaceBotHostility"] = True
        zombies["enabled"] = True
        infection.update(bigmap=50, Interchange=50, sandbox_high=25)
        weather["overrideSeason"] = 1
    except (KeyError, TypeError, AttributeError):
        raise Refused("Unexpected SPT 4.0.13 seasonal/weather configuration shape") from None
    return dict(zip(FILES, (seasonal, weather)))


def atomic_write(path, raw, mode):
    fd, temporary = tempfile.mkstemp(prefix=".halloween-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(raw)
            stream.flush()
            os.fchmod(stream.fileno(), mode)
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        directory_fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def backup(workspace, originals):
    parent = workspace / "linux/backups"
    parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    directory = Path(tempfile.mkdtemp(prefix="halloween-" + stamp + "-", dir=parent))
    rows = {}
    for name, (raw, mode) in originals.items():
        atomic_write(directory / name, raw, 0o600)
        rows[name] = {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw), "mode": mode}
    manifest = {"schemaVersion": 1, "SPT": "4.0.13", "createdAt": stamp, "files": rows}
    atomic_write(directory / "manifest.json", (json.dumps(manifest, indent=2) + "\n").encode(), 0o600)
    return directory


def read_backup(directory):
    if directory.is_symlink() or not directory.is_dir():
        raise Refused("Expected ordinary backup directory: " + str(directory))
    if {path.name for path in directory.iterdir()} != {*FILES, "manifest.json"}:
        raise Refused("Backup must contain only seasonalevents.json, weather.json, and manifest.json")
    raw, _ = read_file(directory / "manifest.json")
    manifest = document(raw, "manifest.json")
    if (not isinstance(manifest, dict) or manifest.get("schemaVersion") != 1 or
            manifest.get("SPT") != "4.0.13" or not isinstance(manifest.get("files"), dict) or
            set(manifest["files"]) != set(FILES)):
        raise Refused("Invalid SPT 4.0.13 backup manifest")
    originals = {}
    for name in FILES:
        raw, _ = read_file(directory / name)
        row = manifest["files"][name]
        if (not isinstance(row, dict) or row.get("bytes") != len(raw) or
                row.get("sha256") != hashlib.sha256(raw).hexdigest() or
                type(row.get("mode")) is not int or not 0 <= row["mode"] <= 0o7777):
            raise Refused("Backup hash or metadata mismatch: " + str(directory / name))
        originals[name] = (raw, row["mode"])
    return originals


def replace_configs(workspace, changes, current):
    config = workspace / "runtime/SPT/SPT_Data/configs"
    require_stopped(workspace)
    for name in FILES:
        if read_file(config / name) != current[name]:
            raise Refused("Configuration changed during the operation: " + str(config / name))
    attempted = []
    try:
        for name in FILES:
            attempted.append(name)
            atomic_write(config / name, *changes[name])
    except BaseException:
        for name in reversed(attempted):
            atomic_write(config / name, *current[name])
        raise


def operate(workspace, restore=None):
    verify_version(workspace)
    require_stopped(workspace)
    config = workspace / "runtime/SPT/SPT_Data/configs"
    current = {name: read_file(config / name) for name in FILES}
    if restore is not None:
        originals = read_backup(restore)
        if originals == current:
            print("Already restored; no files changed.")
            return None
        replace_configs(workspace, originals, current)
        print("Restored raw configuration bytes and modes from: " + str(restore))
        return restore
    documents = [document(current[name][0], name) for name in FILES]
    changed = desired(*documents)
    if all(changed[name] == value for name, value in zip(FILES, documents)):
        print("Halloween/autumn settings already applied; no files changed or backup created.")
        return None
    changes = {name: ((json.dumps(changed[name], indent=2, ensure_ascii=False) + "\n").encode(), current[name][1])
               for name in FILES}
    saved = backup(workspace, current)
    print("Backup: " + str(saved), flush=True)
    replace_configs(workspace, changes, current)
    print("Applied Halloween, zombies, and autumn settings.")
    return saved


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--restore", metavar="BACKUP_DIR", type=Path, help="restore the verified raw backup")
    args = parser.parse_args()
    try:
        operate(WORKSPACE, args.restore.expanduser().absolute() if args.restore is not None else None)
    except (Refused, OSError, subprocess.SubprocessError) as exc:
        print("Refused: " + str(exc), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
