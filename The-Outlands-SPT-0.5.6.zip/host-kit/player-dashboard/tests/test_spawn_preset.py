import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

spec = importlib.util.spec_from_file_location('spawn', Path(__file__).parents[1] / 'ops/spawn_preset.py')
spawn = importlib.util.module_from_spec(spec)
spec.loader.exec_module(spawn)


class SpawnPresetTests(unittest.TestCase):
    def row(self, document, path, expected, value):
        desired = copy.deepcopy(document)
        cursor = desired
        for key in path[:-1]:
            cursor = cursor[key]
        cursor[path[-1]] = value
        return dict(path='SPT/user/mods/zzz-CodexAiPopulationTuning/config/config.json', expectedSemanticSha256=spawn.semantic(document),
                    valueSemanticSha256=spawn.semantic(desired), changes=[dict(path=path, expected=expected, value=value)])

    def test_changes_one_leaf_and_preserves_other_settings(self):
        doc = {'maxBotCap': {'rezervbase': 23, 'default': 18}, 'difficulty': 'unchanged'}
        row = self.row(doc, ['maxBotCap', 'rezervbase'], 23, 27)
        result = spawn.transform(doc, row)
        self.assertEqual(result['maxBotCap'], {'rezervbase': 27, 'default': 18})
        self.assertEqual(result['difficulty'], 'unchanged')
        self.assertEqual(doc['maxBotCap']['rezervbase'], 23)
        self.assertEqual(spawn.transform(result, row), result)

    def test_drift_bad_fingerprint_duplicate_and_bad_expected_are_refused(self):
        doc = {'n': 1, 'unrelated': 'preserve'}
        row = self.row(doc, ['n'], 1, 2)
        for bad in [dict(doc, unrelated='different'), dict(doc, n=3)]:
            with self.assertRaises(ValueError):
                spawn.transform(bad, row)
        for mode in ['hash', 'duplicate', 'expected']:
            bad = copy.deepcopy(row)
            if mode == 'hash': bad['valueSemanticSha256'] = '0' * 64
            elif mode == 'duplicate': bad['changes'] *= 2
            else: bad['changes'][0]['expected'] = 9
            with self.assertRaises(ValueError):
                spawn.transform(doc, bad)

    def test_shipped_preset_only_increases_caps_and_scav_slots(self):
        preset = json.loads(spawn.SOURCE.read_text())
        self.assertEqual(len(preset['caps']), 12)
        self.assertEqual({r['path'] for r in preset['files']}, spawn.TARGETS)
        small = {'factory4_day', 'factory4_night', 'sandbox', 'sandbox_high'}
        for name, row in preset['caps'].items():
            self.assertEqual(row['after'] - row['before'], 2 if name in small else 4)
            self.assertLessEqual(row['after'], 38)
        change = preset['files'][0]['changes'][0]
        self.assertEqual(change['path'], ['Maps'])
        for name, before in change['expected'].items():
            after = change['value'][name]
            self.assertEqual(after['BotMaxAdd'] - before['BotMaxAdd'], 2 if name in small else 4)
            self.assertEqual(after['AssaultWaveSlotAdd'] - before['AssaultWaveSlotAdd'], 1)
            self.assertLessEqual(after['AssaultWaveSlotsMaxCap'], 5)
            self.assertFalse(after['TouchZeroSlotWaves'])
            allowed = {'BotMaxAdd', 'BotMaxCap', 'AssaultWaveSlotAdd', 'AssaultWaveSlotsMaxCap'}
            self.assertEqual({k:v for k,v in before.items() if k not in allowed}, {k:v for k,v in after.items() if k not in allowed})
        self.assertEqual(change['value']['laboratory']['AssaultWaveSlotAdd'], 0)
        self.assertEqual(change['value']['laboratory']['PmcBossChanceAdd'], 0)

    def test_prepare_is_read_only_and_rejects_unknown_targets_and_links(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            doc = {'n': 1}
            rows = [self.row(doc, ['n'], 1, 2)]
            for row, name in zip(rows, sorted(spawn.TARGETS)):
                row['path'] = name
                p = root / name
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(json.dumps(doc))
            preset = dict(schemaVersion=1, files=rows)
            prepared = spawn.prepare(root, preset)
            self.assertEqual(len(prepared), 1)
            self.assertTrue(all(json.loads(p.read_text()) == doc for p in prepared))
            bad = copy.deepcopy(preset)
            bad['files'][0]['path'] = 'SPT/user/profiles/player.json'
            with self.assertRaises(ValueError): spawn.prepare(root, bad)
            p = root / rows[0]['path']
            p.unlink()
            outside = root / 'outside.json'
            outside.write_text(json.dumps(doc))
            p.symlink_to(outside)
            with self.assertRaises(ValueError): spawn.prepare(root, preset)
