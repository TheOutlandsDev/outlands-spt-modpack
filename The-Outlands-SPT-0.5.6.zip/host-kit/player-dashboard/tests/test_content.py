import copy
from datetime import datetime, timezone
import json
from pathlib import Path
import sys
import tempfile
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import app
import content_status

class ContentTests(unittest.TestCase):
    def setUp(self):
        self.now = datetime(2026, 10, 24, 12, tzinfo=timezone.utc)
        day = {'Day': '2026-10-24', 'Theme': 'Outbreak hunt', 'Hotspots': ['woods', 'bigmap']}
        self.raw = {'schemaVersion': 1, 'activeSinceUtc': self.now.isoformat(), 'day': day,
                    'timezone': 'America/New_York', 'rolloverHour': 5,
                    'maps': {'sandbox': {'infection': 10, 'hotspot': False, 'botCap': 23}},
                    'nextSevenDays': [dict(day) for _ in range(7)]}

    def test_public_projection_removes_unrelated_data(self):
        self.raw['apiKey'] = 'must-not-leak'
        self.raw['maps']['sandbox']['profileId'] = 'must-not-leak'
        result = content_status.sanitize(self.raw, self.now)
        self.assertNotIn('must-not-leak', json.dumps(result))
        self.assertEqual(result['maps'], {'sandbox': {'infection': 10, 'hotspot': False}})
        self.assertEqual(len(result['nextSevenDays']), 7)

    def test_invalid_calendar_contract_is_refused(self):
        variants = []
        for key, value in [('schemaVersion', 2), ('timezone', 'UTC'), ('rolloverHour', 0),
                           ('nextSevenDays', []), ('maps', {'unknown': {'infection': 5, 'hotspot': True}}),
                           ('activeSinceUtc', '2027-01-01T00:00:00Z'), ('activeSinceUtc', False)]:
            bad = copy.deepcopy(self.raw); bad[key] = value; variants.append(bad)
        for key, value in [('Theme', '<script>'), ('Hotspots', ['woods', 'woods']), ('Day', '2026-02-30')]:
            bad = copy.deepcopy(self.raw); bad['day'][key] = value; variants.append(bad)
        for bad in variants:
            with self.subTest(data=bad), self.assertRaises((ValueError, TypeError)):
                content_status.sanitize(bad, self.now)

    def test_public_api_requires_fresh_bounded_ordinary_projection(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / 'content.json'
            self.assertFalse(app.content_calendar(root, self.now.timestamp())['available'])
            good = content_status.sanitize(self.raw, self.now)
            path.write_text(json.dumps(good))
            self.assertTrue(app.content_calendar(root, self.now.timestamp())['available'])
            self.assertFalse(app.content_calendar(root, self.now.timestamp() + 151)['available'])
            path.write_text('x' * (16 * 1024 + 1))
            self.assertFalse(app.content_calendar(root, self.now.timestamp())['available'])
            path.unlink(); (root / 'other.json').write_text(json.dumps(good)); path.symlink_to(root / 'other.json')
            self.assertFalse(app.content_calendar(root, self.now.timestamp())['available'])

if __name__ == '__main__': unittest.main()
