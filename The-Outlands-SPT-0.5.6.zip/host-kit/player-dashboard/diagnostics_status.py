"""Bounded, identity-free headless metrics projection for the read-only dashboard."""
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import stat
import time

MAPS={'bigmap','factory4_day','factory4_night','interchange','laboratory','labyrinth','lighthouse','rezervbase','sandbox','sandbox_high','shoreline','tarkovstreets','woods'}

def read(path):
    fd=os.open(path,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_NONBLOCK',0))
    with os.fdopen(fd,'rb')as stream:
        info=os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode)or info.st_size>16384:raise ValueError('Invalid metric file')
        raw=stream.read(16385)
    if len(raw)>16384:raise ValueError('Oversized metrics')
    return json.loads(raw)


def normalize(raw,now=None):
    result={'schemaVersion':1,'available':False,'stale':True}
    try:
        if raw.get('schemaVersion')!=1: return result
        stamp=datetime.fromisoformat(raw['checkedAtUtc'].replace('Z','+00:00'))
        if stamp.tzinfo is None or not -15<=(time.time()if now is None else now)-stamp.timestamp()<=60:return result
        performance=raw['performance'];raid=raw['raid']
        if not isinstance(performance,dict)or not isinstance(raid,dict)or type(raid.get('in_raid'))is not bool:return result
        safe_performance={}
        for key,limit in [('fps',1000),('avg_frame_ms',60000),('p95_frame_ms',60000),('max_frame_ms',60000),('hitches_over_50ms',1000000)]:
            value=performance[key]
            if type(value)not in(int,float)or not math.isfinite(value)or not 0<=value<=limit:return result
            safe_performance[key]=round(value,2)
        safe_raid={'in_raid':raid['in_raid'],'available':raid.get('available')is True}
        if raid['in_raid']:
            safe_raid['map']=raid.get('map')if raid.get('map')in MAPS else None
            for key in ['bot_instances_created','registered_bots','alive_bots','active_bots','fda_sleeping_bots','other_inactive_bots','dead_registered_bots','active_bots_with_goal_enemy']:
                value=raid[key]
                if type(value)is not int or not 0<=value<=2048:return result
                safe_raid[key]=value
            safe_raid['sleeping_count_available']=raid.get('sleeping_count_available')is True
            safe_raid['registry_truncated']=raid.get('registry_truncated')is True
        result.update(available=True,stale=False,checkedAtUtc=stamp.astimezone(timezone.utc).isoformat(),performance=safe_performance,raid=safe_raid)
        for key in ['unityErrors','measurementErrors','droppedSnapshots','writerErrors']:
            value=raw.get(key,0)
            if type(value)is not int or not 0<=value<=1000000000:return {'schemaVersion':1,'available':False,'stale':True}
            result[key]=value
        return result
    except (KeyError,ValueError,TypeError,AttributeError,OverflowError):return {'schemaVersion':1,'available':False,'stale':True}


def snapshot(path,now=None):
    try:return normalize(read(path),now)
    except (OSError,ValueError,TypeError):return {'schemaVersion':1,'available':False,'stale':True}
