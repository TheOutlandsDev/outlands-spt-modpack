using System;using System.IO;using System.Linq;using System.Threading.Tasks;using Codex.Diagnostics.Client;
class Program
{
 static int checks;
 static void Must(bool x,string s){if(!x)throw new Exception(s);checks++;}
 static void Main()
 {
  var frames=new FrameWindow();for(int i=0;i<95;i++)frames.Add(.016f);for(int i=0;i<5;i++)frames.Add(.1f);
  var f=(FrameSnapshot)frames.SnapshotAndReset();Must(f.frames==100&&f.hitches_over_50ms==5,"Frame totals/hitches");Must(f.p95_frame_ms==16&&f.max_frame_ms==100,"Nearest-rank p95 and max");Must(Math.Abs(f.fps-49.5)<.1,"Elapsed-frame FPS");
  frames.Add(float.NaN);frames.Add(float.PositiveInfinity);frames.Add(-1);frames.Add(0);Must(((FrameSnapshot)frames.SnapshotAndReset()).frames==0,"Invalid deltas are excluded");
  for(int i=0;i<10000;i++)frames.Add(.001f);f=(FrameSnapshot)frames.SnapshotAndReset();Must(f.frames==10000&&f.percentile_samples==4096,"Percentile storage is bounded without losing frame totals");
  var host=new object();var counter=CreationCounters.For(host);Parallel.For(0,10000,i=>counter.Register((i%50).ToString()));Must(counter.Count==50,"Concurrent bot instance registration deduplicates");Must(CreationCounters.For(new object()).Count==0,"New raids have independent counters");
  string dir=Path.Combine(Path.GetTempPath(),"outlands-metrics-test-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(dir);
  try
  {
   File.WriteAllText(Path.Combine(dir,"samples-0.jsonl"),new string('x',8*1024*1024));
   using(var writer=new BoundedWriter(dir)){writer.Offer(new{schemaVersion=1,raid=new{in_raid=false},performance=f});}
   Must(File.Exists(Path.Combine(dir,"samples-1.jsonl")),"Log rotation bounds history");Must(File.ReadAllText(Path.Combine(dir,"current.json")).Contains("\"schemaVersion\":1"),"Atomic current snapshot");
   using(var writer=new BoundedWriter(dir)){writer.Offer(new{tooLarge=new string('x',20000)});}
   Must(new FileInfo(Path.Combine(dir,"current.json")).Length<16384,"Oversized snapshots cannot replace public input");
  }finally{Directory.Delete(dir,true);}
  Console.WriteLine("PASS: "+checks+" bounded metrics, raid identity, concurrency, writer and retention checks.");
 }
}
