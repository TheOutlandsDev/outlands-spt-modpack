# Bounded headless raid diagnostics 0.3.0

This replaces the existing host-only `codex.diagnostics.client` 0.2.1 DLL at the
same installed path. Humans do not receive this plugin. Its GUID stays in the
headless role, and the matching fixed CRC policy must be regenerated/restarted
with it. Human managed files, base files and release fingerprints are unchanged.

Every five seconds the plugin publishes headless simulation FPS, average/p95/max
frame time, hitches, current bot registry counts, exact membership of
FikaDynamicAI's `_disabledBots` set, other inactive bots and active bots holding a
GoalEnemy. The latter is awareness evidence, not proof of attacks, shots or hits.
A postfix on the frozen `HostGameController.CreateBot` task counts unique
successfully created local bot instances. These are actual client objects rather
than backend-generated profiles, but created instances are not necessarily
active; registry/alive/active counts remain separate. Profile IDs only exist in a
bounded in-memory deduplication set and are never written to diagnostics.

The patch preserves native tasks/results and makes no gameplay changes. Counts
are read on Unity's thread. File IO/JSON serialization runs on a background
thread with a 16-snapshot queue. Percentile storage is capped at 4096 frames per
window; total frames/hitches/max still count all frames. Logs rotate through four
8 MiB files plus one bounded current snapshot under `Logs/OutlandsRaidDiagnostics`.
Old `Logs/CodexDiagnostics` files are untouched. Unity errors are counted without
copying private messages, paths, players or profiles to the dashboard.

The existing host maintenance tick projects an allowlisted, fresh snapshot into
its read-only public-state directory. `/api/diagnostics` revalidates that schema;
unknown/stale/malformed/oversized/symlinked inputs never claim current counts.
The dashboard shows unavailable counts before a raid, rather than inventing zero.
Sleeping count is unavailable if the frozen FDA set cannot be read.

Enable only on headless with `BepInEx/config/codex.diagnostics.client.cfg`:

```ini
[Capture]
Enabled = true
```

Build with the locally pinned game references:

```sh
python3 player-dashboard/mods/raid-diagnostics/build.py --output /tmp/outlands-metrics
```

Tests cover bounded frame statistics, percentile/hitch calculations, independent
raid counters, concurrent registration deduplication, atomic snapshots, log
rotation and oversized-input refusal. Live startup must show the activation log.
Raid-specific counts, FDA sleep/wake transitions, creation callbacks and overhead
under combat still need the next two-player raid. Idle FPS is not a raid benchmark.
