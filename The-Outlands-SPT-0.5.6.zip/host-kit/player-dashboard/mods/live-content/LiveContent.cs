using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using System.Threading.Tasks;
using SPTarkov.DI.Annotations;
using SPTarkov.Reflection.Patching;
using SPTarkov.Server.Core.Models.Eft.Common;
using SPTarkov.Server.Core.Models.External;
using SPTarkov.Server.Core.Models.Spt.Config;
using SPTarkov.Server.Core.Models.Spt.Mod;
using SPTarkov.Server.Core.Models.Utils;
using SPTarkov.Server.Core.Servers;
using SPTarkov.Server.Core.Services;

namespace Outlands.LiveContent;

public record ModMetadata : AbstractModMetadata {
 public override string ModGuid{get;init;}="outlands.live-content";
 public override string Name{get;init;}="Outlands Live Content";
 public override string Author{get;init;}="TheOutlandsDev";
 public override List<string>? Contributors{get;init;}
 public override SemanticVersioning.Version Version{get;init;}=new(1,0,0);
 public override SemanticVersioning.Range SptVersion{get;init;}=new("=4.0.13");
 public override List<string>? Incompatibilities{get;init;}
 public override Dictionary<string,SemanticVersioning.Range>? ModDependencies{get;init;}
 public override string? Url{get;init;}
 public override bool? IsBundleMod{get;init;}=false;
 public override string License{get;init;}="MIT";
}
public sealed class CalendarConfig {
 public int SchemaVersion{get;set;}=1;
 public bool Enabled{get;set;}=true;
 public string TimeZone{get;set;}="America/New_York";
 public int RolloverHour{get;set;}=5;
 public int NormalInfection{get;set;}=15;
 public int GroundZeroInfection{get;set;}=10;
 public int LabInfection{get;set;}=60;
 public int HotspotInfection{get;set;}=30;
 public int MaxCrowdSize{get;set;}=6;
 public int CrowdCooldownSeconds{get;set;}=180;
 public void Validate(){
  if(SchemaVersion!=1||RolloverHour<0||RolloverHour>23||MaxCrowdSize<1||MaxCrowdSize>8||CrowdCooldownSeconds<120||CrowdCooldownSeconds>900)throw new InvalidDataException("Invalid live-content configuration bounds");
  if(new[]{NormalInfection,GroundZeroInfection,LabInfection,HotspotInfection}.Any(v=>v<0||v>75))throw new InvalidDataException("Infection must be 0..75");
  _=TimeZoneInfo.FindSystemTimeZoneById(TimeZone);
 }
}
public sealed record DayPlan(string Day,string Theme,string[] Hotspots,int Infection,int PmcChanceBonus,int BossChanceBonus,double LootMultiplier);
public static class ContentCalendar {
 public static readonly string[] Infected={"infectedAssault","infectedPmc","infectedCivil","infectedLaborant","infectedTagilla"};
 public static readonly string[] Scavs={"assault","marksman","cursedAssault","assaultGroup"};
 public static DayPlan Select(DateTimeOffset utc,CalendarConfig config){
  config.Validate();var local=TimeZoneInfo.ConvertTime(utc,TimeZoneInfo.FindSystemTimeZoneById(config.TimeZone));var day=local.Date.AddDays(local.Hour<config.RolloverHour?-1:0);
  // Weeks rotate map pairs; this is pure calendar state, never a profile/wipe reset.
  var maps=new[]{"bigmap","woods","shoreline","interchange","rezervbase","lighthouse","tarkovstreets"};
  var week=(int)((day-new DateTime(2026,1,5)).TotalDays/7);var offset=((week%7)+7)%7;var d=((int)day.DayOfWeek+6)%7;
  string[] hotspots={maps[(offset+d)%7],maps[(offset+d+3)%7]};
  var themes=new[]{"Supply lanes","Patrol surge","Containment patrol","Smuggler routes","Boss sightings","Outbreak hunt","Recovery runs"};
  var infection=d==5?Math.Min(40,config.HotspotInfection+5):d==6?15:config.HotspotInfection;
  return new(day.ToString("yyyy-MM-dd"),themes[d],hotspots,infection,d==1?5:0,d==4?10:0,d is 0 or 3 or 6?1.03:1.0);
 }
 public static int InfectionFor(string map,DayPlan day,CalendarConfig config){
  map=map.ToLowerInvariant();if(map is "sandbox"or"sandbox_high")return config.GroundZeroInfection;
  if(map=="laboratory")return config.LabInfection;
  return day.Hotspots.Contains(map)?day.Infection:config.NormalInfection;
 }
 public static void TunePmcWaves(IEnumerable<BossLocationSpawn> waves,bool hotspot,DayPlan day){
  foreach(var wave in waves){
   if(wave.BossName is not ("pmcBEAR"or"pmcUSEC"))continue;
   wave.IgnoreMaxBots=false;
   if(hotspot&&day.PmcChanceBonus>0){
    if(wave.BossChance>0)wave.BossChance=Math.Min(100,wave.BossChance.Value+day.PmcChanceBonus);
    if(wave.Time>=180)wave.Time=Math.Max(120,wave.Time.Value-30);
   }
  }
 }
 public static List<AdditionalHostilitySettings> EnsureHostility(IEnumerable<AdditionalHostilitySettings>? existing){
  var list=(existing??Array.Empty<AdditionalHostilitySettings>()).ToList();
  foreach(var role in Scavs){
   var row=list.FirstOrDefault(r=>r.BotRole==role);if(row==null){row=new(){BotRole=role};list.Add(row);}
   row.AlwaysEnemies??=new();row.AlwaysEnemies.UnionWith(Infected);row.AlwaysFriends?.ExceptWith(Infected);row.Neutral?.ExceptWith(Infected);
  }
  foreach(var role in Infected){
   var row=list.FirstOrDefault(r=>r.BotRole==role);if(row==null){row=new(){BotRole=role};list.Add(row);}
   row.AlwaysEnemies??=new();row.AlwaysEnemies.UnionWith(Scavs);row.AlwaysFriends??=new();row.AlwaysFriends.UnionWith(Infected);row.AlwaysFriends.ExceptWith(Scavs);row.Neutral?.ExceptWith(Scavs);
   row.SavagePlayerBehaviour="AlwaysEnemies";row.BearPlayerBehaviour="AlwaysEnemies";row.UsecPlayerBehaviour="AlwaysEnemies";
  }
  return list;
 }
}
[Injectable]
public sealed class LiveContentLoader(DatabaseService database,ConfigServer configs,ISptLogger<LiveContentLoader> logger):IOnWebAppBuildModAsync {
 private bool applied;
 public Task OnWebAppBuildAsync(){LiveContentPatch.Apply=Apply;new LiveContentPatch().Enable();return Task.CompletedTask;}
 public void Apply(){
  if(applied)return;applied=true;
  var directory=Path.GetDirectoryName(typeof(LiveContentLoader).Assembly.Location)!;
  var config=JsonSerializer.Deserialize<CalendarConfig>(File.ReadAllText(Path.Combine(directory,"settings.json")))??throw new InvalidDataException("Missing calendar configuration");config.Validate();if(!config.Enabled)return;
  var day=ContentCalendar.Select(DateTimeOffset.UtcNow,config);var maps=new Dictionary<string,object>();
  var realMaps=new HashSet<string>{"bigmap","woods","shoreline","interchange","rezervbase","lighthouse","tarkovstreets","sandbox","sandbox_high","laboratory","factory4_day","factory4_night"};
  var bossRoles=new HashSet<string>{"bossBully","bossKilla","bossKojaniy","bossGluhar","bossSanitar","bossTagilla","bossKnight","bossBoar","bossKolontay","bossPartisan"};
  var pmcs=configs.GetConfig<PmcConfig>();
  foreach(var (map,waves)in pmcs.CustomPmcWaves)ContentCalendar.TunePmcWaves(waves,day.Hotspots.Contains(map.ToLowerInvariant()),day);
  foreach(var (name,location)in database.GetLocations().GetDictionary()){
   var b=location.Base;if(b==null)continue;var key=(b.Id??name).ToLowerInvariant();if(!realMaps.Contains(key))continue;
   var infection=ContentCalendar.InfectionFor(key,day,config);
   if(b.Events?.Halloween2024!=null){var z=b.Events.Halloween2024;z.InfectionPercentage=infection;z.MaxCrowdAttackSpawnLimit=Math.Min(z.MaxCrowdAttackSpawnLimit??config.MaxCrowdSize,config.MaxCrowdSize);z.CrowdCooldownPerPlayerSec=Math.Max(z.CrowdCooldownPerPlayerSec??0,config.CrowdCooldownSeconds);}
   if(b.BotLocationModifier!=null)b.BotLocationModifier.AdditionalHostilitySettings=ContentCalendar.EnsureHostility(b.BotLocationModifier.AdditionalHostilitySettings);
   var hotspot=day.Hotspots.Contains(key);
   foreach(var spawn in b.BossLocationSpawn??new()){
    if(spawn.BossName!=null&&ContentCalendar.Infected.Contains(spawn.BossName)){
     spawn.BossChance=spawn.BossName=="infectedTagilla"?Math.Min(spawn.BossChance??5,5):Math.Min(spawn.BossChance??infection,infection);spawn.IgnoreMaxBots=false;
    }else if(hotspot&&spawn.BossName is "pmcBEAR"or"pmcUSEC")spawn.BossChance=Math.Min(100,(spawn.BossChance??0)+day.PmcChanceBonus);
    else if(hotspot&&spawn.BossName!=null&&bossRoles.Contains(spawn.BossName))spawn.BossChance=Math.Min(100,(spawn.BossChance??0)+day.BossChanceBonus);
   }
   if(hotspot&&day.LootMultiplier>1){if(b.GlobalLootChanceModifier.HasValue)b.GlobalLootChanceModifier*=day.LootMultiplier;if(b.GlobalLootChanceModifierPvE.HasValue)b.GlobalLootChanceModifierPvE*=day.LootMultiplier;}
   maps[key]=new{infection,hotspot,botCap=b.BotMax,scavWaves=b.Waves?.Count(w=>w.WildSpawnType?.ToString()=="assault")??0,pmcWaves=pmcs.CustomPmcWaves.TryGetValue(key,out var actualPmcWaves)?actualPmcWaves.Count:0,infectedWaves=b.BossLocationSpawn?.Count(w=>w.BossName!=null&&ContentCalendar.Infected.Contains(w.BossName))??0};
  }
  // Keep the displayed infection map consistent with the actual client locations.
  var infectionUi=database.GetGlobals().LocationInfection;
  foreach(var key in infectionUi.Keys.ToArray()){
   var mapped=key.Equals("factory4",StringComparison.OrdinalIgnoreCase)?"factory4_day":key.Equals("Sandbox",StringComparison.OrdinalIgnoreCase)?"sandbox":key.ToLowerInvariant();
   if(realMaps.Contains(mapped))infectionUi[key]=ContentCalendar.InfectionFor(mapped,day,config);
  }
  var status=new{schemaVersion=1,build="SPT 4.0.13 / EFT 0.16.9.40087 / Fika 2.2.5",activeSinceUtc=DateTimeOffset.UtcNow,day,timezone=config.TimeZone,rolloverHour=config.RolloverHour,activation="At server startup after idle daily maintenance; never during a running raid",zombieSafetyClientVersion="1.0.2",nextSevenDays=Enumerable.Range(1,7).Select(i=>ContentCalendar.Select(DateTimeOffset.UtcNow.AddDays(i),config)).ToArray(),maps};
  var target=Path.Combine(directory,"status.json");File.WriteAllText(target+".tmp",JsonSerializer.Serialize(status,new JsonSerializerOptions{WriteIndented=true})+"\n");File.Move(target+".tmp",target,true);
  logger.Success($"[Outlands.LiveContent] {day.Day}: {day.Theme}; hotspots {string.Join(", ",day.Hotspots)}. Exact infection, Scav/infected hostility, bounded crowds and existing bot caps enforced. Active until the next idle restart.");
 }
}
public sealed class LiveContentPatch:AbstractPatch {
 public static Action? Apply;
 protected override MethodBase GetTargetMethod()=>typeof(PostDbLoadService).GetMethod(nameof(PostDbLoadService.PerformPostDbLoadActions))!;
 [PatchPostfix,HarmonyLib.HarmonyPriority(HarmonyLib.Priority.Last)]public static void Postfix()=>Apply?.Invoke();
}
