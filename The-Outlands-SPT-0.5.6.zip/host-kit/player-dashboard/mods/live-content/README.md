# Outlands live content 1.0.0

A server-only calendar pinned to SPT 4.0.13. Halloween stays enabled. Seven daily
themes rotate pairs of hotspot maps; the map pairs shift each week. The active
calendar day rolls at 5 AM America/New_York, including DST. Settings apply once
after post-database processing at server startup. Existing announced maintenance
waits for all raids before restarting, so raids never change theme midway.

| Day | Theme | Hotspot change |
| --- | --- | --- |
| Monday | Supply lanes | Up to 3% extra location loot chance |
| Tuesday | Patrol surge | Existing PMC wave chance +5 points; late waves up to 30 seconds earlier |
| Wednesday | Containment patrol | Normal hotspot infection |
| Thursday | Smuggler routes | Up to 3% extra location loot chance |
| Friday | Boss sightings | Existing named boss chance +10 points |
| Saturday | Outbreak hunt | Hotspot infection 35% |
| Sunday | Recovery runs | Hotspot infection 15%, loot chance +3% |

Normal maps use exactly 15% infection, Ground Zero 10%, Labs 60%, ordinary hotspots
30%. Crowd spawns are capped at six, with at least 180 seconds per-player cooldown.
Infected initial wave chance is capped at the map infection value, infected
Tagilla at 5%; infected waves and generated PMC waves respect existing bot caps. The mod does not add
bot slots, compound wave counts, raise skill/accuracy, reset profiles or grant
money/items. Economy trade prices, existing Flea Simulator repair, trader unlocks
and standard repeatable quests remain intact. These are conservative initial
values; fight pacing still needs real raid measurements.

Scav/infected hostility is explicitly reciprocal, including missing map rows.
The native 4.0.13 hostility helper's discarded Append result is not relied on.
Normal relationships remain intact. Client rules 1.0.2 separately guard Scav
loyalty and revenge; install that matching DLL on clients and the headless host.

Install Outlands.LiveContent.dll and settings.json in
SPT/user/mods/zzz-OutlandsLiveContent/. status.json is generated locally, is not
part of the installation lock, and contains only public calendar data. The
maintenance worker validates and projects it to the read-only player dashboard.
No API for changing settings is exposed. Disable via Enabled:false and restart
at an idle boundary. Removing the mod restores native processing on next start.

Build with build.py --output PATH --test using matching local SPT/Fika references.
Pure calendar/DST/bounds and typed-hostility tests run offline against actual SPT
model types. Use a fresh isolated backend for integration, then a Ground Zero
Scav test (infected kill, friendly-Scav response, extraction/Fence standing) and
a two-player combat test before declaring the experience proven.
