using System;using System.Collections.Generic;using System.Linq;using System.Reflection;using System.Runtime.Loader;using System.Runtime.CompilerServices;
using SPTarkov.Server.Core.Models.Eft.Common;using Outlands.LiveContent;
class Program {
 static int checks;static void Check(bool ok,string label){checks++;if(!ok)throw new Exception(label);}
 static void Main(string[] args){var root=System.IO.Path.Combine(args[0],"runtime","SPT");AssemblyLoadContext.Default.Resolving+=(_,n)=>{var p=System.IO.Path.Combine(root,n.Name+".dll");return System.IO.File.Exists(p)?AssemblyLoadContext.Default.LoadFromAssemblyPath(p):null;};Run();}
 [MethodImpl(MethodImplOptions.NoInlining)]static void Run(){
  var c=new CalendarConfig();
  foreach(var stamp in new[]{"2026-03-08T08:59:59Z","2026-11-01T09:59:59Z","2026-10-24T08:59:59Z"}){
   var utc=DateTimeOffset.Parse(stamp);var a=ContentCalendar.Select(utc,c);var b=ContentCalendar.Select(utc.AddSeconds(1),c);
   Check(DateTime.Parse(b.Day)==DateTime.Parse(a.Day).AddDays(1),stamp+" rollover/DST");
  }
  var first=DateTimeOffset.Parse("2026-01-01T12:00:00Z");var themes=new HashSet<string>();var hotspotMaps=new HashSet<string>();
  for(int i=0;i<370;i++){
   var now=first.AddDays(i);var a=ContentCalendar.Select(now,c);var b=ContentCalendar.Select(now,c);themes.Add(a.Theme);hotspotMaps.UnionWith(a.Hotspots);
   Check(a.Day==b.Day&&a.Theme==b.Theme&&a.Hotspots.SequenceEqual(b.Hotspots),"deterministic schedule");
   Check(a.Hotspots.Length==2&&a.Hotspots.Distinct().Count()==2,"two distinct hotspots");
   Check(a.LootMultiplier>=1&&a.LootMultiplier<=1.03&&a.BossChanceBonus<=10&&a.PmcChanceBonus<=5,"bounded event bonuses");
   Check(ContentCalendar.InfectionFor("Sandbox",a,c)==10&&ContentCalendar.InfectionFor("sandbox_high",a,c)==10,"beginner map protection");
   Check(ContentCalendar.InfectionFor("laboratory",a,c)==60,"lab infection");
  }
  Check(themes.Count==7&&hotspotMaps.Count==7,"full theme/map rotation");
  var ordinary=new AdditionalHostilitySettings{BotRole="assault",AlwaysEnemies=new(){"pmcBEAR"},AlwaysFriends=new(){"infectedAssault","assault"},Neutral=new(){"infectedCivil"},SavagePlayerBehaviour="Neutral"};
  var rows=ContentCalendar.EnsureHostility(new[]{ordinary});Check(rows.Count==9,"missing rows added and retained");
  foreach(var scav in ContentCalendar.Scavs){var r=rows.Single(x=>x.BotRole==scav);Check(ContentCalendar.Infected.All(x=>r.AlwaysEnemies!.Contains(x)),"scav targets all infected");Check(r.AlwaysFriends==null||!ContentCalendar.Infected.Any(r.AlwaysFriends.Contains),"no infected friends");}
  Check(ordinary.AlwaysEnemies!.Contains("pmcBEAR")&&ordinary.SavagePlayerBehaviour=="Neutral"&&ordinary.AlwaysFriends!.Contains("assault"),"ordinary relationships retained");
  foreach(var role in ContentCalendar.Infected){var r=rows.Single(x=>x.BotRole==role);Check(ContentCalendar.Scavs.All(x=>r.AlwaysEnemies!.Contains(x)),"infected targets scavs");Check(r.SavagePlayerBehaviour=="AlwaysEnemies"&&r.AlwaysFriends!.SetEquals(ContentCalendar.Infected),"infected hostility and own faction");}
  var again=ContentCalendar.EnsureHostility(rows);Check(again.Count==rows.Count&&again.All(r=>r.AlwaysEnemies!.Count==rows.Single(x=>x.BotRole==r.BotRole).AlwaysEnemies!.Count),"idempotent hostility");
  var patrol=new DayPlan("2026-10-27","Patrol surge",new[]{"woods","bigmap"},30,5,0,1);
  var waves=new[]{new BossLocationSpawn{BossName="pmcUSEC",BossChance=80,Time=300,IgnoreMaxBots=true},new BossLocationSpawn{BossName="pmcBEAR",BossChance=100,Time=30,IgnoreMaxBots=true},new BossLocationSpawn{BossName="pmcUSEC",BossChance=0,Time=300,IgnoreMaxBots=true},new BossLocationSpawn{BossName="bossBully",BossChance=50,Time=300,IgnoreMaxBots=true}};
  ContentCalendar.TunePmcWaves(waves,true,patrol);
  Check(waves[0].BossChance==85&&waves[0].Time==270&&waves[0].IgnoreMaxBots==false,"patrol tunes generated PMC waves and respects cap");
  Check(waves[1].BossChance==100&&waves[1].Time==30,"guaranteed/early patrol unchanged");
  Check(waves[2].BossChance==0,"disabled PMC wave stays disabled");
  Check(waves[3].BossChance==50&&waves[3].Time==300&&waves[3].IgnoreMaxBots==true,"non-PMC wave unaffected");
  var normal=new BossLocationSpawn{BossName="pmcUSEC",BossChance=50,Time=300,IgnoreMaxBots=true};ContentCalendar.TunePmcWaves(new[]{normal},false,patrol);
  Check(normal.BossChance==50&&normal.Time==300&&normal.IgnoreMaxBots==false,"normal map keeps timing/chance and respects cap");
  foreach(var invalid in new[]{new CalendarConfig{NormalInfection=100},new CalendarConfig{MaxCrowdSize=0},new CalendarConfig{CrowdCooldownSeconds=1},new CalendarConfig{RolloverHour=24},new CalendarConfig{SchemaVersion=2}}){bool refused=false;try{invalid.Validate();}catch(System.IO.InvalidDataException){refused=true;}Check(refused,"invalid settings refused");}
  Console.WriteLine(checks+" live content calendar/hostility checks passed.");
 }
}
