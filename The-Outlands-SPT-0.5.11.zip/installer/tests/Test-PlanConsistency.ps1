$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$repository=Split-Path -Parent $root
function Read-Json([string]$Path) {Get-Content -LiteralPath $Path -Raw -Encoding UTF8|ConvertFrom-Json}
function Must([bool]$Condition,[string]$Message) {if(-not $Condition){throw $Message}}
$plan=Read-Json (Join-Path $root 'download-plan.json');$lock=Read-Json (Join-Path $root 'setup-lock.json')
$inventory=Read-Json (Join-Path $repository 'host-kit/player-dashboard/client-pack/inventory.json')
$policy=Read-Json (Join-Path $root 'fixed-plugin-policy.json');$base=@(Read-Json (Join-Path $root 'base-prerequisites.json'))
Must ($policy.schemaVersion -eq 2 -and $policy.releaseFingerprint -cmatch '^[a-f0-9]{64}$') 'Missing release admission fingerprint.'
Must ($plan.version -ceq '0.5.9' -and $lock.version -ceq $plan.version) 'Installer/lock release differs.'
Must (($plan.files|ConvertTo-Json -Depth 100 -Compress) -ceq ($lock.files|ConvertTo-Json -Depth 100 -Compress)) 'Plan and installed lock disagree.'
$files=@{};$sources=@{};$projects=@{}
foreach($source in $plan.sources){Must (-not $sources.ContainsKey($source.id)) 'Duplicate source.';Must ($source.sha256 -cmatch '^[a-f0-9]{64}$' -and ([uri]$source.url).Scheme -ceq 'https') 'Unpinned or insecure source.';$sources[$source.id]=$source}
foreach($project in $plan.builds.projects){Must (-not $projects.ContainsKey($project.id)) 'Duplicate project.';$projects[$project.id]=$project;foreach($id in $project.sources){Must ($sources.ContainsKey($id)) 'Missing source-build input.'}}
foreach($row in $plan.files){
 Must (-not $files.ContainsKey($row.path.ToLowerInvariant())) 'Duplicate/case-colliding file.'
 Must ($row.path -cnotmatch '^/|\\|(^|/)\.\.(/|$)|:' -and $row.sha256 -cmatch '^[a-f0-9]{64}$' -and $row.size -gt 0) 'Unsafe or unpinned target.'
 $files[$row.path.ToLowerInvariant()]=$row
 switch($row.provider.kind){
  'author'{Must ($sources.ContainsKey($row.provider.source)) 'Missing author source.'}
  'source-build'{Must ($projects.ContainsKey($row.provider.project)) 'Missing build project.'}
  'derived'{Must ($row.provider.recipe -ceq 'unique-bot-names' -and $row.provider.newline -ceq 'lf') 'Unsupported derived bytes.'}
  {$_ -in @('settings','bundled-owned','bundled-licensed')}{Must ($row.provider.file -cnotmatch '^/|\\|(^|/)\.\.(/|$)|:') 'Unsafe owner-layer member.'}
  default{throw 'Unresolved/unsupported provider.'}
 }
}
foreach($row in $inventory.managedFiles){$match=$files[$row.path.ToLowerInvariant()];Must ($null -ne $match -and $match.mode -ceq 'client' -and $match.sha256 -ceq $row.sha256 -and $match.size -eq $row.size) 'Managed client file differs from hosted inventory.'}
foreach($row in $inventory.baseFiles){$match=@($base|Where-Object{$_.path -ceq $row.path});Must ($match.Count -eq 1 -and $match[0].sha256 -ceq $row.sha256) 'Updater/installer base dependency differs.'}
$clients=@($plan.files|Where-Object{$_.mode -ceq 'client'})
Must ($inventory.managedFiles.Count -eq 351 -and $inventory.baseFiles.Count -eq 27 -and $clients.Count -eq 356 -and $plan.files.Count -eq 2508) 'Unexpected inventory scope; explicitly recurate/review before changing it.'
foreach($row in $clients){Must ($row.path -cnotmatch '/(?:FikaDynamicAI|CodexDiagnostics)/|Fika\.Headless\.dll$|^SPT/|^BepInEx/config/') 'Host-only files offered to humans.'}
Must ($null -eq $policy.human.required.PSObject.Properties['com.fika.headless'] -and $null -eq $policy.human.required.PSObject.Properties['com.lacyway.fda'] -and $null -eq $policy.human.required.PSObject.Properties['codex.diagnostics.client']) 'Unsafe human role.'
Must ($null -ne $policy.human.required.PSObject.Properties['outlands.remote-quests'] -and $null -ne $policy.headless.required.PSObject.Properties['outlands.remote-quests']) 'Missing accept-only quest role.'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip=[IO.Compression.ZipFile]::OpenRead((Join-Path $root 'owner-layer.zip'))
try {
 foreach($row in @($plan.files|Where-Object{$_.provider.kind -in @('settings','bundled-owned','bundled-licensed')})){
  $entries=@($zip.Entries|Where-Object{$_.FullName -ceq $row.provider.file});Must ($entries.Count -eq 1 -and $entries[0].Length -eq $row.size) 'Missing/duplicate owner-layer file.'
  $stream=$entries[0].Open();$hash=[Security.Cryptography.SHA256]::Create();try{$actual=[BitConverter]::ToString($hash.ComputeHash($stream)).Replace('-','').ToLowerInvariant()}finally{$stream.Dispose();$hash.Dispose()}
  Must ($actual -ceq $row.sha256) 'Owner layer differs from plan.'
 }
}finally{$zip.Dispose()}
$fixed=$files['spt/user/mods/zzz-outlandsclientpackpolicy/policy.json'];Must ((Get-FileHash (Join-Path $root 'fixed-plugin-policy.json') -Algorithm SHA256).Hash.ToLowerInvariant() -ceq $fixed.sha256) 'Server fixed policy differs from installed payload.'
'Matching Client/SelfHost inventory, dependencies, providers, role separation and every owner-layer hash verified.'
