# Attribution and scope

The one bundled third-party DLL is the existing repaired MIT Flea Simulator, with its matching source and full upstream notice. All other third-party mod binaries/assets are fetched from pinned sources or built locally; they are not bundled in this installer. `download-plan.json` lists original author source URLs, pinned release/commit identifiers and hashes. Those authors retain all rights to their downloads. Outlands does not claim their work as its own.

The owner's original three mod projects retain the existing MIT scope in LICENSE and the public repository. Gameplay settings are generated separately from the owner's sanitized configuration. SAIN-derived preset data is attributed to Solarint, ArchangelWTF, DrakiaXYZ and contributors under the MIT license declared on the official mod page: https://sp-mod.com/mod/791/sain-solarints-ai-modifications-full-ai-combat-system-replacement . Author license: https://github.com/ArchangelWTF/SAIN/blob/master/LICENSE .

Copyright (c) 2026 Solarint

MIT permission terms for that configuration data: Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions: The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

SVM, Fika code/art, WTT assets and every other downloaded mod remain governed by their original terms. This downloader does not expand redistribution rights. Never republish the assembled stage/cache as a full pack without separate clearance.

Forge API: https://sp-mod.com/docs/index.html . Fika author releases: https://github.com/project-fika/Fika-Plugin/releases and https://github.com/project-fika/Fika-Server-CSharp/releases .

## Verified archived originals and local builds

WelcomeToThursday / GrooveypenguinX and contributors created WTT Armory and WTT Content Backport. Retained original Backport commits in DetectiveSquirrel and 1azyfox repositories are archive provenance, not authorship claims. Each archive source records its original author, repository and commit. Backport declares MIT; Armory declares CC BY-NC-ND. Author source and license locations are recorded in the download/build plan. The installer does not distribute rebuilt WTT binaries; compilation and declared Windows checkout normalization take place locally.

BetterBackpacks is by Refringe. Its original Forge listing declared MIT. The exact installed client/server files are fetched from the retained public git-metalheadtwink/spt-project-pandora commit identified in download-plan.json. That archive does not contain a separate BetterBackpacks license notice; it is not used as a new license grant. Outlands does not rehost those files.

Microsoft supplies the pinned portable .NET SDK and compiler/runtime reference packages. Other NuGet dependencies keep their package licenses. Their downloads are direct and hash pinned; this ZIP does not redistribute those packages. No author project post-build/deploy commands, third-party package build tasks or analyzers are run.

## Repaired MIT Flea Simulator exception

The existing deployed Flea Simulator 1.2.2 repair is retained byte-for-byte. Its
upstream MIT notice (Copyright (c) 2026 minesettimi) and corresponding repaired
source are included under licensed-source/fleasimulator. The installed DLL's
MIT license is included alongside it in the owner layer. This is the one named
third-party binary exception to this release's download-only payload policy.
Original Outlands modules retain their separate MIT scope. All other authors'
terms remain attached to downloaded dependencies; no retail game/base SPT, saves,
credentials or private connection profiles are included.
