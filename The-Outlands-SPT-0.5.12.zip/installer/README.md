# The Outlands SPT 0.5.12

Requires your own legitimate **SPT 4.0.13 / EFT 0.16.9.40087** installation.
Fika Core is pinned to 2.2.5 and Fika server author release to 2.2.4 (assembly
metadata 2.0.9); headless is pinned to 1.4.13. Public downloads do not grant hosted
access. Request approval at https://discord.gg/cNqhhUdFW.

Run **Start-Outlands.cmd**, then choose Client or SelfHost. The download and
staging cache stays outside the game folder. Downloaded archives and selected
members are length/SHA-256 checked. Five unavailable WTT DLLs compile locally
from pinned unmodified author sources with a portable Microsoft SDK; supply your
compatible game folder when prompted. No global SDK installation is needed.
Source/build hashes and proof are in the included JSON records.

Client installs **356 files**: the hosted human inventory's 351 managed files plus
Fika Core and four mod patchers. It excludes headless, Dynamic AI, diagnostics,
server mods and personal BepInEx preferences. Base SPT, BepInEx and retail EFT
are verified prerequisites; they are not downloaded or silently substituted.

**SelfHost is a dedicated headless/server folder. Use a separate Client folder
to play as a human, even on the same PC.**

SelfHost installs **2,508 files**: the same human client files plus current server
mods, bundles, authored policy modules and headless defaults. It also applies the
12 verified base configuration overrides for autumn/Halloween/zombies. The
original repaired Flea Simulator is preserved. SelfHost operators create their
own accounts, credentials, private networking and maintenance deployment.

Install first previews changes. An applied install requires closed game/launcher/
server processes, verifies payload and dependencies, backs up profiles and every
overwrite candidate, and only then copies files. Exact known obsolete 0.4.0 files
are quarantined into those backups; unknown or modified extra DLLs block the
installation for review. A clean compatible SPT folder is recommended. Never
install into the live BSG EFT folder or overwrite node-01's running deployment.

After installing, use **Verify**. Configure your own connection values using
[PLAYING.md](PLAYING.md). Approved Outlands players obtain a private connection
JSON and updater server profile from the host, then use the Play Outlands shortcut created by a successful Windows Client
installation (or run the included shortcut installer separately). Use that shortcut for subsequent update-and-launch sessions.
A changed base patcher requires rerunning this installer before the updater can
verify it; the updater deliberately cannot rewrite base dependencies.

The installer source is included. Most third-party payloads are fetched directly
from pinned author or reviewed archived sources. The only bundled third-party
DLL is the existing repaired MIT Flea Simulator, with its full upstream license
and matching repaired source under `licensed-source/fleasimulator`. Do not
republish assembled third-party caches/payloads without their authors' terms.

[Validation](VALIDATION.json), [lock](setup-lock.json), [plan](download-plan.json),
[baseline transition](BASELINE-TRANSITION.json), [changes](CHANGES.md),
[attribution](THIRD-PARTY-NOTICES.md). Canonical file checks, idle backend/headless
readiness, and a real shared Ground Zero extraction are separate checks. Windows
shortcut installation, first approved-client update, remote asset delivery and
multiplayer extraction/save persistence remain acceptance tests.

## Scheduled live content

This release includes shared infected-AI safety rules and the server-only content
calendar. Halloween stays on daily; hotspots/theme bonuses change at the 5 AM
Eastern maintenance restart after raids finish. See host-kit/player-dashboard/
mods/live-content/README.md and the player dashboard calendar. Existing 0.5.0
clients can use Play Outlands for the managed update; no second base install is
required. A shared raid still must validate observed Scav behavior and saves.


Remote Quests 1.0.3 includes the existing infected-AI safety rules, remote quest
acceptance with local turn-ins, and the unavailable-insurance-provider screen
guard. The unchanged active human client pack is 2026.10.24.3. Headless
diagnostics 0.4.0, the server-only content calendar, updated spawn/map-cap policy
and 350m Dynamic AI activation range are included in SelfHost. A new installer
version does not itself change the approved player file hashes.

Play Outlands 1.4.0 is the public bootstrap; it contains updater engine 1.2.0.
The maintained private dashboard's configured seven-file shortcut ZIP uses that
same engine and already knows its own host origin. A fresh public bootstrap
requires the approved host's private server-profile.json. Keep all files together.
