# Population and reinforcement update — 0.5.12

AI Population Tuning 0.2.0 raises minimum normal Scav group sizes, strengthens PMC opening patrols and brings enabled reinforcements forward by at most two minutes. Large-map caps gain six; small maps/Labs gain two. Existing matching player files are unchanged. Stop the game/server/headless at an idle boundary, back up, and apply the matching SelfHost DLL/config together.

# Headless animation guard and hitch diagnostics — Client and SelfHost 0.5.9

Outlands Headless Raid Diagnostics 0.4.0 skips cosmetic patrol animation checks
only for Fika headless bots and adds bounded timings around bot loading and
activation. It does not suppress warnings or replace animation callbacks. The
matching SelfHost contains the same DLL and headless plugin
validation policy. Human client files are unchanged: 351 managed files and 27
base pins. Existing matching players continue using Play Outlands.

The earlier large frame hitch occurred near spawning, which establishes timing
correlation rather than a confirmed cause. New timings are intended to identify
which work coincides with another hitch. Animation guard behavior, gunplay and frame
performance still require a new raid; this release does not claim all hitches
are fixed. No spawn, difficulty, economy or player profile changes are included.

The cultist summoning ritual stays disabled. Zombies, Halloween, Scav War,
rotating encounters, loot bonuses and optional squad challenges remain enabled.
See [the current host checks](HOST-FIX-CHECKS.json).

The dated seven-day event/recovery report belongs to 0.5.7. RITUAL-CHECKS.json
belongs to 0.5.8. Those are retained historical evidence; neither full rehearsal
was repeated for this host-only update. Fresh Windows installation and the shared
Ground Zero acceptance test remain pending.

# Ritual disabled — Client and SelfHost 0.5.8

The cultist summoning ritual is disabled. Halloween, infected AI, autumn,
Scav War, rotating hotspots, loot bonuses and optional squad challenges stay
enabled. This changes one base server setting and the host helper default;
the 351 managed client files and 27 base pins stay unchanged. The dashboard
also recognizes Reserve's native `RezervBase` map name in raid diagnostics.

Existing matching players continue using Play Outlands. Independent hosts
stop the game, launcher, server and headless client, back up, then run the
matching SelfHost installer to apply the preset. The installer preserves
verified configuration backups and refuses conflicting custom settings.
See [the narrow release checks](RITUAL-CHECKS.json).

The seven-day event/recovery rehearsal below was performed for 0.5.7 on
2026-10-25. It remains prior-build evidence; the full rehearsal was not repeated
for this one-setting update. The event DLL and calendar settings are unchanged.


# Rotating operations — Client and SelfHost 0.5.7

Outlands Live Content 1.1.0 adds distinct daily encounter pacing, primary and
secondary hotspot operations, four weekly campaign phases, small location loot
chance bonuses and optional squad challenges. Halloween and Scav War stay on.

The main dashboard has an interactive active/seven-day forecast, map briefings,
planned modifiers and actual startup wave-adjustment counts. Forecasts are not
active settings. Challenges are self assessed, with no persistent quest progress,
automatic tracking or extra payouts. Existing engine-managed Scav waves keep
their native timing; only eligible timed later waves can move earlier.

All changes activate once after an idle restart. Current caps, difficulty/aim,
Ground Zero event protection, trader prices and ordinary quest rewards remain.
Primary location loot chance is multiplied by at most 1.05 and secondary by at
most 1.025. Enabled PMC waves gain at most seven chance points, enabled boss
waves at most ten. Disabled waves stay disabled, early waves stay early, no wave
counts or slots are multiplied. The schedule is deterministic in Eastern time,
including DST. Delayed maintenance keeps the active plan until restart.

Matching players keep using Play Outlands: all 351 managed client files and 27
base hashes are unchanged. New players use the complete Client installer.
SelfHost changes one server DLL plus dashboard/maintenance source. Hosts use the
new full SelfHost install for a new installation, or stop at an idle boundary,
back up and deploy the included matching authored event source/DLL and host-kit
source update. Event DLL/settings are now explicitly covered in daily checkpoints.

Calendar/policy checks, read-only API/HTTP tests, maintenance/recovery tests and
an isolated backend startup passed. The live backend/headless restarted and
passed native plugin validation. Real encounter feel, client UI, fresh Windows
installation, extraction/saves and a shared Ground Zero raid still need players.
See host-kit/player-dashboard/mods/live-content/README.md for exact modifiers.

# Raid diagnostics and recovery — 0.5.5

Node-01 runs Outlands Headless Raid Diagnostics 0.3.0. The matching SelfHost
payload includes the same DLL, configuration and native plugin-validation policy.
The Client payload remains 356 installation files, including the unchanged 351
managed files. SelfHost remains 2508 files: 2504 exact hosted hashes plus four
sanitized host identity templates. Supply your own private network/identity values.

The read-only dashboard shows headless frame rate, frame p95, alive/active AI,
FikaDynamicAI sleeping bots, and active bots with a target. Five-second snapshots
also record bot instances created, other inactive bots, dead registered bots and
error counters. A created bot instance is stronger evidence than backend profile
generation but does not establish that a bot is alive and fighting. A target does
not prove shots or attacks. Idle FPS does not predict raid performance. A real
shared raid is still required to validate these measurements and gameplay.

The background writer has a 16-entry queue, 16 KiB snapshot limit and four rotating
8 MiB logs. No player/profile IDs or raw error text are written by these metrics.
No spawn settings, hostility, economy, gameplay or player files changed here.

The host-kit protects Fika's nested server configuration and HTTPS identity in
local daily checkpoints. Manual encryption uses standard OpenPGP AES256, checks
checkpoint integrity and decrypts the envelope before accepting it. Keep the
random recovery key separately on another device or in your password manager.
Never upload the recovery key, plaintext profiles, certificates or private configs
to GitHub. An older checkpoint may have its HTTPS certificate included as a
separate encrypted-envelope member; follow the included recovery instructions.
Cloud copies are manual: no automatic cloud-upload timer is installed.

Verified locally: 56 dashboard/backend tests, 30 maintenance/recovery tests and
10 bounded diagnostics checks. An isolated restored SPT backend passed two cold
starts and returned restored profile data, with networking disabled and no
published ports. Live game containers were untouched by the rehearsal. Headless
plugin validation and fresh idle metrics pass. A physical host reboot, shared
raid performance, Windows insurance UI and two-player release transition remain
pending; these are not claimed as tested.

Use host-kit/player-dashboard/maintenance/encrypted_backup.py --create-key once,
save the key separately, then --prepare-latest for manual backup preparation.
The result is under deployment/backups/outbox. Upload only the .gpg envelope to
your private storage. Restore into a new staging directory with recovery.py;
never point a rehearsal at live profile or game directories. Authored source is
MIT; game prerequisites and third-party dependencies remain separately licensed.

# Client update announcements and release checks — 0.5.4

Whenever a committed server publication changes any of the 351 managed client
paths, sizes or SHA256 hashes, its durable outbox queues this Fika notification:

> Client files changed (version). Finish your current raid, then close Escape
> from Tarkov AND SPT Launcher and run Play Outlands before your next raid.

The dashboard keeps these instructions visible. The existing maintenance worker
retries failed notification delivery; successful delivery is deduplicated. A
routine restart, ZIP transport change or server-only update creates no false
client-update warning. There is no extra Codex monitor or public control endpoint.

Outlands.ClientPackPolicy 1.2.0 records each authenticated session's successful
native Fika DLL report against the current managed-content identity. The private
bounded records survive an unchanged daily restart. Changed client content makes
existing records stale: new headless starts and raid joins are refused with update
instructions until the game starts fresh and validates again. Existing raid
traffic/saves and reconnects to the same active match remain available. Never
publish or redistribute validated-sessions.json; fresh installs start without it.

Play Outlands performs the full managed-file SHA256 verification before launch.
The admission record is not a hash report from a running game's config files, a
cryptographic process identity, or anti-cheat. Manually reopening correct DLLs
with old config files could still pass native Fika checking; always use Play
Outlands. No client is force-closed and no profile data is changed.

Hosts use the included matching policy/owner-layer and authored source. Generate
the fixed policy and preflight downloads before changing a DLL baseline, wait
for all raids to finish, back up, and restart the matched backend/headless pair.
Publish with host-kit/player-dashboard/ops/publish-client-bundle.py; it moves the
release fingerprint before the sync manifest and queues the notice after commit.
The first guard installation requires one fresh game startup because prior
servers did not retain native validation records. See the included policy README.

This is a server/dashboard update: client pack 2026.10.24.3, sync bundle
2026.10.24.4, Remote Quests 1.0.3 and all 351 managed/27 base hashes are unchanged.
Matching existing players close game/launcher and use Play Outlands normally;
new players use the complete Client installer. SelfHost has two changed server
files and the improved host-kit. Client/SelfHost counts remain 356/2508.

Verified: 52 backend/publisher/notice tests, 25 maintenance tests, 49 policy,
real-Harmony callback and frozen-client refusal-contract checks, and isolated
backend startup. Exact Windows update dialog rendering and a release transition
with two human players remain to be tested. The 0.5.3 AI/insurance gameplay checks
remain outstanding where documented; no new combat performance claim is made.

# 0.5.3 — headless bot limits and insurance navigation

The headless host had no MainPlayer, causing SPT 4.0.13 to choose the default
18-bot limit on every map. Outlands.ScavWar 1.1.0 resolves this exact fallback
request using the registered headless session's current Fika match map cap.
Human/named-map calls and missing match state keep their native behavior.
The existing map caps and wave timing remain unchanged.

FikaDynamicAI range is 350 metres, formerly 175, with High scanning and snipers
exempt. More distant fights can continue; actual outdoor performance needs a
raid benchmark. The existing SAIN hearing/sight/accuracy settings stay unchanged.

Outlands Remote Quests 1.0.3 skips the insurance step before constructing its
empty trader dropdown when no insurer is available. It follows the native Next
path and retains map/access-key checks. Available insurers retain normal UI.
No insurance is purchased and no trader flags or profile data are edited.

Client pack 2026.10.24.3 changes one managed DLL. Close the game and launcher,
then use Play Outlands to sync before launching. Base EFT/SPT/Fika dependencies
are unchanged. New players use the complete 0.5.3 Client installer; independent
hosts use its matching SelfHost choice. Both require legitimate game files.

Tests cover real Fika match lookup, real SPT callback patching, native insurance
call sites, navigation with real Harmony, and existing quest/zombie guards.
Windows insurance UI and new outdoor combat pacing still need player testing.

# 0.5.2 — moderate AI spawns and individual-file sync

The existing population-mod settings gain four effective AI slots on larger
maps, two on Factory/Ground Zero, and one regular Scav per eligible wave where
group caps allow. Reserve 30→34, Customs 28→32, Woods 33→37, Ground Zero 17→19.
PMC timing/chances, AI difficulty, boss events, zombies, economy, base SPT configs
and client DLLs are unchanged. See docs/SPAWN-PRESET.md. The one owned server
config is verified by hash and included in the matching SelfHost lock.

The complete package includes Play Outlands 1.4.0 for individual-file sync.
Client baseline remains 2026.10.24.2 with 351 managed and 27 verified base files.
Existing matching clients need no new DLLs; relaunch after activation to refresh
cached raid settings. Activation waits for all raids, backs up state, and restarts
the original containers. Real raid performance after the increase needs testing.

# 0.5.1 — scheduled content and infected AI safety

Client managed baseline 2026.10.24.2 retains the same 351 paths and 27 base
contracts. Remote Quests 1.0.2 adds exact infected-role loyalty/revenge guards.
The fixed validator now accepts required shared rules on the headless role:
41 human and 44 headless plugins are required. The host can no longer omit the
shared zombie guard. Both scopes still refuse extra, missing or changed DLLs.

SelfHost adds Outlands Live Content DLL and reviewed settings (2508 files total).
The module schedules seven themes/weekly-shifting hotspots after idle maintenance.
It normalizes infection and reciprocal Scav/infected hostility on all 12 map
variants, limits crowds, keeps existing bot caps, and makes generated PMC waves
respect those caps. Ground Zero remains lightly infected. Economy modifiers
are capped at 3% location loot chance; profiles/trade prices are not reset.

0.5.0 clients receive the managed change by using Play Outlands. New players and
pre-0.5 users run the complete 0.5.1 Client installer once for the matching WTT
base patcher. The public bootstrap policy is unchanged at 1.3.0.

# 0.5.1 — hosted baseline alignment

Client and SelfHost share one canonical lock. Client installs 351 managed plugin,
asset and local gameplay files, Fika Core and four author patchers (356 files).
The updater verifies those 351 managed files and 27 base dependencies separately.
SelfHost installs 2,508 mod/configuration files, including the same human client
files, headless-only plugins, fixed role validation, remote quest acceptance with
local turn-ins, Scav War and the existing repaired Flea Simulator.

NarcoNet is placed in its actual client/server roots. The obsolete human plugin
and preset inventory is removed from the new lock. Known exact 0.4.0 leftovers
can be quarantined into verified backups during an applied install; unknown or
modified extra DLLs stop installation. No unrecognized files are deleted.

Raw gameplay settings preserve node-01 bytes. Eleven base configuration leaf
changes reproduce its complete weather/seasonal JSON behavior: autumn, Halloween
and zombies. Host-specific network addresses, API keys and headless accounts
must be configured independently. Profiles, relationship databases, generated
Fika scripts, caches and economy/player state are never distributed.

Five unmodified WTT DLLs are built locally from pinned author sources. Their
common reproducible hashes replace the previous node-01 binaries only during an
idle backed-up activation. The new patcher matches all 13 original methods and
runtime types/attributes, ignoring declaration order. Existing Armory/Backport
source proof files describe the other four builds. This does not establish a
successful new multiplayer playtest.

One repaired MIT Flea Simulator DLL is included with its corresponding repaired
source and the upstream MIT license. Other third-party binaries/assets download
from pinned sources; the installer never supplies retail game or base SPT files.
