#requires -Version 5.1
<#
Updates only the locally approved Outlands client files in an existing SPT install.
No elevated privileges, GitHub credentials, game download, or profile editing.
#>
[CmdletBinding()]
param(
    [Parameter(Position = 0)][string]$GamePath,
    [ValidateSet('Update', 'Status', 'Repair')][string]$Mode = 'Update',
    [switch]$Launch
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$script:Origin = ''
$script:ManifestPath = '/downloads/client-sync-manifest.json'
$script:Targets = @()
$script:BaseFiles = @()
# Historical permissions are retained for rollback only, never for new pack writes.
$script:LegacyRecoveryPaths = @(
    'BepInEx/plugins/OutlandsRemoteQuests/Outlands.RemoteQuests.dll',
    'BepInEx/plugins/OutlandsRemoteQuests/INSTALL.txt'
)
$script:Compatibility = @{
    'EscapeFromTarkov_Data/Managed/Assembly-CSharp.dll' = 'faef6f0b9f142f9d047495ec3dccfd5d6974ac048368dc7045955cf54b117982'
    'BepInEx/plugins/spt/spt-core.dll' = '2b223747ec8e6b84947d96aac4ff3875cbdf6e130f0d1932399cfff8d382c4f3'
    'BepInEx/plugins/Fika/Fika.Core.dll' = '6b56f43ac9fe6296537be8fbfe2f78da36da73842540602687ba9baba51f938b'
}
$script:MaxZipBytes = 268435456
$script:MaxExpandedBytes = 536870912
$script:MaxFileBytes = 134217728
$script:MaxManagedFiles = 500
$script:MaxJournalBytes = 1048576
$script:Lock = $null

function Assert-True([bool]$Condition, [string]$Message) {
    if (-not $Condition) { throw $Message }
}

function Assert-Keys($Object, [string[]]$Required, [string[]]$Optional = @()) {
    Assert-True ($null -ne $Object -and $Object -is [pscustomobject]) 'Expected a JSON object.'
    $names = @($Object.PSObject.Properties | ForEach-Object { $_.Name })
    foreach ($key in $Required) { Assert-True ($names -ccontains $key) "Missing manifest field: $key" }
    foreach ($key in $names) { Assert-True (($Required + $Optional) -ccontains $key) "Unknown manifest field: $key" }
}

function Assert-Hash($Value) {
    Assert-True ($Value -is [string] -and $Value -cmatch '^[0-9a-f]{64}$') 'Invalid SHA256 value.'
}

function Assert-Size($Value, [long]$Maximum) {
    Assert-True (($Value -is [int] -or $Value -is [long]) -and $Value -gt 0 -and $Value -le $Maximum) 'Invalid file size.'
}

function Get-BytesHash([byte[]]$Bytes) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($sha.ComputeHash($Bytes)).Replace('-', '').ToLowerInvariant() }
    finally { $sha.Dispose() }
}

function Get-LocalHash([string]$Path) {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Convert-JsonBytes([byte[]]$Bytes) {
    $utf8 = New-Object Text.UTF8Encoding($false, $true)
    return ($utf8.GetString($Bytes) | ConvertFrom-Json)
}

function Test-ServerProfile($Profile) {
    Assert-Keys $Profile @('schemaVersion', 'origin')
    Assert-True (($Profile.schemaVersion -is [int] -or $Profile.schemaVersion -is [long]) -and $Profile.schemaVersion -eq 1) 'Unsupported private server profile.'
    Assert-True ($Profile.origin -is [string] -and $Profile.origin.Length -le 300) 'Invalid private update origin.'
    $uri = $null
    Assert-True ([Uri]::TryCreate($Profile.origin, [UriKind]::Absolute, [ref]$uri)) 'Invalid private update origin.'
    Assert-True ($uri.Scheme -ceq 'https' -and $uri.Host.EndsWith('.ts.net', [StringComparison]::OrdinalIgnoreCase) -and
        [string]::IsNullOrEmpty($uri.UserInfo) -and [string]::IsNullOrEmpty($uri.Query) -and
        [string]::IsNullOrEmpty($uri.Fragment) -and $uri.AbsolutePath -ceq '/' -and
        $uri.GetLeftPart([UriPartial]::Authority) -ceq $Profile.origin.TrimEnd('/')) 'Use the Tailscale HTTPS origin supplied by your approved host.'
    return $uri.GetLeftPart([UriPartial]::Authority)
}

function Initialize-ServerProfile {
    $path = Join-Path $PSScriptRoot 'server-profile.json'
    Assert-RegularFile $path
    Assert-True ((Get-Item -LiteralPath $path).Length -le 4096) 'Private server profile is too large.'
    $script:Origin = Test-ServerProfile (Convert-JsonBytes ([IO.File]::ReadAllBytes($path)))
}

function Get-TrustedBytes([string]$RelativePath, [long]$Maximum) {
    Assert-True ($RelativePath -is [string] -and $RelativePath.StartsWith('/downloads/') -and
        $RelativePath -notmatch '[\\?#\x00-\x20]' -and $RelativePath -notmatch '(^|/)\.\.?(/|$)') 'Unapproved download path.'
    $uri = New-Object Uri($script:Origin + $RelativePath)
    Assert-True ($uri.Scheme -ceq 'https' -and $uri.GetLeftPart([UriPartial]::Authority) -ceq $script:Origin -and
        [string]::IsNullOrEmpty($uri.UserInfo)) 'Download must use the approved private HTTPS origin.'
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $request = [Net.HttpWebRequest]::Create($uri)
    $request.Method = 'GET'
    $request.AllowAutoRedirect = $false
    $request.Proxy = $null
    $request.UseDefaultCredentials = $false
    $request.Credentials = $null
    $request.Timeout = 20000
    $request.ReadWriteTimeout = 20000
    $request.UserAgent = 'OutlandsClientUpdater/1.2.0 PowerShell5.1'
    $response = $null; $stream = $null; $memory = $null
    try {
        $response = $request.GetResponse()
        Assert-True ([int]$response.StatusCode -eq 200) 'Download was refused or redirected; no update was installed.'
        Assert-True ($response.ResponseUri.AbsoluteUri -ceq $uri.AbsoluteUri) 'Download redirect refused.'
        Assert-True ($response.ContentLength -le $Maximum) 'Download exceeds the size limit.'
        $stream = $response.GetResponseStream()
        $memory = New-Object IO.MemoryStream
        $buffer = New-Object byte[] 65536
        $nextProgress = 8388608L
        while (($read = $stream.Read($buffer, 0, $buffer.Length)) -gt 0) {
            Assert-True (($memory.Length + $read) -le $Maximum) 'Download exceeds the size limit.'
            $memory.Write($buffer, 0, $read)
            if ($memory.Length -ge $nextProgress) {
                $percent = if ($response.ContentLength -gt 0) { [Math]::Min(100, [int](100 * $memory.Length / $response.ContentLength)) } else { -1 }
                Write-Progress -Id 21 -Activity 'Downloading the approved client pack' -Status ('{0:N0} MiB received' -f ($memory.Length / 1048576)) -PercentComplete $percent
                $nextProgress += 8388608L
            }
        }
        return ,$memory.ToArray()
    }
    finally {
        Write-Progress -Id 21 -Activity 'Downloading the approved client pack' -Completed
        if ($null -ne $stream) { $stream.Dispose() }
        if ($null -ne $memory) { $memory.Dispose() }
        if ($null -ne $response) { $response.Dispose() }
    }
}

function Assert-SafeRelative([string]$Relative) {
    Assert-True (-not [string]::IsNullOrWhiteSpace($Relative) -and $Relative.Length -lt 180 -and
        -not [IO.Path]::IsPathRooted($Relative) -and $Relative -notmatch '[\\<>:"|?*\x00-\x1f]' -and
        -not $Relative.StartsWith('/') -and -not $Relative.EndsWith('/')) 'Unsafe relative path.'
    foreach ($part in $Relative.Split('/')) {
        Assert-True ($part.Length -gt 0 -and $part -ne '.' -and $part -ne '..' -and
            $part -notmatch '[. ]$' -and $part -notmatch '^(?i:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)') 'Unsafe Windows path segment.'
    }
}

function Get-ChildPath([string]$Root, [string]$Relative) {
    Assert-SafeRelative $Relative
    $full = [IO.Path]::GetFullPath((Join-Path $Root ($Relative.Replace('/', '\'))))
    Assert-True ($full.StartsWith($Root.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) 'Path escapes the selected game folder.'
    Assert-True ($full.Length -lt 248) 'Path is too long for this updater; move SPT to a shorter ordinary folder.'
    return $full
}

function Assert-NoReparse([string]$Path) {
    $cursor = [IO.Path]::GetFullPath($Path)
    while (-not [string]::IsNullOrEmpty($cursor)) {
        if (Test-Path -LiteralPath $cursor) {
            $item = Get-Item -LiteralPath $cursor -Force
            Assert-True (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -eq 0) "Junction/symlink/reparse point refused: $cursor"
        }
        $parent = [IO.Directory]::GetParent($cursor)
        if ($null -eq $parent) { break }
        $cursor = $parent.FullName
    }
}

function Assert-RegularFile([string]$Path) {
    Assert-NoReparse $Path
    Assert-True (Test-Path -LiteralPath $Path -PathType Leaf) "Required file is missing: $Path"
}

function Test-ClientPolicy($Policy) {
    Assert-Keys $Policy @('schemaVersion', 'updaterVersion', 'channel', 'managedPaths', 'baseFiles') @('packageId')
    Assert-True (($Policy.schemaVersion -is [int] -or $Policy.schemaVersion -is [long]) -and
        $Policy.schemaVersion -eq 1 -and $Policy.updaterVersion -ceq '1.1.0' -and $Policy.channel -ceq 'node-01') 'Unsupported local client policy.'
    if (@($Policy.PSObject.Properties.Name) -contains 'packageId') {
        Assert-True ($Policy.packageId -ceq 'outlands-client-pack') 'Wrong local package policy.'
    }
    $paths = @($Policy.managedPaths)
    Assert-True ($paths.Count -gt 0 -and $paths.Count -le $script:MaxManagedFiles) 'Local managed-file policy is empty or too large.'
    $seen = New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($path in $paths) {
        Assert-SafeRelative $path
        Assert-True ($path -is [string] -and $path.StartsWith('BepInEx/plugins/', [StringComparison]::Ordinal) -and $seen.Add($path)) 'Duplicate or non-plugin policy target.'
        Assert-True ($path -notmatch '(?i)\.pdb$|^BepInEx/plugins/(?:spt/|FikaDynamicAI/|CodexDiagnostics/)' -and
            $path -ine 'BepInEx/plugins/Fika/Fika.Core.dll' -and $path -ine 'BepInEx/plugins/Fika/Fika.Headless.dll') 'Base or headless-only files cannot be managed client payloads.'
    }
    $baseFiles = @($Policy.baseFiles)
    Assert-True ($baseFiles.Count -ge 3 -and $baseFiles.Count -le 500) 'Local base-file policy is incomplete or too large.'
    foreach ($file in $baseFiles) {
        Assert-Keys $file @('path', 'sha256')
        Assert-SafeRelative $file.path; Assert-Hash $file.sha256
        Assert-True ($seen.Add($file.path)) 'Duplicate or overlapping base-file policy.'
        $scope = $file.path -cmatch '^(?:EscapeFromTarkov\.exe|EscapeFromTarkov_Data/Managed/Assembly-CSharp\.dll|BepInEx/core/[^/]+\.dll|BepInEx/patchers/(?:[^/]+/)*[^/]+\.dll|BepInEx/plugins/spt/(?:[^/]+/)*[^/]+\.dll|BepInEx/plugins/Fika/Fika\.Core\.dll)$'
        Assert-True $scope 'Unapproved base-file verification path.'
        if ($script:Compatibility.ContainsKey($file.path)) {
            Assert-True ($file.sha256 -ceq $script:Compatibility[$file.path]) 'Local policy cannot override a compiled base-version pin.'
        }
    }
    foreach ($required in $script:Compatibility.Keys) {
        Assert-True (@($baseFiles | Where-Object { $_.path -ceq $required -and $_.sha256 -ceq $script:Compatibility[$required] }).Count -eq 1) 'Compiled base-version pin missing from local policy.'
    }
    $script:Targets = $paths
    $script:BaseFiles = $baseFiles
    return $Policy
}

function Read-ClientPolicy {
    $path = Join-Path $PSScriptRoot 'client-policy.json'
    Assert-RegularFile $path
    Assert-True ((Get-Item -LiteralPath $path).Length -le $script:MaxJournalBytes) 'Local client policy is too large.'
    return (Test-ClientPolicy (Convert-JsonBytes ([IO.File]::ReadAllBytes($path))))
}

function Assert-NoUnexpectedPlugins([string]$Root) {
    $allowed = New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($path in $script:Targets) { if ($path.EndsWith('.dll', [StringComparison]::OrdinalIgnoreCase)) { [void]$allowed.Add($path) } }
    foreach ($file in $script:BaseFiles) { if ($file.path.EndsWith('.dll', [StringComparison]::OrdinalIgnoreCase)) { [void]$allowed.Add($file.path) } }
    $queue = New-Object 'Collections.Generic.Queue[string]'
    foreach ($relative in @('BepInEx/plugins', 'BepInEx/core', 'BepInEx/patchers')) {
        $directory = Get-ChildPath $Root $relative
        Assert-NoReparse $directory
        if (Test-Path -LiteralPath $directory -PathType Container) { $queue.Enqueue($directory) }
        elseif ($relative -ceq 'BepInEx/plugins' -or (Test-Path -LiteralPath $directory)) { throw "Required DLL directory is missing or invalid: $relative" }
    }
    $unexpected = @(); $count = 0
    while ($queue.Count -gt 0) {
        $directory = $queue.Dequeue()
        Assert-NoReparse $directory
        foreach ($item in @(Get-ChildItem -LiteralPath $directory -Force)) {
            $count++
            Assert-True ($count -le 20000) 'Plugin inventory exceeds the safety limit.'
            Assert-NoReparse $item.FullName
            if ($item.PSIsContainer) { $queue.Enqueue($item.FullName) }
            elseif ($item.Extension -ieq '.dll') {
                $relative = $item.FullName.Substring($Root.TrimEnd('\').Length + 1).Replace('\', '/')
                if (-not $allowed.Contains($relative)) { $unexpected += $relative }
            }
        }
    }
    if ($unexpected.Count -gt 0) {
        Write-Host 'Unexpected or headless-only DLLs in BepInEx/plugins, core, or patchers prevent a verified client match:' -ForegroundColor Yellow
        foreach ($path in ($unexpected | Sort-Object)) { Write-Host ('  ' + $path) }
        throw 'Move the listed unapproved DLLs outside BepInEx/plugins, core, and patchers manually, then rerun. No addon files were removed.'
    }
}

function Find-GameFolder([string]$Requested) {
    if (-not [string]::IsNullOrWhiteSpace($Requested)) {
        if (Test-Path -LiteralPath $Requested -PathType Leaf) {
            Assert-True ([IO.Path]::GetFileName($Requested) -ieq 'EscapeFromTarkov.exe') 'Select the SPT folder or its EscapeFromTarkov.exe.'
            $Requested = [IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($Requested))
        }
        $candidate = [IO.Path]::GetFullPath($Requested)
    }
    else {
        $candidates = @($PSScriptRoot, ([IO.Path]::GetDirectoryName($PSScriptRoot)), (Get-Location).ProviderPath)
        $candidate = $null
        foreach ($directory in $candidates) {
            if ($directory -and (Test-Path -LiteralPath (Join-Path $directory 'EscapeFromTarkov.exe') -PathType Leaf)) {
                $candidate = [IO.Path]::GetFullPath($directory); break
            }
        }
        if (-not $candidate) {
            Add-Type -AssemblyName System.Windows.Forms
            $dialog = New-Object Windows.Forms.FolderBrowserDialog
            try {
                $dialog.Description = 'Select your existing matching SPT game folder containing EscapeFromTarkov.exe. Do not select the live BSG installation.'
                $dialog.ShowNewFolderButton = $false
                Assert-True ($dialog.ShowDialog() -eq [Windows.Forms.DialogResult]::OK) 'No SPT folder selected.'
                $candidate = [IO.Path]::GetFullPath($dialog.SelectedPath)
            }
            finally { $dialog.Dispose() }
        }
    }
    $candidate = $candidate.TrimEnd('\')
    Assert-True (Test-Path -LiteralPath $candidate -PathType Container) 'The selected game folder does not exist.'
    Assert-NoReparse $candidate
    Assert-RegularFile (Join-Path $candidate 'EscapeFromTarkov.exe')
    return $candidate
}

function Assert-GameClosed {
    $blocked = @(Get-Process -ErrorAction SilentlyContinue | Where-Object {
        $_.ProcessName -match '^(?i:EscapeFromTarkov|SPT\.Launcher|Aki\.Launcher|BsgLauncher|BsgLauncherUpdater|Fika\.Headless|SPT\.Headless)$'
    })
    Assert-True ($blocked.Count -eq 0) ('Close the game, headless client, and SPT/BSG launchers first: ' + (($blocked | ForEach-Object { $_.ProcessName }) -join ', '))
}

function Test-Manifest($Manifest) {
    Assert-Keys $Manifest @('schemaVersion', 'channel', 'bundleVersion', 'generatedAtUtc', 'compatibility', 'packages') @('maintenance')
    Assert-True (($Manifest.schemaVersion -is [int] -or $Manifest.schemaVersion -is [long]) -and
        $Manifest.schemaVersion -eq 1) 'Unsupported manifest schema.'
    Assert-True ($Manifest.channel -ceq 'node-01') 'Wrong update channel.'
    Assert-True ($Manifest.bundleVersion -is [string] -and $Manifest.bundleVersion -cmatch '^\d{1,4}(?:\.\d{1,4}){2,3}$') 'Invalid bundle version.'
    $stamp = [DateTimeOffset]::MinValue
    Assert-True ([DateTimeOffset]::TryParse([string]$Manifest.generatedAtUtc, [ref]$stamp)) 'Invalid manifest timestamp.'
    Assert-Keys $Manifest.compatibility @('sptVersion', 'eftVersion', 'fikaVersion', 'files')
    Assert-True ($Manifest.compatibility.sptVersion -ceq '4.0.13' -and $Manifest.compatibility.eftVersion -ceq '0.16.9.40087' -and
        $Manifest.compatibility.fikaVersion -ceq '2.2.5') 'This updater requires SPT 4.0.13 / EFT 0.16.9.40087 / Fika 2.2.5.'
    $seen = New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    $compatFiles = @($Manifest.compatibility.files)
    Assert-True ($compatFiles.Count -eq $script:Compatibility.Count) 'Compatibility file list is incomplete.'
    foreach ($file in $compatFiles) {
        Assert-Keys $file @('path', 'sha256')
        Assert-SafeRelative $file.path; Assert-Hash $file.sha256
        Assert-True ($script:Compatibility.ContainsKey($file.path) -and $seen.Add($file.path) -and
            $script:Compatibility[$file.path] -ceq $file.sha256) 'Unapproved or duplicate compatibility contract.'
    }
    Assert-True ($script:Targets.Count -gt 0) 'Load the shipped local client policy before checking the server manifest.'
    Assert-True (@($Manifest.packages).Count -eq 1) 'This updater supports one approved full client pack.'
    $package = @($Manifest.packages)[0]
    Assert-Keys $package @('id', 'version', 'url', 'sha256', 'size', 'files') @('fileTransport')
    if (@($package.PSObject.Properties.Name) -contains 'fileTransport') {
        Assert-True ($package.fileTransport -ceq 'sha256-v1') 'Unsupported individual-file transport.'
    }
    Assert-True ($package.id -ceq 'outlands-client-pack' -and $package.url -ceq '/downloads/outlands-client-pack.zip') 'Unapproved update package.'
    Assert-True ($package.version -is [string] -and $package.version -cmatch '^\d{1,4}\.\d{1,4}\.\d{1,4}(?:\.\d{1,4})?$' -and
        [version]$package.version -gt [version]'0.0.0') 'Unsupported package version.'
    Assert-Hash $package.sha256; Assert-Size $package.size $script:MaxZipBytes
    $seen.Clear(); $expanded = 0L
    Assert-True (@($package.files).Count -eq $script:Targets.Count) 'Managed file list is incomplete.'
    foreach ($file in @($package.files)) {
        Assert-Keys $file @('path', 'sha256', 'size')
        Assert-SafeRelative $file.path; Assert-Hash $file.sha256; Assert-Size $file.size $script:MaxFileBytes
        Assert-True ($script:Targets -ccontains $file.path) "This updater does not approve target: $($file.path)"
        Assert-True ($seen.Add($file.path)) 'Duplicate managed file path.'
        $expanded += [long]$file.size
    }
    Assert-True ($expanded -le $script:MaxExpandedBytes) 'Expanded package is too large.'
    return $package
}

function Test-Compatibility([string]$Root) {
    Write-Host 'Checking installed SPT / EFT / Fika compatibility...'
    foreach ($file in $script:BaseFiles) {
        $path = Get-ChildPath $Root $file.path
        Assert-RegularFile $path
        Assert-True ((Get-LocalHash $path) -ceq $file.sha256) "Base version mismatch: $($file.path). Use the matching SPT client supplied for node-01."
    }
    Write-Host 'Compatible: SPT 4.0.13 / EFT 0.16.9.40087 / Fika 2.2.5.'
}

function Get-ManagedStatus([string]$Root, $Package) {
    $rows = @()
    foreach ($file in @($Package.files)) {
        $path = Get-ChildPath $Root $file.path
        Assert-NoReparse $path
        $ok = $false
        if (Test-Path -LiteralPath $path -PathType Leaf) {
            $item = Get-Item -LiteralPath $path -Force
            $ok = $item.Length -eq $file.size -and (Get-LocalHash $path) -ceq $file.sha256
        }
        elseif (Test-Path -LiteralPath $path) { throw "Managed file path is a directory: $path" }
        $rows += [pscustomobject]@{ path = $file.path; current = $ok }
    }
    return $rows
}

function Read-Package([byte[]]$Bytes, $Package) {
    Assert-True ($Bytes.LongLength -eq $Package.size -and (Get-BytesHash $Bytes) -ceq $Package.sha256) 'ZIP size or SHA256 mismatch.'
    Add-Type -AssemblyName System.IO.Compression
    $input = New-Object IO.MemoryStream(,$Bytes)
    $archive = $null; $payloads = @{}
    try {
        $archive = New-Object IO.Compression.ZipArchive($input, [IO.Compression.ZipArchiveMode]::Read, $false)
        Assert-True ($archive.Entries.Count -eq @($Package.files).Count) 'ZIP contains extra or missing entries.'
        $seen = New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
        $total = 0L
        foreach ($entry in $archive.Entries) {
            Assert-SafeRelative $entry.FullName
            Assert-True ($seen.Add($entry.FullName)) 'ZIP contains duplicate paths.'
            $matches = @($Package.files | Where-Object { $_.path -ceq $entry.FullName })
            Assert-True ($matches.Count -eq 1) 'ZIP contains an unapproved file.'
            # Reject Unix symlinks and Windows reparse attributes in ZIP metadata.
            $attributes = [long]$entry.ExternalAttributes -band 4294967295L
            $unixType = ($attributes -shr 16) -band 61440
            Assert-True (($unixType -eq 0 -or $unixType -eq 32768) -and ($attributes -band 1024) -eq 0) 'ZIP link/reparse entry refused.'
            $spec = $matches[0]
            Assert-True ($entry.Length -eq $spec.size -and $entry.Length -le $script:MaxFileBytes -and
                $entry.CompressedLength -gt 0 -and $entry.Length -le ($entry.CompressedLength * 200)) 'ZIP entry size/compression limit exceeded.'
            $total += $entry.Length
            Assert-True ($total -le $script:MaxExpandedBytes) 'ZIP expanded size limit exceeded.'
            $stream = $entry.Open(); $memory = New-Object IO.MemoryStream
            try {
                $buffer = New-Object byte[] 65536
                while (($read = $stream.Read($buffer, 0, $buffer.Length)) -gt 0) {
                    Assert-True (($memory.Length + $read) -le $spec.size) 'ZIP entry exceeds its declared size.'
                    $memory.Write($buffer, 0, $read)
                }
                $data = $memory.ToArray()
                Assert-True ($data.LongLength -eq $spec.size -and (Get-BytesHash $data) -ceq $spec.sha256) 'Extracted file hash/size mismatch.'
                $payloads[$spec.path] = $data
            }
            finally { $stream.Dispose(); $memory.Dispose() }
        }
    }
    finally { if ($archive) { $archive.Dispose() }; $input.Dispose() }
    return $payloads
}

function Get-ChangedFiles($Package, $Status, [switch]$Repair) {
    $changed = @($Status | Where-Object { -not $_.current } | ForEach-Object { $_.path })
    return @($Package.files | Where-Object { $Repair -or $changed -ccontains $_.path })
}

function Get-SyncPayloads($Package, $Files, [string]$Control) {
    Assert-True (@($Package.PSObject.Properties.Name) -contains 'fileTransport' -and
        $Package.fileTransport -ceq 'sha256-v1') 'This host has not published individual-file sync. Install the matching updater/host release.'
    $cache = Join-Path $Control 'cache'
    Assert-NoReparse $cache
    [IO.Directory]::CreateDirectory($cache) | Out-Null
    Assert-NoReparse $cache
    $payloads = @{}; $index = 0; $downloaded = 0L; $reused = 0
    foreach ($file in @($Files)) {
        Assert-True (@($Package.files | Where-Object { $_.path -ceq $file.path -and $_.sha256 -ceq $file.sha256 -and $_.size -eq $file.size }).Count -eq 1) 'Unapproved file sync request.'
        Assert-Hash $file.sha256
        $cached = Join-Path $cache ($file.sha256 + '.bin')
        Assert-NoReparse $cached
        $data = $null
        if (Test-Path -LiteralPath $cached) {
            Assert-True (Test-Path -LiteralPath $cached -PathType Leaf) 'Cache entry is not an ordinary file.'
            if ((Get-Item -LiteralPath $cached).Length -eq $file.size -and (Get-LocalHash $cached) -ceq $file.sha256) {
                $data = [IO.File]::ReadAllBytes($cached)
                $reused++
            }
            else { Remove-Item -LiteralPath $cached -Force }
        }
        $index++
        Write-Host ('Sync {0}/{1}: {2}' -f $index, @($Files).Count, $file.path)
        if ($null -eq $data) {
            $data = Get-TrustedBytes ('/downloads/client-file-' + $file.sha256 + '.bin') $file.size
            Assert-True ($data.LongLength -eq $file.size -and (Get-BytesHash $data) -ceq $file.sha256) ('Downloaded file hash/size mismatch: ' + $file.path)
            # A verified cache survives an interrupted download/apply, so retrying
            # never needs to transfer completed files again.
            $temporary = Join-Path $cache ([Guid]::NewGuid().ToString('N') + '.tmp')
            try {
                [IO.File]::WriteAllBytes($temporary, $data)
                Assert-NoReparse $cached
                if (Test-Path -LiteralPath $cached) { [IO.File]::Replace($temporary, $cached, [NullString]::Value) }
                else { [IO.File]::Move($temporary, $cached) }
            }
            finally { if (Test-Path -LiteralPath $temporary -PathType Leaf) { Remove-Item -LiteralPath $temporary -Force } }
            $downloaded += $data.LongLength
        }
        Assert-True ($data.LongLength -eq $file.size -and (Get-BytesHash $data) -ceq $file.sha256) 'Cached payload changed while reading; no files installed.'
        $payloads[$file.path] = $data
    }
    Write-Host ('Sync ready: {0} files; {1:N2} MiB downloaded; {2} verified cached files reused.' -f @($Files).Count, ($downloaded / 1048576), $reused)
    return $payloads
}

function Assert-ReleaseCurrent($Package) {
    $latest = Test-Manifest (Convert-JsonBytes (Get-TrustedBytes $script:ManifestPath $script:MaxJournalBytes))
    Assert-True ($latest.version -ceq $Package.version -and $latest.sha256 -ceq $Package.sha256 -and
        $latest.size -eq $Package.size -and
        ($latest.files | ConvertTo-Json -Depth 6 -Compress) -ceq ($Package.files | ConvertTo-Json -Depth 6 -Compress)) 'The server release changed during this check. Run Play Outlands again before launching.'
}

function Write-JsonAtomic([string]$Path, $Value) {
    Assert-NoReparse $Path
    $temporary = $Path + '.new-' + [Guid]::NewGuid().ToString('N')
    try {
        $utf8 = New-Object Text.UTF8Encoding($false)
        [IO.File]::WriteAllText($temporary, (($Value | ConvertTo-Json -Depth 12) + "`n"), $utf8)
        if (Test-Path -LiteralPath $Path -PathType Leaf) { [IO.File]::Replace($temporary, $Path, [NullString]::Value) }
        else { [IO.File]::Move($temporary, $Path) }
    }
    finally { if (Test-Path -LiteralPath $temporary -PathType Leaf) { Remove-Item -LiteralPath $temporary -Force } }
}

function Install-BytesAtomic([string]$Root, [string]$Relative, [byte[]]$Bytes, [string]$Work, [switch]$Recovery) {
    Assert-True (($script:Targets -ccontains $Relative) -or ($Recovery -and ($script:LegacyRecoveryPaths -ccontains $Relative))) 'Unapproved write target.'
    $target = Get-ChildPath $Root $Relative
    Assert-NoReparse $target; Assert-NoReparse $Work
    $parent = [IO.Path]::GetDirectoryName($target)
    [IO.Directory]::CreateDirectory($parent) | Out-Null
    Assert-NoReparse $parent
    $temporary = Join-Path $Work ([Guid]::NewGuid().ToString('N') + '.tmp')
    try {
        [IO.File]::WriteAllBytes($temporary, $Bytes)
        Assert-GameClosed
        Assert-NoReparse $target
        if (Test-Path -LiteralPath $target -PathType Leaf) { [IO.File]::Replace($temporary, $target, [NullString]::Value) }
        else { [IO.File]::Move($temporary, $target) }
    }
    finally { if (Test-Path -LiteralPath $temporary -PathType Leaf) { Remove-Item -LiteralPath $temporary -Force } }
}

function Restore-Transaction([string]$Root, [string]$Backup, $Journal, [string]$Work) {
    Assert-GameClosed
    foreach ($entry in @($Journal.files)) {
        Assert-True (($script:Targets -ccontains $entry.path) -or ($script:LegacyRecoveryPaths -ccontains $entry.path)) 'Recovery journal contains an unapproved target.'
        Assert-Hash $entry.installedSha256
        $target = Get-ChildPath $Root $entry.path
        Assert-NoReparse $target
        $exists = Test-Path -LiteralPath $target -PathType Leaf
        $hash = if ($exists) { Get-LocalHash $target } else { $null }
        # Never undo an unrelated file that appeared before our recorded commit.
        # A crash between atomic replacement and journal persistence is ambiguous:
        # preserve that file; the next package check verifies/reconciles it.
        if (-not $entry.applied) { continue }
        if ($entry.existedBefore -eq $true) {
            Assert-Hash $entry.previousSha256
            Assert-True (-not $exists -or $hash -ceq $entry.previousSha256 -or $hash -ceq $entry.installedSha256) "Recovery stopped because another program changed $($entry.path)."
            $saved = Get-ChildPath $Backup ('files/' + $entry.path)
            Assert-RegularFile $saved
            Assert-True ((Get-LocalHash $saved) -ceq $entry.previousSha256) 'Backup hash mismatch; automatic recovery refused.'
            if ($hash -cne $entry.previousSha256) { Install-BytesAtomic $Root $entry.path ([IO.File]::ReadAllBytes($saved)) $Work -Recovery }
        }
        else {
            Assert-True (-not $exists -or $hash -ceq $entry.installedSha256) "Recovery stopped because another program changed $($entry.path)."
            if ($exists) { Assert-GameClosed; Remove-Item -LiteralPath $target -Force }
        }
    }
    $Journal.status = 'rolled-back'
    Write-JsonAtomic (Join-Path $Backup 'transaction.json') $Journal
}

function Get-PendingTransactions([string]$Control) {
    $backups = Join-Path $Control 'backups'
    Assert-NoReparse $backups
    if (-not (Test-Path -LiteralPath $backups -PathType Container)) { return @() }
    $pending = @()
    foreach ($directory in @(Get-ChildItem -LiteralPath $backups -Directory -Force)) {
        Assert-NoReparse $directory.FullName
        $path = Join-Path $directory.FullName 'transaction.json'
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { continue }
        Assert-RegularFile $path
        Assert-True ((Get-Item -LiteralPath $path).Length -le $script:MaxJournalBytes) 'Recovery journal is too large.'
        $journal = Convert-JsonBytes ([IO.File]::ReadAllBytes($path))
        if ($journal.status -in @('prepared', 'applying')) {
            Assert-Keys $journal @('schemaVersion', 'status', 'createdAtUtc', 'packageVersion', 'files')
            Assert-True ($journal.schemaVersion -eq 1 -and @($journal.files).Count -gt 0 -and
                @($journal.files).Count -le $script:MaxManagedFiles) 'Invalid recovery journal.'
            $seen = New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
            foreach ($entry in @($journal.files)) {
                Assert-Keys $entry @('path', 'existedBefore', 'previousSha256', 'installedSha256', 'applied')
                Assert-True ($entry.existedBefore -is [bool] -and $entry.applied -is [bool] -and
                    (($script:Targets -ccontains $entry.path) -or ($script:LegacyRecoveryPaths -ccontains $entry.path)) -and $seen.Add($entry.path)) 'Unsafe recovery journal.'
                Assert-Hash $entry.installedSha256
                if ($entry.existedBefore) { Assert-Hash $entry.previousSha256 }
            }
            $pending += [pscustomobject]@{ backup = $directory.FullName; journal = $journal }
        }
    }
    return $pending
}

function Save-Receipt([string]$Control, $Manifest, $Package) {
    $receipt = [ordered]@{ schemaVersion = 1; bundleVersion = $Manifest.bundleVersion; packageId = $Package.id;
        packageVersion = $Package.version; checkedAtUtc = [DateTime]::UtcNow.ToString('o'); files = @($Package.files) }
    Write-JsonAtomic (Join-Path $Control 'state.json') $receipt
}

function Invoke-Updater {
    Assert-True ($env:OS -eq 'Windows_NT') 'Run this updater on your Windows SPT player PC.'
    Assert-True ([Environment]::Is64BitOperatingSystem -and [Environment]::Is64BitProcess) 'Use 64-bit Windows PowerShell for the full client pack. Open the supplied CMD entry point.'
    Assert-True (-not ($Mode -eq 'Status' -and $Launch)) 'Status is read-only. Omit -Launch or use -Mode Update.'
    Initialize-ServerProfile
    $policy = Read-ClientPolicy
    $root = Find-GameFolder $GamePath
    Write-Host "SPT folder: $root"
    if ($Mode -ne 'Status') { Assert-GameClosed }
    Test-Compatibility $root
    Assert-NoUnexpectedPlugins $root
    Write-Host 'Checking node-01 over your private Tailscale connection...'
    $manifest = Convert-JsonBytes (Get-TrustedBytes $script:ManifestPath $script:MaxJournalBytes)
    $package = Test-Manifest $manifest
    Write-Host "Latest approved client release: $($package.version) ($($script:Targets.Count) managed files; bundle $($manifest.bundleVersion))."
    if (@($manifest.PSObject.Properties.Name) -contains 'maintenance' -and $manifest.maintenance) {
        $notice = $manifest.maintenance
        if (@($notice.PSObject.Properties.Name) -contains 'message' -and $notice.message -is [string]) {
            Write-Host ('Server notice: ' + $notice.message.Substring(0, [Math]::Min(1000, $notice.message.Length))) -ForegroundColor Yellow
        }
        if (@($notice.PSObject.Properties.Name) -contains 'nextRestartAtUtc' -and $notice.nextRestartAtUtc) {
            $next = [DateTimeOffset]::MinValue
            if ([DateTimeOffset]::TryParse([string]$notice.nextRestartAtUtc, [ref]$next)) { Write-Host ('Next server restart: ' + $next.ToLocalTime().ToString('f')) }
        }
    }
    $control = Get-ChildPath $root '.outlands-client-updater'
    Assert-NoReparse $control
    $pending = @(Get-PendingTransactions $control)
    $status = @(Get-ManagedStatus $root $package)
    foreach ($row in $status) { Write-Host (('  {0}: {1}' -f $(if ($row.current) { 'CURRENT' } else { 'UPDATE NEEDED' }), $row.path)) }
    if ($Mode -eq 'Status') {
        if ($pending.Count -gt 0) { throw 'An interrupted update needs recovery. Close the game and run -Mode Repair.' }
        if (@($status | Where-Object { -not $_.current }).Count -gt 0) { Write-Host 'Run this updater without -Mode Status to install the approved files.'; return 2 }
        Write-Host 'Your managed files match node-01. No files were changed.' -ForegroundColor Green
        return 0
    }

    [IO.Directory]::CreateDirectory($control) | Out-Null
    Assert-NoReparse $control
    $lockPath = Join-Path $control 'update.lock'
    Assert-NoReparse $lockPath
    try { $script:Lock = [IO.File]::Open($lockPath, [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None) }
    catch { throw 'Another updater is running, or this SPT folder is not writable.' }
    $work = Join-Path $control ('work-' + [Guid]::NewGuid().ToString('N'))
    [IO.Directory]::CreateDirectory($work) | Out-Null
    try {
        # Re-read under the updater lock. Recovery never runs in read-only status.
        foreach ($unfinished in @(Get-PendingTransactions $control)) {
            Write-Host "Recovering interrupted update: $($unfinished.backup)" -ForegroundColor Yellow
            Restore-Transaction $root $unfinished.backup $unfinished.journal $work
        }
        $receiptPath = Join-Path $control 'state.json'
        if (Test-Path -LiteralPath $receiptPath -PathType Leaf) {
            Assert-RegularFile $receiptPath
            Assert-True ((Get-Item -LiteralPath $receiptPath).Length -le $script:MaxJournalBytes) 'Installed-version receipt is invalid.'
            $receipt = Convert-JsonBytes ([IO.File]::ReadAllBytes($receiptPath))
            if ($receipt.packageId -ceq 'outlands-remote-quests') { Write-Host 'Upgrading the previous quest-only updater receipt to the full client baseline.' }
            else {
                Assert-True ($receipt.packageId -ceq $package.id -and [version]$receipt.packageVersion -le [version]$package.version) 'Server manifest would downgrade the recorded package; update refused.'
            }
        }
        $status = @(Get-ManagedStatus $root $package)
        if (@($status | Where-Object { -not $_.current }).Count -gt 0 -or $Mode -eq 'Repair') {
            Write-Host 'Synchronizing missing/changed client files from node-01...'
            $changedFiles = @(Get-ChangedFiles $package $status -Repair:($Mode -eq 'Repair'))
            $payloads = Get-SyncPayloads $package $changedFiles $control
            Assert-GameClosed
            $backup = Join-Path (Join-Path $control 'backups') ([DateTime]::UtcNow.ToString('yyyyMMddTHHmmssZ') + '-' + [Guid]::NewGuid().ToString('N'))
            Assert-NoReparse $backup
            [IO.Directory]::CreateDirectory($backup) | Out-Null
            Assert-NoReparse $backup
            $entries = @()
            foreach ($file in $changedFiles) {
                $target = Get-ChildPath $root $file.path
                Assert-NoReparse $target
                $existed = Test-Path -LiteralPath $target -PathType Leaf
                $oldHash = $null
                if ($existed) {
                    Assert-True (((Get-Item -LiteralPath $target -Force).Attributes -band [IO.FileAttributes]::ReadOnly) -eq 0) "Managed file is read-only: $($file.path)"
                    $oldHash = Get-LocalHash $target
                    $saved = Get-ChildPath $backup ('files/' + $file.path)
                    Assert-NoReparse $saved
                    [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($saved)) | Out-Null
                    Assert-NoReparse $saved
                    [IO.File]::Copy($target, $saved, $false)
                    Assert-True ((Get-LocalHash $saved) -ceq $oldHash) 'File changed while creating its backup.'
                }
                $entries += [pscustomobject]@{ path = $file.path; existedBefore = [bool]$existed; previousSha256 = $oldHash; installedSha256 = $file.sha256; applied = $false }
            }
            $journal = [pscustomobject]@{ schemaVersion = 1; status = 'prepared'; createdAtUtc = [DateTime]::UtcNow.ToString('o'); packageVersion = $package.version; files = $entries }
            Write-JsonAtomic (Join-Path $backup 'transaction.json') $journal
            try {
                $journal.status = 'applying'; Write-JsonAtomic (Join-Path $backup 'transaction.json') $journal
                foreach ($entry in $entries) {
                    $target = Get-ChildPath $root $entry.path
                    Assert-NoReparse $target
                    if ($entry.existedBefore) {
                        Assert-True ((Test-Path -LiteralPath $target -PathType Leaf) -and (Get-LocalHash $target) -ceq $entry.previousSha256) 'A managed file changed after backup; update stopped.'
                    }
                    else { Assert-True (-not (Test-Path -LiteralPath $target)) 'A managed path appeared after backup; update stopped.' }
                    Install-BytesAtomic $root $entry.path $payloads[$entry.path] $work
                    $entry.applied = $true
                    Write-JsonAtomic (Join-Path $backup 'transaction.json') $journal
                }
                Assert-True (@(Get-ManagedStatus $root $package | Where-Object { -not $_.current }).Count -eq 0) 'Installed file verification failed.'
                $journal.status = 'committed'; Write-JsonAtomic (Join-Path $backup 'transaction.json') $journal
            }
            catch {
                $failure = $_.Exception.Message
                Write-Host 'Update did not complete. Restoring the previous managed files...' -ForegroundColor Yellow
                try { Restore-Transaction $root $backup $journal $work }
                catch { throw "Update failed: $failure Recovery also needs attention: $($_.Exception.Message) Backup: $backup" }
                throw "Update rolled back: $failure Backup: $backup"
            }
            Write-Host "Verified backup: $backup"
        }
        else { Write-Host 'All managed files already match; no reinstall needed.' }
        try { Save-Receipt $control $manifest $package }
        catch { Write-Warning ('Files are verified, but the local status receipt could not be saved: ' + $_.Exception.Message) }
        Test-Compatibility $root
        Assert-NoUnexpectedPlugins $root
        Assert-True (@(Get-ManagedStatus $root $package | Where-Object { -not $_.current }).Count -eq 0) 'Final managed baseline verification failed.'
        Assert-ReleaseCurrent $package
        Write-Host "MATCH VERIFIED: full human client pack $($package.version). Restart the game after any update." -ForegroundColor Green
        Write-Host 'All approved managed files and pinned base files match; no unapproved plugin, core, or patcher DLLs were found.'
    }
    finally {
        # Only updater-created work files are cleaned; backups are retained.
        if (Test-Path -LiteralPath $work -PathType Container) {
            Assert-NoReparse $work
            foreach ($temporary in @(Get-ChildItem -LiteralPath $work -File -Force)) {
                Assert-NoReparse $temporary.FullName
                if ($temporary.Name -match '^[0-9a-f]{32}\.tmp$') { Remove-Item -LiteralPath $temporary.FullName -Force }
            }
            if (@(Get-ChildItem -LiteralPath $work -Force).Count -eq 0) { [IO.Directory]::Delete($work) }
        }
    }
    if ($Launch) {
        Assert-GameClosed
        Assert-NoUnexpectedPlugins $root
        Assert-ReleaseCurrent $package
        $launcher = Join-Path $root 'SPT.Launcher.exe'
        Assert-RegularFile $launcher
        Write-Host 'Opening your existing SPT Launcher...'
        Start-Process -FilePath $launcher -WorkingDirectory $root | Out-Null
    }
    return 0
}

try { $exitCode = Invoke-Updater; exit ([int]$exitCode) }
catch {
    Write-Host ('Update stopped: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'No game/profile files are downloaded. Keep Tailscale connected and close the game/launchers before retrying.'
    exit 1
}
finally { if ($null -ne $script:Lock) { $script:Lock.Dispose() } }
