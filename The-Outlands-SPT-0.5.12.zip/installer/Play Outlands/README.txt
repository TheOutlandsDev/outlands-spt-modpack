PLAY OUTLANDS PUBLIC 1.4.0 - INDIVIDUAL-FILE SYNC
Updater engine 1.2.0; game baseline 2026.10.24.2 unchanged.
Requires the matching 0.5.0/0.5.1 Client installation (351 managed + 27 base files).
New players and pre-0.5 users install the complete matching Client package first.

1. Request approved access through https://discord.gg/cNqhhUdFW .
2. Connect Tailscale and close the game plus all SPT/BSG launchers.
3. Extract the complete ZIP. Obtain server-profile.json privately from your host,
   place it beside these scripts, and run Install Play Outlands.cmd once. Select
   your modded SPT folder. An existing private profile in the installed updater
   folder can be retained; the installer does not overwrite it.
4. Use the Play Outlands desktop shortcut each time. It checks every required
   managed/base hash, downloads only missing/changed client files, verifies the
   result, and opens your existing SPT Launcher. A failed check blocks launch.

Existing Play Outlands users install this package once to enable individual-file
sync. Ordinary SPT.Launcher.exe alone does not run the updater. No admin rights,
GitHub login, or additional software is required beyond built-in PowerShell.

Downloads come only from your approved host's Tailscale HTTPS origin. The host
publishes fixed approved client copies; clients never read raw game/server paths.
Only changed managed files are replaced, with verified backups and rollback.
Completed downloads are cached by SHA-256 and rechecked before reuse. Retry after
an interruption; completed files do not download again. Repair reinstalls all
managed files using verified cache. This is not partial-byte download resume.

Base EFT/SPT/Fika dependencies are verified, not downloaded or upgraded. Extra
unapproved DLLs block launch and are reported for manual review. Profiles and
personal BepInEx/config preferences are preserved. New managed paths require a
reviewed updater/policy package; approved file contents synchronize automatically.
If a release changes during verification, launch stops and asks you to rerun.

Backups and cache remain under .outlands-client-updater in your SPT folder.
Keep the installed Outlands Client Updater folder. Move/reinstall the shortcut
if your game folder changes. Close all game/launcher processes before updating.
Do not share private profiles, tailnet invitations, credentials or logs publicly.
Windows desktop/first-player execution still needs a real Windows smoke test.
