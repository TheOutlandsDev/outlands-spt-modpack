using SPTarkov.DI.Annotations;
using SPTarkov.Server.Core.DI;
using SPTarkov.Server.Core.Models.Utils;
using SPTarkov.Server.Core.Services;

namespace Codex.PrestigeRequirements;

[Injectable(TypePriority = OnLoadOrder.PostSptModLoader + 1000)]
public sealed class PrestigeRequirementLoader(
    DatabaseService databaseService,
    ISptLogger<PrestigeRequirementLoader> logger) : IOnLoad
{
    public Task OnLoad()
    {
        var prestige = databaseService.GetTemplates().Prestige
            ?? throw new InvalidOperationException("The SPT prestige table was not loaded.");
        var result = PrestigeRequirementTransformer.Configure(prestige);

        logger.Success(
            "[Codex.PrestigeRequirements] Applied update-safe prestige requirements: " +
            $"{result.PrestigeLevels} levels, " +
            $"{result.RubleConditionsUpdated} ruble requirements set to ₽1,000,000,000, " +
            $"{result.SkillConditionsPreserved} skill requirements preserved, " +
            $"{result.RemovedConditions} other requirements removed.");

        return Task.CompletedTask;
    }
}
