using SPTarkov.Server.Core.Models.Eft.Common.Tables;

namespace Codex.PrestigeRequirements;

public static class PrestigeRequirementTransformer
{
    public const string RubleTemplateId = "5449016a4bdc2d6f028b456f";
    public const double RequiredRubles = 1_000_000_000d;

    public static PrestigeTransformResult Configure(Prestige prestige)
    {
        ArgumentNullException.ThrowIfNull(prestige);

        var elements = prestige.Elements
            ?? throw new InvalidOperationException("The prestige table has no elements.");
        if (elements.Count == 0)
        {
            throw new InvalidOperationException("The prestige table is empty.");
        }

        var removedConditions = 0;
        var rubleConditionsUpdated = 0;
        var skillConditionsPreserved = 0;

        foreach (var element in elements)
        {
            var conditions = element.Conditions
                ?? throw new InvalidOperationException(
                    $"Prestige element '{element.Id}' has no conditions.");

            removedConditions += conditions.RemoveAll(condition =>
                !IsSkillCondition(condition) &&
                !IsRubleCondition(condition));

            var rubleConditions = conditions.Where(IsRubleCondition).ToList();
            if (rubleConditions.Count != 1)
            {
                throw new InvalidOperationException(
                    $"Prestige element '{element.Id}' has {rubleConditions.Count} ruble conditions; exactly one is required.");
            }

            rubleConditions[0].Value = RequiredRubles;
            rubleConditionsUpdated++;
            skillConditionsPreserved += conditions.Count(IsSkillCondition);

            if (conditions.Any(condition =>
                    !IsSkillCondition(condition) &&
                    !IsRubleCondition(condition)))
            {
                throw new InvalidOperationException(
                    $"Prestige element '{element.Id}' retained a non-skill, non-ruble condition.");
            }
        }

        return new PrestigeTransformResult(
            elements.Count,
            removedConditions,
            rubleConditionsUpdated,
            skillConditionsPreserved);
    }

    private static bool IsSkillCondition(QuestCondition condition) =>
        string.Equals(
            condition.ConditionType,
            "Skill",
            StringComparison.OrdinalIgnoreCase);

    private static bool IsRubleCondition(QuestCondition condition)
    {
        if (!string.Equals(
                condition.ConditionType,
                "HasItem",
                StringComparison.OrdinalIgnoreCase) ||
            condition.Target is null)
        {
            return false;
        }

        if (condition.Target.IsItem)
        {
            return string.Equals(
                condition.Target.Item,
                RubleTemplateId,
                StringComparison.OrdinalIgnoreCase);
        }

        return condition.Target.IsList &&
               condition.Target.List?.Contains(
                   RubleTemplateId,
                   StringComparer.OrdinalIgnoreCase) == true;
    }
}

public sealed record PrestigeTransformResult(
    int PrestigeLevels,
    int RemovedConditions,
    int RubleConditionsUpdated,
    int SkillConditionsPreserved);
