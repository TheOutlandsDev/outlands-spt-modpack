using SPTarkov.DI.Annotations;
using SPTarkov.Server.Core.DI;
using SPTarkov.Server.Core.Models.Utils;
using SPTarkov.Server.Core.Services;
using SPTarkov.Server.Core.Utils.Cloners;

namespace Codex.MinimalHardcoreProfile;

[Injectable(TypePriority = OnLoadOrder.PostSptModLoader + 1)]
public sealed class HardcoreProfileLoader(
    DatabaseService databaseService,
    ICloner cloner,
    ISptLogger<HardcoreProfileLoader> logger) : IOnLoad
{
    public const string ProfileName = "Hardcore";
    public const string SourceProfileName = "Standard";

    public Task OnLoad()
    {
        var profiles = databaseService.GetProfileTemplates();
        if (profiles.ContainsKey(ProfileName))
        {
            logger.Warning(
                $"[Codex.MinimalHardcoreProfile] Profile template '{ProfileName}' already exists; no template was overwritten.");
            return Task.CompletedTask;
        }

        if (!profiles.TryGetValue(SourceProfileName, out var standard) || standard is null)
        {
            throw new InvalidOperationException(
                $"Required source profile template '{SourceProfileName}' was not found.");
        }

        var hardcore = cloner.Clone(standard);
        var result = HardcoreProfileTransformer.Configure(hardcore);
        profiles.Add(ProfileName, hardcore);

        logger.Success(
            $"[Codex.MinimalHardcoreProfile] Added selectable '{ProfileName}' profile from '{SourceProfileName}': " +
            $"USEC removed {result.Usec.RemovedStashItems} stash items and {result.Usec.RemovedSecureItems} secure-container items; " +
            $"BEAR removed {result.Bear.RemovedStashItems} stash items and {result.Bear.RemovedSecureItems} secure-container items; " +
            "starting trader standing is 0. Existing profiles were not changed.");

        return Task.CompletedTask;
    }
}
