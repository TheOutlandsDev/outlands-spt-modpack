using SPTarkov.Server.Core.Models.Eft.Common.Tables;

namespace Codex.MinimalHardcoreProfile;

public static class HardcoreProfileTransformer
{
    public const string MarkerFlag = "codexMinimalHardcore";
    private const string SecureContainerSlot = "SecuredContainer";

    public static ProfileTransformResult Configure(ProfileSides profile)
    {
        ArgumentNullException.ThrowIfNull(profile);

        profile.DescriptionLocaleKey = "launcher-profile_standard";
        profile.CustomFlags ??= new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
        profile.CustomFlags[MarkerFlag] = true;

        var usec = ConfigureSide(
            profile.Usec ?? throw new InvalidOperationException("USEC source template is missing."),
            "USEC");
        var bear = ConfigureSide(
            profile.Bear ?? throw new InvalidOperationException("BEAR source template is missing."),
            "BEAR");
        return new ProfileTransformResult(usec, bear);
    }

    private static SideTransformResult ConfigureSide(TemplateSide side, string sideName)
    {
        var character = side.Character
            ?? throw new InvalidOperationException($"{sideName} source template has no character.");
        var inventory = character.Inventory
            ?? throw new InvalidOperationException($"{sideName} source template has no inventory.");
        var items = inventory.Items
            ?? throw new InvalidOperationException($"{sideName} source template has no inventory item list.");

        if (inventory.Stash is null || inventory.Equipment is null)
        {
            throw new InvalidOperationException(
                $"{sideName} source template is missing its required stash or equipment root.");
        }

        var stashRoot = inventory.Stash.Value.ToString();
        var equipmentRoot = inventory.Equipment.Value.ToString();
        var itemsByParent = items
            .Where(item => !string.IsNullOrWhiteSpace(item.ParentId))
            .GroupBy(item => item.ParentId!, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(group => group.Key, group => group.ToList(), StringComparer.OrdinalIgnoreCase);

        var stashIds = DescendantIds(stashRoot, itemsByParent);
        var secureRoots = items
            .Where(item =>
                string.Equals(item.ParentId, equipmentRoot, StringComparison.OrdinalIgnoreCase) &&
                string.Equals(item.SlotId, SecureContainerSlot, StringComparison.OrdinalIgnoreCase))
            .Select(item => item.Id.ToString())
            .ToList();

        var secureIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var secureRoot in secureRoots)
        {
            secureIds.Add(secureRoot);
            secureIds.UnionWith(DescendantIds(secureRoot, itemsByParent));
        }

        var removedIds = new HashSet<string>(stashIds, StringComparer.OrdinalIgnoreCase);
        removedIds.UnionWith(secureIds);
        items.RemoveAll(item => removedIds.Contains(item.Id.ToString()));

        inventory.FastPanel = (inventory.FastPanel ?? [])
            .Where(entry => !removedIds.Contains(entry.Value.ToString()))
            .ToDictionary(entry => entry.Key, entry => entry.Value);
        inventory.FavoriteItems = (inventory.FavoriteItems ?? [])
            .Where(id => !removedIds.Contains(id.ToString()))
            .ToList();

        var trader = side.Trader
            ?? throw new InvalidOperationException($"{sideName} source template has no trader settings.");
        trader.InitialStanding ??= new Dictionary<string, double?>(StringComparer.OrdinalIgnoreCase);
        foreach (var key in trader.InitialStanding.Keys.ToList())
        {
            trader.InitialStanding[key] = 0d;
        }

        trader.InitialStanding["default"] = 0d;
        trader.InitialSalesSum = 0;
        trader.InitialLoyaltyLevel ??= [];
        foreach (var traderId in trader.InitialLoyaltyLevel.Keys.ToList())
        {
            trader.InitialLoyaltyLevel[traderId] = 1;
        }

        if (character.TradersInfo is not null)
        {
            foreach (var traderInfo in character.TradersInfo.Values)
            {
                traderInfo.Standing = 0d;
                traderInfo.SalesSum = 0d;
                traderInfo.LoyaltyLevel = 1;
            }
        }

        Validate(side, sideName, stashRoot, equipmentRoot);
        return new SideTransformResult(stashIds.Count, secureIds.Count, items.Count);
    }

    private static HashSet<string> DescendantIds(
        string rootId,
        IReadOnlyDictionary<string, List<Item>> itemsByParent)
    {
        var descendants = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var pending = new Stack<string>();
        pending.Push(rootId);

        while (pending.Count > 0)
        {
            var parentId = pending.Pop();
            if (!itemsByParent.TryGetValue(parentId, out var children))
            {
                continue;
            }

            foreach (var child in children)
            {
                var childId = child.Id.ToString();
                if (descendants.Add(childId))
                {
                    pending.Push(childId);
                }
            }
        }

        return descendants;
    }

    private static void Validate(
        TemplateSide side,
        string sideName,
        string stashRoot,
        string equipmentRoot)
    {
        var items = side.Character?.Inventory?.Items
            ?? throw new InvalidOperationException($"{sideName} transformed inventory is missing.");
        var itemIds = items
            .Select(item => item.Id.ToString())
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        if (!itemIds.Contains(stashRoot) || !itemIds.Contains(equipmentRoot))
        {
            throw new InvalidOperationException(
                $"{sideName} transformation removed a required inventory root.");
        }

        if (items.Any(item => string.Equals(
                item.ParentId,
                stashRoot,
                StringComparison.OrdinalIgnoreCase)))
        {
            throw new InvalidOperationException(
                $"{sideName} transformation left direct items in the stash.");
        }

        if (items.Any(item => string.Equals(
                item.SlotId,
                SecureContainerSlot,
                StringComparison.OrdinalIgnoreCase)))
        {
            throw new InvalidOperationException(
                $"{sideName} transformation left a secured container.");
        }

        var orphan = items.FirstOrDefault(item =>
            !string.IsNullOrWhiteSpace(item.ParentId) &&
            !itemIds.Contains(item.ParentId));
        if (orphan is not null)
        {
            throw new InvalidOperationException(
                $"{sideName} transformation created orphan item {orphan.Id}.");
        }

        var trader = side.Trader;
        if (trader?.InitialStanding is null ||
            trader.InitialStanding.Values.Any(value => value.GetValueOrDefault() != 0d))
        {
            throw new InvalidOperationException(
                $"{sideName} transformation left non-zero starting trader standing.");
        }
    }
}

public sealed record SideTransformResult(
    int RemovedStashItems,
    int RemovedSecureItems,
    int RemainingItems);

public sealed record ProfileTransformResult(
    SideTransformResult Usec,
    SideTransformResult Bear);
