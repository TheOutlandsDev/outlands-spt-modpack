# Additional deployed Outlands source

These authored sources correspond to saved build artifacts matching the deployed
Minimal Hardcore Profile and Prestige Requirements DLLs. The C# source is
unchanged. Project references/output paths were made portable; use your own .NET
9 SDK and SPT 4.0.13 references, for example:

`dotnet build minimal-hardcore/Codex.MinimalHardcoreProfile.csproj -c Release -p:OutlandsSptRoot="C:/YourSPT/SPT"`

A fresh compiler build can have a different hash. The installer uses the reviewed
saved DLL; replacing it requires explicit inventory and policy recuration. The
Minimal Hardcore module adds a selectable edition for new accounts; it never
converts existing profiles. Prestige Requirements adjusts the configured prestige
requirement model. Do not publish referenced SPT/game assemblies or build outputs.
