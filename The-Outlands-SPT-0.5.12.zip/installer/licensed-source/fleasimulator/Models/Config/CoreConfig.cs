using System.Text.Json.Serialization;

namespace FleaSimulator.Models.Config;

public class CoreConfig
{
    [JsonPropertyName("name")] public string Name { get; set; } = "Default Config";
    [JsonPropertyName("author")] public string Author { get; set; } = "minesettimi";
    [JsonPropertyName("buy")] public BuyConfig BuyConfig { get; set; } = new();
    [JsonPropertyName("sell")] public SellConfig SellConfig { get; set; } = new();
    [JsonPropertyName("wipePrices")] public WipePriceConfig WipePrices { get; set; } = new();
    [JsonPropertyName("progressiveFlea")] public ProgressiveConfig ProgressiveFlea { get; set; } = new();
    [JsonPropertyName("updateInterval")] public double UpdateInterval { get; set; } = 60.0;
    [JsonPropertyName("simInterval")] public double SimulationInterval { get; set; } = 60.0;
    [JsonPropertyName("interpSim")] public bool InterpSimulation { get; set; } = true;
    [JsonPropertyName("overrideUnreasonablePrices")] public bool UnreasonablePrices { get; set; } = true;
    [JsonPropertyName("debug")] public bool Debug { get; set; } = false;
    [JsonPropertyName("debugSimulation")] public bool DebugSimulation { get; set; } = false;
    [JsonPropertyName("debugItem")] public string DebugItem { get; set; } = "";
}

public class BuyConfig
{
    [JsonPropertyName("enabled")] public bool Enabled { get; set; } = true;
    [JsonPropertyName("canHaveNoOffers")] public bool CanHaveNoOffers { get; set; } = true;
    [JsonPropertyName("traderPrices")] public bool TraderPrices { get; set; } = false;
    [JsonPropertyName("useHandbook")] public bool UseHandbook { get; set; } = false;
    [JsonPropertyName("enableBarter")] public bool EnableBarter { get; set; } = false;
    [JsonPropertyName("supplyMinOffers")] public int SupplyMinOffers { get; set; } = 2;
    [JsonPropertyName("supplyMaxOffers")] public int SupplyMaxOffers { get; set; } = 20;
    [JsonPropertyName("supplyOfferOffset")] public int SupplyOfferOffset { get; set; } = 1;
    [JsonPropertyName("supplyMinQuantity")] public int SupplyMinQuantity { get; set; } = 1;

    [JsonPropertyName("supplyMaxQuantity")] public int SupplyMaxQuantity { get; set; } = 5;
    //[JsonPropertyName("demandMinSoldChance")] public double DemandMinSoldChance { get; set; } = 0.0;
    //[JsonPropertyName("demandMaxSoldChance")] public double DemandMaxSoldChance { get; set; } = 0.85;
}

public class SellConfig
{
    [JsonPropertyName("enabled")] public bool Enabled { get; set; } = true;

    [JsonPropertyName("supplyMinPosition")] 
    public int SupplyMinPosition { get; set; } = 2;

    [JsonPropertyName("supplyMaxPosition")] 
    public int SupplyMaxPosition { get; set; } = 10;

    [JsonPropertyName("demandMinBuyChance")]
    public double DemandMinBuyChance { get; set; } = 50.0;

    [JsonPropertyName("demandMaxBuyChance")]
    public double DemandMaxBuyChance { get; set; } = 100.0;

    [JsonPropertyName("dealThresholdMult")]
    public double DealThreshold { get; set; } = 0.15;

    [JsonPropertyName("dealChanceIncrease")]
    public double DealChance { get; set; } = 10.0;

    [JsonPropertyName("demandMinDelay")] public int DemandMinDelay { get; set; } = 3600;

    [JsonPropertyName("demandMaxDelay")] public int DemandMaxDelay { get; set; } = 0;
    [JsonPropertyName("demandDelayExp")] public int DemandDelayExp { get; set; } = 4;
    [JsonPropertyName("posDelay")] public int PosDelay { get; set; } = 30;
    [JsonPropertyName("maxSaleAttempts")] public int MaxSaleAttempts { get; set; } = 8;
    [JsonPropertyName("retryIntervalSeconds")] public int RetryIntervalSeconds { get; set; } = 900;
    [JsonPropertyName("saleDiagnostics")] public bool SaleDiagnostics { get; set; } = true;
}

public class WipePriceConfig
{
    [JsonPropertyName("enabled")] public bool Enabled { get; set; } = true;

    [JsonPropertyName("disableAboveLevel")]
    public int DisableLevel { get; set; } = 15;

    [JsonPropertyName("balancedPricing")] public bool BalancedPricing { get; set; } = false;
    [JsonPropertyName("startLength")] public double StartLength { get; set; } = 10.0;
    [JsonPropertyName("earlyQuantityMult")] public double EarlyQuantityMult { get; set; } = 0.5;
}