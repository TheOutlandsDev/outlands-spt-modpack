using SPTarkov.Server.Core.Models.Eft.Ragfair;

namespace FleaSimulator.Utils;

public static class FleaSaleMath
{
    public static double ClampChance(double chance)
    {
        return double.IsFinite(chance) ? Math.Clamp(chance, 0.0, 100.0) : 0.0;
    }

    public static double CalculateQualityModifier(double singleItemPrice, double qualityAdjustedAverage)
    {
        if (!double.IsFinite(singleItemPrice) || !double.IsFinite(qualityAdjustedAverage)
            || singleItemPrice <= 0 || qualityAdjustedAverage <= 0)
        {
            return 1.0;
        }

        // A cheaper item should be easier to sell and a more expensive item harder to sell.
        double modifier = 1.0 + (qualityAdjustedAverage - singleItemPrice) / qualityAdjustedAverage;
        return Math.Clamp(modifier, 0.25, 2.0);
    }

    public static List<SellResult> SortSellResults(IEnumerable<SellResult> results)
    {
        return results.OrderBy(result => result.SellTime ?? long.MaxValue).ToList();
    }

    public static List<int> GetRetryOffsets(int maxAttempts, int retryIntervalSeconds,
        long currentTimestamp, long? offerEndTime)
    {
        List<int> offsets = [];
        int attempts = Math.Clamp(maxAttempts, 1, 48);
        int interval = Math.Clamp(retryIntervalSeconds, 60, 3600);

        for (int attempt = 0; attempt < attempts; attempt++)
        {
            int offset = checked(attempt * interval);
            if (offerEndTime.HasValue && currentTimestamp + offset >= offerEndTime.Value)
                break;

            offsets.Add(offset);
        }

        return offsets;
    }
}