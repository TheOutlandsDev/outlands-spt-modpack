using SPTarkov.DI.Annotations;

namespace FleaSimulator.Utils;

[Injectable(InjectionType.Singleton)]
public class FleaMathUtil
{
    //functions like MapToRange but the values use an exponential curve
    public double MapToRangeExp(double x, double minIn, double maxIn, double minOut, double maxOut, int exp)
    {
        double difIn = maxIn - minIn;
        double difOut = maxOut - minOut;

        if (Math.Abs(difIn) < double.Epsilon)
            return Math.Clamp(minOut, Math.Min(minOut, maxOut), Math.Max(minOut, maxOut));

        double scale = Math.Clamp((x - minIn) / difIn, 0.0, 1.0);

        scale = Math.Pow(scale, Math.Max(exp, 1));
        
        return Math.Clamp(minOut + scale * difOut, Math.Min(minOut, maxOut), Math.Max(minOut, maxOut));
    }

    public double MapToRangeExp(double x, double minOut, double maxOut, int exp)
    {
        return MapToRangeExp(x, 0, 1, minOut, maxOut, exp);
    }
}