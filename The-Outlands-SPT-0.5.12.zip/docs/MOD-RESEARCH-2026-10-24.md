# Frozen-build content review — October 24, 2026

Target stays SPT 4.0.13 / EFT 0.16.9.40087 / Fika client 2.2.5, server 2.2.4,
headless 1.4.13. Author compatibility claims are candidate evidence, not an
integration test of this exact mod stack. Nothing follows floating latest URLs
or upgrades the game/server automatically.

| Candidate | Evidence reviewed | Decision for this release |
| --- | --- | --- |
| [Dynamic Raid Events 0.3.0-beta](https://sp-mod.com/mod/2842/dynamic-raid-events) | Author declares SPT 4.0.13 and tested Fika; server-side random boss/raider/cultist/loot events; [source](https://github.com/CobraSnipper/DynamicRaidEvents) | Do not stack another spawn/loot event engine over the new calendar before multiplayer validation. Its features informed the review; its code/binary is not installed or copied. |
| [Quests Extended 5.0.0](https://sp-mod.com/mod/2106/completed-fika-quests-extended) | Author declares SPT 4.0.13 and Fika multi-choice/per-player progression; [source](https://github.com/Light-of-the-World/QuestsExtended) | Promising future custom quest-condition foundation. It is not itself a ready-made quest campaign. Exact 2.2.5 API, NarcoNet/trader gating, progression and profile migration need isolated testing before adoption. Not installed. |
| [Questing Bots](https://sp-mod.com/mod/1109/questing-bots) | Latest author listing is 1.2.0 for SPT 4.1.6 and newer Waypoints/BigBrain | Reject latest for this frozen build. A historical compatible version would need a separate version-pinned AI-stack and headless review. Not installed. |
| [ZSlayer Zombies](https://github.com/ZSlayerHQ/ZSlayerZombies) / [Roaming Zombies](https://github.com/Vonbraunz/SPT-Roaming-Zombies) | Author sources provide zombie event/wave systems | Overlap with active native Halloween infection and the Outlands calendar; no second zombie spawn owner is installed. |

This release adds original Outlands content instead: seven scheduled daily
modifiers, weekly-shifting hotspots, controlled infection/crowds and a player
calendar. Existing WTT content, Labyrinth, NarcoNet progression, Scav War and
repeatable quests stay in place. No unreviewed third-party campaign, trader,
item bundle, overlapping AI spawner or permanent profile migration is added.

Future additions should have a pinned version, original download/source digest,
license/provenance, isolated backend startup, client/headless role policy and
updater package in the same release. Test with copied disposable profiles before
adopting content that adds trader/quest/item IDs; only then use an idle cutover.
