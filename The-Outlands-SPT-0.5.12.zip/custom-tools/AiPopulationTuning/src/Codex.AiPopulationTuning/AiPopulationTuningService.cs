using SPTarkov.DI.Annotations;
using SPTarkov.Server.Core.Models.Eft.Common;
using SPTarkov.Server.Core.Services;
using SPTarkov.Server.Core.Models.Spt.Config;
using SPTarkov.Server.Core.Servers;
using SPTarkov.Server.Core.Utils.Logger;
using System.Reflection;
using System.Text.Json;

namespace Codex.AiPopulationTuning;

[Injectable]
public sealed class AiPopulationTuningService(
    DatabaseService databaseService,
    ConfigServer configServer,
    SptLogger<AiPopulationTuningService> logger)
{
    private bool applied;

    public void Apply()
    {
        if (applied)
        {
            return;
        }

        applied = true;

        try
        {
            var config = LoadConfig();
            if (!config.Enabled)
            {
                logger.Info("Codex AI Population Tuning is disabled by config.", null);
                return;
            }

            var excludedMaps = BuildNormalizedSet(config.ExcludedMaps);
            var locations = databaseService.GetLocations().GetDictionary();
            var totalMapChanges = 0;
            var totalWaveChanges = 0;
            var totalPmcChanges = 0;

            var tunedPmcWaves = new HashSet<BossLocationSpawn>(ReferenceEqualityComparer.Instance);
            if (config.TunePmcWaves)
            {
                foreach (var (key, waves) in configServer.GetConfig<PmcConfig>().CustomPmcWaves)
                {
                    if (config.Maps.TryGetValue(key, out var tuning) && tuning.Enabled
                        && !excludedMaps.Contains(Normalize(key)))
                    {
                        totalPmcChanges += TunePmcWaves(waves.Where(w => tunedPmcWaves.Add(w)), tuning);
                    }
                }
            }

            foreach (var (key, location) in locations)
            {
                var locationBase = location.Base;
                if (locationBase is null)
                {
                    continue;
                }

                if (IsExcludedMap(key, locationBase, excludedMaps))
                {
                    continue;
                }

                if (!TryGetMapConfig(config, key, locationBase, out var mapConfig) || !mapConfig.Enabled)
                {
                    continue;
                }

                var result = ApplyMapTuning(key, locationBase, mapConfig, config, tunedPmcWaves);
                totalMapChanges += result.MapFieldChanges;
                totalWaveChanges += result.NormalWaveChanges;
                totalPmcChanges += result.PmcWaveChanges;

                if (config.LogMapDetails && result.HasChanges)
                {
                    logger.Info(
                        "Codex AI tuning " +
                        $"{key}: map fields {result.MapFieldChanges}, normal waves {result.NormalWaveChanges}, " +
                        $"PMC waves {result.PmcWaveChanges}.",
                        null);
                }
            }

            logger.Success(
                "Codex AI Population Tuning applied: " +
                $"{totalMapChanges} map field changes, {totalWaveChanges} normal scav wave changes, " +
                $"{totalPmcChanges} PMC wave chance changes.",
                null);
        }
        catch (Exception ex)
        {
            logger.Error("Codex AI Population Tuning failed while applying spawn settings.", ex);
        }
    }

    private TuningResult ApplyMapTuning(
        string mapKey,
        LocationBase locationBase,
        MapPopulationTuning mapConfig,
        AiPopulationTuningConfig config, HashSet<BossLocationSpawn> tunedPmcWaves)
    {
        var result = new TuningResult();

        if (mapConfig.BotMaxAdd > 0)
        {
            var target = locationBase.BotMax + mapConfig.BotMaxAdd;
            if (mapConfig.BotMaxCap.HasValue)
            {
                target = Math.Min(target, mapConfig.BotMaxCap.Value);
            }

            if (target > locationBase.BotMax)
            {
                locationBase.BotMax = target;
                result.MapFieldChanges++;
            }
        }

        if (mapConfig.BotStartMaxSeconds.HasValue
            && locationBase.BotStart > mapConfig.BotStartMaxSeconds.Value)
        {
            locationBase.BotStart = mapConfig.BotStartMaxSeconds.Value;
            result.MapFieldChanges++;
        }

        if (mapConfig.BotSpawnCountStepMax.HasValue
            && locationBase.BotSpawnCountStep.HasValue
            && locationBase.BotSpawnCountStep.Value > mapConfig.BotSpawnCountStepMax.Value)
        {
            locationBase.BotSpawnCountStep = mapConfig.BotSpawnCountStepMax.Value;
            result.MapFieldChanges++;
        }

        if (mapConfig.BotSpawnPeriodCheckMaxSeconds.HasValue
            && locationBase.BotSpawnPeriodCheck.HasValue
            && locationBase.BotSpawnPeriodCheck.Value > mapConfig.BotSpawnPeriodCheckMaxSeconds.Value)
        {
            locationBase.BotSpawnPeriodCheck = mapConfig.BotSpawnPeriodCheckMaxSeconds.Value;
            result.MapFieldChanges++;
        }

        if (mapConfig.MaxBotPerZoneMin.HasValue
            && locationBase.MaxBotPerZone.HasValue
            && locationBase.MaxBotPerZone.Value < mapConfig.MaxBotPerZoneMin.Value)
        {
            locationBase.MaxBotPerZone = mapConfig.MaxBotPerZoneMin.Value;
            result.MapFieldChanges++;
        }

        if (config.TuneNormalScavWaves)
        {
            result.NormalWaveChanges = TuneNormalScavWaves(locationBase, mapConfig);
        }

        if (config.TunePmcWaves)
        {
            result.PmcWaveChanges = TuneRaiderWaves(locationBase, mapConfig) + TunePmcWaves((locationBase.BossLocationSpawn ?? []).Where(w => tunedPmcWaves.Add(w)), mapConfig);
        }

        return result;
    }

    internal static int TuneNormalScavWaves(LocationBase locationBase, MapPopulationTuning mapConfig)
    {
        var changed = 0;
        foreach (var wave in locationBase.Waves ?? [])
        {
            if (!IsNormalScavAssaultWave(wave)) continue;
            var oldMax = wave.SlotsMax ?? 0;
            if (oldMax <= 0 && !mapConfig.TouchZeroSlotWaves) continue;
            var targetMax = Math.Max(oldMax, mapConfig.AssaultWaveMinimumSlotsMax)
                + Math.Max(0, mapConfig.AssaultWaveSlotAdd);
            // Never reduce an existing group or turn a disabled wave on implicitly.
            targetMax = Math.Max(oldMax, Math.Min(targetMax, Math.Max(1, mapConfig.AssaultWaveSlotsMaxCap)));
            var oldMin = wave.SlotsMin ?? 0;
            var targetMin = Math.Min(targetMax, Math.Max(oldMin,
                Math.Clamp(mapConfig.AssaultWaveMinimumSlotsMin, 0, 3)));
            if (oldMax == targetMax && oldMin == targetMin) continue;
            wave.SlotsMax = targetMax;
            wave.SlotsMin = targetMin;
            changed++;
        }
        return changed;
    }

    private static int TuneRaiderWaves(LocationBase location, MapPopulationTuning tuning)
    {
        // Retain the previous preset's separate raider chance boost. PMC pacing
        // and group-size changes must not lower Reserve's existing raider odds.
        var changes = 0;
        foreach (var wave in location.BossLocationSpawn ?? [])
        {
            if (!string.Equals(wave.BossName, "pmcBot", StringComparison.OrdinalIgnoreCase)) continue;
            var before = wave.BossChance ?? 0;
            var after = Math.Min(100, Math.Max(before, tuning.RaiderBossChanceFloor ?? 0)
                + Math.Max(0, tuning.RaiderBossChanceAdd));
            if (after <= before) continue;
            wave.BossChance = after;
            changes++;
        }
        return changes;
    }

    internal static int TunePmcWaves(IEnumerable<BossLocationSpawn> waves, MapPopulationTuning mapConfig)
    {
        var changed = 0;
        foreach (var wave in waves)
        {
            // Disabled waves, bosses, raiders and infected retain their own rules.
            if (!IsPmcWave(wave) || !(wave.BossChance > 0)) continue;
            var before = (wave.BossChance, wave.Time, wave.BossEscortAmount, wave.IgnoreMaxBots);
            var chance = Math.Max(wave.BossChance ?? 0, mapConfig.PmcBossChanceFloor ?? 0);
            wave.BossChance = Math.Min(100, Math.Min(mapConfig.PmcBossChanceCap,
                chance + Math.Max(0, mapConfig.PmcBossChanceAdd)));
            var late = wave.Time >= 120;
            if (late && mapConfig.PmcReinforcementTimeScale < 1)
            {
                var scale = Math.Clamp(mapConfig.PmcReinforcementTimeScale, 0.5, 1);
                wave.Time = Math.Max(120, Math.Max(wave.Time!.Value - 120, Math.Round(wave.Time.Value * scale)));
            }
            var floor = Math.Clamp(late ? mapConfig.PmcReinforcementEscortMinimum
                : mapConfig.PmcOpeningEscortMinimum, 0, 2);
            if (floor > 0 && !string.IsNullOrWhiteSpace(wave.BossEscortAmount))
            {
                var tokens = wave.BossEscortAmount.Split(',');
                if (tokens.All(t => int.TryParse(t, out var n) && n >= 0 && n <= 10))
                    wave.BossEscortAmount = string.Join(",", tokens.Select(t => Math.Max(floor, int.Parse(t))));
            }
            wave.IgnoreMaxBots = false;
            if (before != (wave.BossChance, wave.Time, wave.BossEscortAmount, wave.IgnoreMaxBots)) changed++;
        }
        return changed;
    }

    private AiPopulationTuningConfig LoadConfig()
    {
        var configPath = GetConfigPath();
        var configDirectory = Path.GetDirectoryName(configPath);

        if (!string.IsNullOrWhiteSpace(configDirectory))
        {
            Directory.CreateDirectory(configDirectory);
        }

        if (!File.Exists(configPath))
        {
            var defaultConfig = new AiPopulationTuningConfig();
            File.WriteAllText(
                configPath,
                JsonSerializer.Serialize(defaultConfig, AiPopulationTuningConfig.JsonOptions));
            return defaultConfig;
        }

        try
        {
            var json = File.ReadAllText(configPath);
            return JsonSerializer.Deserialize<AiPopulationTuningConfig>(
                json,
                AiPopulationTuningConfig.JsonOptions) ?? new AiPopulationTuningConfig();
        }
        catch (Exception ex)
        {
            logger.Warning(
                $"Codex AI Population Tuning could not read config at {configPath}; using defaults.",
                ex);
            return new AiPopulationTuningConfig();
        }
    }

    private static bool IsNormalScavAssaultWave(Wave wave)
    {
        var spawnType = wave.WildSpawnType?.ToString();
        if (!string.Equals(spawnType, "assault", StringComparison.OrdinalIgnoreCase)
            && !string.Equals(spawnType, "assaultGroup", StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }

        return string.Equals(wave.BotSide, "Savage", StringComparison.OrdinalIgnoreCase)
            || string.IsNullOrWhiteSpace(wave.BotSide);
    }

    private static bool IsPmcWave(BossLocationSpawn wave)
    {
        return IsPmcRole(wave.BossName);
    }

    private static bool IsPmcRole(string? role)
    {
        return string.Equals(role, "pmcBEAR", StringComparison.OrdinalIgnoreCase)
            || string.Equals(role, "pmcUSEC", StringComparison.OrdinalIgnoreCase);
    }

    private static bool TryGetMapConfig(
        AiPopulationTuningConfig config,
        string key,
        LocationBase locationBase,
        out MapPopulationTuning mapConfig)
    {
        return config.Maps.TryGetValue(key, out mapConfig!)
            || config.Maps.TryGetValue(locationBase.Id ?? string.Empty, out mapConfig!)
            || config.Maps.TryGetValue(locationBase.Name ?? string.Empty, out mapConfig!)
            || config.Maps.TryGetValue(Normalize(key), out mapConfig!)
            || config.Maps.TryGetValue(Normalize(locationBase.Id), out mapConfig!)
            || config.Maps.TryGetValue(Normalize(locationBase.Name), out mapConfig!);
    }

    private static bool IsExcludedMap(
        string key,
        LocationBase locationBase,
        HashSet<string> excludedMaps)
    {
        return excludedMaps.Contains(Normalize(key))
            || excludedMaps.Contains(Normalize(locationBase.Id))
            || excludedMaps.Contains(Normalize(locationBase.Name));
    }

    private static HashSet<string> BuildNormalizedSet(IEnumerable<string> values)
    {
        return values
            .Select(Normalize)
            .Where(value => value.Length > 0)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
    }

    private static string GetConfigPath()
    {
        var modDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)
            ?? AppContext.BaseDirectory;

        return Path.Combine(modDirectory, "config", "config.json");
    }

    private static string Normalize(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return string.Empty;
        }

        return new string(value
            .Where(char.IsLetterOrDigit)
            .Select(char.ToLowerInvariant)
            .ToArray());
    }

    private sealed class TuningResult
    {
        public int MapFieldChanges { get; set; }

        public int NormalWaveChanges { get; set; }

        public int PmcWaveChanges { get; set; }

        public bool HasChanges => MapFieldChanges > 0 || NormalWaveChanges > 0 || PmcWaveChanges > 0;
    }
}
