using System.Reflection;using System.Runtime.Loader;using System.Runtime.CompilerServices;using System.Text.Json;
using SPTarkov.Server.Core.Models.Eft.Common;using Codex.AiPopulationTuning;
class Program{
 static int checks;static void Check(bool ok,string label){checks++;if(!ok)throw new Exception(label);}
 static void Main(string[] args){var core=Path.Combine(args[0],"SPT");AssemblyLoadContext.Default.Resolving+=(_,n)=>{var p=Path.Combine(core,n.Name+".dll");return File.Exists(p)?AssemblyLoadContext.Default.LoadFromAssemblyPath(p):null;};Run(args[0],args[1]);}
 [MethodImpl(MethodImplOptions.NoInlining)]static void Run(string root,string config){
 var cfg=JsonSerializer.Deserialize<AiPopulationTuningConfig>(File.ReadAllText(config))!;
 foreach(var(map,tune)in cfg.Maps){
 var source=JsonDocument.Parse(File.ReadAllText(Path.Combine(root,"SPT/SPT_Data/database/locations",map,"base.json"))).RootElement.GetProperty("waves");
 var raw=new LocationBase{Id=map,Waves=source.EnumerateArray().Select(w=>new Wave{WildSpawnType=Enum.Parse<WildSpawnType>(w.GetProperty("WildSpawnType").GetString()!),BotSide=w.GetProperty("BotSide").GetString(),SlotsMin=w.GetProperty("slots_min").GetInt32(),SlotsMax=w.GetProperty("slots_max").GetInt32()}).ToList()};
 var before=JsonSerializer.SerializeToElement(raw);AiPopulationTuningService.TuneNormalScavWaves(raw,tune);
 for(int i=0;i<raw.Waves!.Count;i++){var w=raw.Waves[i];var old=before.GetProperty("waves")[i];
 var role=w.WildSpawnType?.ToString();var eligible=(role=="assault"||role=="assaultGroup")&&(w.BotSide=="Savage"||string.IsNullOrWhiteSpace(w.BotSide))&&old.GetProperty("slots_max").GetInt32()>0;
 if(eligible){Check(w.SlotsMax>=old.GetProperty("slots_max").GetInt32(),map+" never reduces group");Check(w.SlotsMin>=Math.Min(w.SlotsMax??0,tune.AssaultWaveMinimumSlotsMin),map+" actual Scav minimum");}
 else Check(JsonSerializer.SerializeToElement(w).ToString()==old.ToString(),map+" disabled/non-Scav unchanged");
 }
 }
 var t=cfg.Maps["interchange"];
 var rows=new[]{new BossLocationSpawn{BossName="pmcUSEC",BossChance=50,Time=300,BossEscortAmount="0,1,2,3",IgnoreMaxBots=true},new BossLocationSpawn{BossName="pmcBEAR",BossChance=100,Time=30,BossEscortAmount="1,2,3",IgnoreMaxBots=true},new BossLocationSpawn{BossName="pmcBEAR",BossChance=0,Time=300,BossEscortAmount="0",IgnoreMaxBots=true},new BossLocationSpawn{BossName="bossKilla",BossChance=30,Time=300,BossEscortAmount="0",IgnoreMaxBots=true},new BossLocationSpawn{BossName="pmcBot",BossChance=50,Time=300,BossEscortAmount="0",IgnoreMaxBots=true}};
 Check(AiPopulationTuningService.TunePmcWaves(rows,t)==2,"only enabled human PMC waves");
 Check(rows[0].BossChance==70&&rows[0].Time==195&&rows[0].BossEscortAmount=="1,1,2,3"&&rows[0].IgnoreMaxBots==false,"reinforcement chance, timing, group, cap");
 Check(rows[1].BossChance==100&&rows[1].Time==30&&rows[1].BossEscortAmount=="2,2,3","opening groups larger without delaying");
 Check(rows[2].BossChance==0&&rows[2].Time==300&&rows[2].BossEscortAmount=="0","disabled PMC preserved");
 Check(rows[3].BossChance==30&&rows[4].Time==300&&rows[3].IgnoreMaxBots==true,"bosses/raiders unaffected");
 var bad=new BossLocationSpawn{BossName="pmcBEAR",BossChance=80,Time=121,BossEscortAmount="invalid"};AiPopulationTuningService.TunePmcWaves(new[]{bad},t);Check(bad.Time==120&&bad.BossEscortAmount=="invalid","timing floor and invalid group preserved");
 var late=new BossLocationSpawn{BossName="pmcUSEC",BossChance=50,Time=1800,BossEscortAmount="0,1"};AiPopulationTuningService.TunePmcWaves(new[]{late},t);Check(late.Time==1680,"late raid coverage retained: advance at most 120 seconds");
 Console.WriteLine(checks+" population checks passed");
 }
}
