# Population policy checks

Supply your own legitimate SPT 4.0.13 installation and a .NET 9 SDK. The test
reads its map wave definitions; it does not start SPT or write game files.
Run from this directory with paths to your installation and reviewed config:

```powershell
dotnet run --project PopulationTests.csproj -p:SptRoot="D:/YourSPT" -- "D:/YourSPT" "../config/config.json"
```

The executable includes the authored policy source and resolves SPT libraries
from the supplied installation. It checks real Scav wave minima, disabled waves,
PMC timing/chance/squad bounds, late-raid coverage and non-PMC exclusions.
No SPT/game reference libraries are distributed. A fresh compiler build may
have a different DLL hash; deployment uses the exact reviewed saved artifact.
