using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace Codex.Diagnostics.Client
{
    public sealed class FrameWindow
    {
        private readonly float[] _values = new float[4096];
        private int _samples, _frames, _hitches;
        private double _total;
        private float _max;
        public void Add(float seconds)
        {
            if (float.IsNaN(seconds) || float.IsInfinity(seconds) || seconds <= 0) return;
            float ms = Math.Min(seconds * 1000, 60000);
            _frames++; _total += ms; _max = Math.Max(_max, ms);
            if (ms >= 50) _hitches++;
            if (_samples < _values.Length) _values[_samples++] = ms;
        }
        public object SnapshotAndReset()
        {
            var values = new float[_samples]; Array.Copy(_values, values, _samples); Array.Sort(values);
            var snapshot = new FrameSnapshot { frames = _frames, percentile_samples = _samples,
                fps = _total > 0 ? Math.Round(_frames * 1000 / _total, 2) : 0,
                avg_frame_ms = _frames > 0 ? Math.Round(_total / _frames, 2) : 0,
                p95_frame_ms = _samples > 0 ? Math.Round(values[Math.Max(0, (int)Math.Ceiling(_samples * .95) - 1)], 2) : 0,
                max_frame_ms = Math.Round(_max, 2), hitches_over_50ms = _hitches };
            _samples = _frames = _hitches = 0; _total = 0; _max = 0;
            return snapshot;
        }
    }
    public sealed class FrameSnapshot
    {
        public int frames, percentile_samples, hitches_over_50ms;
        public double fps, avg_frame_ms, p95_frame_ms, max_frame_ms;
    }
    public sealed class CreationCounter
    {
        private readonly object _lock = new object();
        private readonly HashSet<string> _ids = new HashSet<string>(StringComparer.Ordinal);
        public void Register(string id) { if (string.IsNullOrEmpty(id)) return; lock (_lock) { if (_ids.Count < 2048) _ids.Add(id); } }
        public int Count { get { lock (_lock) return _ids.Count; } }
    }
    public static class CreationCounters
    {
        private static readonly ConditionalWeakTable<object, CreationCounter> Values = new ConditionalWeakTable<object, CreationCounter>();
        public static CreationCounter For(object host) { return Values.GetValue(host, _ => new CreationCounter()); }
    }
}
