using System;
using System.Collections.Concurrent;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using Newtonsoft.Json;

namespace Codex.Diagnostics.Client
{
    public sealed class BoundedWriter : IDisposable
    {
        private readonly BlockingCollection<object> _queue = new BlockingCollection<object>(16);
        private readonly Thread _thread;
        private readonly string _directory;
        private int _dropped, _errors;
        private bool _disposed;
        public int Dropped { get { return Volatile.Read(ref _dropped); } }
        public int Errors { get { return Volatile.Read(ref _errors); } }
        public BoundedWriter(string directory)
        {
            _directory = directory; Directory.CreateDirectory(directory);
            _thread = new Thread(Loop) { IsBackground = true, Name = "OutlandsBoundedMetrics" }; _thread.Start();
        }
        public void Offer(object snapshot)
        {
            if (_disposed) return;
            try { if (!_queue.TryAdd(snapshot)) Interlocked.Increment(ref _dropped); }
            catch (InvalidOperationException) { Interlocked.Increment(ref _dropped); }
        }
        private void Loop()
        {
            try
            {
                foreach (var snapshot in _queue.GetConsumingEnumerable())
                {
                    try
                    {
                        string json = JsonConvert.SerializeObject(snapshot, Formatting.None);
                        if (Encoding.UTF8.GetByteCount(json) > 16384) { Interlocked.Increment(ref _dropped); continue; }
                        string current = Path.Combine(_directory, "current.json"), temp = current + ".tmp";
                        File.WriteAllText(temp, json + "\n", new UTF8Encoding(false));
                        if (File.Exists(current)) File.Replace(temp, current, null); else File.Move(temp, current);
                        string log = Path.Combine(_directory, "samples-0.jsonl");
                        if (File.Exists(log) && new FileInfo(log).Length >= 8 * 1024 * 1024)
                        {
                            string oldest = Path.Combine(_directory, "samples-3.jsonl"); if (File.Exists(oldest)) File.Delete(oldest);
                            for (int i = 2; i >= 0; i--) { string from = Path.Combine(_directory, "samples-" + i + ".jsonl"); if (File.Exists(from)) File.Move(from, Path.Combine(_directory, "samples-" + (i + 1) + ".jsonl")); }
                        }
                        File.AppendAllText(log, json + "\n", new UTF8Encoding(false));
                    }
                    catch { Interlocked.Increment(ref _errors); }
                }
            }
            catch { Interlocked.Increment(ref _errors); }
        }
        public void Dispose()
        {
            if (_disposed) return; _disposed = true; _queue.CompleteAdding();
            // The background worker owns all streams. A slow disk cannot hold raid
            // teardown indefinitely, and resources are not disposed under its feet.
            if (_thread.Join(2000)) _queue.Dispose();
        }
    }
}
