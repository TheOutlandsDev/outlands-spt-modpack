using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using BepInEx;
using BepInEx.Bootstrap;
using BepInEx.Configuration;
using Comfort.Common;
using EFT;
using Fika.Core.Main.GameMode;
using Fika.Core.Main.Players;
using FikaDynamicAI.Scripts;
using HarmonyLib;
using UnityEngine;

namespace Codex.Diagnostics.Client
{
    [BepInPlugin("codex.diagnostics.client", "Outlands Headless Raid Diagnostics", "0.3.0")]
    [BepInDependency("com.fika.core", "2.2.5")]
    [BepInDependency("com.fika.headless", "1.4.13")]
    [BepInDependency("com.lacyway.fda", "1.0.1")]
    public sealed class Plugin : BaseUnityPlugin
    {
        private readonly FrameWindow _frames = new FrameWindow();
        private readonly string _run = Guid.NewGuid().ToString("N");
        private BoundedWriter _writer;
        private Harmony _harmony;
        private ConfigEntry<bool> _enabled;
        private float _next;
        private int _errors, _measurementErrors;
        private FikaDynamicAIManager _fda;
        private static readonly FieldInfo Disabled = typeof(FikaDynamicAIManager).GetField("_disabledBots", BindingFlags.Instance | BindingFlags.NonPublic);

        private void Awake()
        {
            _enabled = Config.Bind("Capture", "Enabled", false, "Record bounded headless metrics without changing gameplay.");
            if (!_enabled.Value || !Chainloader.PluginInfos.ContainsKey("com.fika.headless")) return;
            try
            {
                _writer = new BoundedWriter(Path.Combine(BepInEx.Paths.GameRootPath, "Logs", "OutlandsRaidDiagnostics"));
                _harmony = new Harmony("outlands.headless.metrics");
                var target = AccessTools.Method(typeof(HostGameController), "CreateBot", new[] { typeof(GameWorld), typeof(Profile), typeof(Vector3) });
                if (target == null || target.ReturnType != typeof(Task<LocalPlayer>)) throw new MissingMethodException("Frozen Fika CreateBot contract is unavailable.");
                _harmony.Patch(target, postfix: new HarmonyMethod(typeof(Plugin), nameof(CreatedBot)));
                Application.logMessageReceivedThreaded += OnLog;
                _next = Time.realtimeSinceStartup + 5;
                Logger.LogInfo("Outlands bounded headless diagnostics active: 5-second frames/bot registry samples; no profile IDs or gameplay changes.");
            }
            catch (Exception error)
            {
                _harmony?.UnpatchSelf(); _writer?.Dispose(); _writer = null;
                Logger.LogError("Headless diagnostics unavailable: " + error.Message);
            }
        }

        private static void CreatedBot(HostGameController __instance, Task<LocalPlayer> __result)
        {
            if (__result == null) return;
            var counter = CreationCounters.For(__instance);
            _ = __result.ContinueWith(task =>
            {
                // No Unity calls or gameplay mutations on the completion thread.
                var player = task.Result;
                if (!ReferenceEquals(player, null)) counter.Register(player.ProfileId);
            }, CancellationToken.None, TaskContinuationOptions.OnlyOnRanToCompletion | TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Default);
        }

        private void OnLog(string message, string stack, LogType type)
        {
            if (type == LogType.Error || type == LogType.Exception || type == LogType.Assert) Interlocked.Increment(ref _errors);
        }

        private void Update()
        {
            if (_writer == null) return;
            _frames.Add(Time.unscaledDeltaTime);
            var now = Time.realtimeSinceStartup;
            if (now < _next) return;
            _next = now + 5;
            object raid;
            try { raid = Raid(); }
            catch { Interlocked.Increment(ref _measurementErrors); raid = new { in_raid = false, available = false }; }
            _writer.Offer(new { schemaVersion = 1, checkedAtUtc = DateTime.UtcNow.ToString("O"), runId = _run,
                performance = _frames.SnapshotAndReset(), raid,
                unityErrors = Volatile.Read(ref _errors), measurementErrors = Volatile.Read(ref _measurementErrors),
                droppedSnapshots = _writer.Dropped, writerErrors = _writer.Errors });
        }

        private object Raid()
        {
            var world = Singleton<GameWorld>.Instance;
            var host = Singleton<IBotGame>.Instance as HostGameController;
            if (world == null || host == null || !host.RaidStarted)
            { _fda = null; return new { in_raid = false, available = true }; }
            if (_fda == null) _fda = UnityEngine.Object.FindObjectOfType<FikaDynamicAIManager>();
            var disabled = _fda != null && Disabled != null ? Disabled.GetValue(_fda) as HashSet<FikaBot> : null;
            int alive = 0, active = 0, sleeping = 0, other = 0, dead = 0, enemy = 0, checkedBots = 0;
            foreach (var pair in host.Bots)
            {
                if (++checkedBots > 2048) break;
                var player = pair.Value;
                if (player == null || player.HealthController == null || !player.HealthController.IsAlive) { dead++; continue; }
                var owner = player.AIData?.BotOwner;
                if (owner != null && owner.IsDead) { dead++; continue; }
                alive++;
                if (disabled != null && player is FikaBot fika && disabled.Contains(fika)) sleeping++;
                else if (player.gameObject.activeSelf && owner != null && owner.BotState == EBotState.Active)
                { active++; if (owner.Memory?.GoalEnemy != null) enemy++; }
                else other++;
            }
            return new { in_raid = true, available = true, map = world.LocationId,
                bot_instances_created = CreationCounters.For(host).Count, registered_bots = host.Bots.Count,
                alive_bots = alive, active_bots = active, fda_sleeping_bots = sleeping,
                sleeping_count_available = disabled != null, other_inactive_bots = other,
                dead_registered_bots = dead, active_bots_with_goal_enemy = enemy,
                registry_truncated = host.Bots.Count > 2048 };
        }

        private void OnDestroy()
        {
            Application.logMessageReceivedThreaded -= OnLog;
            _harmony?.UnpatchSelf(); _writer?.Dispose(); _writer = null;
        }
    }
}
