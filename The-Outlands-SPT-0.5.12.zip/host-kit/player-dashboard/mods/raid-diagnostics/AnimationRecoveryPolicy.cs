namespace Codex.Diagnostics.Client
{
    // These actions are cosmetic patrol inspections. Actual weapon operation,
    // reloading, ammunition accounting and malfunction handling stay native.
    internal static class AnimationRecoveryPolicy
    {
        internal static bool SkipCosmeticInspection(bool headless, bool fikaBot, bool ai, bool yourPlayer)
        {
            return headless && fikaBot && ai && !yourPlayer;
        }
    }
}
