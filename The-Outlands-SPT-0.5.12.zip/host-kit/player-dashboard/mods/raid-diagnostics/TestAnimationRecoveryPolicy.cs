using System;
using Codex.Diagnostics.Client;
class TestAnimationRecoveryPolicy
{
    static void Main()
    {
        var cases = 0;
        // Exhaustive ownership gate: only the real headless AI ownership tuple
        // opts out. A Windows player, observed teammate, or ordinary client AI
        // must retain all original behavior.
        for (var bits = 0; bits < 16; bits++)
        {
            bool headless = (bits & 1) != 0, fikaBot = (bits & 2) != 0, ai = (bits & 4) != 0, yourPlayer = (bits & 8) != 0;
            bool actual = AnimationRecoveryPolicy.SkipCosmeticInspection(headless, fikaBot, ai, yourPlayer);
            if (actual != (bits == 7)) throw new Exception("Ownership boundary failed at " + bits);
            cases++;
        }
        Console.WriteLine("Cosmetic patrol ownership policy: " + cases + " cases passed. Native animation/combat behavior still requires a raid check.");
    }
}
