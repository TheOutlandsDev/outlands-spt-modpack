using System;using System.IO;using System.Linq;using System.Threading.Tasks;using Codex.Diagnostics.Client;
class Program
{
 static int checks;
 static void Must(bool x,string s){if(!x)throw new Exception(s);checks++;}
 static void Main()
 {
  var frames=new FrameWindow();for(int i=0;i<95;i++)frames.Add(.016f);for(int i=0;i<5;i++)frames.Add(.1f);
  var f=(FrameSnapshot)frames.SnapshotAndReset();Must(f.frames==100&&f.hitches_over_50ms==5,"Frame totals/hitches");Must(f.p95_frame_ms==16&&f.max_frame_ms==100,"Nearest-rank p95 and max");Must(Math.Abs(f.fps-49.5)<.1,"Elapsed-frame FPS");
  frames.Add(float.NaN);frames.Add(float.PositiveInfinity);frames.Add(-1);frames.Add(0);Must(((FrameSnapshot)frames.SnapshotAndReset()).frames==0,"Invalid deltas are excluded");
  for(int i=0;i<10000;i++)frames.Add(.001f);f=(FrameSnapshot)frames.SnapshotAndReset();Must(f.frames==10000&&f.percentile_samples==4096,"Percentile storage is bounded without losing frame totals");
  var utc = new DateTime(2026,10,25,20,35,5,DateTimeKind.Utc);
  frames.Add(.099f,100);frames.Add(1.08726f,102);frames.Add(.1f,103);
  f=(FrameSnapshot)frames.SnapshotAndReset(utc,105);
  Must(f.hitches_at_least_100ms==2&&f.hitch_events.Length==2&&f.omitted_hitch_events==0,"Only >=100 ms events retained");
  Must(f.hitch_events[0].frame_ms==1087.26&&f.hitch_events[0].age_ms==3000,"Hitch duration and age preserve units");
  Must(DateTime.Parse(f.hitch_events[0].ended_at_utc).ToUniversalTime()==utc.AddSeconds(-3),"Hitch UTC back-derived from monotonic end");
  for(int i=0;i<40;i++)frames.Add(.101f,200+i);
  f=(FrameSnapshot)frames.SnapshotAndReset(utc,250);
  Must(f.hitches_at_least_100ms==40&&f.hitch_events.Length==16&&f.omitted_hitch_events==24,"Hitch event ring retains bounded most recent events");
  Must(f.hitch_events[0].age_ms==26000&&f.hitch_events[15].age_ms==11000,"Wrapped ring remains chronological");
  f=(FrameSnapshot)frames.SnapshotAndReset(utc,251);Must(f.hitch_events.Length==0&&f.hitches_at_least_100ms==0,"Hitch sample reset clears previous window");
  frames.Add(.2f);f=(FrameSnapshot)frames.SnapshotAndReset(utc,252);Must(f.hitch_events[0].ended_at_utc==null&&f.hitch_events[0].age_ms==null,"Unavailable monotonic timestamp is not invented");
  frames.Add(.2f,260);f=(FrameSnapshot)frames.SnapshotAndReset(utc,259);Must(f.hitch_events[0].ended_at_utc==null,"Regressed monotonic clock refuses a false event timestamp");
  // Add is the per-frame path: both ordinary frames and retained hitches reuse fixed storage.
  frames.Add(.2f,300);long allocationBefore=GC.GetAllocatedBytesForCurrentThread();
  for(int i=0;i<10000;i++)frames.Add(i%10==0?.2f:.016f,300+i);
  Must(GC.GetAllocatedBytesForCurrentThread()==allocationBefore,"Per-frame measurement has no managed allocations");
  frames.SnapshotAndReset();
  var runtime=new RuntimeCounterWindow(10,3,2);var memory=runtime.Snapshot(12,4,2,12345678);
  Must(memory.gc_gen0==2&&memory.gc_gen1==1&&memory.gc_gen2==0&&memory.managed_heap_bytes==12345678&&!memory.counters_reset,"GC deltas use initial baseline and keep heap bytes");
  memory=runtime.Snapshot(12,4,2,8765432);Must(memory.gc_gen0==0&&memory.managed_heap_bytes==8765432,"Unchanged GC counters yield zero deltas without forcing collection");
  memory=runtime.Snapshot(1,0,0,-1);Must(memory.counters_reset&&memory.gc_gen0==0&&memory.gc_gen1==0&&memory.managed_heap_bytes==0,"Counter resets never produce negative collections");
  var unavailableRuntime=new RuntimeCounterWindow(10,-1,-1);memory=unavailableRuntime.Snapshot(12,-1,-1,100);
  Must(memory.gc_gen0==2&&memory.gc_gen1==null&&memory.gc_gen2==null&&!memory.counters_reset,"Unsupported generations remain unavailable while supported GC is counted");
  Must(Newtonsoft.Json.JsonConvert.SerializeObject(memory).Contains("\"gc_gen1\":null")&&Newtonsoft.Json.JsonConvert.SerializeObject(memory).Contains("\"gc_gen2\":null"),"Unavailable GC generations serialize as null rather than zero");
  memory=unavailableRuntime.Snapshot(12,100,-1,100);Must(memory.gc_gen0==0&&memory.gc_gen1==null&&memory.gc_gen2==null&&!memory.counters_reset,"First available counter establishes baseline without inventing a delta or reset");
  memory=unavailableRuntime.Snapshot(13,101,-1,100);Must(memory.gc_gen0==1&&memory.gc_gen1==1&&memory.gc_gen2==null&&!memory.counters_reset,"Available counter begins measuring after its baseline");
  memory=unavailableRuntime.Snapshot(13,-1,-1,100);Must(memory.gc_gen1==null&&!memory.counters_reset,"Losing counter availability is not a GC counter reset");
  memory=unavailableRuntime.Snapshot(14,1,1,100);Must(memory.gc_gen0==1&&memory.gc_gen1==null&&memory.gc_gen2==null&&!memory.counters_reset,"Recovered lower-valued counter needs a fresh baseline without a spurious reset");
  var allUnavailable=new RuntimeCounterWindow(-1,-1,-1);memory=allUnavailable.Snapshot(-1,-1,-1,100);Must(memory.gc_gen0==null&&memory.gc_gen1==null&&memory.gc_gen2==null&&!memory.counters_reset,"All unsupported counters remain explicitly unavailable");
  var timings=new BotTimingWindow();timings.Begin();timings.SynchronousReturned(2.5);var timing=timings.SnapshotAndReset();
  Must(timing.begun_calls==1&&timing.in_flight==1&&timing.completed_calls==0&&timing.synchronous_max_ms==2.5,"Pending async creation is separated from synchronous call timing");
  timings.Complete(1087.26,true);timing=timings.SnapshotAndReset();
  Must(timing.begun_calls==0&&timing.completed_calls==1&&timing.successful_calls==1&&timing.in_flight==0&&timing.elapsed_max_ms==1087.26,"Completion across windows retains elapsed timing and in-flight count");
  timing=timings.SnapshotAndReset();Must(timing.completed_calls==0&&timing.elapsed_samples==0&&timing.max_in_flight==0,"Timing aggregates reset without stale pending work");
  Parallel.For(0,10000,i=>{timings.Begin();timings.SynchronousReturned(i%2==0?1:3);timings.Complete(i%2==0?10:20,i%2==0);});
  timing=timings.SnapshotAndReset();Must(timing.begun_calls==10000&&timing.completed_calls==10000&&timing.successful_calls==5000&&timing.failed_or_cancelled_calls==5000&&timing.in_flight==0,"Concurrent completion accounts for success, faults and cancellation");
  Must(timing.synchronous_mean_ms==2&&timing.synchronous_max_ms==3&&timing.elapsed_mean_ms==15&&timing.elapsed_max_ms==20,"Concurrent elapsed and synchronous aggregates are independent");
  timings.Begin();timings.SynchronousReturned(double.NaN);timings.Complete(double.PositiveInfinity,false);timing=timings.SnapshotAndReset();Must(timing.failed_or_cancelled_calls==1&&timing.synchronous_samples==0&&timing.elapsed_samples==0&&timing.in_flight==0,"Invalid timing values cannot poison aggregates or lose completion status");
  var host=new object();var counter=CreationCounters.For(host);Parallel.For(0,10000,i=>counter.Register((i%50).ToString()));Must(counter.Count==50,"Concurrent bot instance registration deduplicates");Must(CreationCounters.For(new object()).Count==0,"New raids have independent counters");
  string dir=Path.Combine(Path.GetTempPath(),"outlands-metrics-test-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(dir);
  try
  {
   File.WriteAllText(Path.Combine(dir,"samples-0.jsonl"),new string('x',8*1024*1024));
   using(var writer=new BoundedWriter(dir)){writer.Offer(new{schemaVersion=1,raid=new{in_raid=false},performance=f});}
   Must(File.Exists(Path.Combine(dir,"samples-1.jsonl")),"Log rotation bounds history");Must(File.ReadAllText(Path.Combine(dir,"current.json")).Contains("\"schemaVersion\":1"),"Atomic current snapshot");
   using(var writer=new BoundedWriter(dir)){writer.Offer(new{tooLarge=new string('x',20000)});}
   Must(new FileInfo(Path.Combine(dir,"current.json")).Length<16384,"Oversized snapshots cannot replace public input");
   for(int i=0;i<40;i++)frames.Add(60,400+i);
   var fullSnapshot=new {schemaVersion=1,checkedAtUtc=utc.ToString("O"),runId=new string('a',32),
    performance=frames.SnapshotAndReset(utc,450),
    raid=new {in_raid=true,available=true,map="RezervBase",bot_instances_created=2048,registered_bots=2048,alive_bots=2048,active_bots=2048,fda_sleeping_bots=2048,sleeping_count_available=true,other_inactive_bots=2048,dead_registered_bots=2048,active_bots_with_goal_enemy=2048,registry_truncated=true},
    runtime=new RuntimeCounterSnapshot {gc_gen0=long.MaxValue,gc_gen1=long.MaxValue,gc_gen2=long.MaxValue,managed_heap_bytes=long.MaxValue,counters_reset=true},
    botCreation=new BotTimingSnapshot {begun_calls=long.MaxValue,completed_calls=long.MaxValue,successful_calls=long.MaxValue,failed_or_cancelled_calls=long.MaxValue,in_flight=long.MaxValue,max_in_flight=long.MaxValue,synchronous_samples=long.MaxValue,elapsed_samples=long.MaxValue,synchronous_mean_ms=double.MaxValue,synchronous_max_ms=double.MaxValue,elapsed_mean_ms=double.MaxValue,elapsed_max_ms=double.MaxValue},
    utilityAnimations=new {cosmeticMagazineUpdateCallsSkipped=long.MaxValue,cosmeticSecondaryInspectionsDisabled=long.MaxValue},unityErrors=int.MaxValue,measurementErrors=int.MaxValue,droppedSnapshots=int.MaxValue,writerErrors=int.MaxValue};
   int snapshotBytes=System.Text.Encoding.UTF8.GetByteCount(Newtonsoft.Json.JsonConvert.SerializeObject(fullSnapshot));
   Must(snapshotBytes<16384,"Full retained hitch/runtime/timing/utility snapshot fits bounded writer limit");
   using(var writer=new BoundedWriter(dir)){writer.Offer(fullSnapshot);}
   string persisted=File.ReadAllText(Path.Combine(dir,"current.json"));
   Must(persisted.Contains("\"omitted_hitch_events\":24")&&persisted.Contains("\"managed_heap_bytes\":9223372036854775807")&&persisted.Contains("\"botCreation\""),"Writer retains the full bounded diagnostics payload rather than silently dropping it");
  }finally{Directory.Delete(dir,true);}
  Console.WriteLine("PASS: "+checks+" bounded frame/hitch, GC, bot timing, raid identity, concurrency, writer and retention checks.");
 }
}
