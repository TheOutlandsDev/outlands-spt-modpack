using System;
using System.Reflection;
using System.Threading;
using BepInEx.Bootstrap;
using EFT;
using Fika.Core.Main.Players;
using HarmonyLib;

namespace Codex.Diagnostics.Client
{
    // Host-only opt-out of two native cosmetic patrol behaviors. No Unity log
    // filter, fabricated animation callbacks, shortened timeout, or asset edits.
    internal static class AnimationRecovery
    {
        private static bool Headless;
        private static long MagazineChecksSkipped, SecondaryInspectionsDisabled, PolicyErrors;

        internal static void Install(Harmony harmony, Action<string> log)
        {
            if (!Chainloader.PluginInfos.ContainsKey("com.fika.headless"))
                throw new InvalidOperationException("Headless utility policy requires Fika Headless.");
            ValidateContracts();
            Headless = true;
            harmony.Patch(MagazineUpdate(), prefix: new HarmonyMethod(typeof(AnimationRecovery), nameof(BeforeMagazineCheck)));
            harmony.Patch(SecondaryConstructor(), postfix: new HarmonyMethod(typeof(AnimationRecovery), nameof(AfterSecondaryConstructor)));
            log?.Invoke("Headless cosmetic utility guard active: AI cosmetic magazine checks and secondary-weapon inspections disabled; native fire, reload, malfunction, weapon selection and timeout handling retained.");
        }

        private static MethodInfo MagazineUpdate()
        {
            return typeof(BotMagazineChecker).GetMethod("ManualUpdate", BindingFlags.Instance | BindingFlags.Public | BindingFlags.DeclaredOnly, null, Type.EmptyTypes, null);
        }
        private static ConstructorInfo SecondaryConstructor()
        {
            return typeof(BotSecondWeaponData).GetConstructor(new[] { typeof(BotOwner) });
        }
        internal static void ValidateContracts()
        {
            var method = MagazineUpdate();
            var ctor = SecondaryConstructor();
            var owner = typeof(GClass429).GetField("BotOwner_0", BindingFlags.Instance | BindingFlags.Public);
            var canUse = typeof(BotSecondWeaponData).GetField("CanUse", BindingFlags.Instance | BindingFlags.Public | BindingFlags.DeclaredOnly);
            if (method == null || method.ReturnType != typeof(void) || method.IsStatic || ctor == null ||
                owner == null || owner.FieldType != typeof(BotOwner) || canUse == null || canUse.FieldType != typeof(bool) ||
                !typeof(GClass429).IsAssignableFrom(typeof(BotMagazineChecker)) || !typeof(GClass429).IsAssignableFrom(typeof(BotSecondWeaponData)))
                throw new InvalidOperationException("Frozen cosmetic patrol contract changed; policy not installed.");
        }
        private static bool Eligible(BotOwner owner)
        {
            if (owner == null) return false;
            var player = owner.GetPlayer;
            return player != null && AnimationRecoveryPolicy.SkipCosmeticInspection(Headless, player is FikaBot, player.IsAI, player.IsYourPlayer);
        }
        private static bool BeforeMagazineCheck(BotMagazineChecker __instance)
        {
            try
            {
                if (__instance == null || !Eligible(__instance.BotOwner_0)) return true;
                Interlocked.Increment(ref MagazineChecksSkipped);
                return false;
            }
            catch { Interlocked.Increment(ref PolicyErrors); return true; }
        }
        private static void AfterSecondaryConstructor(BotSecondWeaponData __instance)
        {
            try
            {
                if (__instance == null || !__instance.CanUse || !Eligible(__instance.BotOwner_0)) return;
                // CanUse is the native CAN_WATCH_SECOND_WEAPON opt-out, copied into
                // this behavior at construction. Do not mutate shared bot settings.
                __instance.CanUse = false;
                Interlocked.Increment(ref SecondaryInspectionsDisabled);
            }
            catch { Interlocked.Increment(ref PolicyErrors); }
        }
        internal static object Snapshot()
        {
            return new {
                cosmeticMagazineUpdateCallsSkipped = Interlocked.Read(ref MagazineChecksSkipped),
                cosmeticSecondaryInspectionsDisabled = Interlocked.Read(ref SecondaryInspectionsDisabled),
                policyErrors = Interlocked.Read(ref PolicyErrors)
            };
        }
    }
}
