using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using System.Threading.Tasks;
using FikaServer.Callbacks;
using FikaServer.Controllers;
using FikaServer.Models.Fika.Routes.Headless;
using FikaServer.Models.Fika.Routes.Raid.Join;
using SPTarkov.Reflection.Patching;
using SPTarkov.Server.Core.Models.Common;

namespace Outlands.ClientPackPolicy;

// This gate records the release at which a game submitted its native DLL check.
// It is accidental mismatch prevention, not proof of configuration bytes or an
// anti-cheat protocol. Play Outlands supplies the full SHA256 file verification.
public sealed class ReleaseGate(string directory)
{
    public const string Message = "Client update required. Close Escape from Tarkov AND SPT Launcher, then run Play Outlands before your next raid.";
    private readonly object _sync = new();
    private readonly string _directory = directory;
    private Dictionary<string, string>? _validated;

    public string Expected()
    {
        var path = Path.Combine(_directory, "policy.json");
        var info = new FileInfo(path);
        if (!info.Exists || info.Length > 524288 || info.LinkTarget != null) throw new InvalidDataException("Client release policy unavailable.");
        using var document = JsonDocument.Parse(File.ReadAllBytes(path));
        string? value = document.RootElement.GetProperty("releaseFingerprint").GetString();
        if (value == null || value.Length != 64 || value.Any(c => !((c >= 'a' && c <= 'f') || (c >= '0' && c <= '9'))))
            throw new InvalidDataException("Client release fingerprint unavailable.");
        return value;
    }

    private Dictionary<string, string> Records()
    {
        if (_validated != null) return _validated;
        var path = Path.Combine(_directory, "validated-sessions.json");
        var info = new FileInfo(path);
        if (!info.Exists) return _validated = new(StringComparer.Ordinal);
        if (info.Length > 131072 || info.LinkTarget != null) throw new InvalidDataException("Unsafe private validation state.");
        var records = JsonSerializer.Deserialize<Dictionary<string, string>>(File.ReadAllBytes(path))
            ?? throw new InvalidDataException("Missing private validation state.");
        if (records.Count > 1000 || records.Any(p => p.Key.Length != 24 || p.Key.Any(c => !Uri.IsHexDigit(c)) ||
                p.Value.Length != 64 || p.Value.Any(c => !Uri.IsHexDigit(c))))
            throw new InvalidDataException("Invalid private validation state.");
        return _validated = records;
    }

    public void Record(MongoId session, bool success)
    {
        lock (_sync)
        {
            var records = Records();
            records.Remove(session.ToString()); // A failed new check revokes previous success.
            if (success)
            {
                string expected = Expected();
                // Old generations have no admission value and need not be retained.
                foreach (string key in records.Where(p => p.Value != expected).Select(p => p.Key).ToArray()) records.Remove(key);
                if (records.Count >= 1000) throw new InvalidOperationException("Client validation state limit reached.");
                records[session.ToString()] = expected;
            }
            string path = Path.Combine(_directory, "validated-sessions.json");
            if (new FileInfo(path).LinkTarget != null) throw new InvalidDataException("Symlinked validation state refused.");
            string temp = Path.Combine(_directory, ".validated-" + Guid.NewGuid().ToString("N"));
            try
            {
                using (var stream = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                { JsonSerializer.Serialize(stream, records); stream.Flush(true); }
                if (!OperatingSystem.IsWindows()) File.SetUnixFileMode(temp, UnixFileMode.UserRead | UnixFileMode.UserWrite);
                File.Move(temp, path, overwrite: true);
            }
            finally { if (File.Exists(temp)) File.Delete(temp); }
        }
    }

    public bool Allows(MongoId session)
    {
        lock (_sync)
        {
            try { return Records().TryGetValue(session.ToString(), out string? release) && release == Expected(); }
            catch { return false; } // Never interrupt active raids: only new admission calls use this.
        }
    }
}

public static class ReleaseAdmission
{
    public static Func<MongoId, bool>? Allowed;
    public static Func<MongoId, string, bool>? ExistingMember;
    public static bool CanEnter(MongoId session) => Allowed?.Invoke(session) == true;
}

public sealed class UpdatedHeadlessStartPatch : AbstractPatch
{
    protected override MethodBase GetTargetMethod() => typeof(RaidController).GetMethod(
        nameof(RaidController.HandleRaidStartHeadless), [typeof(MongoId), typeof(StartHeadlessRequest)])
        ?? throw new MissingMethodException("Pinned Fika headless start contract unavailable.");
    [PatchPrefix]
    public static bool Prefix(MongoId __0, ref Task<StartHeadlessResponse> __result)
    {
        if (ReleaseAdmission.CanEnter(__0)) return true;
        __result = Task.FromResult(new StartHeadlessResponse { MatchId = null, Error = ReleaseGate.Message });
        return false;
    }
}

public sealed class UpdatedRaidJoinPatch : AbstractPatch
{
    protected override MethodBase GetTargetMethod() => typeof(RaidCallbacks).GetMethod(nameof(RaidCallbacks.HandleRaidJoin),
        [typeof(string), typeof(FikaRaidJoinRequestData), typeof(MongoId)])
        ?? throw new MissingMethodException("Pinned Fika raid join contract unavailable.");
    [PatchPrefix]
    public static bool Prefix(FikaRaidJoinRequestData __1, MongoId __2, ref ValueTask<string> __result)
    {
        if (ReleaseAdmission.CanEnter(__2) || ReleaseAdmission.ExistingMember?.Invoke(__2, __1.ServerId) == true) return true;
        // Fika 2.2.5 has no join error DTO. Its native JoinMatch checks GameVersion
        // first and shows the server value in its refusal dialog, before using any
        // match ID or accepting the player. Preserve that pinned refusal contract.
        __result = ValueTask.FromResult(JsonSerializer.Serialize(new { gameVersion = ReleaseGate.Message }));
        return false;
    }
}
