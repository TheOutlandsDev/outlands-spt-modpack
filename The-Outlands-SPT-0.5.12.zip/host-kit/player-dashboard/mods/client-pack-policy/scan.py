#!/usr/bin/env python3
"""Read BepInPlugin metadata and CRC32C without loading or executing game assemblies."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

SOURCE = Path(__file__).resolve().parent
ROOT = SOURCE.parents[2]


def scan(paths):
    sdk = ROOT / "MAINSPT/Tools/dotnet-sdk-9.0.316"
    dotnet = ROOT / "linux/dotnet/dotnet"
    references = sorted((sdk / "packs/Microsoft.NETCore.App.Ref/9.0.18/ref/net9.0").glob("*.dll"))
    if not references:
        raise ValueError("The local .NET 9 compiler reference pack is missing.")
    with tempfile.TemporaryDirectory(prefix="outlands-plugin-metadata-") as temporary:
        work = Path(temporary)
        shutil.copyfile(ROOT / "runtime/SPT/Mono.Cecil.dll", work / "Mono.Cecil.dll")
        config = {"runtimeOptions": {"tfm": "net9.0", "framework": {"name": "Microsoft.NETCore.App", "version": "9.0.17"}}}
        (work / "inspect.runtimeconfig.json").write_text(json.dumps(config) + "\n")
        args = ["-nologo", "-target:exe", "-deterministic+", f"-out:{work / 'inspect.dll'}"]
        args += [f"-r:{path}" for path in references + [work / "Mono.Cecil.dll"]]
        args += [str(SOURCE / "InspectPlugins.cs")]
        (work / "compile.rsp").write_text("\n".join('"' + argument + '"' for argument in args) + "\n")
        environment = dict(os.environ, COMPlus_ReadyToRun="0")
        subprocess.run([str(dotnet), "exec", "--runtimeconfig", str(work / "inspect.runtimeconfig.json"),
                        str(sdk / "sdk/9.0.316/Roslyn/bincore/csc.dll"), "@" + str(work / "compile.rsp")],
                       check=True, env=environment, capture_output=True, text=True)
        (work / "paths.json").write_text(json.dumps([str(Path(path).resolve()) for path in paths]))
        result = subprocess.run([str(dotnet), str(work / "inspect.dll"), str(work / "paths.json")],
                                check=True, env=environment, capture_output=True, text=True)
        return json.loads(result.stdout)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--files", type=Path, required=True, help="JSON array of absolute DLL paths")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.write_text(json.dumps(scan(json.loads(args.files.read_text())), indent=2) + "\n")


if __name__ == "__main__":
    main()
