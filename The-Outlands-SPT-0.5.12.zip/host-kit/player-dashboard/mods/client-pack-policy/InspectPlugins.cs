using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;
using Mono.Cecil;

internal static class Program
{
    private static readonly uint[] Table = Enumerable.Range(0, 256).Select(i =>
    {
        uint value = (uint)i;
        for (int bit = 0; bit < 8; bit++) value = (value >> 1) ^ ((value & 1) != 0 ? 0x82F63B78U : 0);
        return value;
    }).ToArray();
    private static void Main(string[] args)
    {
        var results = new List<object>();
        foreach (string source in JsonSerializer.Deserialize<string[]>(File.ReadAllText(args[0]))!)
        {
            string path = Path.GetFullPath(source);
            byte[] bytes = File.ReadAllBytes(path);
            uint crc = uint.MaxValue;
            foreach (byte value in bytes) crc = Table[(crc ^ value) & 255] ^ (crc >> 8);
            var plugins = new List<object>();
            try
            {
                using var assembly = AssemblyDefinition.ReadAssembly(new MemoryStream(bytes));
                foreach (var type in assembly.MainModule.Types.SelectMany(Flatten))
                foreach (var attribute in type.CustomAttributes.Where(a => a.AttributeType.FullName == "BepInEx.BepInPlugin"))
                {
                    if (attribute.ConstructorArguments.Count != 3) throw new InvalidDataException("Unexpected BepInPlugin contract: " + path);
                    plugins.Add(new { guid = (string)attribute.ConstructorArguments[0].Value,
                        name = (string)attribute.ConstructorArguments[1].Value, version = (string)attribute.ConstructorArguments[2].Value });
                }
            }
            catch (BadImageFormatException) { /* Native support DLLs have no registered plugin GUID. */ }
            results.Add(new { path, sha256 = Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant(), crc32c = crc ^ uint.MaxValue, plugins });
        }
        Console.WriteLine(JsonSerializer.Serialize(results));
    }
    private static IEnumerable<TypeDefinition> Flatten(TypeDefinition type)
    { yield return type; foreach (var nested in type.NestedTypes.SelectMany(Flatten)) yield return nested; }
}
