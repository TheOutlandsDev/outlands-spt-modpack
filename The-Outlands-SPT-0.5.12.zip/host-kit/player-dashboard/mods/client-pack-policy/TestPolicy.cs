using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Loader;
using System.Text.Json;
using System.Threading.Tasks;
using FikaServer.Callbacks;
using FikaServer.Helpers;
using FikaServer.Models.Fika.Routes.Client.Check;
using FikaServer.Services.Headless;
using Outlands.ClientPackPolicy;
using SPTarkov.Server.Core.Models.Common;
using SPTarkov.Server.Core.Models.Eft.Profile;
using SPTarkov.Server.Core.Utils;

internal static class Program
{
    private static int checks;
    private static void Main(string[] args)
    {
        string core = Path.Combine(args[0], "runtime", "SPT");
        bool discovery = args.Length > 1 && args[1] == "--discovery";
        AssemblyLoadContext.Default.Resolving += (_, name) =>
        {
            foreach (string folder in discovery ? new[] { core } : new[] { core, Path.Combine(core, "user", "mods", "fika-server") })
            {
                string path = Path.Combine(folder, name.Name + ".dll");
                if (File.Exists(path)) return AssemblyLoadContext.Default.LoadFromAssemblyPath(path);
            }
            return null;
        };
        if (discovery)
        {
            var assembly = AssemblyLoadContext.Default.LoadFromAssemblyPath(args[2]);
            Console.WriteLine("PASS: client policy discovery before Fika; types=" + assembly.GetTypes().Length);
            return;
        }
        if (args.Length > 2 && args[1] == "--policy") { CheckCanonicalPolicy(args[2]); return; }
        string executable = Assembly.GetExecutingAssembly().Location;
        var start = new ProcessStartInfo(Environment.ProcessPath!) { UseShellExecute = false, RedirectStandardOutput = true, RedirectStandardError = true };
        start.ArgumentList.Add(executable); start.ArgumentList.Add(args[0]); start.ArgumentList.Add("--discovery");
        start.ArgumentList.Add(Path.Combine(Path.GetDirectoryName(executable)!, "Outlands.ClientPackPolicy.dll"));
        using (var process = Process.Start(start)!)
        {
            string output = process.StandardOutput.ReadToEnd(), errors = process.StandardError.ReadToEnd();
            process.WaitForExit();
            Require(process.ExitCode == 0, "Core-only type discovery must succeed: " + errors);
            Console.Write(output);
        }
        CheckJoinContract(args[0]);
        Run();
    }

    private static void CheckJoinContract(string root)
    {
        string path = Path.Combine(root, "runtime/BepInEx/plugins/Fika/Fika.Core.dll");
        Require(Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant() ==
            "6b56f43ac9fe6296537be8fbfe2f78da36da73842540602687ba9baba51f938b", "Join refusal contract requires the exact frozen Fika client.");
        using var assembly = Mono.Cecil.AssemblyDefinition.ReadAssembly(path);
        var type = assembly.MainModule.Types.Single(t => t.FullName == "Fika.Core.Main.Utils.FikaBackendUtils");
        var method = type.Methods.Single(m => m.Name == "JoinMatch");
        var il = method.Body.Instructions.ToArray();
        int version = Array.FindIndex(il, i => i.Operand is Mono.Cecil.FieldReference f && f.Name == "GameVersion");
        int crc = Array.FindIndex(il, i => i.Operand is Mono.Cecil.FieldReference f && f.Name == "Crc32");
        int format = Array.FindIndex(il, i => i.Operand is Mono.Cecil.MethodReference m && m.DeclaringType.FullName == "System.String" && m.Name == "Format");
        Require(version >= 0 && format > version && crc > format, "Native join must format a version error before checking CRC or accepting the match.");
        Require(il[format + 1].OpCode.Code == Mono.Cecil.Cil.Code.Stind_Ref &&
            il[format + 2].OpCode.Code == Mono.Cecil.Cil.Code.Ldc_I4_0 && il[format + 3].OpCode.Code == Mono.Cecil.Cil.Code.Ret,
            "Native version refusal writes the UI error and returns false.");
        var ui = assembly.MainModule.Types.Single(t => t.FullName == "Fika.Core.UI.Custom.MatchMakerUIScript");
        var move = ui.NestedTypes.Single(t => t.Name.StartsWith("<JoinMatch>")).Methods.Single(m => m.Name == "MoveNext");
        var call = move.Body.Instructions.Single(i => i.Operand is Mono.Cecil.MethodReference m && m.DeclaringType == type && m.Name == "JoinMatch");
        Require(call.Next.OpCode.FlowControl == Mono.Cecil.Cil.FlowControl.Cond_Branch, "Match UI must branch on refused native JoinMatch before using the match ID.");
        var errorStart = (Mono.Cecil.Cil.Instruction)call.Next.Operand;
        var errorInstructions = move.Body.Instructions.SkipWhile(i => i != errorStart).Take(6).ToArray();
        Require(errorInstructions.Any(i => i.Operand is Mono.Cecil.MethodReference m && m.Name == "ShowErrorScreen"), "Native refusal must reach the error screen.");
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private static void CheckCanonicalPolicy(string path)
    {
        var policy = ClientPolicy.Load(path);
        using var document = JsonDocument.Parse(File.ReadAllText(path));
        foreach (string role in new[] { "human", "headless" })
        {
            var report = new Dictionary<string, uint>(StringComparer.Ordinal);
            foreach (var property in document.RootElement.GetProperty(role).GetProperty("required").EnumerateObject())
                report.Add(property.Name, property.Value.GetUInt32());
            Clean(policy.Validate(report, role == "headless"), "Canonical " + role + " role must validate.");
            Console.WriteLine("PASS: canonical " + role + " required plugin baseline; count=" + report.Count);
        }
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private static void Run()
    {
        string directory = Path.Combine(Path.GetTempPath(), "outlands-client-policy-test-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(directory);
        try { Fixtures(directory); }
        finally { Directory.Delete(directory, recursive: true); }
    }

    private static void Fixtures(string directory)
    {
        string path = Path.Combine(directory, "policy.json");
        var human = new Dictionary<string, uint>(StringComparer.Ordinal)
        {
            ["com.fika.core"] = 1, ["com.SPT.custom"] = 2, ["com.SPT.singleplayer"] = 3,
            ["com.SPT.core"] = 4, ["com.SPT.debugging"] = 5, ["outlands.remote-quests"] = 6, ["fixture.gameplay"] = 7
        };
        var headless = human.Where(pair => pair.Key != "outlands.remote-quests").ToDictionary(p => p.Key, p => p.Value, StringComparer.Ordinal);
        headless.Add("com.fika.headless", 8); headless.Add("com.lacyway.fda", 9); headless.Add("codex.diagnostics.client", 10);
        object schema = new { schemaVersion = 2, releaseFingerprint = new string('a', 64), sptVersion = "4.0.13", fikaServerVersion = "2.2.4",
            human = new { required = human, optional = new Dictionary<string, uint>() },
            headless = new { required = headless, optional = new Dictionary<string, uint> { ["outlands.remote-quests"] = 6 } } };
        string fixture = JsonSerializer.Serialize(schema);
        File.WriteAllText(path, fixture);
        var policy = ClientPolicy.Load(path);
        Clean(policy.Validate(human, false), "Exact approved human report must pass.");
        Clean(policy.Validate(headless, true), "Configured headless role may omit Remote Quests.");
        var bad = new Dictionary<string, uint>(human) { ["fixture.gameplay"] = 999 };
        Require(policy.Validate(bad, false).HashMismatch.SequenceEqual(new[] { "fixture.gameplay" }), "Wrong version must fail against the fixed hash.");
        Clean(policy.Validate(human, false), "A bad first report must never poison the baseline.");
        bad.Remove("outlands.remote-quests");
        Require(policy.Validate(bad, false).MissingRequired.Contains("outlands.remote-quests"), "Human Remote Quests is required.");
        bad = new(human) { ["unapproved.plugin"] = 42 };
        Require(policy.Validate(bad, false).Forbidden.Contains("unapproved.plugin"), "Unknown plugins must be refused.");
        foreach (string guid in new[] { "com.fika.headless", "com.lacyway.fda", "codex.diagnostics.client" })
        {
            bad = new(human) { [guid] = headless[guid] };
            Require(policy.Validate(bad, false).Forbidden.Contains(guid), "Host-only plugin is forbidden for humans: " + guid);
        }
        bad = new(headless) { ["outlands.remote-quests"] = 6 };
        Clean(policy.Validate(bad, true), "Approved optional Remote Quests may remain on headless.");
        bad["outlands.remote-quests"] = 999;
        Require(policy.Validate(bad, true).HashMismatch.Contains("outlands.remote-quests"), "Optional headless UI must still have its exact approved hash.");
        bad = new(headless); bad.Remove("com.lacyway.fda");
        Require(policy.Validate(bad, true).MissingRequired.Contains("com.lacyway.fda"), "Headless AI plugin is required for the host role.");
        bad = new(human); bad.Remove("com.SPT.core"); bad.Add("com.spt.core", 4);
        var wrongCase = policy.Validate(bad, false);
        Require(wrongCase.MissingRequired.Contains("com.SPT.core") && wrongCase.Forbidden.Contains("com.spt.core"), "Plugin GUID casing must remain exact.");
        Require(policy.Validate(null, false).Forbidden.Count == 1, "Malformed report must fail closed.");
        Require(policy.Validate(new Dictionary<string, uint> { [new string('x', 161)] = 1 }, false).Forbidden.SequenceEqual(new[] { "invalid-client-mod-report" }), "Unbounded submitted GUIDs must not be reflected into responses.");
        File.WriteAllText(path, "{}");
        Clean(policy.Validate(human, false), "Editing the policy file must not mutate an active baseline.");
        Reject(() => ClientPolicy.Load(path), "Missing policy contracts must prevent startup.");
        File.Delete(path);
        Reject(() => ClientPolicy.Load(path), "Missing policy file must prevent startup.");
        File.WriteAllText(path, fixture.Replace("\"4.0.13\"", "\"4.0.14\""));
        Reject(() => ClientPolicy.Load(path), "Changed target version must prevent startup.");
        File.WriteAllText(path, fixture.Replace("\"com.SPT.core\":4", "\"com.SPT.core\":4,\"com.SPT.core\":5"));
        Reject(() => ClientPolicy.Load(path), "Duplicate policy GUIDs must prevent startup.");
        headless["com.SPT.core"] = 999;
        File.WriteAllText(path, JsonSerializer.Serialize(schema));
        Reject(() => ClientPolicy.Load(path), "Common human/headless plugin hashes must agree.");
        headless["com.SPT.core"] = 4;

        // Classify through the actual native helper's configured profile list,
        // never through a client-claimed headless plugin or updater token.
        MongoId hostId = new("000000000000000000000001"), humanId = new("000000000000000000000002");
        var hostInfo = (SPTarkov.Server.Core.Models.Eft.Profile.Info)RuntimeHelpers.GetUninitializedObject(typeof(SPTarkov.Server.Core.Models.Eft.Profile.Info));
        hostInfo.ProfileId = hostId;
        var profileService = (HeadlessProfileService)RuntimeHelpers.GetUninitializedObject(typeof(HeadlessProfileService));
        profileService.HeadlessProfiles = [new SptProfile { ProfileInfo = hostInfo }];
        var helper = (HeadlessHelper)RuntimeHelpers.GetUninitializedObject(typeof(HeadlessHelper));
        typeof(HeadlessHelper).GetField("<headlessProfileService>P", BindingFlags.Instance | BindingFlags.NonPublic)!.SetValue(helper, profileService);
        Require(helper.IsHeadlessClient(hostId) && !helper.IsHeadlessClient(humanId), "Native configured profile IDs must determine the role.");
        var responses = new HttpResponseUtil(new JsonUtil([]), null!);
        ClientPolicyHooks.Configure(policy, helper.IsHeadlessClient, responses.NoBody<ValidationResponse>);
        var callbacks = new ClientCallbacks(responses, null!);
        var patch = new ClientCheckPatch();
        patch.Enable();
        try
        {
            Require(patch.IsActive, "Real Fika client validation callback hook must activate.");
            NativeClean(human, humanId, "Real human callback must pass without native first-client seeding.");
            NativeClean(headless, hostId, "Real configured headless callback must accept host-only plugins and missing optional UI.");
            var spoof = callbacks.HandleCheckMods("/fika/client/check/mods", Report(headless), humanId).GetAwaiter().GetResult();
            using (var document = JsonDocument.Parse(spoof))
                Require(document.RootElement.GetProperty("forbidden").EnumerateArray().Any(v => v.GetString() == "com.fika.headless"), "Claiming a headless plugin must not change a human session's role.");
            bad = new(human) { ["fixture.gameplay"] = 999 };
            using (var document = JsonDocument.Parse(callbacks.HandleCheckMods("/fika/client/check/mods", Report(bad), humanId).GetAwaiter().GetResult()))
                Require(document.RootElement.GetProperty("hashMismatch").GetArrayLength() == 1, "Real callback must return native mismatch response fields.");
            NativeClean(human, humanId, "Real bad-first report must never change later validation.");
        }
        finally { patch.Disable(); }
        // Admission records survive ordinary backend restarts but become stale
        // when any managed config/asset/DLL content changes its release identity.
        File.WriteAllText(path, fixture);
        var gate = new ReleaseGate(directory);
        Require(!gate.Allows(humanId), "Unchecked cached games must not start a new raid.");
        gate.Record(humanId, true);
        Require(gate.Allows(humanId) && new ReleaseGate(directory).Allows(humanId), "Daily backend restart preserves a successful unchanged release check.");
        File.WriteAllText(path, fixture.Replace(new string('a',64), new string('b',64)));
        Require(!gate.Allows(humanId), "A config-only release change invalidates previous admission.");
        gate.Record(humanId, true);
        Require(gate.Allows(humanId), "Fresh native client validation permits the current release.");
        gate.Record(humanId, false);
        Require(!gate.Allows(humanId) && !new ReleaseGate(directory).Allows(humanId), "A failed report revokes previous success durably.");
        ClientPolicyHooks.Gate = gate;
        ReleaseAdmission.Allowed = id => helper.IsHeadlessClient(id) || gate.Allows(id);
        ReleaseAdmission.ExistingMember = (id, target) => target == "existing-raid";
        var startPatch = new UpdatedHeadlessStartPatch();
        var joinPatch = new UpdatedRaidJoinPatch();
        startPatch.Enable(); joinPatch.Enable();
        try
        {
            var controller = (FikaServer.Controllers.RaidController)RuntimeHelpers.GetUninitializedObject(typeof(FikaServer.Controllers.RaidController));
            var blocked = controller.HandleRaidStartHeadless(humanId, null!).GetAwaiter().GetResult();
            Require(blocked.MatchId == null && blocked.Error == ReleaseGate.Message, "Actual Fika headless start returns the actionable native refusal.");
            var raidCallbacks = new RaidCallbacks(responses, null!);
            var join = new FikaServer.Models.Fika.Routes.Raid.Join.FikaRaidJoinRequestData { ServerId = "new-raid", ProfileId = humanId.ToString() };
            string denial = raidCallbacks.HandleRaidJoin("/fika/raid/join", join, humanId).GetAwaiter().GetResult();
            using var denied = JsonDocument.Parse(denial);
            Require(denied.RootElement.GetProperty("gameVersion").GetString() == ReleaseGate.Message, "Actual Fika join uses its pinned version-refusal UI before any match admission.");
            Task<FikaServer.Models.Fika.Routes.Headless.StartHeadlessResponse> result = null!;
            Require(UpdatedHeadlessStartPatch.Prefix(hostId, ref result), "Configured headless host remains allowed.");
            ValueTask<string> joinResult = default;
            join.ServerId = "existing-raid";
            Require(UpdatedRaidJoinPatch.Prefix(join, humanId, ref joinResult), "Existing-raid reconnects remain available after a release change.");
            gate.Record(humanId, true);
            join.ServerId = "new-raid";
            Require(UpdatedRaidJoinPatch.Prefix(join, humanId, ref joinResult), "Revalidated human reaches native join.");
            File.Delete(path);
            Require(!gate.Allows(humanId), "Missing release policy blocks new admissions.");
        }
        finally { startPatch.Disable(); joinPatch.Disable(); ClientPolicyHooks.Gate = null; }
        var metadata = new ModMetadata();
        Require(metadata.SptVersion.IsSatisfied(new SemanticVersioning.Version(4, 0, 13)) && !metadata.SptVersion.IsSatisfied(new SemanticVersioning.Version(4, 0, 14)), "SPT pin must remain exact.");
        Require(metadata.ModDependencies!["Fika"].IsSatisfied(new SemanticVersioning.Version(2, 2, 4)) && !metadata.ModDependencies["Fika"].IsSatisfied(new SemanticVersioning.Version(2, 2, 5)), "Fika pin must remain exact.");
        // Modern shared client rules are required on the headless raid host too.
        var requiredHost = new Dictionary<string, uint>(headless) { ["outlands.remote-quests"] = 6 };
        var modern = new { schemaVersion = 2, releaseFingerprint = new string('a', 64), sptVersion = "4.0.13", fikaServerVersion = "2.2.4",
            human = new { required = human, optional = new Dictionary<string,uint>() },
            headless = new { required = requiredHost, optional = new Dictionary<string,uint>() } };
        File.WriteAllText(path, JsonSerializer.Serialize(modern));
        var strict = ClientPolicy.Load(path);
        Clean(strict.Validate(requiredHost, true), "Shared client guards are accepted as required headless rules.");
        Require(strict.Validate(headless, true).MissingRequired.Contains("outlands.remote-quests"), "Headless missing zombie guards is rejected.");
        Console.WriteLine($"PASS: {checks} client policy checks; native callback and configured role classification, fixed CRC baseline, optional UI, unknown/missing/mismatch refusal, discovery before Fika, fail-closed policy loading.");

        void NativeClean(Dictionary<string, uint> report, MongoId session, string label)
        {
            using var document = JsonDocument.Parse(callbacks.HandleCheckMods("/fika/client/check/mods", Report(report), session).GetAwaiter().GetResult());
            Require(new[] { "forbidden", "missingRequired", "hashMismatch" }.All(key => document.RootElement.GetProperty(key).GetArrayLength() == 0), label);
        }
    }

    private static FikaCheckModRequestData Report(Dictionary<string, uint> values)
    { var result = new FikaCheckModRequestData(); foreach (var item in values) result.Add(item.Key, item.Value); return result; }
    private static void Clean(ValidationResponse result, string label) => Require(result.Forbidden.Count + result.MissingRequired.Count + result.HashMismatch.Count == 0, label);
    private static void Reject(Action action, string label)
    { try { action(); } catch { Require(true, label); return; } throw new Exception(label); }
    private static void Require(bool condition, string message)
    { if (!condition) throw new Exception(message); checks++; }
}
