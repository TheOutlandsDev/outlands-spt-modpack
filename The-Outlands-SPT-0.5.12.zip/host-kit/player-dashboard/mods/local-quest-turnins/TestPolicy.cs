using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Loader;
using System.Text.Json;
using Outlands.LocalQuestTurnIns;
using SPTarkov.Reflection.Patching;
using SPTarkov.Server.Core.Callbacks;
using SPTarkov.Server.Core.Helpers;
using SPTarkov.Server.Core.Models.Common;
using SPTarkov.Server.Core.Models.Eft.Common;
using SPTarkov.Server.Core.Models.Eft.Common.Tables;
using SPTarkov.Server.Core.Models.Eft.ItemEvent;
using SPTarkov.Server.Core.Models.Eft.Quests;
using SPTarkov.Server.Core.Models.Enums;
using SPTarkov.Server.Core.Routers;
using SPTarkov.Server.Core.Services;
using SPTarkov.Server.Core.Utils;
using SPTarkov.Server.Core.Utils.Json.Converters;
using Path = System.IO.Path;

internal static class Program
{
    private static int checks;
    private static void Main(string[] args)
    {
        string core = Path.Combine(args[0], "runtime", "SPT");
        AssemblyLoadContext.Default.Resolving += (_, name) =>
        {
            string path = Path.Combine(core, name.Name + ".dll");
            return File.Exists(path) ? AssemblyLoadContext.Default.LoadFromAssemblyPath(path) : null;
        };
        Run();
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private static void Run()
    {
        MongoId session = new("000000000000000000000001");
        MongoId traderId = new("000000000000000000000002");
        MongoId normalId = new("000000000000000000000003");
        MongoId repeatableId = new("000000000000000000000004");
        MongoId unknownId = new("000000000000000000000005");
        var normal = (Quest)RuntimeHelpers.GetUninitializedObject(typeof(Quest));
        normal.Id = normalId;
        normal.TraderId = traderId;
        var repeatable = (RepeatableQuest)RuntimeHelpers.GetUninitializedObject(typeof(RepeatableQuest));
        repeatable.Id = repeatableId;
        repeatable.TraderId = traderId;
        var database = new FixtureDatabase(new() { [normalId] = normal });
        // Only the read-only native lookup is exercised. Its other dependencies
        // remain uninitialized, preventing accidental profile/database access.
        var quests = (QuestHelper)RuntimeHelpers.GetUninitializedObject(typeof(QuestHelper));
        typeof(QuestHelper).GetField("<databaseService>P", BindingFlags.Instance | BindingFlags.NonPublic)!
            .SetValue(quests, database);
        var trader = new TraderInfo { Disabled = true, Unlocked = true };
        var profile = new PmcData
        {
            TradersInfo = new() { [traderId] = trader },
            RepeatableQuests = [new PmcDataRepeatableQuest { ActiveQuests = [repeatable], InactiveQuests = [], ChangeRequirement = new() }]
        };
        var outputs = new FixtureOutputs(session);
        var responses = new HttpResponseUtil(null!, null!);
        var policy = new TurnInPolicy(quests, outputs, responses);
        QuestTurnInHooks.Configure(policy);
        Require(ReferenceEquals(quests.GetQuestFromDb(normalId, profile), normal), "Normal quest must resolve from fixture DB.");
        Require(ReferenceEquals(quests.GetQuestFromDb(repeatableId, profile), repeatable), "Repeatable quest must resolve from native active quest lookup.");

        var jsonOptions = new JsonSerializerOptions();
        jsonOptions.Converters.Add(new StringToMongoIdConverter());
        string beforeProfile = JsonSerializer.Serialize(profile, jsonOptions);
        var sentinelChange = outputs.Shared.ProfileChanges!;
        var previousWarning = outputs.Shared.Warnings![0];
        ItemEventRouterResponse result = null!;
        int originalMutations = 0;
        if (HandoverPatch.Prefix(profile, new() { QuestId = normalId }, session, ref result)) originalMutations++;
        Require(originalMutations == 0, "Remote handover must stop before inventory mutations.");
        Require(ReferenceEquals(result, outputs.Shared), "Rejection must reuse the shared event response.");
        Require(ReferenceEquals(result.ProfileChanges, sentinelChange), "Earlier profile changes must be preserved.");
        Require(ReferenceEquals(result.Warnings![0], previousWarning), "Earlier warnings must be preserved.");
        Require(result.Warnings.Count == 2 && result.Warnings.Last().Code == BackendErrorCodes.TraderDisabled,
            "Rejection must append a TraderDisabled warning.");
        if (CompletePatch.Prefix(profile, new() { QuestId = repeatableId }, session, ref result)) originalMutations++;
        if (RepeatableChangePatch.Prefix(profile, new() { QuestId = repeatableId }, session, ref result)) originalMutations++;
        Require(originalMutations == 0, "Remote completion/replacement must stop before rewards or charges.");
        Require(JsonSerializer.Serialize(profile, jsonOptions) == beforeProfile, "Denied requests must never modify profile data.");

        trader.Disabled = false;
        int outputCalls = outputs.Calls;
        var sentinelResult = new ItemEventRouterResponse();
        result = sentinelResult;
        Require(HandoverPatch.Prefix(profile, new() { QuestId = normalId }, session, ref result), "Local item handover must run native logic.");
        Require(CompletePatch.Prefix(profile, new() { QuestId = repeatableId }, session, ref result), "Local repeatable completion must run native logic.");
        Require(RepeatableChangePatch.Prefix(profile, new() { QuestId = repeatableId }, session, ref result), "Local replacement must run native logic.");
        Require(ReferenceEquals(result, sentinelResult) && outputs.Calls == outputCalls, "Pass-through must not touch output or manufacture a result.");
        trader.Disabled = null;
        Require(CompletePatch.Prefix(profile, new() { QuestId = normalId }, session, ref result), "Unset availability must retain native validation.");
        trader.Disabled = true;
        Require(CompletePatch.Prefix(profile, new() { QuestId = unknownId }, session, ref result), "Unknown quest must retain native validation.");
        var repeatables = profile.RepeatableQuests;
        profile.RepeatableQuests = null;
        Require(CompletePatch.Prefix(profile, new() { QuestId = unknownId }, session, ref result), "Unknown quest without repeatables must retain native validation.");
        profile.RepeatableQuests = repeatables;
        profile.TradersInfo.Clear();
        Require(HandoverPatch.Prefix(profile, new() { QuestId = normalId }, session, ref result), "Unknown trader must retain native validation.");
        Require(HandoverPatch.Prefix(null, new() { QuestId = normalId }, session, ref result), "Missing profile must retain native validation.");
        Require(CompletePatch.Prefix(profile, null, session, ref result), "Missing request must retain native validation.");
        Require(outputs.Calls == outputCalls, "Unknown/malformed pass-through must not create event responses.");
        profile.TradersInfo[traderId] = trader;

        // Patch the actual installed callbacks. Their controllers are absent: any
        // request that reaches an original method fails immediately. This proves
        // remote denial happens before its mutation path, without a live server.
        var callbacks = new QuestCallbacks(responses, null!, null!);
        AbstractPatch[] patches = [new HandoverPatch(), new CompletePatch(), new RepeatableChangePatch()];
        foreach (var patch in patches) patch.Enable();
        try
        {
            Require(patches.All(p => p.IsActive), "All three real Harmony hooks must activate.");
            Require(ReferenceEquals(callbacks.HandoverQuest(profile, new() { QuestId = normalId }, session), outputs.Shared), "Real remote handover must skip original.");
            Require(ReferenceEquals(callbacks.CompleteQuest(profile, new() { QuestId = repeatableId }, session), outputs.Shared), "Real remote repeatable completion must skip original.");
            Require(ReferenceEquals(callbacks.ChangeRepeatableQuest(profile, new() { QuestId = repeatableId }, session), outputs.Shared), "Real remote reroll must skip original.");
            trader.Disabled = false;
            NativeReached(() => callbacks.HandoverQuest(profile, new() { QuestId = normalId }, session), "Local handover must reach original.");
            NativeReached(() => callbacks.CompleteQuest(profile, new() { QuestId = normalId }, session), "Local completion must reach original.");
            NativeReached(() => callbacks.ChangeRepeatableQuest(profile, new() { QuestId = repeatableId }, session), "Local replacement must reach original.");
            trader.Disabled = true;
            NativeReached(() => callbacks.CompleteQuest(profile, new() { QuestId = unknownId }, session), "Unknown quest must reach native validation.");
            NativeReached(() => callbacks.AcceptQuest(profile, new() { QuestId = normalId }, session), "Remote acceptance must remain unpatched.");
        }
        finally { foreach (var patch in patches) patch.Disable(); }
        var metadata = new ModMetadata();
        Require(metadata.SptVersion.IsSatisfied(new SemanticVersioning.Version(4, 0, 13)), "Version pin must accept installed SPT.");
        Require(!metadata.SptVersion.IsSatisfied(new SemanticVersioning.Version(4, 0, 14)), "Version pin must reject changed SPT.");
        Console.WriteLine($"PASS: {checks} local turn-in checks; real Harmony callbacks, native normal/repeatable lookup, pre-mutation rejection, shared-output preservation, local/unknown pass-through, unchanged acceptance, exact version pin.");
    }

    private static void NativeReached(Action invoke, string message)
    {
        try { invoke(); }
        catch (NullReferenceException) { Require(true, message); return; }
        throw new Exception(message);
    }
    private static void Require(bool condition, string message)
    { if (!condition) throw new Exception(message); checks++; }
}

internal sealed class FixtureDatabase(Dictionary<MongoId, Quest> quests) : DatabaseService(null!, null!, null!)
{
    public override Dictionary<MongoId, Quest> GetQuests() => quests;
}

internal sealed class FixtureOutputs(MongoId session) : EventOutputHolder(null!, null!, null!)
{
    public int Calls { get; private set; }
    public ItemEventRouterResponse Shared { get; } = new()
    {
        ProfileChanges = new() { [session] = new ProfileChange() },
        Warnings = [new Warning { Code = BackendErrorCodes.UnknownError, ErrorMessage = "Earlier action warning" }]
    };
    public override ItemEventRouterResponse GetOutput(MongoId sessionId)
    {
        if (sessionId != session) throw new Exception("Unexpected session ID.");
        Calls++;
        return Shared;
    }
}
