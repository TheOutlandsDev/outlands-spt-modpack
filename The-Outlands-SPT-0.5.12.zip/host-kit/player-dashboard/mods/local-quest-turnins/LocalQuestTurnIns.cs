using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using SPTarkov.DI.Annotations;
using SPTarkov.Reflection.Patching;
using SPTarkov.Server.Core.Callbacks;
using SPTarkov.Server.Core.DI;
using SPTarkov.Server.Core.Helpers;
using SPTarkov.Server.Core.Models.Common;
using SPTarkov.Server.Core.Models.Eft.Common;
using SPTarkov.Server.Core.Models.Eft.ItemEvent;
using SPTarkov.Server.Core.Models.Eft.Quests;
using SPTarkov.Server.Core.Models.Enums;
using SPTarkov.Server.Core.Models.Spt.Mod;
using SPTarkov.Server.Core.Models.Utils;
using SPTarkov.Server.Core.Routers;
using SPTarkov.Server.Core.Utils;

namespace Outlands.LocalQuestTurnIns;

public record ModMetadata : AbstractModMetadata
{
    public override string ModGuid { get; init; } = "outlands.local-quest-turnins";
    public override string Name { get; init; } = "Outlands Local Quest Turn-ins";
    public override string Author { get; init; } = "TheOutlandsDev";
    public override List<string>? Contributors { get; init; }
    public override SemanticVersioning.Version Version { get; init; } = new(1, 0, 0);
    public override SemanticVersioning.Range SptVersion { get; init; } = new("=4.0.13");
    public override List<string>? Incompatibilities { get; init; }
    public override Dictionary<string, SemanticVersioning.Range>? ModDependencies { get; init; }
    public override string? Url { get; init; }
    public override bool? IsBundleMod { get; init; } = false;
    public override string License { get; init; } = "MIT";
}

/// <summary>Consult the transit mod's authoritative profile flag without changing it.</summary>
public sealed class TurnInPolicy(QuestHelper quests, EventOutputHolder outputs, HttpResponseUtil responses)
{
    public bool Before(PmcData? profile, MongoId questId, MongoId sessionId, ref ItemEventRouterResponse result)
    {
        // Unresolved data stays with native validation. AcceptQuest is never patched.
        if (profile?.TradersInfo == null) return true;
        // An incomplete profile may have no repeatable list. A database-only
        // lookup avoids throwing in the native helper's repeatable fallback.
        var quest = profile.RepeatableQuests == null
            ? quests.GetQuestsFromDb().FirstOrDefault(q => q.Id == questId)
            : quests.GetQuestFromDb(questId, profile);
        if (quest == null || !profile.TradersInfo.TryGetValue(quest.TraderId, out var trader) ||
            trader?.Disabled != true) return true;

        // Reuse the event batch's response so earlier actions/changes are preserved.
        result = responses.AppendErrorToOutput(outputs.GetOutput(sessionId),
            "This trader is inactive at your location. Accept new quests remotely; turn in items, complete quests, and replace repeatable quests locally.",
            BackendErrorCodes.TraderDisabled);
        return false;
    }
}

[Injectable(TypePriority = OnLoadOrder.PostSptModLoader + 1000)]
public sealed class LocalQuestTurnInsLoader(
    ISptLogger<LocalQuestTurnInsLoader> logger,
    QuestHelper quests, EventOutputHolder outputs, HttpResponseUtil responses) : IOnLoad
{
    private readonly AbstractPatch[] _patches = [new HandoverPatch(), new CompletePatch(), new RepeatableChangePatch()];

    public Task OnLoad()
    {
        QuestTurnInHooks.Configure(new TurnInPolicy(quests, outputs, responses));
        try
        {
            foreach (var patch in _patches)
            {
                patch.Enable();
                if (!patch.IsActive) throw new InvalidOperationException("Outlands local quest turn-in hook did not activate.");
            }
        }
        catch
        {
            foreach (var patch in _patches) if (patch.IsActive) patch.Disable();
            throw;
        }
        logger.Success("[Outlands.LocalQuestTurnIns] Local-only item handover, quest completion, and repeatable replacement enforced; all 3 hooks active. Remote acceptance unchanged.");
        return Task.CompletedTask;
    }
}

public static class QuestTurnInHooks
{
    private static TurnInPolicy? _policy;
    public static void Configure(TurnInPolicy policy) => _policy = policy ?? throw new ArgumentNullException(nameof(policy));
    public static bool Before(PmcData? profile, MongoId questId, MongoId sessionId, ref ItemEventRouterResponse result) =>
        (_policy ?? throw new InvalidOperationException("Local quest turn-in policy is not initialized."))
            .Before(profile, questId, sessionId, ref result);

    public static MethodBase Target(string name, Type requestType) =>
        typeof(QuestCallbacks).GetMethod(name, [typeof(PmcData), requestType, typeof(MongoId)])
        ?? throw new MissingMethodException("SPT 4.0.13 quest callback not found: " + name);
}

public sealed class HandoverPatch : AbstractPatch
{
    protected override MethodBase GetTargetMethod() => QuestTurnInHooks.Target(nameof(QuestCallbacks.HandoverQuest), typeof(HandoverQuestRequestData));
    [PatchPrefix]
    public static bool Prefix(PmcData? __0, HandoverQuestRequestData? __1, MongoId __2, ref ItemEventRouterResponse __result) =>
        __1 == null || QuestTurnInHooks.Before(__0, __1.QuestId, __2, ref __result);
}

public sealed class CompletePatch : AbstractPatch
{
    protected override MethodBase GetTargetMethod() => QuestTurnInHooks.Target(nameof(QuestCallbacks.CompleteQuest), typeof(CompleteQuestRequestData));
    [PatchPrefix]
    public static bool Prefix(PmcData? __0, CompleteQuestRequestData? __1, MongoId __2, ref ItemEventRouterResponse __result) =>
        __1 == null || QuestTurnInHooks.Before(__0, __1.QuestId, __2, ref __result);
}

public sealed class RepeatableChangePatch : AbstractPatch
{
    protected override MethodBase GetTargetMethod() => QuestTurnInHooks.Target(nameof(QuestCallbacks.ChangeRepeatableQuest), typeof(RepeatableQuestChangeRequest));
    [PatchPrefix]
    public static bool Prefix(PmcData? __0, RepeatableQuestChangeRequest? __1, MongoId __2, ref ItemEventRouterResponse __result) =>
        __1 == null || QuestTurnInHooks.Before(__0, __1.QuestId, __2, ref __result);
}
