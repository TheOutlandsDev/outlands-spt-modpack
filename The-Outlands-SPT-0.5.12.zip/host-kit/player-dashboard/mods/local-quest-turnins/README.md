# Local quest turn-ins for node-01

This small SPT 4.0.13 server policy allows the remote quest client patch to accept
new quests while retaining location requirements for handing over items,
completing quests, and replacing daily/weekly quests. It checks the existing
transit mod's `PmcData.TradersInfo[quest.TraderId].Disabled` flag; it never changes
that flag, unlocks traders, alters prerequisites, removes items, or grants rewards.
The client patch supplies the remote Tasks screen and hides restricted controls.

Three prefixes guard `QuestCallbacks.HandoverQuest`, `CompleteQuest`, and
`ChangeRepeatableQuest`. An explicitly disabled trader gets a `TraderDisabled`
warning before the original method can change inventory, rewards, quest status,
or repeatable replacement costs. The warning is appended to the shared
`EventOutputHolder` response so earlier actions in a batch remain represented.
Acceptance is untouched. Local traders, absent availability flags, unresolved
quests/traders, and malformed requests retain native validation.

The native `QuestHelper.GetQuestFromDb(questId, profile)` lookup resolves both
normal database quests and repeatable quests in the profile's active quest lists.
The policy depends on the existing transit mod maintaining authoritative trader
availability and is intentionally pinned to SPT 4.0.13. Recheck all contracts when
upgrading. It does not require a Fika-specific hook.

Build and run isolated tests from the SPT workspace:

```sh
python3 player-dashboard/mods/local-quest-turnins/build.py --output /tmp/outlands-local-quest-turnins --test
```

The build downloads nothing. Tests use in-memory models, the actual installed
SPT quest lookup and error helper, and real Harmony callback hooks with absent
controllers. They confirm rejection before original methods, profile preservation,
shared-output preservation, local/unknown pass-through, repeatable lookup, and
unchanged acceptance. They never contact the live server or load player profiles.

To install while no raid is running, place only the generated
`Outlands.LocalQuestTurnIns.dll` in
`runtime/SPT/user/mods/zzz-OutlandsLocalQuestTurnIns/`, then restart the backend.
Verify this startup message:

```text
[Outlands.LocalQuestTurnIns] Local-only item handover, quest completion, and repeatable replacement enforced; all 3 hooks active. Remote acceptance unchanged.
```

To revert, remove that mod directory and restart the backend while idle. Existing
quests, items, profiles, and transit configuration are preserved. In-game menu
behavior still needs checking on a Windows client using the matching remote
quest patch.

Source in this directory is MIT licensed. Referenced SPT assemblies remain local
and retain their own licenses.
