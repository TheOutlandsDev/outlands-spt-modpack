using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Loader;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using FikaServer.Controllers;
using FikaServer.Helpers;
using FikaServer.Models.Fika.Headless;
using FikaServer.Models.Fika.Routes.Headless;
using FikaServer.Services.Headless;
using HarmonyLib;
using Outlands.Maintenance;

internal static class Program
{
    private static int checks;
    private static void Main(string[] args)
    {
        string core = Path.Combine(args[0], "runtime", "SPT");
        bool discovery = args.Length > 1 && args[1] == "--discovery";
        AssemblyLoadContext.Default.Resolving += (_, name) =>
        {
            foreach (string folder in discovery ? new[] { core } : new[] { core, Path.Combine(core, "user", "mods", "fika-server") })
            {
                string path = Path.Combine(folder, name.Name + ".dll");
                if (File.Exists(path)) return AssemblyLoadContext.Default.LoadFromAssemblyPath(path);
            }
            return null;
        };
        if (discovery)
        {
            var assembly = AssemblyLoadContext.Default.LoadFromAssemblyPath(args[2]);
            Console.WriteLine("PASS: core-only mod discovery without Fika loaded; types=" + assembly.GetTypes().Length);
            return;
        }
        var executable = Assembly.GetExecutingAssembly().Location;
        var start = new ProcessStartInfo(Environment.ProcessPath!) { UseShellExecute = false, RedirectStandardOutput = true, RedirectStandardError = true };
        start.ArgumentList.Add(executable);
        start.ArgumentList.Add(args[0]);
        start.ArgumentList.Add("--discovery");
        start.ArgumentList.Add(Path.Combine(Path.GetDirectoryName(executable)!, "Outlands.Maintenance.dll"));
        using (var process = Process.Start(start)!)
        {
            string output = process.StandardOutput.ReadToEnd();
            string errors = process.StandardError.ReadToEnd();
            process.WaitForExit();
            Require(process.ExitCode == 0, "Mod must be discoverable before Fika loads: " + errors);
            Console.Write(output);
        }
        Run();
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private static void Run()
    {
        string directory = Path.Combine(Path.GetTempPath(), "outlands-maintenance-test-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(directory);
        try { RunFixtures(directory); }
        finally { Directory.Delete(directory, recursive: true); }
    }

    private static void RunFixtures(string directory)
    {
        DateTimeOffset now = DateTimeOffset.Parse("2026-10-24T09:00:00Z");
        string leaseId = "75b59888-6024-43e4-b8c4-eac2b8073114";
        string otherId = "4f6f64d8-bdb3-4b0b-9a42-034092e71303";
        string control = Path.Combine(directory, "control.json");
        string ack = Path.Combine(directory, "ack.json");
        var warnings = new List<string>();
        var state = new MaintenanceState(directory, () => now, warnings.Add);
        state.MarkLoaded(true);
        MaintenanceHooks.Configure(state);
        Require(!state.Read().Draining, "Missing control file must permit new raids.");
        using (var document = JsonDocument.Parse(File.ReadAllText(ack)))
        {
            var root = document.RootElement;
            Require(root.GetProperty("schemaVersion").GetInt32() == 1 && root.GetProperty("loaded").GetBoolean(), "Startup acknowledgement must report loaded schema version 1.");
            Require(root.GetProperty("leaseId").ValueKind == JsonValueKind.Null && !root.GetProperty("draining").GetBoolean(), "Inactive ack must have null lease ID.");
            Require(root.GetProperty("inFlightAdmissions").GetInt32() == 0, "Startup acknowledgement must confirm no in-flight admissions.");
            Require(DateTimeOffset.Parse(root.GetProperty("checkedAtUtc").GetString()!) == now, "Ack must contain the injected current UTC time.");
        }

        WriteIntent(leaseId, now.AddSeconds(90));
        var decision = state.Read();
        Require(decision.Draining && decision.LeaseId == leaseId && decision.Message == "Maintenance in progress.", "Valid short lease must activate the gate.");
        using (var document = JsonDocument.Parse(File.ReadAllText(ack)))
            Require(document.RootElement.GetProperty("leaseId").GetString() == leaseId && document.RootElement.GetProperty("draining").GetBoolean(), "Ack must confirm the exact active worker lease.");

        var start = new StartHeadlessRequest { HeadlessSessionID = "000000000000000000000001" };
        string startBefore = JsonSerializer.Serialize(start);
        Task<StartHeadlessResponse> response = null!;
        Require(!HeadlessStartPatch.Prefix(ref response, out var deniedToken) && deniedToken == null, "Active gate must deny the production start prefix without counting an admission.");
        Require(response.IsCompletedSuccessfully && response.Result.MatchId == null && response.Result.Error == "Maintenance in progress.", "Denial must use a completed native error response rather than faulting.");
        Require(JsonSerializer.Serialize(start) == startBefore, "Gate must not change raid settings.");
        HeadlessAvailableClients[] available = null!;
        Require(!HeadlessAvailabilityPatch.Prefix(ref available) && available.Length == 0, "Active gate must hide available headless choices.");

        // Exercise actual installed Fika methods. Their dependencies are absent,
        // so reaching an original throws before any state/network/profile action.
        var controller = new RaidController(null!, null!, null!, null!, null!, null!, null!);
        var helper = (HeadlessHelper)RuntimeHelpers.GetUninitializedObject(typeof(HeadlessHelper));
        var startPatch = new HeadlessStartPatch();
        var availablePatch = new HeadlessAvailabilityPatch();
        startPatch.Enable();
        availablePatch.Enable();
        try
        {
            Require(startPatch.IsActive && availablePatch.IsActive, "Both real Harmony hooks must activate.");
            var nativeResponse = controller.HandleRaidStartHeadless("000000000000000000000002", start).GetAwaiter().GetResult();
            Require(nativeResponse.MatchId == null && nativeResponse.Error == "Maintenance in progress.", "Real Fika callback must deny before original mutation path.");
            Require(helper.GetAvailableHeadlessClients().Length == 0, "Real Fika availability method must return no new choices while draining.");
            foreach (string name in new[] { nameof(RaidController.HandleRaidJoin), nameof(RaidController.HandleRaidLeave), nameof(RaidController.HandleRaidCreate) })
            {
                var patches = Harmony.GetPatchInfo(typeof(RaidController).GetMethod(name)!);
                Require(patches == null || patches.Prefixes.All(p => p.PatchMethod.DeclaringType?.Namespace != "Outlands.Maintenance"), "Existing raid operation must remain unpatched: " + name);
            }
            Require(Harmony.GetPatchInfo(typeof(HeadlessService).GetMethod(nameof(HeadlessService.EndHeadlessRaid))!) == null,
                "Maintenance gate must not patch raid completion.");

            File.Delete(control);
            Require(!state.Read().Draining, "Deleting control must release even an unexpired lease.");
            var sentinel = Task.FromResult(new StartHeadlessResponse { Error = "sentinel" });
            response = sentinel;
            Require(HeadlessStartPatch.Prefix(ref response, out var passToken) && ReferenceEquals(response, sentinel), "Inactive start prefix must preserve native execution and output.");
            passToken!.Dispose();
            NativeReached(() => controller.HandleRaidStartHeadless("000000000000000000000002", start).GetAwaiter().GetResult(), "Real start callback must reach native behavior after release.");
            NativeReached(() => helper.GetAvailableHeadlessClients(), "Real availability must reach native behavior after release.");
        }
        finally { availablePatch.Disable(); startPatch.Disable(); }

        // A start admitted before the lease may still be awaiting Fika. Track the
        // real production postfix until completion so the worker cannot confuse
        // a quiet snapshot with an idle backend during this gap.
        File.Delete(control);
        response = null!;
        Require(HeadlessStartPatch.Prefix(ref response, out var pendingToken), "Inactive gate must admit an asynchronous native start.");
        var pending = new TaskCompletionSource<StartHeadlessResponse>(TaskCreationOptions.RunContinuationsAsynchronously);
        response = pending.Task;
        HeadlessStartPatch.Postfix(ref response, pendingToken);
        Require(ReferenceEquals(response, pending.Task), "Tracking must preserve the original native task identity.");
        WriteIntent(leaseId, now.AddSeconds(90));
        state.Read();
        Require(AckCount() == 1, "A newly active lease must acknowledge the earlier start still in flight.");
        HeadlessStartPatch.Finalizer(null, pendingToken);
        Require(AckCount() == 1, "A normal Harmony finalizer must not release an incomplete asynchronous start.");
        pending.SetResult(new StartHeadlessResponse { MatchId = "fixture-match" });
        Require(response.GetAwaiter().GetResult().MatchId == "fixture-match" && SpinWait.SpinUntil(() => AckCount() == 0, 2000), "Native task completion must preserve response and release its admission.");
        pendingToken!.Dispose();
        Require(AckCount() == 0, "Admission completion must be idempotent and never go negative.");
        File.Delete(control);
        Require(HeadlessStartPatch.Prefix(ref response, out var syncToken), "Sync-exception fixture must be admitted before its original runs.");
        var originalError = new InvalidOperationException("fixture original failure");
        Require(ReferenceEquals(HeadlessStartPatch.Finalizer(originalError, syncToken), originalError) && AckCount() == 0,
            "Synchronous original failure must release once and preserve the original exception.");
        Require(HeadlessStartPatch.Prefix(ref response, out var faultToken), "Faulted-task fixture must be admitted.");
        response = Task.FromException<StartHeadlessResponse>(originalError);
        HeadlessStartPatch.Postfix(ref response, faultToken);
        try { response.GetAwaiter().GetResult(); throw new Exception("Original task failure was swallowed."); }
        catch (InvalidOperationException error) { Require(ReferenceEquals(error, originalError) && AckCount() == 0, "Faulted native task must release admission and preserve its exception."); }

        WriteIntent(leaseId, now.AddSeconds(90));
        Require(state.Read().Draining, "Gate can activate again after release.");
        File.WriteAllText(control, "{secret-from-invalid-input");
        Require(state.Read().LeaseId == leaseId, "Malformed replacement must retain previous valid lease.");
        state.Read();
        Require(warnings.Count == 1 && !warnings[0].Contains("secret"), "Invalid intent warnings must be throttled and never contain file contents.");
        WriteIntent(otherId, now.AddSeconds(121));
        Require(state.Read().LeaseId == leaseId, "A lease beyond maximum future duration must not replace a valid lease.");
        File.WriteAllText(control, new string('x', 5000));
        Require(state.Read().LeaseId == leaseId, "Oversized intent must not replace a valid lease.");
        now = now.AddSeconds(61);
        state.Read();
        Require(warnings.Count == 2, "Repeated invalid input may log at most once each minute.");
        now = now.AddSeconds(30);
        Require(!state.Read().Draining, "Invalid replacement cannot keep a previous lease beyond its original expiry.");
        WriteIntent(otherId, now.AddSeconds(90));
        Require(state.Read().LeaseId == otherId, "A fresh new valid lease must activate.");
        WriteIntent(otherId, now.AddSeconds(90), draining: false);
        Require(!state.Read().Draining, "An explicit release must permit native starts.");
        WriteIntent(otherId, now.AddSeconds(-1));
        Require(!state.Read().Draining, "An expired lease must never activate a permanent gate.");
        WriteIntent(otherId, now.AddSeconds(120));
        Require(state.Read().Draining, "A lease at the exact maximum horizon must be accepted.");
        now = now.AddSeconds(121);
        Require(!state.Read().Draining, "Worker failure must release the gate after TTL.");
        Require(!Directory.EnumerateFiles(directory, ".ack-*.tmp").Any(), "Atomic ack writes must leave no temporary files.");
        state.MarkLoaded(false);
        state.Read();
        using (var document = JsonDocument.Parse(File.ReadAllText(ack)))
            Require(!document.RootElement.GetProperty("loaded").GetBoolean(), "Failed startup cleanup must withdraw loaded acknowledgement.");
        var brokenTimer = new MaintenanceState(directory, () => throw new IOException("private-error"), _ => throw new IOException("logger-error"));
        brokenTimer.RefreshSafely();
        Require(true, "Timer refresh must catch unexpected and logging failures.");

        var metadata = new ModMetadata();
        Require(metadata.SptVersion.IsSatisfied(new SemanticVersioning.Version(4, 0, 13)), "SPT pin must accept 4.0.13.");
        Require(!metadata.SptVersion.IsSatisfied(new SemanticVersioning.Version(4, 0, 14)), "SPT pin must reject another version.");
        Require(metadata.ModDependencies!["Fika"].IsSatisfied(new SemanticVersioning.Version(2, 2, 4)), "Fika pin must accept 2.2.4.");
        Require(!metadata.ModDependencies["Fika"].IsSatisfied(new SemanticVersioning.Version(2, 2, 5)), "Fika pin must reject another version.");
        Console.WriteLine($"PASS: {checks} maintenance checks; real Fika hooks, native error/pass-through, existing joins untouched, bounded expiring lease, previous-lease recovery, atomic acknowledgement, safe timer, version pins.");

        void WriteIntent(string id, DateTimeOffset expiresAt, bool draining = true) => File.WriteAllText(control,
            JsonSerializer.Serialize(new { schemaVersion = 1, leaseId = id, expiresAtUtc = expiresAt.ToString("O"), draining, message = "Maintenance in progress." }));
        int AckCount()
        {
            using var document = JsonDocument.Parse(File.ReadAllText(ack));
            return document.RootElement.GetProperty("inFlightAdmissions").GetInt32();
        }
    }

    private static void NativeReached(Action action, string message)
    {
        try { action(); }
        catch (NullReferenceException) { Require(true, message); return; }
        throw new Exception(message);
    }
    private static void Require(bool condition, string message)
    { if (!condition) throw new Exception(message); checks++; }
}
