# Expiring maintenance gate for node-01

This server mod prevents new Fika headless raid admissions while the separate
maintenance worker waits for existing raids to finish. It is pinned to SPT 4.0.13
and Fika Server 2.2.4. The mod never stops containers, shuts down a raid, changes
profiles, alters raid settings, broadcasts notices, or opens an HTTP endpoint.

`RaidController.HandleRaidStartHeadless` returns the native
`StartHeadlessResponse` with a clear error during a valid drain lease. Headless
availability also returns an empty array. Existing joins, leaves, headless match
creation, and completion keep their original behavior, including raids already
loading when draining starts. Direct hosting from a player's client is outside
this gate's scope; this deployment uses the headless host.

The worker atomically writes this intent to the installed mod's own directory,
`runtime/SPT/user/mods/zzz-OutlandsMaintenance/control.json`:

```json
{"schemaVersion":1,"leaseId":"75b59888-6024-43e4-b8c4-eac2b8073114","expiresAtUtc":"2026-10-24T09:01:30Z","draining":true,"message":"Maintenance is waiting for existing raids to finish."}
```

Use a UUID lease ID, UTC ISO timestamp, and expiry more than zero and at most 120
seconds in the future. The worker should use a 90-second TTL and refresh every
15 seconds. Messages are limited to 240 characters without control characters.
Input is bounded to 4096 bytes. Missing control or a valid `draining:false`
intent permits native starts. Malformed replacements retain the previous valid
lease only through its original expiry. If the worker fails, the gate expires;
it cannot leave a permanent maintenance lock. Invalid input is logged using a
redacted constant message at most once a minute.

The mod atomically writes `ack.json` at successful startup, every 10 seconds, and
when an admission/availability request rechecks the lease:

```json
{"schemaVersion":1,"loaded":true,"checkedAtUtc":"2026-10-24T09:00:00+00:00","leaseId":"75b59888-6024-43e4-b8c4-eac2b8073114","draining":true,"inFlightAdmissions":0}
```

An inactive acknowledgement has `leaseId:null` and `draining:false`. The worker
must require a fresh, loaded acknowledgement for its exact drain lease and
`inFlightAdmissions:0` before trusting drain status. Starts admitted just before
the drain are counted until their native asynchronous callback finishes, including
faults and synchronous exceptions. Completion is idempotent. It must separately confirm live headless/match/presence
data are fresh and idle across repeated samples, and allow profile-save time.
This module's acknowledgement alone is never permission to stop a raid.
The dashboard may display a sanitized read-only maintenance report; it gets no
write access to this control file or container actions.

Build and run isolated tests:

```sh
python3 player-dashboard/mods/maintenance/build.py --output /tmp/outlands-maintenance --test
```

Tests use a temporary directory and in-memory fixtures. They exercise the actual
installed Fika Harmony methods with absent dependencies, proving the gate returns
before its original start path, then permits native behavior after release.
They also check unaffected existing raid operations, lease expiry/recovery,
atomic acknowledgement, safe timer errors, redacted logging, and exact version
pins. A separate fresh process verifies mod type discovery with only SPT core
dependencies available, before Fika is loaded. Admission completion uses a
non-generic task continuation and preserves the native task unchanged; no
compiler-generated async state machine can force early Fika dependency loading.
Tests do not contact the live server or load player profiles.

Install only `Outlands.Maintenance.dll` in
`runtime/SPT/user/mods/zzz-OutlandsMaintenance/`. Loading a new mod requires an
initial backend restart while idle; do not interrupt a playtest to activate it.
Verify this startup message and a fresh loaded acknowledgement:

```text
[Outlands.Maintenance] New headless raid admission gate loaded; lease acknowledgements every 10 seconds. Existing raids and joins remain available.
```

To release a drain, remove `control.json` or write a valid `draining:false` intent.
To remove the policy, remove its installed mod directory and restart while idle.
The timer writes only the mod's own acknowledgement file. Source is MIT licensed;
referenced game/SPT/Fika assemblies remain local under their own licenses.
