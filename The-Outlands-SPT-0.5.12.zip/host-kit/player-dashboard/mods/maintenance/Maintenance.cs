using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using FikaServer.Controllers;
using FikaServer.Helpers;
using FikaServer.Models.Fika.Headless;
using FikaServer.Models.Fika.Routes.Headless;
using SPTarkov.DI.Annotations;
using SPTarkov.Reflection.Patching;
using SPTarkov.Server.Core.DI;
using SPTarkov.Server.Core.Models.Common;
using SPTarkov.Server.Core.Models.Spt.Mod;
using SPTarkov.Server.Core.Models.Utils;

namespace Outlands.Maintenance;

public record ModMetadata : AbstractModMetadata
{
    public override string ModGuid { get; init; } = "outlands.maintenance";
    public override string Name { get; init; } = "Outlands Maintenance Admission Gate";
    public override string Author { get; init; } = "TheOutlandsDev";
    public override List<string>? Contributors { get; init; }
    public override SemanticVersioning.Version Version { get; init; } = new(1, 0, 0);
    public override SemanticVersioning.Range SptVersion { get; init; } = new("=4.0.13");
    public override List<string>? Incompatibilities { get; init; }
    public override Dictionary<string, SemanticVersioning.Range>? ModDependencies { get; init; } =
        new() { ["Fika"] = new("=2.2.4") };
    public override string? Url { get; init; }
    public override bool? IsBundleMod { get; init; } = false;
    public override string License { get; init; } = "MIT";
}

public sealed record GateDecision(bool Draining, string? LeaseId, string Message);

public sealed class AdmissionToken(MaintenanceState state) : IDisposable
{
    private MaintenanceState? _state = state;
    public void Dispose() => Interlocked.Exchange(ref _state, null)?.CompleteAdmission();
}

/// <summary>A short file lease blocks new admissions while existing raids continue.</summary>
public sealed class MaintenanceState(string directory, Func<DateTimeOffset> utcNow, Action<string> warn)
{
    public const int MaxLeaseSeconds = 120;
    public const string DefaultMessage = "Daily maintenance is waiting for existing raids to finish. New headless raids will be available after the server is ready.";
    private readonly object _sync = new();
    private readonly string _directory = Path.GetFullPath(directory);
    private GateDecision _decision = new(false, null, DefaultMessage);
    private DateTimeOffset _expiresAtUtc;
    private DateTimeOffset? _lastWarning;
    private bool _loaded;
    private int _inFlightAdmissions;

    public void MarkLoaded(bool loaded) { lock (_sync) _loaded = loaded; }

    public bool TryAdmit(out GateDecision decision, out AdmissionToken? admission)
    {
        lock (_sync)
        {
            decision = Read();
            admission = null;
            if (decision.Draining) return false;
            _inFlightAdmissions = checked(_inFlightAdmissions + 1);
            admission = new AdmissionToken(this);
            RefreshSafely();
            return true;
        }
    }

    internal void CompleteAdmission()
    {
        lock (_sync)
        {
            if (_inFlightAdmissions <= 0) throw new InvalidOperationException("Maintenance admission accounting underflow.");
            _inFlightAdmissions--;
            RefreshSafely();
        }
    }

    public void RefreshSafely()
    {
        try { Read(); }
        catch
        {
            lock (_sync) Warning(DateTimeOffset.UtcNow,
                "[Outlands.Maintenance] Maintenance acknowledgement refresh failed; automatic restart must wait.");
        }
    }

    public GateDecision Read()
    {
        lock (_sync)
        {
            DateTimeOffset now = utcNow().ToUniversalTime();
            if (_decision.Draining && _expiresAtUtc <= now) Clear();
            string control = Path.Combine(_directory, "control.json");
            try
            {
                if (!File.Exists(control)) Clear();
                else
                {
                    using var stream = new FileStream(control, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
                    if (stream.Length > 4096) throw new InvalidDataException();
                    using var document = JsonDocument.Parse(stream, new JsonDocumentOptions { MaxDepth = 8 });
                    JsonElement root = document.RootElement;
                    if (root.ValueKind != JsonValueKind.Object ||
                        !root.TryGetProperty("schemaVersion", out var schema) || !schema.TryGetInt32(out int version) || version != 1 ||
                        !root.TryGetProperty("draining", out var draining) || draining.ValueKind is not (JsonValueKind.True or JsonValueKind.False) ||
                        !root.TryGetProperty("leaseId", out var leaseId) || leaseId.ValueKind != JsonValueKind.String ||
                        !Guid.TryParseExact(leaseId.GetString(), "D", out var leaseGuid) || leaseGuid == Guid.Empty)
                        throw new InvalidDataException();

                    if (!draining.GetBoolean()) Clear();
                    else
                    {
                        if (!root.TryGetProperty("expiresAtUtc", out var expiry) || expiry.ValueKind != JsonValueKind.String ||
                            !DateTimeOffset.TryParse(expiry.GetString(), CultureInfo.InvariantCulture,
                                DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal, out var expiresAt) ||
                            expiresAt <= now || expiresAt > now.AddSeconds(MaxLeaseSeconds))
                            throw new InvalidDataException();
                        string message = DefaultMessage;
                        if (root.TryGetProperty("message", out var supplied))
                        {
                            if (supplied.ValueKind != JsonValueKind.String) throw new InvalidDataException();
                            string? text = supplied.GetString();
                            if (text == null || text.Length > 240 || text.Any(char.IsControl)) throw new InvalidDataException();
                            if (!string.IsNullOrWhiteSpace(text)) message = text.Trim();
                        }
                        _expiresAtUtc = expiresAt;
                        _decision = new(true, leaseGuid.ToString("D"), message);
                    }
                }
            }
            catch (Exception error) when (error is IOException or InvalidDataException or UnauthorizedAccessException or JsonException or InvalidOperationException)
            {
                // Keep a previous valid lease only until its original expiry.
                // Never log file contents, user-supplied errors, or credentials.
                Warning(now, "[Outlands.Maintenance] Invalid or unreadable maintenance intent; retaining an unexpired prior lease only.");
            }

            try { WriteAck(now); }
            catch (Exception error) when (error is IOException or UnauthorizedAccessException)
            { Warning(now, "[Outlands.Maintenance] Maintenance acknowledgement could not be written; automatic restart must wait for a fresh acknowledgement."); }
            return _decision;
        }
    }

    private void Clear() { _decision = new(false, null, DefaultMessage); _expiresAtUtc = default; }

    private void WriteAck(DateTimeOffset now)
    {
        string temporary = Path.Combine(_directory, ".ack-" + Guid.NewGuid().ToString("N") + ".tmp");
        try
        {
            File.WriteAllText(temporary, JsonSerializer.Serialize(new
            {
                schemaVersion = 1, loaded = _loaded, checkedAtUtc = now.ToString("O"),
                leaseId = _decision.LeaseId, draining = _decision.Draining,
                inFlightAdmissions = _inFlightAdmissions
            }) + "\n");
            File.Move(temporary, Path.Combine(_directory, "ack.json"), overwrite: true);
        }
        finally { if (File.Exists(temporary)) File.Delete(temporary); }
    }

    private void Warning(DateTimeOffset now, string message)
    {
        if (_lastWarning.HasValue && now - _lastWarning.Value < TimeSpan.FromMinutes(1)) return;
        _lastWarning = now;
        try { warn(message); } catch { /* A logging failure must not stop the timer or a raid request. */ }
    }
}

public static class MaintenanceHooks
{
    private static MaintenanceState? _state;
    public static void Configure(MaintenanceState state) => _state = state ?? throw new ArgumentNullException(nameof(state));
    public static GateDecision Read() =>
        (_state ?? throw new InvalidOperationException("Maintenance admission gate is not initialized.")).Read();
    public static bool TryAdmit(out GateDecision decision, out AdmissionToken? admission) =>
        (_state ?? throw new InvalidOperationException("Maintenance admission gate is not initialized."))
            .TryAdmit(out decision, out admission);
}

[Injectable(TypePriority = OnLoadOrder.PostSptModLoader + 1000)]
public sealed class MaintenanceLoader(ISptLogger<MaintenanceLoader> logger) : IOnLoad
{
    private readonly AbstractPatch[] _patches = [new HeadlessStartPatch(), new HeadlessAvailabilityPatch()];
    private Timer? _timer;

    public Task OnLoad()
    {
        string directory = Path.GetDirectoryName(typeof(MaintenanceLoader).Assembly.Location)
            ?? throw new InvalidOperationException("Maintenance mod directory could not be resolved.");
        var state = new MaintenanceState(directory, () => DateTimeOffset.UtcNow, message => logger.Warning(message));
        MaintenanceHooks.Configure(state);
        try
        {
            foreach (var patch in _patches)
            {
                patch.Enable();
                if (!patch.IsActive) throw new InvalidOperationException("Maintenance admission hook did not activate.");
            }
            state.MarkLoaded(true);
            state.Read();
            _timer = new Timer(_ => state.RefreshSafely(), null, TimeSpan.FromSeconds(10), TimeSpan.FromSeconds(10));
        }
        catch
        {
            _timer?.Dispose();
            state.MarkLoaded(false);
            state.RefreshSafely();
            foreach (var patch in _patches) if (patch.IsActive) patch.Disable();
            throw;
        }
        logger.Success("[Outlands.Maintenance] New headless raid admission gate loaded; lease acknowledgements every 10 seconds. Existing raids and joins remain available.");
        return Task.CompletedTask;
    }
}

public sealed class HeadlessStartPatch : AbstractPatch
{
    protected override MethodBase GetTargetMethod() => typeof(RaidController).GetMethod(
        nameof(RaidController.HandleRaidStartHeadless), [typeof(MongoId), typeof(StartHeadlessRequest)])
        ?? throw new MissingMethodException("Fika 2.2.4 headless raid callback was not found.");
    [PatchPrefix]
    public static bool Prefix(ref Task<StartHeadlessResponse> __result, out AdmissionToken? __state)
    {
        if (MaintenanceHooks.TryAdmit(out var decision, out __state)) return true;
        __result = Task.FromResult(new StartHeadlessResponse { MatchId = null, Error = decision.Message });
        return false;
    }

    [PatchPostfix]
    public static void Postfix(ref Task<StartHeadlessResponse> __result, AdmissionToken? __state)
    {
        if (__state == null) return;
        // SPT discovers mod types before resolving Fika assemblies. Keep the
        // continuation non-generic: an async state machine holding a Fika DTO
        // would force Fika resolution during discovery and silently skip this mod.
        // Preserve the original task, result, fault, and cancellation unchanged.
        _ = ((Task)__result).ContinueWith(static (_, state) => ((AdmissionToken)state!).Dispose(),
            __state, CancellationToken.None, TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Default);
    }

    [PatchFinalizer]
    public static Exception? Finalizer(Exception? __exception, AdmissionToken? __state)
    {
        if (__exception != null) __state?.Dispose();
        return __exception;
    }
}

public sealed class HeadlessAvailabilityPatch : AbstractPatch
{
    protected override MethodBase GetTargetMethod() => typeof(HeadlessHelper).GetMethod(
        nameof(HeadlessHelper.GetAvailableHeadlessClients), Type.EmptyTypes)
        ?? throw new MissingMethodException("Fika 2.2.4 headless availability method was not found.");
    [PatchPrefix]
    public static bool Prefix(ref HeadlessAvailableClients[] __result)
    {
        if (!MaintenanceHooks.Read().Draining) return true;
        __result = [];
        return false;
    }
}
