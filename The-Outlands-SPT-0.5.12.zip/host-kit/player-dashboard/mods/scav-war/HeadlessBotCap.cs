using System;
using System.Reflection;
using System.Threading.Tasks;
using FikaServer.Helpers;
using FikaServer.Services;
using SPTarkov.Reflection.Patching;
using SPTarkov.Server.Core.Callbacks;
using SPTarkov.Server.Core.Models.Common;

namespace Outlands.ScavWar;

// SPT 4.0.13 uses GameWorld.MainPlayer.Location to choose this endpoint. A
// headless GameWorld has no MainPlayer, so its correctly tuned map cap was
// overwritten by the stock default of 18. Human and named-map calls stay native.
public sealed class HeadlessBotCapPatch : AbstractPatch
{
    public const string FallbackUrl = "/singleplayer/settings/bot/maxCap/default";
    public static Func<MongoId, int?>? Resolve { get; set; }
    public static Action<string>? Log { get; set; }

    public static int? MatchCap(HeadlessHelper headless, MatchService matches, MongoId session)
    {
        if (!headless.HeadlessClients.ContainsKey(session)) return null;
        var match = matches.GetMatch(session) ?? matches.GetMatch(matches.GetMatchIdByProfile(session));
        return match?.LocationData?.BotMax;
    }

    protected override MethodBase GetTargetMethod() => typeof(BotCallbacks).GetMethod(nameof(BotCallbacks.GetBotCap))
        ?? throw new MissingMethodException("SPT 4.0.13 bot-cap callback was not found.");

    public static bool TryCap(string url, int? matchCap, out int cap)
    {
        cap = 0;
        if (url != FallbackUrl || matchCap is not (>= 1 and <= 64)) return false;
        cap = matchCap.Value;
        return true;
    }

    [PatchPrefix]
    public static bool Prefix(string __0, MongoId __2, ref ValueTask<string> __result)
    {
        if (__0 != FallbackUrl || Resolve is null) return true;
        int? candidate;
        try { candidate = Resolve(__2); }
        catch { return true; } // Missing match/identity must retain the native fallback.
        if (!TryCap(__0, candidate, out int cap)) return true;
        __result = ValueTask.FromResult(cap.ToString(System.Globalization.CultureInfo.InvariantCulture));
        Log?.Invoke($"[Outlands.ScavWar] Headless match bot cap: {cap} (replaces unmapped default lookup).");
        return false;
    }
}
