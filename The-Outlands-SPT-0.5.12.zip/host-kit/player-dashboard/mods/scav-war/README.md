# Scav War and map-specific headless bot limits

This small server mod enables Scav War for every Fika headless raid, without
requiring a Windows client plugin or ticking the checkbox each time. The client
checkbox can still appear unchecked: the host applies this policy after receiving
the request. Unticking it does not disable the host policy.

The patch changes only `StartHeadlessRequest.BotSettings.IsScavWars` immediately
before Fika sends the headless start message. It preserves bot amount, difficulty,
bosses, Tagged and Cursed, event, weather, map, and player settings. Normal Fika
availability checks and the original start method still run.

Version 1.1.0 also fixes the SPT 4.0.13 headless bot-limit fallback. SPT's
client patch selects a map through `GameWorld.MainPlayer`, which is absent on
headless hosts. Recent logs showed it replacing the raid limit with `default`
(18) on every map. For a registered headless session with a current Fika match,
the exact fallback callback now returns that match's `LocationData.BotMax`.
Human sessions, named-map requests, missing matches, and invalid caps keep the
native behavior. No global limit, spawn wave, aim, reaction-time, or profile is
changed by this hook. The first raid after installation must log
`Headless match bot cap: ...` to verify the live match resolution.

This policy is pinned to SPT 4.0.13 and Fika Server 2.2.4. Recheck the hook and
models before changing either version. It does not change raids hosted directly
by a player's game client.

Build and run the isolated tests from the SPT workspace:

```sh
python3 player-dashboard/mods/scav-war/build.py --output /tmp/outlands-scav-war --test
```

The build uses the already installed local libraries and .NET compiler; it
downloads nothing. Tests check settings preservation and exercise Harmony on the
real Fika method using an isolated service with no headless clients or sockets.
They do not start a raid or contact the live server.

To install while no raid is running, put only the generated `Outlands.ScavWar.dll`
in `runtime/SPT/user/mods/zzz-OutlandsScavWar/`, then restart the SPT backend. The
startup log must contain:

```text
[Outlands.ScavWar] Scav War is enforced for every Fika headless raid; hook active.
```

The loader checks that Harmony registered the hook. A real raid is still needed
to confirm the resulting AI behavior. To revert, remove that mod directory and
restart the backend while idle. No profiles or game binaries are replaced.

Reference sources:

- [Fika 2.2.4 headless start method](https://github.com/project-fika/Fika-Server-CSharp/blob/v2.2.4/FikaServer/Services/Headless/HeadlessService.cs)
- [Fika 2.2.4 request model](https://github.com/project-fika/Fika-Server-CSharp/blob/v2.2.4/FikaServer/Models/Fika/Routes/Headless/StartHeadlessRequest.cs)
- [SPT 4.0.13 bot settings model](https://github.com/sp-tarkov/server-csharp/blob/4.0.13/Libraries/SPTarkov.Server.Core/Models/Eft/Match/RaidSettings.cs)

Source in this directory is MIT licensed. Game, SPT, and Fika assemblies remain
local and retain their own licenses.
