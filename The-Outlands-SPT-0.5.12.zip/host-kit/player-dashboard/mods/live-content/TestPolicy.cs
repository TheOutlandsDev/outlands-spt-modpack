using System;using System.Collections.Generic;using System.Linq;using System.Reflection;using System.Runtime.Loader;using System.Runtime.CompilerServices;
using SPTarkov.Server.Core.Models.Eft.Common;using Outlands.LiveContent;
class Program {
 static int checks;static void Check(bool ok,string label){checks++;if(!ok)throw new Exception(label);}
 static void Main(string[] args){var root=System.IO.Path.Combine(args[0],"runtime","SPT");AssemblyLoadContext.Default.Resolving+=(_,n)=>{var p=System.IO.Path.Combine(root,n.Name+".dll");return System.IO.File.Exists(p)?AssemblyLoadContext.Default.LoadFromAssemblyPath(p):null;};Run();}
 [MethodImpl(MethodImplOptions.NoInlining)]static void Run(){
  var c=new CalendarConfig();
  foreach(var stamp in new[]{"2026-03-08T08:59:59Z","2026-11-01T09:59:59Z","2026-10-24T08:59:59Z"}){
   var utc=DateTimeOffset.Parse(stamp);var a=ContentCalendar.Select(utc,c);var b=ContentCalendar.Select(utc.AddSeconds(1),c);
   Check(DateTime.Parse(b.Day)==DateTime.Parse(a.Day).AddDays(1),stamp+" rollover/DST");
  }
  var first=DateTimeOffset.Parse("2026-01-01T12:00:00Z");var themes=new HashSet<string>();var hotspotMaps=new HashSet<string>();
  for(int i=0;i<370;i++){
   var now=first.AddDays(i);var a=ContentCalendar.Select(now,c);var b=ContentCalendar.Select(now,c);themes.Add(a.Theme);hotspotMaps.UnionWith(a.Hotspots);
   Check(a.Day==b.Day&&a.Theme==b.Theme&&a.Hotspots.SequenceEqual(b.Hotspots),"deterministic schedule");
   Check(a.Hotspots.Length==2&&a.Hotspots.Distinct().Count()==2,"two distinct hotspots");
   Check(a.LootMultiplier>=1&&a.LootMultiplier<=1.05&&a.BossChanceBonus<=10&&a.PmcChanceBonus<=7,"bounded event bonuses");
   Check(ContentCalendar.InfectionFor("Sandbox",a,c)==10&&ContentCalendar.InfectionFor("sandbox_high",a,c)==10,"beginner map protection");
   Check(ContentCalendar.InfectionFor("laboratory",a,c)==60,"lab infection");
  }
  Check(themes.Count==7&&hotspotMaps.Count==7,"full theme/map rotation");
  var campaigns=new HashSet<string>();var challenges=new HashSet<string>();
  for(int i=0;i<370;i++){
   var day=ContentCalendar.Select(first.AddDays(i),c);campaigns.Add(day.Campaign);challenges.Add(day.Challenges[0]);
   var primary=day.Operations[0].Modifiers;var secondary=day.Operations[1].Modifiers;
   Check(primary.PmcChanceBonus>secondary.PmcChanceBonus&&primary.PmcAdvanceSeconds>=secondary.PmcAdvanceSeconds,"primary/secondary intensity differs");
   Check(primary.ScavAdvanceSeconds<=45&&primary.PmcAdvanceSeconds<=45,"timing budget");
   Check(day.Operations.Length==2&&day.Challenges.Length==3&&day.Briefing.Length>30,"complete briefing and optional squad goals");
   Check(ContentCalendar.ModifiersFor("sandbox",day)==new MapTuning(0,0,0,0,1),"Ground Zero event tuning excluded");
   var future=ContentCalendar.Forecast(day,c);
   Check(future.Length==7&&future.Select(x=>x.Day).Distinct().Count()==7&&future[0].Day==DateTime.Parse(day.Day).AddDays(1).ToString("yyyy-MM-dd")&&future[6].Day==DateTime.Parse(day.Day).AddDays(7).ToString("yyyy-MM-dd"),"consecutive forecast including DST");
  }
  Check(campaigns.Count==4&&challenges.Count==7,"four campaign phases and seven themed squad challenges");
  var ordinary=new AdditionalHostilitySettings{BotRole="assault",AlwaysEnemies=new(){"pmcBEAR"},AlwaysFriends=new(){"infectedAssault","assault"},Neutral=new(){"infectedCivil"},SavagePlayerBehaviour="Neutral"};
  var rows=ContentCalendar.EnsureHostility(new[]{ordinary});Check(rows.Count==9,"missing rows added and retained");
  foreach(var scav in ContentCalendar.Scavs){var r=rows.Single(x=>x.BotRole==scav);Check(ContentCalendar.Infected.All(x=>r.AlwaysEnemies!.Contains(x)),"scav targets all infected");Check(r.AlwaysFriends==null||!ContentCalendar.Infected.Any(r.AlwaysFriends.Contains),"no infected friends");}
  Check(ordinary.AlwaysEnemies!.Contains("pmcBEAR")&&ordinary.SavagePlayerBehaviour=="Neutral"&&ordinary.AlwaysFriends!.Contains("assault"),"ordinary relationships retained");
  foreach(var role in ContentCalendar.Infected){var r=rows.Single(x=>x.BotRole==role);Check(ContentCalendar.Scavs.All(x=>r.AlwaysEnemies!.Contains(x)),"infected targets scavs");Check(r.SavagePlayerBehaviour=="AlwaysEnemies"&&r.AlwaysFriends!.SetEquals(ContentCalendar.Infected),"infected hostility and own faction");}
  var again=ContentCalendar.EnsureHostility(rows);Check(again.Count==rows.Count&&again.All(r=>r.AlwaysEnemies!.Count==rows.Single(x=>x.BotRole==r.BotRole).AlwaysEnemies!.Count),"idempotent hostility");
  var patrol=new DayPlan("2026-10-27","Patrol surge",new[]{"woods","bigmap"},30,5,0,1);
  var waves=new[]{new BossLocationSpawn{BossName="pmcUSEC",BossChance=80,Time=300,IgnoreMaxBots=true},new BossLocationSpawn{BossName="pmcBEAR",BossChance=100,Time=30,IgnoreMaxBots=true},new BossLocationSpawn{BossName="pmcUSEC",BossChance=0,Time=300,IgnoreMaxBots=true},new BossLocationSpawn{BossName="bossBully",BossChance=50,Time=300,IgnoreMaxBots=true}};
  ContentCalendar.TunePmcWaves(waves,true,patrol);
  Check(waves[0].BossChance==85&&waves[0].Time==270&&waves[0].IgnoreMaxBots==false,"patrol tunes generated PMC waves and respects cap");
  Check(waves[1].BossChance==100&&waves[1].Time==30,"guaranteed/early patrol unchanged");
  Check(waves[2].BossChance==0&&waves[2].Time==300,"disabled PMC wave stays disabled and retains timing");
  Check(waves[3].BossChance==50&&waves[3].Time==300&&waves[3].IgnoreMaxBots==true,"non-PMC wave unaffected");
  var normal=new BossLocationSpawn{BossName="pmcUSEC",BossChance=50,Time=300,IgnoreMaxBots=true};ContentCalendar.TunePmcWaves(new[]{normal},false,patrol);
  Check(normal.BossChance==50&&normal.Time==300&&normal.IgnoreMaxBots==false,"normal map keeps timing/chance and respects cap");
  var scavs=new[]{new Wave{WildSpawnType=WildSpawnType.assault,TimeMin=300,TimeMax=360,SlotsMin=2,SlotsMax=3},new Wave{WildSpawnType=WildSpawnType.assault,TimeMin=30,TimeMax=60},new Wave{WildSpawnType=WildSpawnType.marksman,TimeMin=300,TimeMax=360},new Wave{WildSpawnType=WildSpawnType.assault,TimeMin=300,TimeMax=200},new Wave{WildSpawnType=WildSpawnType.assault,TimeMin=null,TimeMax=300}};
  var adjustments=ContentCalendar.TuneScavWaves(scavs,new(5,45,45,0,1));
  Check(adjustments==1&&scavs[0].TimeMin==255&&scavs[0].TimeMax==315,"eligible Scav window moves earlier once");
  Check(scavs[0].SlotsMin==2&&scavs[0].SlotsMax==3&&scavs.Length==5,"Scav population never multiplied");
  Check(scavs[1].TimeMin==30&&scavs[2].TimeMin==300&&scavs[3].TimeMin==300&&scavs[4].TimeMin==null,"early/non-Scav/invalid windows left alone");
  Check(ContentCalendar.TuneScavWaves(scavs,new(0,0,0,0,1))==0,"normal map Scav timing unchanged");
  foreach(var invalid in new[]{new CalendarConfig{NormalInfection=100},new CalendarConfig{MaxCrowdSize=0},new CalendarConfig{CrowdCooldownSeconds=1},new CalendarConfig{RolloverHour=24},new CalendarConfig{SchemaVersion=2}}){bool refused=false;try{invalid.Validate();}catch(System.IO.InvalidDataException){refused=true;}Check(refused,"invalid settings refused");}
  Console.WriteLine(checks+" live content calendar/hostility checks passed.");
 }
}
