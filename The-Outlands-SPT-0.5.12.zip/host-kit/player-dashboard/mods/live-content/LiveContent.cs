using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using System.Threading.Tasks;
using SPTarkov.DI.Annotations;
using SPTarkov.Reflection.Patching;
using SPTarkov.Server.Core.Models.Eft.Common;
using SPTarkov.Server.Core.Models.External;
using SPTarkov.Server.Core.Models.Spt.Config;
using SPTarkov.Server.Core.Models.Spt.Mod;
using SPTarkov.Server.Core.Models.Utils;
using SPTarkov.Server.Core.Servers;
using SPTarkov.Server.Core.Services;

namespace Outlands.LiveContent;

public record ModMetadata : AbstractModMetadata {
 public override string ModGuid{get;init;}="outlands.live-content";
 public override string Name{get;init;}="Outlands Live Content";
 public override string Author{get;init;}="TheOutlandsDev";
 public override List<string>? Contributors{get;init;}
 public override SemanticVersioning.Version Version{get;init;}=new(1,1,0);
 public override SemanticVersioning.Range SptVersion{get;init;}=new("=4.0.13");
 public override List<string>? Incompatibilities{get;init;}
 public override Dictionary<string,SemanticVersioning.Range>? ModDependencies{get;init;}
 public override string? Url{get;init;}
 public override bool? IsBundleMod{get;init;}=false;
 public override string License{get;init;}="MIT";
}
public sealed class CalendarConfig {
 public int SchemaVersion{get;set;}=1;
 public bool Enabled{get;set;}=true;
 public string TimeZone{get;set;}="America/New_York";
 public int RolloverHour{get;set;}=5;
 public int NormalInfection{get;set;}=15;
 public int GroundZeroInfection{get;set;}=10;
 public int LabInfection{get;set;}=60;
 public int HotspotInfection{get;set;}=30;
 public int MaxCrowdSize{get;set;}=6;
 public int CrowdCooldownSeconds{get;set;}=180;
 public void Validate(){
  if(SchemaVersion!=1||RolloverHour<0||RolloverHour>23||MaxCrowdSize<1||MaxCrowdSize>8||CrowdCooldownSeconds<120||CrowdCooldownSeconds>900)throw new InvalidDataException("Invalid live-content configuration bounds");
  if(new[]{NormalInfection,GroundZeroInfection,LabInfection,HotspotInfection}.Any(v=>v<0||v>75))throw new InvalidDataException("Infection must be 0..75");
  _=TimeZoneInfo.FindSystemTimeZoneById(TimeZone);
 }
}
public sealed record DayPlan(string Day,string Theme,string[] Hotspots,int Infection,int PmcChanceBonus,int BossChanceBonus,double LootMultiplier) {
 public string Campaign{get;init;}="Reconnaissance";
 public string Briefing{get;init;}="";
 public int PmcAdvanceSeconds{get;init;}=30;
 public int ScavAdvanceSeconds{get;init;}
 public string[] Challenges{get;init;}=Array.Empty<string>();
 public Operation[] Operations=>Hotspots.Select((map,index)=>new Operation(map,index==0?"Primary":"Secondary",ContentCalendar.OperationTitle(Theme,index),ContentCalendar.ModifiersFor(map,this))).ToArray();
}
public sealed record MapTuning(int PmcChanceBonus,int PmcAdvanceSeconds,int ScavAdvanceSeconds,int BossChanceBonus,double LootMultiplier);
public sealed record Operation(string Map,string Role,string Title,MapTuning Modifiers);
public static class ContentCalendar {
 public static readonly string[] Infected={"infectedAssault","infectedPmc","infectedCivil","infectedLaborant","infectedTagilla"};
 public static readonly string[] Scavs={"assault","marksman","cursedAssault","assaultGroup"};
 public static DayPlan Select(DateTimeOffset utc,CalendarConfig config){
  config.Validate();var local=TimeZoneInfo.ConvertTime(utc,TimeZoneInfo.FindSystemTimeZoneById(config.TimeZone));var day=local.Date.AddDays(local.Hour<config.RolloverHour?-1:0);
  // Weeks rotate map pairs; this is pure calendar state, never a profile/wipe reset.
  var maps=new[]{"bigmap","woods","shoreline","interchange","rezervbase","lighthouse","tarkovstreets"};
  var week=(int)Math.Floor((day-new DateTime(2026,1,5)).TotalDays/7);var offset=((week%7)+7)%7;var d=((int)day.DayOfWeek+6)%7;
  string[] hotspots={maps[(offset+d)%7],maps[(offset+d+3)%7]};
  var themes=new[]{"Supply lanes","Patrol surge","Containment patrol","Smuggler routes","Boss sightings","Outbreak hunt","Recovery runs"};
  var infection=d==5?Math.Min(40,config.HotspotInfection+5):d==6?15:config.HotspotInfection;
  var phase=((week%4)+4)%4;
  var pmc=new[]{3,6,4,4,3,4,3}[d]+(phase is 1 or 2?1:0);
  var briefings=new[]{
   "Supply traffic is drawing armed groups into the sector. Recover provisions and leave before the routes get crowded.",
   "PMC patrols are moving earlier. Work as a pair, clear one contact at a time and reposition after a fight.",
   "Scav reinforcement windows are moving forward while infection remains active. Keep a route out of the containment area.",
   "Smuggling routes offer better recovery prospects, with earlier PMC contacts. Choose what you can carry and keep moving.",
   "Existing boss groups are more likely to appear. Scout first; sightings are chance based, never guaranteed.",
   "Infection pressure is elevated in the hotspots. Regular armed groups remain present; bring ammunition for both threats.",
   "Infection pressure is lower in the hotspots. Recover supplies, finish local tasks and extract together."
  };
  var variations=new[]{
   new[]{"Recover three useful medical items between the squad.","Win one engagement, then relocate before looting.","Extract with every surviving squad member."},
   new[]{"Recover provisions for the next raid without buying them first.","Let each player lead one contact and cover the other player.","Extract together with one found-in-raid item for a teammate."},
   new[]{"Recover one weapon or useful attachment for a teammate.","Clear a route through two separate areas before extracting.","Complete a local trader task or make progress toward one."}
  };
  var squadGoals=variations[((week%3)+3)%3].ToArray();
  squadGoals[0]=new[]{"Recover food or drink for both players on a hotspot map.","Identify a patrol, engage from cover, then change position.","Clear an infected threat while a teammate covers the exit route.","Recover one useful attachment for a teammate on a hotspot map.","Scout a suspected boss area and extract with the squad; a kill is optional.","Deal with infected and armed threats, then extract without splitting up.","Recover medical supplies for the squad and leave with surviving teammates."}[d];
  return new(day.ToString("yyyy-MM-dd"),themes[d],hotspots,infection,pmc,d==4?10:0,new[]{1.05,1.00,1.02,1.05,1.02,1.03,1.04}[d]){
   Campaign=new[]{"Reconnaissance","Supply push","Containment","Recovery"}[phase],Briefing=briefings[d],
   PmcAdvanceSeconds=new[]{20,45,30,20,20,30,15}[d],ScavAdvanceSeconds=new[]{15,30,45,15,15,30,15}[d],
   Challenges=squadGoals
  };
 }
 public static DayPlan[] Forecast(DayPlan active,CalendarConfig config)=>Enumerable.Range(1,7).Select(i=>{
  var noon=DateTime.SpecifyKind(DateTime.ParseExact(active.Day,"yyyy-MM-dd",System.Globalization.CultureInfo.InvariantCulture).AddDays(i).AddHours(12),DateTimeKind.Unspecified);
  var zone=TimeZoneInfo.FindSystemTimeZoneById(config.TimeZone);return Select(new DateTimeOffset(noon,zone.GetUtcOffset(noon)),config);
 }).ToArray();
 public static string OperationTitle(string theme,int index)=>theme switch{
  "Supply lanes"=>index==0?"Supply interception":"Provision recovery",
  "Patrol surge"=>index==0?"Patrol contact":"Flank and reposition",
  "Containment patrol"=>index==0?"Containment line":"Reinforcement watch",
  "Smuggler routes"=>index==0?"Route interdiction":"Cache recovery",
  "Boss sightings"=>index==0?"Boss reconnaissance":"Armed escort watch",
  "Outbreak hunt"=>index==0?"Outbreak perimeter":"Survivor corridor",
  _=>index==0?"Recovery corridor":"Resupply run"
 };
 public static MapTuning ModifiersFor(string map,DayPlan day){
  var index=Array.IndexOf(day.Hotspots,map.ToLowerInvariant());if(index<0)return new(0,0,0,0,1);
  var scale=index==0?1.0:0.5;
  return new((int)(day.PmcChanceBonus*scale),(int)(day.PmcAdvanceSeconds*scale),(int)(day.ScavAdvanceSeconds*scale),(int)(day.BossChanceBonus*scale),Math.Round(1+(day.LootMultiplier-1)*scale,4));
 }
 public static int InfectionFor(string map,DayPlan day,CalendarConfig config){
  map=map.ToLowerInvariant();if(map is "sandbox"or"sandbox_high")return config.GroundZeroInfection;
  if(map=="laboratory")return config.LabInfection;
  return day.Hotspots.Contains(map)?day.Infection:config.NormalInfection;
 }
 public static int TunePmcWaves(IEnumerable<BossLocationSpawn> waves,bool hotspot,DayPlan day)=>TunePmcWaves(waves,hotspot?new(day.PmcChanceBonus,day.PmcAdvanceSeconds,day.ScavAdvanceSeconds,day.BossChanceBonus,day.LootMultiplier):new(0,0,0,0,1));
 public static int TunePmcWaves(IEnumerable<BossLocationSpawn> waves,MapTuning tuning){
  var changed=0;
  foreach(var wave in waves){
   if(wave.BossName is not ("pmcBEAR"or"pmcUSEC"))continue;
   wave.IgnoreMaxBots=false;
   if(wave.BossChance>0&&tuning.PmcChanceBonus>0){
    var chance=wave.BossChance;var time=wave.Time;
    wave.BossChance=Math.Min(100,wave.BossChance.Value+tuning.PmcChanceBonus);
    if(wave.Time>=180)wave.Time=Math.Max(120,wave.Time.Value-tuning.PmcAdvanceSeconds);
    if(chance!=wave.BossChance||time!=wave.Time)changed++;
   }
  }
  return changed;
 }
 public static int TuneScavWaves(IEnumerable<Wave> waves,MapTuning tuning){
  var changed=0;if(tuning.ScavAdvanceSeconds<=0)return changed;
  foreach(var wave in waves){
   if(wave.WildSpawnType?.ToString()!="assault"||wave.TimeMin<180||wave.TimeMin==null||wave.TimeMax==null||wave.TimeMax<wave.TimeMin)continue;
   wave.TimeMin=Math.Max(120,wave.TimeMin.Value-tuning.ScavAdvanceSeconds);
   wave.TimeMax=Math.Max(wave.TimeMin.Value,wave.TimeMax.Value-tuning.ScavAdvanceSeconds);changed++;
  }
  return changed;
 }
 public static List<AdditionalHostilitySettings> EnsureHostility(IEnumerable<AdditionalHostilitySettings>? existing){
  var list=(existing??Array.Empty<AdditionalHostilitySettings>()).ToList();
  foreach(var role in Scavs){
   var row=list.FirstOrDefault(r=>r.BotRole==role);if(row==null){row=new(){BotRole=role};list.Add(row);}
   row.AlwaysEnemies??=new();row.AlwaysEnemies.UnionWith(Infected);row.AlwaysFriends?.ExceptWith(Infected);row.Neutral?.ExceptWith(Infected);
  }
  foreach(var role in Infected){
   var row=list.FirstOrDefault(r=>r.BotRole==role);if(row==null){row=new(){BotRole=role};list.Add(row);}
   row.AlwaysEnemies??=new();row.AlwaysEnemies.UnionWith(Scavs);row.AlwaysFriends??=new();row.AlwaysFriends.UnionWith(Infected);row.AlwaysFriends.ExceptWith(Scavs);row.Neutral?.ExceptWith(Scavs);
   row.SavagePlayerBehaviour="AlwaysEnemies";row.BearPlayerBehaviour="AlwaysEnemies";row.UsecPlayerBehaviour="AlwaysEnemies";
  }
  return list;
 }
}
[Injectable]
public sealed class LiveContentLoader(DatabaseService database,ConfigServer configs,ISptLogger<LiveContentLoader> logger):IOnWebAppBuildModAsync {
 private bool applied;
 public Task OnWebAppBuildAsync(){LiveContentPatch.Apply=Apply;new LiveContentPatch().Enable();return Task.CompletedTask;}
 public void Apply(){
  if(applied)return;applied=true;
  var directory=Path.GetDirectoryName(typeof(LiveContentLoader).Assembly.Location)!;
  var config=JsonSerializer.Deserialize<CalendarConfig>(File.ReadAllText(Path.Combine(directory,"settings.json")))??throw new InvalidDataException("Missing calendar configuration");config.Validate();if(!config.Enabled)return;
  var day=ContentCalendar.Select(DateTimeOffset.UtcNow,config);var maps=new Dictionary<string,object>();
  var realMaps=new HashSet<string>{"bigmap","woods","shoreline","interchange","rezervbase","lighthouse","tarkovstreets","sandbox","sandbox_high","laboratory","factory4_day","factory4_night"};
  var bossRoles=new HashSet<string>{"bossBully","bossKilla","bossKojaniy","bossGluhar","bossSanitar","bossTagilla","bossKnight","bossBoar","bossKolontay","bossPartisan"};
  var pmcs=configs.GetConfig<PmcConfig>();
  var tunedPmcs=new Dictionary<string,int>();var tunedWaves=new HashSet<BossLocationSpawn>(ReferenceEqualityComparer.Instance);
  foreach(var (map,waves)in pmcs.CustomPmcWaves)tunedPmcs[map.ToLowerInvariant()]=ContentCalendar.TunePmcWaves(waves.Where(w=>tunedWaves.Add(w)),ContentCalendar.ModifiersFor(map,day));
  foreach(var (name,location)in database.GetLocations().GetDictionary()){
   var b=location.Base;if(b==null)continue;var key=(b.Id??name).ToLowerInvariant();if(!realMaps.Contains(key))continue;
   var infection=ContentCalendar.InfectionFor(key,day,config);
   if(b.Events?.Halloween2024!=null){var z=b.Events.Halloween2024;z.InfectionPercentage=infection;z.MaxCrowdAttackSpawnLimit=Math.Min(z.MaxCrowdAttackSpawnLimit??config.MaxCrowdSize,config.MaxCrowdSize);z.CrowdCooldownPerPlayerSec=Math.Max(z.CrowdCooldownPerPlayerSec??0,config.CrowdCooldownSeconds);}
   if(b.BotLocationModifier!=null)b.BotLocationModifier.AdditionalHostilitySettings=ContentCalendar.EnsureHostility(b.BotLocationModifier.AdditionalHostilitySettings);
   var hotspot=day.Hotspots.Contains(key);var tuning=ContentCalendar.ModifiersFor(key,day);var bossAdjusted=0;
   var scavAdjusted=ContentCalendar.TuneScavWaves(b.Waves??new(),tuning);
   foreach(var spawn in b.BossLocationSpawn??new()){
    if(spawn.BossName!=null&&ContentCalendar.Infected.Contains(spawn.BossName)){
     spawn.BossChance=spawn.BossName=="infectedTagilla"?Math.Min(spawn.BossChance??5,5):Math.Min(spawn.BossChance??infection,infection);spawn.IgnoreMaxBots=false;
    }else if(hotspot&&spawn.BossName is "pmcBEAR"or"pmcUSEC"){
     if(tunedWaves.Add(spawn))tunedPmcs[key]=tunedPmcs.GetValueOrDefault(key)+ContentCalendar.TunePmcWaves(new[]{spawn},tuning);
    }
    else if(hotspot&&spawn.BossName!=null&&bossRoles.Contains(spawn.BossName)&&spawn.BossChance>0&&tuning.BossChanceBonus>0){var before=spawn.BossChance;spawn.BossChance=Math.Min(100,spawn.BossChance.Value+tuning.BossChanceBonus);if(before!=spawn.BossChance)bossAdjusted++;}
   }
   if(tuning.LootMultiplier>1){if(b.GlobalLootChanceModifier.HasValue)b.GlobalLootChanceModifier*=tuning.LootMultiplier;if(b.GlobalLootChanceModifierPvE.HasValue)b.GlobalLootChanceModifierPvE*=tuning.LootMultiplier;}
   maps[key]=new{infection,hotspot,botCap=b.BotMax,pmcWavesAdjusted=tunedPmcs.GetValueOrDefault(key),scavWavesAdjusted=scavAdjusted,bossWavesAdjusted=bossAdjusted,scavWaves=b.Waves?.Count(w=>w.WildSpawnType?.ToString()=="assault")??0,pmcWaves=pmcs.CustomPmcWaves.TryGetValue(key,out var actualPmcWaves)?actualPmcWaves.Count:0,infectedWaves=b.BossLocationSpawn?.Count(w=>w.BossName!=null&&ContentCalendar.Infected.Contains(w.BossName))??0};
  }
  // Keep the displayed infection map consistent with the actual client locations.
  var infectionUi=database.GetGlobals().LocationInfection;
  foreach(var key in infectionUi.Keys.ToArray()){
   var mapped=key.Equals("factory4",StringComparison.OrdinalIgnoreCase)?"factory4_day":key.Equals("Sandbox",StringComparison.OrdinalIgnoreCase)?"sandbox":key.ToLowerInvariant();
   if(realMaps.Contains(mapped))infectionUi[key]=ContentCalendar.InfectionFor(mapped,day,config);
  }
  var status=new{schemaVersion=1,eventVersion="1.1.0",build="SPT 4.0.13 / EFT 0.16.9.40087 / Fika 2.2.5",activeSinceUtc=DateTimeOffset.UtcNow,day,timezone=config.TimeZone,rolloverHour=config.RolloverHour,activation="At server startup after idle daily maintenance; never during a running raid",zombieSafetyClientVersion="1.0.3",nextSevenDays=ContentCalendar.Forecast(day,config),maps};
  var target=Path.Combine(directory,"status.json");File.WriteAllText(target+".tmp",JsonSerializer.Serialize(status,new JsonSerializerOptions{WriteIndented=true})+"\n");File.Move(target+".tmp",target,true);
  logger.Success($"[Outlands.LiveContent] {day.Day}: {day.Theme}; hotspots {string.Join(", ",day.Hotspots)}. Exact infection, Scav/infected hostility, bounded crowds and existing bot caps enforced. Active until the next idle restart.");
 }
}
public sealed class LiveContentPatch:AbstractPatch {
 public static Action? Apply;
 protected override MethodBase GetTargetMethod()=>typeof(PostDbLoadService).GetMethod(nameof(PostDbLoadService.PerformPostDbLoadActions))!;
 [PatchPostfix,HarmonyLib.HarmonyPriority(HarmonyLib.Priority.Last)]public static void Postfix()=>Apply?.Invoke();
}
