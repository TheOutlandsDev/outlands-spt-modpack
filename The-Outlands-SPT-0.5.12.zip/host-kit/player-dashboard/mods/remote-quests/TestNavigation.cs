// Executes the production navigation hooks against UI doubles with real Harmony.
using System;
using System.Linq;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using System.IO;
using System.Security.Cryptography;
using EFT;
using EFT.UI;
using HarmonyLib;
using Outlands.RemoteQuests;
class TestNavigation {
 static int count;
 static readonly Type Hooks=typeof(RemoteQuestsPlugin).Assembly.GetType("Outlands.RemoteQuests.NavigationPatches");
 static MethodInfo Method(string name)=>Hooks.GetMethod(name,BindingFlags.Static|BindingFlags.NonPublic|BindingFlags.Public);
 static object Call(string name,params object[] args)=>Method(name).Invoke(null,args);
 static void Check(bool value,string name){count++;if(!value)throw new Exception(name);}
 static Profile.TraderInfo Info(bool disabled,bool unlocked=true,bool banned=false)=>new Profile.TraderInfo{Disabled=disabled,Unlocked=unlocked,Banned=banned};
 static List<CodeInstruction> Rewrite(string name, params MethodInfo[] calls)=>(Call(name,new List<CodeInstruction>(calls.Select(m=>new CodeInstruction(OpCodes.Callvirt,m)))) as IEnumerable<CodeInstruction>).ToList();
 static void Main(){
  var gameRoot=Path.Combine(Path.GetTempPath(),"outlands-remote-quests-path-test-"+Guid.NewGuid().ToString("N"));
  BepInEx.Paths.GameRootPath=gameRoot;
  const string relative="EscapeFromTarkov_Data/Managed/Assembly-CSharp.dll";
  Check(RemoteQuestsPlugin.ResolveAssemblyPath("",relative)==Path.Combine(gameRoot,relative),"memory-loaded assembly uses canonical game path");
  Check(RemoteQuestsPlugin.ResolveAssemblyPath(null,relative)==Path.Combine(gameRoot,relative),"missing assembly location uses canonical game path");
  var reported=Path.Combine(gameRoot,"loaded.dll");
  Check(RemoteQuestsPlugin.ResolveAssemblyPath(reported,relative)==reported,"reported assembly path preserved");
  BepInEx.Paths.GameRootPath="";
  var noRootRefused=false;try{RemoteQuestsPlugin.ResolveAssemblyPath("",relative);}catch(InvalidOperationException){noRootRefused=true;}
  Check(noRootRefused,"empty location and unavailable game root fail closed");
  BepInEx.Paths.GameRootPath=gameRoot;
  var canonical=RemoteQuestsPlugin.ResolveAssemblyPath("",relative);
  Directory.CreateDirectory(Path.GetDirectoryName(canonical));File.WriteAllText(canonical,"hash verification fixture");
  try{
   string expected;using(var sha=SHA256.Create())expected=BitConverter.ToString(sha.ComputeHash(File.ReadAllBytes(canonical))).Replace("-","").ToLowerInvariant();
   var verify=typeof(RemoteQuestsPlugin).GetMethod("VerifyHash",BindingFlags.NonPublic|BindingFlags.Static);
   verify.Invoke(null,new object[]{canonical,expected});Check(true,"canonical fallback still verifies file hash");
   File.AppendAllText(canonical," changed");var hashRefused=false;
   try{verify.Invoke(null,new object[]{canonical,expected});}catch(TargetInvocationException e){hashRefused=e.InnerException is InvalidOperationException;}
   Check(hashRefused,"changed canonical file fails closed");
  }finally{Directory.Delete(gameRoot,true);}
  foreach(var name in new[]{"ModePrefix","ModePostfix","ClosePrefix","SelectionTranspiler","RefreshTranspiler","AvailabilityTranspiler"})
   Check(Call("Hook",name) is HarmonyMethod,"real hook resolves: "+name);
  var available=typeof(Profile.TraderInfo).GetProperty("Available").GetMethod;
  var refresh=typeof(TraderClass).GetMethod("RefreshAssortment");
  var services=typeof(ServicesScreen).GetMethod("CheckAvailableServices");
  var selection=Rewrite("SelectionTranspiler",available,refresh,services);
  Check(selection.Count==3 && selection.All(i=>i.opcode==OpCodes.Call),"instance calls become static calls");
  Check(selection.Select(i=>((MethodInfo)i.operand).Name).SequenceEqual(new[]{"CanSelect","RefreshForLocalTrader","ServicesForLocalTrader"}),"selection calls rewritten to intended guards");
  Check(((MethodInfo)Rewrite("AvailabilityTranspiler",available)[0].operand).Name=="CanSelect","card availability rewrite");
  Check(((MethodInfo)Rewrite("RefreshTranspiler",refresh)[0].operand).Name=="RefreshForLocalTrader","refresh rewrite");
  foreach(var bad in new[]{new MethodInfo[0],new[]{available,available}}){
   bool refused=false;try{Rewrite("AvailabilityTranspiler",bad);}catch(TargetInvocationException e){refused=e.InnerException is InvalidOperationException;}
   Check(refused,"mismatching call layout refused");
  }
  foreach(var disabled in new[]{false,true})foreach(var unlocked in new[]{false,true})foreach(var banned in new[]{false,true}){
   var i=Info(disabled,unlocked,banned);var t=new TraderClass{Info=i};var s=new ServicesScreen();
   var remote=disabled&&unlocked&&!banned;
   Check((bool)Call("CanSelect",i)==(unlocked&&!banned),"actual CanSelect preserves locked/banned gates");
   Call("RefreshForLocalTrader",t,true,false);Check(t.Refreshes==(remote?0:1),"actual refresh guard");
   Call("ServicesForLocalTrader",s,t,ESessionMode.Regular);Check(s.Checks==(remote?0:1),"actual services guard");
   Check(i.Disabled==disabled&&i.Unlocked==unlocked&&i.Banned==banned,"all native flags unchanged");
  }
  var remoteTrader=new TraderClass{Info=Info(true)};
  var localTrader=new TraderClass{Info=Info(false)};
  var group=new TraderScreensGroup{traderClass=remoteTrader,ETraderMode_0=TraderScreensGroup.ETraderMode.Trade};
  object[] modeArgs={group,TraderScreensGroup.ETraderMode.Trade};Method("ModePrefix").Invoke(null,modeArgs);
  Check((TraderScreensGroup.ETraderMode)modeArgs[1]==TraderScreensGroup.ETraderMode.Tasks && group.ETraderMode_0==TraderScreensGroup.ETraderMode.Tasks,"remote selects tasks argument and backing mode");
  Check(!group._tradingTab.gameObject.activeSelf&&!group._servicesTab.gameObject.activeSelf&&!group._tradingTab.Interactable&&!group._servicesTab.Interactable,"remote commerce tabs hidden/disabled");
  group._tradingTab.gameObject.SetActive(true);group._servicesTab.gameObject.SetActive(true);Call("ModePostfix",group);
  Check(!group._tradingTab.gameObject.activeSelf&&!group._servicesTab.gameObject.activeSelf,"postfix restores remote guard after original UI changes");
  group.traderClass=localTrader;group._servicesTab.Interactable=false;
  modeArgs=new object[]{group,TraderScreensGroup.ETraderMode.Trade};Method("ModePrefix").Invoke(null,modeArgs);
  Check((TraderScreensGroup.ETraderMode)modeArgs[1]==TraderScreensGroup.ETraderMode.Trade,"local requested mode preserved");
  Check(group._tradingTab.gameObject.activeSelf&&group._servicesTab.gameObject.activeSelf&&group._tradingTab.Interactable,"local tab visibility and trade interaction restored");
  Check(!group._servicesTab.Interactable,"fresh local services decision preserved");
  group.traderClass=remoteTrader;modeArgs=new object[]{group,TraderScreensGroup.ETraderMode.Services};Method("ModePrefix").Invoke(null,modeArgs);
  Check((TraderScreensGroup.ETraderMode)modeArgs[1]==TraderScreensGroup.ETraderMode.Tasks,"remote forces tasks when services requested");
  Call("ClosePrefix",group);
  Check(group._tradingTab.gameObject.activeSelf&&group._servicesTab.gameObject.activeSelf&&group._tradingTab.Interactable&&!group._servicesTab.Interactable,"close restores latest saved tab states");
  Check(remoteTrader.Info.Disabled&&remoteTrader.Info.Unlocked&&!remoteTrader.Info.Banned&&!remoteTrader.Info.Available,"remote UI cycle leaves global commerce disabled");
  var harmony=new Harmony("outlands.remote-quests.stub-review");
  try {
   NavigationPatches.Install(harmony);
   Check(Harmony.GetPatchInfo(typeof(TraderScreensGroup).GetMethod("method_3")).Prefixes.Any(),"actual Harmony installs mode guard");
   var panel=new TraderPanel{Info=remoteTrader.Info};panel.method_0();Check(panel.CanOpen,"patched panel selects remote trader");
   var card=new TraderCard();card.SetCardState(remoteTrader.Info);Check(card.Selected,"patched card selects remote trader");
   var avatar=new TraderAvatar{Info=remoteTrader.Info};avatar.method_0();Check(avatar.BadgeVisible,"patched avatar shows remote quest badges");
   var installedGroup=new TraderScreensGroup();
   installedGroup.method_6(remoteTrader);
   Check(installedGroup.SelectedCount==1&&installedGroup.ObservedMode==TraderScreensGroup.ETraderMode.Tasks,"actual patched remote selection forces tasks");
   Check(remoteTrader.Refreshes==0&&installedGroup.Services.Checks==0,"actual patched remote selection calls no commerce");
   installedGroup.method_9();Check(remoteTrader.Refreshes==0,"actual patched loyalty refresh skips remote assortment");
   installedGroup.method_3(TraderScreensGroup.ETraderMode.Trade);
   Check(installedGroup.ObservedMode==TraderScreensGroup.ETraderMode.Tasks,"actual patched manual trade mode is rerouted");
   installedGroup.method_3(TraderScreensGroup.ETraderMode.Services);
   Check(installedGroup.ObservedMode==TraderScreensGroup.ETraderMode.Tasks,"actual patched manual services mode is rerouted");
   Check(!installedGroup._tradingTab.gameObject.activeSelf&&!installedGroup._servicesTab.gameObject.activeSelf,"actual patched remote commerce tabs hidden");
   installedGroup.method_6(localTrader);
   Check(localTrader.Refreshes==1&&installedGroup.Services.Checks==1,"actual patched local trader keeps commerce calls");
   Check(installedGroup._tradingTab.gameObject.activeSelf&&installedGroup._servicesTab.gameObject.activeSelf&&installedGroup._tradingTab.Interactable&&installedGroup._servicesTab.Interactable,"actual patched local trader restores visibility and service availability");
   var locked=new TraderClass{Info=Info(true,false,false)};installedGroup.method_6(locked);
   Check(installedGroup.traderClass==localTrader,"actual patched selection refuses locked trader");
   var banned=new TraderClass{Info=Info(true,true,true)};installedGroup.method_6(banned);
   Check(installedGroup.traderClass==localTrader,"actual patched selection refuses banned trader");
   installedGroup.method_6(remoteTrader);installedGroup.Close();
   Check(installedGroup._tradingTab.gameObject.activeSelf&&installedGroup._servicesTab.gameObject.activeSelf,"actual patched Close restores tabs");
   Check(remoteTrader.Info.Disabled&&!remoteTrader.Info.Available,"actual installed patches never alter native availability");
  } finally {harmony.UnpatchSelf();}
  Console.WriteLine("Production Remote Quests hooks: "+count+" checks passed using stub UI and real Harmony reflection/code instructions.");
 }
}
