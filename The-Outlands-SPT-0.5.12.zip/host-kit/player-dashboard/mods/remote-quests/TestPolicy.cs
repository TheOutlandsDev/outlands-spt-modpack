using System;
using Outlands.RemoteQuests;

class TestPolicy
{
    static void Main()
    {
        var checks = 0;
        foreach (var disabled in new[] { false, true })
        foreach (var unlocked in new[] { false, true })
        foreach (var banned in new[] { false, true })
        {
            var available = !disabled && unlocked && !banned;
            var remote = disabled && unlocked && !banned;
            Assert(QuestAccessPolicy.IsRemote(disabled, unlocked, banned) == remote, "remote eligibility"); checks++;
            Assert(QuestAccessPolicy.CanSelect(available, disabled, unlocked, banned) == (unlocked && !banned), "selection eligibility"); checks++;
            foreach (var mode in new[] { 0, 1, 2 })
            {
                Assert(QuestAccessPolicy.SelectMode(remote, mode) == (remote ? 1 : mode), "mode selection"); checks++;
            }
            Assert(available == (!disabled && unlocked && !banned), "native commerce availability retained"); checks++;
        }
        Console.WriteLine("Remote quest policy: " + checks + " checks passed.");
    }
    static void Assert(bool ok, string label) { if (!ok) throw new Exception(label); }
}
