using System;
using System.Reflection;
using System.Threading.Tasks;
using Comfort.Common;
using EFT;
using EFT.Quests;
using EFT.UI;
using HarmonyLib;

namespace Outlands.RemoteQuests
{
    // Remote navigation permits acceptance only. Each mutation checks the quest's
    // actual trader against the original native availability, never the open card.
    internal static class TurnInPatches
    {
        internal const string LocalTurnInMessage = "Visit this trader locally to turn in quests.";
        private static readonly FieldInfo ViewQuest = AccessTools.Field(typeof(QuestView), "_quest");
        private static readonly FieldInfo ViewController = AccessTools.Field(typeof(QuestView), "_questController");
        private static readonly FieldInfo CompleteButton = AccessTools.Field(typeof(QuestView), "_button");
        private static readonly FieldInfo RerollButton = AccessTools.Field(typeof(QuestView), "_buttonReRoll");
        private static readonly FieldInfo ObjectiveQuest = AccessTools.Field(typeof(QuestObjectiveView), "questClass");
        private static readonly FieldInfo ObjectiveController = AccessTools.Field(typeof(QuestObjectiveView), "abstractQuestControllerClass");
        private static readonly FieldInfo HandoverButton = AccessTools.Field(typeof(QuestObjectiveView), "_handoverButton");

        internal static void Install(Harmony harmony)
        {
            foreach (var field in new[] { ViewQuest, ViewController, CompleteButton, RerollButton,
                ObjectiveQuest, ObjectiveController, HandoverButton })
                if (field == null) throw new MissingMemberException("A required quest UI field was not found.");

            var finishArguments = new[] { typeof(QuestClass), typeof(bool) };
            var handoverArguments = new[] { typeof(QuestClass), typeof(ConditionItem), typeof(EFT.InventoryLogic.Item[]), typeof(bool) };
            // These are every concrete implementation in the pinned game assembly.
            // Fika's ClientQuestController delegates to GClass4007 and propagates a
            // failed result without sending its inventory/reward packet.
            var nativeControllers = new[] { typeof(LocalQuestControllerClass), typeof(GClass4007), typeof(GClass4008) };
            var methods = new MethodInfo[nativeControllers.Length * 2];
            for (var index = 0; index < nativeControllers.Length; index++)
            {
                methods[index * 2] = RequireDeclared(nativeControllers[index], "FinishQuest",
                    typeof(Task<GStruct154<GStruct426<QuestClass>>>), finishArguments);
                methods[index * 2 + 1] = RequireDeclared(nativeControllers[index], "HandoverItem",
                    typeof(Task<IResult>), handoverArguments);
            }
            var buttonBlock = RequireDeclared(typeof(QuestView), "ShowButtonBlock", typeof(void));
            var objectiveUpdate = RequireDeclared(typeof(QuestObjectiveView), "OnConditionChanged",
                typeof(bool), typeof(ConditionProgressChecker));
            var finishUi = RequireDeclared(typeof(QuestView), "FinishQuest", typeof(Task), typeof(QuestClass));
            var handoverUi = RequireDeclared(typeof(QuestObjectiveView), "method_2", typeof(Task), typeof(QuestClass));
            var rerollUi = RequireDeclared(typeof(QuestView), "ShowChangeQuestConfirmation", typeof(Task));

            for (var index = 0; index < methods.Length; index += 2)
            {
                harmony.Patch(methods[index], prefix: Hook(nameof(FinishPrefix)));
                harmony.Patch(methods[index + 1], prefix: Hook(nameof(HandoverPrefix)));
            }
            harmony.Patch(buttonBlock, postfix: Hook(nameof(ButtonBlockPostfix)));
            harmony.Patch(objectiveUpdate, postfix: Hook(nameof(ObjectiveUpdatePostfix)));
            harmony.Patch(finishUi, prefix: Hook(nameof(FinishUiPrefix)));
            harmony.Patch(handoverUi, prefix: Hook(nameof(HandoverUiPrefix)));
            harmony.Patch(rerollUi, prefix: Hook(nameof(RerollUiPrefix)));
        }

        private static MethodInfo RequireDeclared(Type type, string name, Type result, params Type[] arguments)
        {
            var method = type.GetMethod(name, BindingFlags.DeclaredOnly | BindingFlags.Instance |
                BindingFlags.Public | BindingFlags.NonPublic, null, arguments, null);
            if (method == null || method.IsAbstract || method.ReturnType != result)
                throw new MissingMethodException(type.FullName, name);
            return method;
        }

        private static HarmonyMethod Hook(string name) => new HarmonyMethod(
            AccessTools.Method(typeof(TurnInPatches), name) ?? throw new MissingMethodException(name));

        internal static bool CanTurnIn(AbstractQuestControllerClass controller, QuestClass quest)
        {
            var profile = controller?.Profile;
            var traderId = quest?.Template?.TraderId;
            if (profile?.TradersInfo == null || string.IsNullOrWhiteSpace(traderId) || traderId.Length != 24) return false;
            foreach (var character in traderId) if (!Uri.IsHexDigit(character)) return false;
            return
                profile.TryGetTraderInfo(traderId, out var info) && info != null && info.Available;
        }

        private static bool FinishPrefix(AbstractQuestControllerClass __instance, QuestClass __0,
            ref Task<GStruct154<GStruct426<QuestClass>>> __result)
        {
            if (CanTurnIn(__instance, __0)) return true;
            // A failed native result resets the caller's action state normally.
            // Throwing or returning a faulted task can leave its UI action locked.
            __result = Task.FromResult(new GStruct154<GStruct426<QuestClass>>(new GClass1522(LocalTurnInMessage)));
            return false;
        }

        private static bool HandoverPrefix(AbstractQuestControllerClass __instance, QuestClass __0,
            ref Task<IResult> __result)
        {
            if (CanTurnIn(__instance, __0)) return true;
            __result = new FailedResult(LocalTurnInMessage, 0).Task;
            return false;
        }

        private static bool FinishUiPrefix(QuestView __instance, QuestClass __0, ref Task __result) =>
            GuardUi(CanTurnIn((AbstractQuestControllerClass)ViewController.GetValue(__instance), __0), ref __result);

        private static bool HandoverUiPrefix(QuestObjectiveView __instance, QuestClass __0, ref Task __result) =>
            GuardUi(CanTurnIn((AbstractQuestControllerClass)ObjectiveController.GetValue(__instance), __0), ref __result);

        private static bool RerollUiPrefix(QuestView __instance, ref Task __result) => GuardUi(
            CanTurnIn((AbstractQuestControllerClass)ViewController.GetValue(__instance),
                (QuestClass)ViewQuest.GetValue(__instance)), ref __result);

        private static bool GuardUi(bool allowed, ref Task result)
        {
            if (allowed) return true;
            result = Task.CompletedTask;
            return false;
        }

        private static void ButtonBlockPostfix(QuestView __instance)
        {
            var quest = (QuestClass)ViewQuest.GetValue(__instance);
            if (CanTurnIn((AbstractQuestControllerClass)ViewController.GetValue(__instance), quest)) return;
            // Native ShowButtonBlock restores these states for each newly selected
            // quest. Acceptance is deliberately left wired to the native handler.
            var reroll = (DefaultUIButton)RerollButton.GetValue(__instance);
            if (reroll != null) reroll.gameObject.SetActive(false);
            if (quest?.QuestStatus != EQuestStatus.AvailableForFinish) return;
            var complete = (DefaultUIButton)CompleteButton.GetValue(__instance);
            if (complete == null) return;
            complete.Interactable = false;
            complete.SetHeaderText("Visit trader to turn in");
        }

        private static void ObjectiveUpdatePostfix(QuestObjectiveView __instance)
        {
            if (CanTurnIn((AbstractQuestControllerClass)ObjectiveController.GetValue(__instance),
                (QuestClass)ObjectiveQuest.GetValue(__instance))) return;
            var button = (DefaultUIButton)HandoverButton.GetValue(__instance);
            if (button != null) button.gameObject.SetActive(false);
        }
    }
}
