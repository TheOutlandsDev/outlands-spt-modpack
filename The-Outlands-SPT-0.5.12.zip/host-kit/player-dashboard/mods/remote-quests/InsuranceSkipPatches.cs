using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;

namespace Outlands.RemoteQuests
{
    internal static class InsuranceSkipPatches
    {
        private static readonly MethodInfo InsuranceStep = AccessTools.Method(typeof(MainMenuControllerClass), "method_51", Type.EmptyTypes);
        private static readonly MethodInfo AcceptStep = AccessTools.Method(typeof(MainMenuControllerClass), "method_52", Type.EmptyTypes);

        internal static void Install(Harmony harmony)
        {
            if (InsuranceStep == null || AcceptStep == null || AccessTools.Field(typeof(MainMenuControllerClass), "ISession") == null)
                throw new InvalidOperationException("Pinned pre-raid insurance flow was not found.");
            harmony.Patch(InsuranceStep, prefix: new HarmonyMethod(typeof(InsuranceSkipPatches), nameof(BeforeInsurance)));
        }

        internal static bool CanSkip(IEnumerable<TraderClass> insurers)
        {
            if (insurers == null) return false;
            foreach (var trader in insurers)
            {
                // Incomplete state keeps the native flow; do not conceal loading errors.
                if (trader == null || trader.Info == null || trader.Info.Available) return false;
            }
            return true;
        }

        private static bool BeforeInsurance(MainMenuControllerClass __instance, ISession ___ISession)
        {
            if (!CanSkip(___ISession?.InsuranceCompany?.Insurers)) return true;
            // Take the same next step as the native insurance Next button, before
            // constructing any insurance screen. That avoids its empty dropdown
            // crash and avoids closing an insurance view that was never initialized.
            AcceptStep.Invoke(__instance, null);
            return false;
        }
    }
}
