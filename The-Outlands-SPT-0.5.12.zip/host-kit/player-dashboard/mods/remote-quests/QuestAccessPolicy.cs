namespace Outlands.RemoteQuests
{
    // This policy changes UI navigation only. Native trader flags remain authoritative.
    public static class QuestAccessPolicy
    {
        public static bool IsRemote(bool disabled, bool unlocked, bool banned) =>
            disabled && unlocked && !banned;

        public static bool CanSelect(bool available, bool disabled, bool unlocked, bool banned) =>
            available || IsRemote(disabled, unlocked, banned);

        public static int SelectMode(bool remote, int requested) => remote ? 1 : requested;
    }
}
