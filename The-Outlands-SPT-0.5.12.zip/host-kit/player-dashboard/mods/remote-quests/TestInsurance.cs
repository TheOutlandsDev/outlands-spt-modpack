using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using HarmonyLib;
using Mono.Cecil;
using Outlands.RemoteQuests;

public class TraderClass { public TraderInfo Info; }
public class TraderInfo { public bool Available; }
public class InsuranceCompanyClass { public IEnumerable<TraderClass> Insurers; }
public interface ISession { InsuranceCompanyClass InsuranceCompany {get;} }
public class Session : ISession { public InsuranceCompanyClass InsuranceCompany {get;set;} }
public class MainMenuControllerClass {
 public ISession ISession; public int InsuranceShown, AcceptShown;
 [MethodImpl(MethodImplOptions.NoInlining)] public void method_51() { InsuranceShown++; }
 [MethodImpl(MethodImplOptions.NoInlining)] public void method_52() { AcceptShown++; }
}
class Program {
 static void Check(bool ok,string message) {if(!ok)throw new Exception(message);}
 static void Main(string[] args) {
  using(var assembly=AssemblyDefinition.ReadAssembly(args[0])) {
   var menu=assembly.MainModule.Types.Single(t=>t.Name=="MainMenuControllerClass");
   var step=menu.Methods.Single(m=>m.Name=="method_51"&&m.Parameters.Count==0);
   Check(step.Body.Instructions.Any(i=>i.Operand is MethodReference m&&m.DeclaringType.FullName.Contains("MatchmakerInsuranceScreen/GClass3913")&&m.Name==".ctor"),"Pinned insurance step constructs insurance screen");
   Check(step.Body.Instructions.Any(i=>i.Operand is MethodReference m&&m.DeclaringType.Name==menu.Name&&m.Name=="method_52"),"Pinned insurance Next points to native accept step");
   var accept=menu.Methods.Single(m=>m.Name=="method_52"&&m.Parameters.Count==0);
   Check(accept.Body.Instructions.Any(i=>i.Operand is MethodReference m&&m.Name=="method_54"),"Native map/access checks remain in accept step");
  }
  var harmony=new Harmony("outlands.test.insurance"); InsuranceSkipPatches.Install(harmony);
  try {
   var inactive=new TraderClass{Info=new TraderInfo{Available=false}};var active=new TraderClass{Info=new TraderInfo{Available=true}};
   foreach(var insurers in new[]{Array.Empty<TraderClass>(),new[]{inactive},new[]{inactive,inactive}}) {
    var menu=new MainMenuControllerClass{ISession=new Session{InsuranceCompany=new InsuranceCompanyClass{Insurers=insurers}}};
    menu.method_51();Check(menu.InsuranceShown==0&&menu.AcceptShown==1,"Empty/inactive insurer list skips exactly one screen");
   }
   foreach(var insurers in new[]{new[]{active},new[]{inactive,active},new TraderClass[]{null},new[]{new TraderClass()}}) {
    var menu=new MainMenuControllerClass{ISession=new Session{InsuranceCompany=new InsuranceCompanyClass{Insurers=insurers}}};
    menu.method_51();Check(menu.InsuranceShown==1&&menu.AcceptShown==0,"Available/incomplete state retains native screen");
   }
   var unloaded=new MainMenuControllerClass();unloaded.method_51();Check(unloaded.InsuranceShown==1,"Missing session stays native");
   Check(!InsuranceSkipPatches.CanSkip(null),"Null enumeration stays native");
   Console.WriteLine("PASS: pinned insurance/accept flow contracts and real Harmony navigation with empty, inactive, available, mixed, and unloaded insurer states.");
  } finally {harmony.UnpatchSelf();}
 }
}
