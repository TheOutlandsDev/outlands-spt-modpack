using System;
using System.Linq;
using Mono.Cecil;
using Mono.Cecil.Cil;

class InspectContracts
{
    static int checks;
    static void Main(string[] args)
    {
        var game = AssemblyDefinition.ReadAssembly(args[0]);
        var plugin = AssemblyDefinition.ReadAssembly(args[1]);
        var loyalty = Find(game, "PlayerLoyaltyData");
        foreach (var name in new[] { "method_1", "method_2" }) {
            var method = Method(loyalty, name);
            Check(method.Parameters.Count == 1 && method.Parameters[0].ParameterType.FullName == "EFT.Player" && method.ReturnType.FullName == "System.Void", "infected kill loyalty contract " + name);
            Check(method.Body.Instructions.Any(i => i.Operand is MethodReference m && m.Name == "set_CanBeFreeKilled"), "native kill marks scav flag " + name);
        }
        Check(Method(loyalty, "MarkAsAggressor").Parameters.Single().ParameterType.FullName == "EFT.IPlayer", "infected aggressor guard contract");
        var revenge = Method(Find(game, "BotsGroup"), "ShallRevengeFor");
        Check(revenge.Parameters.Single().ParameterType.FullName == "EFT.IPlayer" && revenge.ReturnType.FullName == "System.Boolean", "infected revenge guard contract");
        var infected = Find(game, "EFT.WildSpawnType").Fields.Where(f => f.HasConstant && f.Name.StartsWith("infected", StringComparison.Ordinal)).Select(f => f.Name).OrderBy(n => n).ToArray();
        Check(infected.SequenceEqual(new[] { "infectedAssault", "infectedCivil", "infectedLaborant", "infectedPmc", "infectedTagilla" }), "exact five infected roles");
        var info = Find(game, "EFT.Profile/TraderInfo");
        var available = Method(info, "get_Available");
        Calls(available, "System.Boolean EFT.Profile/TraderInfo::get_Disabled()", 1);
        Calls(available, "System.Boolean EFT.Profile/TraderInfo::get_Unlocked()", 1);
        Check(available.Body.Instructions.Any(i => i.Operand is FieldReference f && f.Name == "Banned"), "native bans gate");

        foreach (var pair in new[] { new[] { "EFT.UI.TraderPanel", "method_0" },
            new[] { "TraderCard", "SetCardState" }, new[] { "EFT.UI.TraderAvatar", "method_0" } })
            Calls(Method(Find(game, pair[0]), pair[1]), available.FullName, 1);
        var group = Find(game, "EFT.UI.TraderScreensGroup");
        var select = Method(group, "method_6");
        Calls(select, available.FullName, 1);
        const string refresh = "System.Threading.Tasks.Task TraderClass::RefreshAssortment(System.Boolean,System.Boolean)";
        Calls(select, refresh, 1);
        Calls(Method(group, "method_9"), refresh, 1);
        Calls(select, "System.Boolean EFT.UI.ServicesScreen::CheckAvailableServices(TraderClass,ESessionMode)", 1);
        Check(Method(group, "method_3").Parameters.Single().ParameterType.FullName == "EFT.UI.TraderScreensGroup/ETraderMode", "mode signature");
        Check(group.Fields.Single(f => f.Name == "_tradingTab").FieldType.FullName == "Tab", "trade tab field");
        Check(group.Fields.Single(f => f.Name == "_servicesTab").FieldType.FullName == "Tab", "services tab field");
        Check(Convert.ToInt32(Find(game, "EFT.UI.TraderScreensGroup/ETraderMode").Fields.Single(f => f.Name == "Tasks").Constant) == 1, "tasks mode value");
        Check(Method(Find(game, "Tab"), "get_CanHandlePointerClick").Body.Instructions.Any(i => i.Operand is FieldReference f && f.Name == "Interactable"), "tab input gate");

        var methods = plugin.MainModule.Types.SelectMany(Flat).SelectMany(t => t.Methods).Where(m => m.HasBody).ToArray();
        var forbidden = methods.SelectMany(m => m.Body.Instructions).Where(i =>
            i.Operand is MethodReference m && m.DeclaringType.FullName == "EFT.Profile/TraderInfo" &&
            (m.Name.StartsWith("set_", StringComparison.Ordinal) || m.Name.StartsWith("Set", StringComparison.Ordinal)));
        Check(!forbidden.Any(), "plugin never mutates trader flags or standing");
        Check(!methods.SelectMany(m => m.Body.Instructions).Any(i =>
            (i.OpCode == OpCodes.Stfld || i.OpCode == OpCodes.Stsfld) && i.Operand is FieldReference f &&
            f.DeclaringType.FullName == "EFT.Profile/TraderInfo"), "plugin never writes trader fields");
        var patches = plugin.MainModule.Types.SelectMany(Flat).Single(t => t.Name == "NavigationPatches");
        var replacement = Method(patches, "SelectionTranspiler");
        Check(replacement.Body.Instructions.Count(i => i.Operand is FieldReference f && f.Name.StartsWith("Native", StringComparison.Ordinal)) == 3,
            "selection rewrites exactly availability, assort and services calls");
        Check(Method(patches, "ModePrefix").Body.Instructions.Any(i => i.Operand is MethodReference m && m.Name == "set_ETraderMode_0"), "retained mode changes with displayed mode");

        var turnIns = Find(plugin, "Outlands.RemoteQuests.TurnInPatches");
        Calls(Method(turnIns, "CanTurnIn"), "System.Boolean EFT.Profile/TraderInfo::get_Available()", 1);
        Calls(Method(turnIns, "CanTurnIn"), "System.Boolean EFT.Profile::TryGetTraderInfo(System.String,EFT.Profile/TraderInfo&)", 1);
        Check(!turnIns.Methods.SelectMany(m => m.HasBody ? m.Body.Instructions : Enumerable.Empty<Instruction>())
            .Any(i => i.Operand is MethodReference m && m.Name == "AcceptQuest"), "turn-in guards never alter acceptance");
        var controllerNames = new[] { "LocalQuestControllerClass", "GClass4007", "GClass4008" };
        foreach (var name in controllerNames)
        {
            var controller = Find(game, name);
            var finish = Method(controller, "FinishQuest");
            var handover = Method(controller, "HandoverItem");
            Check(finish.HasBody && finish.IsVirtual && finish.ReturnType.FullName ==
                "System.Threading.Tasks.Task`1<GStruct154`1<GStruct426`1<QuestClass>>>", name + " concrete finish result");
            Check(finish.Parameters.Select(p => p.ParameterType.FullName).SequenceEqual(new[] { "QuestClass", "System.Boolean" }), name + " finish arguments");
            Check(handover.HasBody && handover.IsVirtual && handover.ReturnType.FullName ==
                "System.Threading.Tasks.Task`1<Comfort.Common.IResult>", name + " concrete handover result");
            Check(handover.Parameters.Select(p => p.ParameterType.FullName).SequenceEqual(new[] {
                "QuestClass", "EFT.Quests.ConditionItem", "EFT.InventoryLogic.Item[]", "System.Boolean" }), name + " handover arguments");
        }
        var declaredActions = game.MainModule.Types.SelectMany(Flat).SelectMany(t => t.Methods).Where(m => m.HasBody &&
            (m.Name == "HandoverItem" || m.Name == "FinishQuest") && m.DeclaringType.FullName != "EFT.UI.QuestView").ToArray();
        Check(declaredActions.Length == 6 && declaredActions.All(m => controllerNames.Contains(m.DeclaringType.FullName)),
            "every native concrete quest mutation implementation guarded");
        foreach (var spec in new[] { new[] { "_quest", "QuestClass" }, new[] { "_questController", "AbstractQuestControllerClass" },
            new[] { "_button", "EFT.UI.DefaultUIButton" }, new[] { "_buttonReRoll", "EFT.UI.DefaultUIButton" } })
            Check(Find(game, "EFT.UI.QuestView").Fields.Single(f => f.Name == spec[0]).FieldType.FullName == spec[1], "quest UI field " + spec[0]);
        foreach (var spec in new[] { new[] { "questClass", "QuestClass" }, new[] { "abstractQuestControllerClass", "AbstractQuestControllerClass" },
            new[] { "_handoverButton", "EFT.UI.DefaultUIButton" } })
            Check(Find(game, "EFT.UI.QuestObjectiveView").Fields.Single(f => f.Name == spec[0]).FieldType.FullName == spec[1], "objective UI field " + spec[0]);
        var view = Find(game, "EFT.UI.QuestView");
        var finishUi = view.Methods.Single(m => m.Name == "FinishQuest" && m.Parameters.Count == 1);
        Check(finishUi.ReturnType.FullName == "System.Threading.Tasks.Task" && finishUi.Parameters.Single().ParameterType.FullName == "QuestClass", "finish UI task signature");
        var objectiveUi = Method(Find(game, "EFT.UI.QuestObjectiveView"), "method_2");
        Check(objectiveUi.ReturnType.FullName == "System.Threading.Tasks.Task" && objectiveUi.Parameters.Single().ParameterType.FullName == "QuestClass", "handover UI task signature");
        Check(Method(view, "ShowChangeQuestConfirmation").ReturnType.FullName == "System.Threading.Tasks.Task", "reroll UI task signature");
        Calls(Method(Find(game, "EFT.UI.QuestObjectiveView"), "method_1"), objectiveUi.FullName, 1);
        Check(Method(Find(game, "GStruct154`1"), "get_Failed").Body.Instructions.Any(i => i.OpCode == OpCodes.Cgt_Un), "non-null native error marks completion failed");
        Check(Find(game, "GClass1522").BaseType.FullName == "Diz.LanguageExtensions.Error", "message failure type inherits native error");
        Check(Method(Find(game, "GClass1522"), ".ctor").Parameters.Single().ParameterType.FullName == "System.String", "message failure constructor");
        Check(Method(turnIns, "FinishPrefix").Body.Instructions.Any(i => i.Operand is MethodReference m && m.DeclaringType.FullName == "GClass1522"), "completion guard returns native message failure");
        Check(Method(turnIns, "HandoverPrefix").Body.Instructions.Any(i => i.Operand is MethodReference m && m.DeclaringType.FullName == "Comfort.Common.FailedResult"), "handover guard returns native failure");
        var fika = AssemblyDefinition.ReadAssembly(args[2]);
        var client = Find(fika, "Fika.Core.Main.ClientClasses.ClientQuestController");
        Check(client.BaseType.FullName == "GClass4007", "Fika controller uses guarded native base");
        Calls(Method(client, "<>n__0"), "System.Threading.Tasks.Task`1<GStruct154`1<GStruct426`1<QuestClass>>> GClass4007::FinishQuest(QuestClass,System.Boolean)", 1);
        Calls(Method(client, "<>n__1"), "System.Threading.Tasks.Task`1<Comfort.Common.IResult> GClass4007::HandoverItem(QuestClass,EFT.Quests.ConditionItem,EFT.InventoryLogic.Item[],System.Boolean)", 1);
        Check(Method(Find(fika, client.FullName + "/<FinishQuest>d__2"), "MoveNext").Body.Instructions.Any(i =>
            i.Operand is MethodReference m && m.Name == "get_Succeeded"), "Fika finish packet conditioned on success");
        Check(Method(Find(fika, client.FullName + "/<HandoverItem>d__3"), "MoveNext").Body.Instructions.Any(i =>
            i.Operand is MethodReference m && m.Name == "get_Succeed"), "Fika handover packet conditioned on success");
        Console.WriteLine("Remote quest assembly contracts: " + checks + " checks passed.");
    }
    static TypeDefinition Find(AssemblyDefinition assembly, string name) => assembly.MainModule.Types.SelectMany(Flat).Single(t => t.FullName == name);
    static System.Collections.Generic.IEnumerable<TypeDefinition> Flat(TypeDefinition type)
    { yield return type; foreach (var nested in type.NestedTypes.SelectMany(Flat)) yield return nested; }
    static MethodDefinition Method(TypeDefinition type, string name) => type.Methods.Single(m => m.Name == name);
    static void Calls(MethodDefinition method, string fullName, int count) => Check(
        method.Body.Instructions.Count(i => i.Operand is MethodReference m && m.FullName == fullName) == count,
        method.FullName + " calls " + fullName);
    static void Check(bool ok, string label) { if (!ok) throw new Exception(label); checks++; }
}
