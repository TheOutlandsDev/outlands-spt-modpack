using System;
using System.Runtime.CompilerServices;
using EFT;
using HarmonyLib;
using Outlands.RemoteQuests;
namespace EFT {
 public interface IPlayer { bool IsAI{get;} Profile Profile{get;} }
 public enum WildSpawnType { assault, marksman, cursedAssault, bossTagilla, pmcBEAR, pmcUSEC, infectedAssault, infectedPmc, infectedCivil, infectedLaborant, infectedTagilla }
 public class Profile { public InfoClass Info=new InfoClass(); }
 public class InfoClass { public ProfileInfoSettingsClass Settings=new ProfileInfoSettingsClass(); }
 public class ProfileInfoSettingsClass { public WildSpawnType Role; }
 public class Player:IPlayer {public bool IsAI{get;set;}=true; public Profile Profile{get;set;}=new Profile();}
}
public class PlayerLoyaltyData {
 public int Penalties,Flags;
 [MethodImpl(MethodImplOptions.NoInlining)] public void method_1(Player victim){Penalties++;Flags++;}
 [MethodImpl(MethodImplOptions.NoInlining)] public void method_2(Player victim){Penalties++;Flags++;}
 [MethodImpl(MethodImplOptions.NoInlining)] public void MarkAsAggressor(IPlayer victim){Flags++;}
}
public class BotsGroup {
 [MethodImpl(MethodImplOptions.NoInlining)] public bool ShallRevengeFor(IPlayer victim){return true;}
}
class TestZombieSafety {
 static int n;static void Check(bool v,string s){n++;if(!v)throw new Exception(s);}
 static void Main(){
  var h=new Harmony("outlands.zombie-safety.fixture");ZombieSafetyPatches.Install(h);
  try {
   foreach(WildSpawnType role in Enum.GetValues(typeof(WildSpawnType))){
    var p=new Player();p.Profile.Info.Settings.Role=role;var loyalty=new PlayerLoyaltyData();var infected=role.ToString().StartsWith("infected",StringComparison.Ordinal);
    loyalty.method_1(p);loyalty.method_2(p);loyalty.MarkAsAggressor(p);
    Check(loyalty.Penalties==(infected?0:2),role+" penalty isolation");
    Check(loyalty.Flags==(infected?0:3),role+" flag isolation");
    Check(new BotsGroup().ShallRevengeFor(p)==!infected,role+" revenge isolation");
    p.IsAI=false;Check(!ZombieSafetyPatches.IsInfected(p),role+" human never exempt");
   }
   Check(!ZombieSafetyPatches.IsInfected(null),"null stays native");Check(!ZombieSafetyPatches.IsInfectedRole("infectedPretend"),"no broad prefix exemption");
   var malformed=new Player{Profile=null};Check(!ZombieSafetyPatches.IsInfected(malformed),"missing profile stays native");
   malformed.Profile=new Profile{Info=null};Check(!ZombieSafetyPatches.IsInfected(malformed),"missing info stays native");
   malformed.Profile.Info=new InfoClass{Settings=null};Check(!ZombieSafetyPatches.IsInfected(malformed),"missing settings stays native");
   Console.WriteLine(n+" production zombie safety hook checks passed.");
  }finally{h.UnpatchSelf();}
 }
}
