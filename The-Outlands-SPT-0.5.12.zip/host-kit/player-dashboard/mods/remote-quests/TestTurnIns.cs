// Production turn-in hooks run against isolated doubles; no live game/profile API.
using System;
using System.Linq;
using System.Threading.Tasks;
using EFT;
using EFT.UI;
using EFT.Quests;
using EFT.InventoryLogic;
using HarmonyLib;
using Outlands.RemoteQuests;

class TestTurnIns
{
    static int checks;
    const string Away = "aaaaaaaaaaaaaaaaaaaaaaaa", Local = "bbbbbbbbbbbbbbbbbbbbbbbb";
    static void Check(bool ok, string label) { checks++; if (!ok) throw new Exception(label); }
    static QuestClass Quest(string trader, EQuestStatus status = EQuestStatus.AvailableForFinish) =>
        new QuestClass { Template = new RawQuestClass { TraderId = trader }, QuestStatus = status, IsChangeAllowed = true };
    static Profile Profile() => new Profile { TradersInfo = {
        { Away, new Profile.TraderInfo { Disabled = true, Unlocked = true } },
        { Local, new Profile.TraderInfo { Disabled = false, Unlocked = true } } } };

    static void Main()
    {
        var harmony = new Harmony("outlands.remote-quests.turn-in-review");
        try
        {
            TurnInPatches.Install(harmony);
            foreach (var type in new[] { typeof(LocalQuestControllerClass), typeof(GClass4007), typeof(GClass4008) })
                foreach (var name in new[] { "FinishQuest", "HandoverItem" })
                    Check(Harmony.GetPatchInfo(type.GetMethod(name)).Prefixes.Any(), "central guard installed: " + type.Name + "." + name);

            foreach (var controller in new AbstractQuestControllerClass[] { new LocalQuestControllerClass(), new GClass4007(), new GClass4008(), new FikaClientQuestController() })
            {
                controller.Profile = Profile();
                var remote = Quest(Away);
                var result = controller.FinishQuest(remote, true).GetAwaiter().GetResult();
                Check(result.Failed && !result.Succeeded, "remote finish returns a native failure: " + controller.GetType().Name);
                Check(controller.Finishes == 0 && remote.QuestStatus == EQuestStatus.AvailableForFinish, "remote finish has no reward/status mutation");
                foreach (var condition in new ConditionItem[] { new ConditionHandoverItem(), new ConditionHandoverItem { Money = true }, new ConditionWeaponAssembly() })
                {
                    var kind = condition is ConditionWeaponAssembly ? "weapon assembly" : ((ConditionHandoverItem)condition).Money ? "money" : "items";
                    var items = new[] { new Item() };
                    var handover = controller.HandoverItem(remote, condition, items, true).GetAwaiter().GetResult();
                    Check(handover.Failed && !handover.Succeed, "remote " + kind + " handover returns failure");
                    Check(controller.Handovers == 0 && !items[0].Consumed, "remote " + kind + " handover preserves inventory");
                }
                if (controller is FikaClientQuestController fika) Check(fika.SentPackets == 0, "Fika propagates failure without inventory/reward packet");
                var accepted = Quest(Away, EQuestStatus.AvailableForStart);
                Check(controller.AcceptQuest(accepted, true).GetAwaiter().GetResult().Succeed && controller.Accepts == 1 && accepted.QuestStatus == EQuestStatus.Started,
                    "remote new quest acceptance remains native and functional");
                var local = Quest(Local);
                Check(controller.FinishQuest(local, true).GetAwaiter().GetResult().Succeeded && controller.Finishes == 1 && local.QuestStatus == EQuestStatus.Success,
                    "local completion reaches native handler");
                var localItems = new[] { new Item() };
                Check(controller.HandoverItem(local, new ConditionItem(), localItems, true).GetAwaiter().GetResult().Succeed && controller.Handovers == 1 && localItems[0].Consumed,
                    "local handover reaches native handler");
                if (controller is FikaClientQuestController localFika) Check(localFika.SentPackets == 2, "Fika still sends successful local inventory/reward packets");
            }

            var active = new LocalQuestControllerClass { Profile = Profile() };
            var quest = Quest(Away);
            foreach (var disabled in new[] { false, true }) foreach (var unlocked in new[] { false, true }) foreach (var banned in new[] { false, true })
            {
                var info = active.Profile.TradersInfo[Away];
                info.Disabled = disabled; info.Unlocked = unlocked; info.Banned = banned;
                Check(TurnInPatches.CanTurnIn(active, quest) == (!disabled && unlocked && !banned), "original availability truth table");
                Check(info.Disabled == disabled && info.Unlocked == unlocked && info.Banned == banned, "native trader flags preserved");
            }
            active.Profile = Profile();
            foreach (var bad in new[] { (QuestClass)null, new QuestClass(), Quest(null), Quest(" "), Quest("short"), Quest("zzzzzzzzzzzzzzzzzzzzzzzz"), Quest("cccccccccccccccccccccccc") })
                Check(!TurnInPatches.CanTurnIn(active, bad), "missing quest/trader metadata fails closed");
            Check(!TurnInPatches.CanTurnIn(null, quest), "missing controller fails closed");
            Check(!TurnInPatches.CanTurnIn(new LocalQuestControllerClass(), quest), "missing profile fails closed");

            var view = new QuestView { _questController = active, _quest = Quest(Away),
                _trader = new TraderClass { Info = active.Profile.TradersInfo[Local] } };
            view.ShowButtonBlock();
            Check(!view._button.Interactable && view._button.Header == "Visit trader to turn in", "remote completion visibly requires a visit");
            Check(!view._buttonReRoll.gameObject.activeSelf, "remote reroll hidden");
            view.FinishQuest(view._quest).GetAwaiter().GetResult();
            Check(active.Finishes == 0, "remote completion UI handler guarded");
            view.ShowChangeQuestConfirmation().GetAwaiter().GetResult();
            Check(view.Rerolls == 0, "remote reroll confirmation guarded");
            view._quest = Quest(Away, EQuestStatus.AvailableForStart);
            view.ShowButtonBlock();
            Check(view._button.Interactable && view._button.Header == "Accept", "remote accept button stays available");
            view.StartQuest(view._quest).GetAwaiter().GetResult();
            Check(active.Accepts == 1, "remote acceptance UI handler unmodified");

            var objective = new QuestObjectiveView { abstractQuestControllerClass = active, questClass = Quest(Away), Items = new[] { new Item() } };
            Check(objective.OnConditionChanged(new ConditionProgressChecker()), "objective native result preserved");
            Check(!objective._handoverButton.gameObject.activeSelf, "remote handover hidden after native refresh");
            objective._handoverButton.gameObject.SetActive(true);
            objective.OnConditionChanged(new ConditionProgressChecker());
            Check(!objective._handoverButton.gameObject.activeSelf, "repeated objective refresh cannot reopen remote handover");
            objective.method_2(objective.questClass).GetAwaiter().GetResult();
            Check(active.Handovers == 0 && !objective.Items[0].Consumed, "remote handover UI handler guarded");

            view._quest = Quest(Local); view._trader.Info = active.Profile.TradersInfo[Away];
            view.ShowButtonBlock();
            Check(view._button.Interactable && view._button.Header == "Complete" && view._buttonReRoll.gameObject.activeSelf,
                "local quest restores completion and reroll even when a different trader card is away");
            view.FinishQuest(view._quest).GetAwaiter().GetResult(); view.ShowChangeQuestConfirmation().GetAwaiter().GetResult();
            Check(active.Finishes == 1 && view.Rerolls == 1, "local completion and reroll UI remain functional");
            objective.questClass = Quest(Local); objective.OnConditionChanged(new ConditionProgressChecker());
            Check(objective._handoverButton.gameObject.activeSelf, "local objective restores native handover visibility");
            objective.method_2(objective.questClass).GetAwaiter().GetResult();
            Check(active.Handovers == 1 && objective.Items[0].Consumed, "local handover UI remains functional");

            // An already displayed local quest must be rechecked at action time.
            var stale = Quest(Local); active.Profile.TradersInfo[Local].Disabled = true;
            Check(active.FinishQuest(stale, true).GetAwaiter().GetResult().Failed && active.Finishes == 1,
                "trader becoming unavailable after rendering blocks completion");
            var staleItems = new[] { new Item() };
            Check(active.HandoverItem(stale, new ConditionItem(), staleItems, true).GetAwaiter().GetResult().Failed && !staleItems[0].Consumed,
                "trader becoming unavailable after rendering blocks inventory mutation");
        }
        finally { harmony.UnpatchSelf(); }
        Console.WriteLine("Production acceptance-only quest hooks: " + checks + " checks passed using isolated UI/controllers and real Harmony.");
    }
}
