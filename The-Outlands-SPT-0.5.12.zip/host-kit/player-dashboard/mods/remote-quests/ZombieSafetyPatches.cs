using System;
using System.Reflection;
using EFT;
using HarmonyLib;

namespace Outlands.RemoteQuests
{
    // Shared client rules stay in the existing managed DLL so the approved updater
    // can deliver the fix without asking users to install a second plugin.
    internal static class ZombieSafetyPatches
    {
        internal static bool IsInfectedRole(string role)
        {
            return role == "infectedAssault" || role == "infectedPmc" ||
                role == "infectedCivil" || role == "infectedLaborant" || role == "infectedTagilla";
        }

        internal static bool IsInfected(IPlayer player)
        {
            return player != null && player.IsAI && player.Profile != null &&
                player.Profile.Info != null && player.Profile.Info.Settings != null &&
                IsInfectedRole(player.Profile.Info.Settings.Role.ToString());
        }

        public static void Install(Harmony harmony)
        {
            foreach (var name in new[] { "method_1", "method_2" })
                harmony.Patch(Require(typeof(PlayerLoyaltyData), name, typeof(Player)),
                    prefix: new HarmonyMethod(typeof(ZombieSafetyPatches), nameof(KillPrefix)));
            harmony.Patch(Require(typeof(PlayerLoyaltyData), "MarkAsAggressor", typeof(IPlayer)),
                prefix: new HarmonyMethod(typeof(ZombieSafetyPatches), nameof(AggressorPrefix)));
            harmony.Patch(Require(typeof(BotsGroup), "ShallRevengeFor", typeof(IPlayer)),
                postfix: new HarmonyMethod(typeof(ZombieSafetyPatches), nameof(RevengePostfix)));
        }

        private static MethodInfo Require(Type type, string name, Type argument)
        {
            return AccessTools.DeclaredMethod(type, name, new[] { argument }) ??
                throw new MissingMethodException(type.FullName, name);
        }

        internal static bool KillPrefix(Player __0) { return !IsInfected(__0); }
        internal static bool AggressorPrefix(IPlayer __0) { return !IsInfected(__0); }
        internal static void RevengePostfix(IPlayer __0, ref bool __result)
        {
            if (IsInfected(__0)) __result = false;
        }
    }
}
