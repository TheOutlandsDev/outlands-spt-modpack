#!/usr/bin/env python3
"""Prepare the reviewed population-mod spawn configuration; never changes live files."""
import copy
import hashlib
import json
from pathlib import Path

SOURCE = Path(__file__).with_name('spawn-preset.json')
TARGETS = {'SPT/user/mods/zzz-CodexAiPopulationTuning/config/config.json'}


def semantic(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()


def transform(document, row):
    """Exact baseline/preset hashes prevent compounding or erasing other edits."""
    current = semantic(document)
    if current == row['valueSemanticSha256']:
        return copy.deepcopy(document)
    if current != row['expectedSemanticSha256']:
        raise ValueError('Spawn settings differ from the reviewed baseline and preset')
    result = copy.deepcopy(document)
    seen = set()
    for change in row['changes']:
        path = change['path']
        identity = tuple(path)
        if not path or identity in seen:
            raise ValueError('Duplicate or empty spawn setting')
        seen.add(identity)
        cursor = result
        for key in path[:-1]:
            cursor = cursor[key]
        if cursor[path[-1]] != change['expected']:
            raise ValueError('Spawn setting baseline changed')
        cursor[path[-1]] = change['value']
    if semantic(result) != row['valueSemanticSha256']:
        raise ValueError('Spawn preset fingerprint mismatch')
    return result


def prepare(root, preset=None):
    preset = json.loads(SOURCE.read_text()) if preset is None else preset
    if preset['schemaVersion'] != 1 or {r['path'] for r in preset['files']} != TARGETS or len(preset['files']) != 1:
        raise ValueError('Unexpected spawn preset targets')
    root = Path(root).absolute()
    required = preset.get('requiredPopulationDllSha256')
    if required is not None:
        module = root / 'SPT/user/mods/zzz-CodexAiPopulationTuning/Codex.AiPopulationTuning.dll'
        if any(p.is_symlink() for p in (module, *module.parents)) or not module.is_file():
            raise ValueError('Matching population module is required before preparing this preset')
        if module.stat().st_size > 2 * 1024 * 1024 or hashlib.sha256(module.read_bytes()).hexdigest() != required:
            raise ValueError('Population module differs; update the matching SelfHost DLL and config together')
    changes = {}
    for row in preset['files']:
        path = root / row['path']
        cursor = path
        while cursor != root.parent:
            if cursor.is_symlink():
                raise ValueError('Linked spawn configurations are refused')
            if cursor == root:
                break
            cursor = cursor.parent
        if not path.is_file() or path.stat().st_size > 2 * 1024 * 1024:
            raise ValueError('Expected bounded spawn configuration')
        document = json.loads(path.read_text())
        result = transform(document, row)
        changes[path] = (json.dumps(result, indent=2) + '\n').encode()
    return changes


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True, help='SPT game folder, containing SPT/SPT_Data')
    args = parser.parse_args()
    rows = prepare(args.root)
    print(json.dumps({'prepared': len(rows), 'liveFilesChanged': False}))
