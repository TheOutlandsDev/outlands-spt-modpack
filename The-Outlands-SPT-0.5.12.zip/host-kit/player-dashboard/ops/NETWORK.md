# Private Tailscale hosting

The host was reachable from itself but could not accept a player connection
because Tailscale's `ShieldsUp` (block incoming connections) preference was true.
SPT already listens only on the host's Tailscale IPv4 address, TCP 6969.
Fika WebSockets share that HTTPS listener. Raid traffic uses UDP 25565.

`enable-private-hosting.sh` first installs and enables a persistent, dedicated
nftables host-input table. It accepts established/related traffic plus TCP 6969,
UDP 25565, and TCP 8446 on `tailscale0`, then drops other input on that interface.
It leaves LAN, loopback, forwarding, and the host's other firewall tables alone.
Only after that policy loads does it turn off Tailscale's host-wide incoming block.
The policy loads before tailscaled at boot. Stopping the oneshot service leaves
the active firewall table intact. An already active UFW policy makes the script
stop before applying changes so the rules can be integrated explicitly.

Port 8446 is reserved for a Tailscale Serve HTTPS proxy to the dashboard's
loopback HTTP port 3010. Do not use Funnel or expose Dockhand's admin port.
Tailscale ACLs/grants still decide which peers may access these ports.

Review the policy, then run the installer with sudo on the game host. To disable
all incoming Tailscale hosting again, use `sudo tailscale set --shields-up=true`.
Keep the dedicated firewall enabled while ShieldsUp is false.

From a separate Windows peer, test:

```powershell
Test-NetConnection 127.0.0.1 -Port 6969
curl.exe -k -H "responsecompressed: 0" https://127.0.0.1:6969/singleplayer/settings/version
```

Use the host's actual Tailscale address if deploying somewhere else. A successful
HTTP test proves the backend path; complete a headless raid to test UDP transport.
