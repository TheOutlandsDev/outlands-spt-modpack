#!/usr/bin/env python3
"""Exclude host-only plugins from NarcoNet's human-client advertisements."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import tempfile

ROOT = Path(__file__).resolve().parents[2]
CONFIG = "runtime/SPT/user/mods/NarcoNet-Server/config.yaml"
REQUIRED = ("BepInEx/plugins/FikaDynamicAI", "BepInEx/plugins/CodexDiagnostics",
            "BepInEx/plugins/Fika/Fika.Headless*", "BepInEx/plugins/Fika/LICENSE-HEADLESS*")


class Refused(ValueError):
    pass


def ordinary(path):
    cursor = path.absolute()
    while cursor != cursor.parent:
        if cursor.is_symlink():
            raise Refused("Symlinked NarcoNet configuration or backup path refused")
        cursor = cursor.parent
    if not path.is_file() or path.stat().st_size > 1024 * 1024:
        raise Refused("Expected bounded ordinary NarcoNet configuration")
    return path.read_bytes(), stat.S_IMODE(path.stat().st_mode)


def desired(raw):
    """Only insert exclusions; preserve sync settings, comments and other bytes."""
    if len(raw) > 1024 * 1024:
        raise Refused("NarcoNet configuration exceeds its limit")
    try:
        text = raw.decode("utf-8")
    except UnicodeError as error:
        raise Refused("Expected UTF-8 NarcoNet YAML") from error
    lines = text.splitlines(keepends=True)
    headers = [index for index, line in enumerate(lines) if re.fullmatch(r"exclusions:[ \t]*(?:\r?\n)?", line)]
    if len(headers) != 1 or len(re.findall(r"^syncPaths:[ \t]*\r?$", text, re.M)) != 1:
        raise Refused("Expected one syncPaths and one exclusions YAML block")
    position = headers[0]
    entries = set()
    for line in lines[position + 1:]:
        value = line.rstrip("\r\n")
        if not value.strip() or value.lstrip().startswith("#"):
            continue
        match = re.fullmatch(r"  - ([^\r\n]+)", value)
        if not match:
            raise Refused("Unsupported NarcoNet exclusions YAML shape; no changes made")
        scalar = match[1]
        try:
            if scalar.startswith('"'):
                scalar = json.loads(scalar)
            elif scalar.startswith("'") and scalar.endswith("'"):
                scalar = scalar[1:-1].replace("''", "'")
            elif re.search(r"[\s:#{}\[\]&!|>]", scalar):
                raise ValueError
        except (ValueError, TypeError) as error:
            raise Refused("Unsupported exclusion scalar; no changes made") from error
        if not isinstance(scalar, str) or not scalar:
            raise Refused("Expected nonempty exclusion paths")
        entries.add(scalar)
    missing = [path for path in REQUIRED if path not in entries]
    if not missing:
        return raw, []
    newline = "\r\n" if lines[position].endswith("\r\n") else "\n"
    if not lines[position].endswith("\n"):
        lines[position] += newline
    addition = ["  # Host-only plugins must never sync onto human clients." + newline]
    addition += ["  - " + json.dumps(path) + newline for path in missing]
    lines[position + 1:position + 1] = addition
    return "".join(lines).encode("utf-8"), missing


def atomic(path, data, mode):
    if path.is_symlink() or path.parent.is_symlink():
        raise Refused("Symlinked write target refused")
    fd, temporary = tempfile.mkstemp(prefix=".narconet-policy-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            os.fchmod(stream.fileno(), mode)
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def operate(workspace, apply=False):
    path = workspace / CONFIG
    raw, mode = ordinary(path)
    changed, added = desired(raw)
    result = {"changed": bool(added), "applied": False, "addedExclusions": added,
              "requiresBackendRestart": bool(added), "config": CONFIG,
              "beforeSha256": hashlib.sha256(raw).hexdigest(),
              "afterSha256": hashlib.sha256(changed).hexdigest()}
    if not apply or not added:
        return result
    parent = workspace / "linux/backups"
    # Check ancestry before mkdir/write, including an existing backup directory.
    cursor = parent.absolute()
    while cursor != cursor.parent:
        if cursor.is_symlink():
            raise Refused("Symlinked backup path refused")
        cursor = cursor.parent
    parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    backup = Path(tempfile.mkdtemp(prefix="narconet-client-policy-" + stamp + "-", dir=parent))
    atomic(backup / "config.yaml", raw, 0o600)
    manifest = {"schemaVersion": 1, "path": CONFIG, "bytes": len(raw), "mode": mode,
                "sha256": result["beforeSha256"], "createdAtUtc": stamp}
    atomic(backup / "manifest.json", (json.dumps(manifest, indent=2) + "\n").encode(), 0o600)
    if ordinary(path) != (raw, mode) or (backup / "config.yaml").read_bytes() != raw:
        raise Refused("Configuration changed or backup verification failed; original preserved")
    atomic(path, changed, mode)
    if ordinary(path) != (changed, mode):
        raise Refused("NarcoNet configuration verification failed; inspect the retained backup")
    result.update(applied=True, backup=str(backup))
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--apply", action="store_true", help="Backup and atomically update the config; never restart services")
    args = parser.parse_args()
    print(json.dumps(operate(ROOT, args.apply), indent=2))
