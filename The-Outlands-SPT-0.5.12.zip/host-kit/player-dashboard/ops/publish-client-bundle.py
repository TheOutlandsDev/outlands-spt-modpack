#!/usr/bin/env python3
"""Publish the curated client manifest/updater without touching running game services."""
import argparse
import fcntl
import hashlib
import importlib.util
import io
import json
import os
import re
import tempfile
import zipfile
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "player-dashboard"))
import client_updates
spec = importlib.util.spec_from_file_location("outlands_client_pack", ROOT / "player-dashboard/client-pack/build.py")
pack = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pack)
CLIENT_FILES = ("BepInEx/plugins/OutlandsRemoteQuests/Outlands.RemoteQuests.dll",
                "BepInEx/plugins/OutlandsRemoteQuests/INSTALL.txt")
UPDATER_FILES = ("Update-Outlands.ps1", "Outlands Client Updater.cmd", "Update and Play.cmd", "README.txt", "client-policy.json",
                 "Install Play Outlands.cmd", "Install-PlayOutlands.ps1")
PUBLICATION_ORDER = ("outlands-client-pack.zip", "outlands-client-updater.zip",
                     "outlands-client-updater.sha256", "client-manifest.json", "client-sync-manifest.json")
LEGACY_FILES = ("outlands-remote-quests.zip", "outlands-remote-quests.sha256")
HTTP_FILES = (*LEGACY_FILES, *PUBLICATION_ORDER)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def ordinary(path, maximum):
    if path.is_symlink() or not path.is_file() or not 0 < path.stat().st_size <= maximum:
        raise ValueError("Expected bounded ordinary file: " + str(path))
    data = path.read_bytes()
    if len(data) > maximum:
        raise ValueError("File grew beyond limit")
    return data


def inspect_package(raw):
    if not 0 < len(raw) <= 16 * 1024 * 1024:
        raise ValueError("Invalid package size")
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        infos = archive.infolist()
        if len(infos) != 2 or sorted(x.filename for x in infos) != sorted(CLIENT_FILES):
            raise ValueError("Package must contain exactly the two approved Remote Quests files")
        rows = []
        for info in infos:
            if (info.is_dir() or info.file_size > 1024 * 1024 or
                    ((info.external_attr >> 16) & 0o170000) not in (0, 0o100000) or info.external_attr & 1024):
                raise ValueError("Invalid package member")
            data = archive.read(info)
            if not data or len(data) != info.file_size:
                raise ValueError("Invalid package member length")
            rows.append(dict(path=info.filename, sha256=digest(data), size=len(data)))
        install = archive.read(CLIENT_FILES[1]).decode("utf-8")
        version = re.search(r"^Outlands Remote Quests (\d+\.\d+\.\d+)$", install, re.M)
        if not version or not archive.read(CLIENT_FILES[0]).startswith(b"MZ"):
            raise ValueError("Invalid authored client package")
        return version.group(1), rows


def atomic(path, data):
    if path.is_symlink() or path.parent.is_symlink():
        raise ValueError("Refusing a symlinked publication target")
    descriptor, temporary = tempfile.mkstemp(prefix=".client-bundle-", dir=path.parent)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            os.fchmod(stream.fileno(), 0o600)
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        parent = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(parent)
        finally:
            os.close(parent)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def prepare(workspace, bundle_version, now=None):
    """Only disposable scratch files are written; no source/runtime/downloads mutation."""
    if not re.fullmatch(r"\d{1,4}(?:\.\d{1,4}){2,3}", bundle_version):
        raise ValueError("Invalid bundle version")
    source = workspace / "player-dashboard"
    downloads = source / "deployment/downloads"
    package = ordinary(downloads / "outlands-remote-quests.zip", 16 * 1024 * 1024)
    inspect_package(package)
    checksum = ordinary(downloads / LEGACY_FILES[1], 512)
    if checksum.decode("ascii").split() != [digest(package), LEGACY_FILES[0]]:
        raise ValueError("Preserved legacy checksum does not match its ZIP")
    key_path = source / "deployment/fika_api_key"
    key = ordinary(key_path, 4096).strip() if key_path.exists() else b""
    approved = json.loads(ordinary(source / "client-pack/inventory.json", 1024 * 1024))
    runtime = workspace / "runtime"
    pack.verify_pins(runtime)
    with tempfile.TemporaryDirectory(prefix="outlands-client-publish-") as temporary:
        directory = Path(temporary)
        manifest, policy = pack.build(runtime, approved, directory, [key] if key else [])
        payload = ordinary(directory / "outlands-client-pack.zip", pack.LIMITS["zipBytes"])
    policy_bytes = ordinary(source / "client-updater/client-policy.json", 1024 * 1024)
    if json.loads(policy_bytes) != policy:
        raise ValueError("Shipped updater policy differs from curated runtime; review/copy the generated policy before publishing")
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in UPDATER_FILES:
            data = ordinary(source / "client-updater" / name, 1024 * 1024)
            data.decode("utf-8")
            if name == "Update-Outlands.ps1" and b"OutlandsClientUpdater/1.2.0" not in data:
                raise ValueError("Full-pack publication requires updater 1.2.0")
            info = zipfile.ZipInfo("Outlands Client Updater/" + name, (2026, 10, 23, 0, 0, 0))
            info.external_attr = 0o100644 << 16
            info.create_system = 3
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, data, compresslevel=9)
    updater = output.getvalue()
    if len(updater) > 2 * 1024 * 1024:
        raise ValueError("Updater archive is too large")
    manifest["bundleVersion"] = bundle_version
    if now is not None:
        manifest["generatedAtUtc"] = now.isoformat()
    artifacts = {"outlands-client-pack.zip": payload, "outlands-client-updater.zip": updater,
                 "outlands-client-updater.sha256": (digest(updater) + "  outlands-client-updater.zip\n").encode(),
                 "client-manifest.json": (json.dumps(manifest, indent=2) + "\n").encode()}
    sync_manifest = json.loads(json.dumps(manifest))
    sync_manifest["packages"][0]["fileTransport"] = "sha256-v1"
    artifacts["client-sync-manifest.json"] = pack.canonical(sync_manifest)
    if len(artifacts["client-sync-manifest.json"]) > 1024 * 1024:
        raise ValueError("Sync manifest is too large")
    if len(artifacts["client-manifest.json"]) > 1024 * 1024:
        raise ValueError("Manifest is too large")
    if key:
        with zipfile.ZipFile(io.BytesIO(updater)) as archive:
            if any(key in archive.read(name) for name in archive.namelist()):
                raise ValueError("Private deployment key found in updater source")
        if key in artifacts["client-manifest.json"]:
            raise ValueError("Private deployment key found in manifest")
        with zipfile.ZipFile(io.BytesIO(package)) as archive:
            if any(key in archive.read(name) for name in archive.namelist()):
                raise ValueError("Private deployment key found in legacy package")
    return artifacts, manifest


def publish_blobs(downloads, artifacts):
    """Install verified immutable blobs before exposing the new sync manifest.

    Old blobs remain available to clients pinned to an earlier manifest. They
    contain only reviewed human payloads, never raw runtime or server files.
    """
    manifest = json.loads(artifacts["client-sync-manifest.json"])
    package = manifest["packages"][0]
    raw = artifacts["outlands-client-pack.zip"]
    if digest(raw) != package["sha256"] or len(raw) != package["size"]:
        raise ValueError("Full pack differs from its sync manifest")
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        if archive.namelist() != [r["path"] for r in package["files"]]:
            raise ValueError("Blob membership mismatch")
        for row in package["files"]:
            data = archive.read(row["path"])
            if len(data) != row["size"] or digest(data) != row["sha256"]:
                raise ValueError("Blob hash/size mismatch")
            name = "client-file-" + row["sha256"] + ".bin"
            if not re.fullmatch(r"client-file-[0-9a-f]{64}\.bin", name):
                raise ValueError("Invalid blob identity")
            target = downloads / name
            if target.exists() or target.is_symlink():
                if ordinary(target, pack.LIMITS["fileBytes"]) != data:
                    raise ValueError("Immutable published blob was modified")
            else:
                atomic(target, data)


def publish(downloads, artifacts):
    """Verify immutable blobs first; stage metadata and expose sync manifest last."""
    if set(artifacts) != set(PUBLICATION_ORDER):
        raise ValueError("Only the exact approved HTTP artifact set may be published")
    if downloads.is_symlink() or not downloads.is_dir():
        raise ValueError("Expected ordinary downloads directory")
    lock_path = downloads.parent / ".client-publish.lock"
    if lock_path.is_symlink():
        raise ValueError("Symlinked publication lock refused")
    with lock_path.open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        previous = client_updates.read(downloads / "client-sync-manifest.json")
        client_updates.identity(json.loads(artifacts["client-sync-manifest.json"]))
        publish_blobs(downloads, artifacts)
        staged = {}
        try:
            for name in PUBLICATION_ORDER:
                target = downloads / name
                if target.is_symlink() or (target.exists() and not target.is_file()):
                    raise ValueError("Publication target must be an ordinary file")
                descriptor, temporary = tempfile.mkstemp(prefix=".client-bundle-", dir=downloads)
                staged[name] = Path(temporary)
                with os.fdopen(descriptor, "wb") as stream:
                    os.fchmod(stream.fileno(), 0o600)
                    stream.write(artifacts[name])
                    stream.flush()
                    os.fsync(stream.fileno())
            # Close admission for old validation generations before exposing new
            # sync metadata. A partial publication remains conservatively blocked.
            gate_path = downloads.parents[2] / "runtime/SPT/user/mods/zzz-OutlandsClientPackPolicy/policy.json"
            gate = client_updates.read(gate_path)
            if gate is not None:
                if gate.get("schemaVersion") != 2:
                    raise ValueError("Upgrade the client policy before publishing a new client release")
                gate["releaseFingerprint"] = client_updates.identity(json.loads(artifacts["client-sync-manifest.json"]))["fingerprint"]
                atomic(gate_path, (json.dumps(gate, indent=2) + "\n").encode())
            for name in PUBLICATION_ORDER:
                os.replace(staged[name], downloads / name)
                parent = os.open(downloads, os.O_RDONLY | os.O_DIRECTORY)
                try:
                    os.fsync(parent)
                finally:
                    os.close(parent)
            client_updates.publication(downloads.parents[2],
                json.loads(artifacts["client-sync-manifest.json"]), previous, atomic)
        finally:
            for temporary in staged.values():
                if temporary.exists():
                    temporary.unlink()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle-version", required=True)
    parser.add_argument("--check", action="store_true", help="Validate/build in disposable scratch space; do not publish or change source")
    args = parser.parse_args()
    artifacts, manifest = prepare(ROOT, args.bundle_version)
    downloads = ROOT / "player-dashboard/deployment/downloads"
    if not args.check:
        publish(downloads, artifacts)
    print(json.dumps(dict(published=not args.check, bundleVersion=manifest["bundleVersion"],
                          managedPackages=len(manifest["packages"]),
                          updaterVersion="1.2.0", updaterEngineVersion="1.2.0", managedFiles=len(manifest["packages"][0]["files"]),
                          httpAssets=list(HTTP_FILES), legacyDownloadsPreserved=True,
                          files={name: dict(bytes=len(data), sha256=digest(data)) for name, data in artifacts.items()}), indent=2))


if __name__ == "__main__":
    main()
