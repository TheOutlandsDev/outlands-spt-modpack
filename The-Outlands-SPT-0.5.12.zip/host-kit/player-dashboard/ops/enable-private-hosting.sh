#!/usr/bin/env bash
# Run as root after reviewing the adjacent policy. No public router exposure.
set -euo pipefail
[[ $EUID == 0 ]] || { echo 'Run this script with sudo in your own Ubuntu terminal.' >&2; exit 1; }
root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
command -v nft >/dev/null
command -v tailscale >/dev/null
# Require the existing host firewall to be inactive. An active policy needs a
# deliberate integration instead of silently overriding its input decisions.
if command -v ufw >/dev/null && ufw status | head -n 1 | grep -q '^Status: active'; then
    echo 'UFW is active. No changes made; integrate the three ports into its policy first.' >&2
    exit 1
fi
nft --check -f "$root/tailnet-firewall.nft"
install -m 0644 "$root/tailnet-firewall.nft" /etc/node01-spt-tailnet.nft
install -m 0644 "$root/node01-spt-tailnet.service" /etc/systemd/system/node01-spt-tailnet.service
systemctl daemon-reload
systemctl enable --now node01-spt-tailnet.service
# The dedicated policy must exist before the host-wide incoming block is lifted.
nft list table inet node01_spt_tailnet >/dev/null
tailscale set --shields-up=false
echo 'Private hosting enabled: TCP 6969, UDP 25565, TCP 8446 on tailscale0 only.'
echo 'Other new incoming connections on tailscale0 remain blocked by the dedicated policy.'
