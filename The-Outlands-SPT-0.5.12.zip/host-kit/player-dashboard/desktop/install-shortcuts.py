#!/usr/bin/env python3
"""Install owner-only SPT desktop and application-menu shortcuts."""
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VIEWS = (
    ('players', 'SPT Players and Raids', 'Live player presence, raids, and headless readiness'),
    ('metrics', 'SPT Server Metrics', 'Live CPU, memory, health, and restart information on node-01'),
    ('logs', 'SPT Live Logs', 'Grouped live SPT backend and Fika headless logs'),
)


def exec_quote(value):
    return '"' + str(value).replace('\\', '\\\\').replace('"', '\\"').replace('`', '\\`').replace('$', '\\$') + '"'


def main():
    if os.geteuid() == 0:
        raise SystemExit('Run this installer as your normal desktop user, without sudo.')
    desktop = Path(subprocess.check_output(['xdg-user-dir', 'DESKTOP'], text=True).strip())
    applications = Path(os.environ.get('XDG_DATA_HOME', str(Path.home() / '.local/share'))) / 'applications'
    applications.mkdir(parents=True, exist_ok=True)
    desktop.mkdir(parents=True, exist_ok=True)
    installed = []
    warnings = []
    for view, title, description in VIEWS:
        icon = ROOT / 'icons' / (view + '.svg')
        if not icon.is_file():
            raise SystemExit('Shortcut icon missing: ' + str(icon))
        entry = '\n'.join([
            '[Desktop Entry]', 'Version=1.0', 'Type=Application', 'Name=' + title,
            'Comment=' + description,
            'Exec=' + exec_quote(sys.executable) + ' ' + exec_quote(ROOT / 'open-view.py') + ' ' + view,
            'Path=' + str(ROOT.parent), 'Icon=' + str(icon), 'Terminal=false',
            'StartupNotify=false', 'Categories=Game;',
            'Keywords=SPT;Fika;Tailscale;node-01;Players;Metrics;Logs;', '',
        ])
        menu_path = applications / ('spt-node01-' + view + '.desktop')
        menu_path.write_text(entry)
        menu_path.chmod(0o755)
        if shutil.which('desktop-file-validate'):
            subprocess.run(['desktop-file-validate', str(menu_path)], check=True)
        desktop_path = desktop / (title + '.desktop')
        desktop_path.write_text(entry)
        desktop_path.chmod(0o755)
        trust = subprocess.run(['gio', 'set', '--type=string', str(desktop_path), 'metadata::trusted', 'true'], capture_output=True, text=True)
        if trust.returncode:
            warnings.append(str(desktop_path) + ': ' + trust.stderr.strip())
        installed.append(str(desktop_path))
    if shutil.which('update-desktop-database'):
        subprocess.run(['update-desktop-database', str(applications)], check=True)
    print('Installed desktop and application-menu shortcuts:')
    print('\n'.join(installed))
    if warnings:
        print('Desktop trust metadata needs attention:', file=sys.stderr)
        print('\n'.join(warnings), file=sys.stderr)
        raise SystemExit(1)


if __name__ == '__main__':
    main()
