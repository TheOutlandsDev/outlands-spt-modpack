"""Client-content release identity and durable player update announcements.

The publisher serializes this outbox with publication. The existing maintenance
worker retries delivery; no additional scheduler or dashboard write API exists.
"""
import fcntl
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

MESSAGE = ('Client files changed ({version}). Finish your current raid, then close '
           'Escape from Tarkov AND SPT Launcher and run Play Outlands before your next raid.')


def identity(manifest):
    if manifest.get('schemaVersion') != 1 or len(manifest.get('packages', [])) != 1:
        raise ValueError('Unsupported client manifest')
    package = manifest['packages'][0]
    if package.get('id') != 'outlands-client-pack' or not re.fullmatch(r'\d{1,4}(?:\.\d{1,4}){2,3}', package.get('version', '')):
        raise ValueError('Unsupported client package')
    rows = package.get('files')
    if not isinstance(rows, list) or not 1 <= len(rows) <= 500:
        raise ValueError('Invalid client file count')
    clean, seen = [], set()
    for row in rows:
        path, size, digest = row.get('path'), row.get('size'), row.get('sha256')
        if (not isinstance(path, str) or not path.startswith('BepInEx/plugins/') or
                len(path) > 240 or '\\' in path or any(ord(c) < 32 or ord(c) > 126 for c in path) or
                any(part in ('', '.', '..') for part in path.split('/')) or path.lower() in seen or
                type(size) is not int or not 0 < size <= 128 * 1024 * 1024 or
                not isinstance(digest, str) or not re.fullmatch('[0-9a-f]{64}', digest)):
            raise ValueError('Invalid managed file identity')
        seen.add(path.lower())
        clean.append((path, size, digest))
    canonical = 'outlands-client-files-v1\n' + ''.join(f'{p}\0{s}\0{h}\n' for p, s, h in sorted(clean))
    return {'fingerprint': hashlib.sha256(canonical.encode('utf-8')).hexdigest(),
            'version': package['version'], 'managedFiles': len(clean)}


def read(path, fallback=None):
    if path.is_symlink():
        raise ValueError('Symlinked client update state refused')
    try:
        if path.stat().st_size > 1024 * 1024:
            raise ValueError('Oversized client update state')
        return json.loads(path.read_bytes())
    except FileNotFoundError:
        return fallback


def publication(workspace, manifest, previous, atomic):
    """Called under the publication lock after the final manifest is committed."""
    current = identity(manifest)
    state_path = workspace / 'player-dashboard/deployment/client-update.json'
    state = read(state_path, {})
    prior = identity(previous)['fingerprint'] if previous else state.get('fingerprint')
    changed = prior is not None and prior != current['fingerprint']
    # Preserve pending delivery across an identical republish and worker failure.
    if state.get('fingerprint') != current['fingerprint']:
        state = {**current, 'schemaVersion': 1, 'pending': changed,
                 'changed': changed, 'publishedAtUtc': datetime.now(timezone.utc).isoformat()}
    elif changed:
        state.update(changed=True, pending=state.get('pending', True))
    state.update(current) # Display current labels without inventing a content-change notice.
    atomic(state_path, (json.dumps(state, indent=2) + '\n').encode())
    project(workspace, state, atomic)
    return state


def project(workspace, state, atomic):
    public = workspace / 'player-dashboard/deployment/public-state'
    public.mkdir(parents=True, exist_ok=True, mode=0o755)
    data = {k: state[k] for k in ('schemaVersion', 'version', 'fingerprint', 'managedFiles', 'changed', 'publishedAtUtc') if k in state}
    data['message'] = MESSAGE.format(version=state['version']) if state.get('changed') else (
        'Before playing, close Escape from Tarkov and SPT Launcher and run Play Outlands to verify the approved client files.')
    atomic(public / 'client-update.json', (json.dumps(data, indent=2) + '\n').encode())


def deliver(workspace, notify, atomic):
    """Serialized with the publisher; a failed send leaves its durable outbox pending."""
    deployment = workspace / 'player-dashboard/deployment'
    lock_path = deployment / '.client-publish.lock'
    if lock_path.is_symlink():
        raise ValueError('Symlinked client publication lock')
    with lock_path.open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        manifest = read(deployment / 'downloads/client-sync-manifest.json')
        if manifest is None:
            return
        # Also recover the outbox if publication committed its manifest just
        # before a process/power failure. The old durable identity is retained.
        state = publication(workspace, manifest, None, atomic)
        if state.get('pending'):
            notify(MESSAGE.format(version=state['version']))
            state.update(pending=False, deliveredAtUtc=datetime.now(timezone.utc).isoformat())
            atomic(deployment / 'client-update.json', (json.dumps(state, indent=2) + '\n').encode())
