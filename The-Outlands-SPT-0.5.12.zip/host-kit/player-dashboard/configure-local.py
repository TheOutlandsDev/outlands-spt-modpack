#!/usr/bin/env python3
"""Create ignored local dashboard configuration from this host's SPT installation."""
import json
import os
import re
from pathlib import Path

root = Path(__file__).resolve().parent
runtime = root.parent / 'runtime'
headless = json.loads((runtime / 'HeadlessConfig.json').read_text())
source = (runtime / 'SPT/user/mods/fika-server/assets/configs/fika.jsonc').read_text()
match = re.search(r'"apiKey"\s*:\s*("(?:\\.|[^"\\])*")', source)
key = json.loads(match[1]) if match else ''
if not key:
    raise SystemExit('Fika API key not configured. No dashboard secrets written.')
destination = root / 'deployment'
destination.mkdir(mode=0o700, exist_ok=True)
os.chmod(destination, 0o700)
config = dict(serverName='node-01 SPT/Fika', backendUrl=headless['BackendUrl'],
              headlessProfileId=headless['ProfileId'], managementUrl='http://127.0.0.1:3000/containers',
              pollSeconds=5, bind='127.0.0.1', port=3010)
for path, content in [(destination / 'config.json', json.dumps(config, indent=2) + '\n'),
                      (destination / 'fika_api_key', key + '\n'),
                      (root / '.env', 'DASHBOARD_SOURCE_DIR=' + str(root) + '\n')]:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(descriptor, 'w') as output:
        output.write(content)
    os.chmod(path, 0o600)
print('Local dashboard configuration created; secret values were not printed.')
