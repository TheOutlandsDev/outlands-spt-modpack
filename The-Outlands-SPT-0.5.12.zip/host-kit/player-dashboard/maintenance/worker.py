#!/usr/bin/env python3
"""Host-only scheduled game maintenance. The dashboard receives a read-only projection."""
import argparse
import concurrent.futures
from contextlib import contextmanager
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import ssl
import stat
import subprocess
import tarfile
import tempfile
import threading
import time
import urllib.request
import uuid
import sys

import engine

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "player-dashboard"))
import client_updates

PRIVATE = ROOT / "player-dashboard/deployment/maintenance"
PUBLIC = ROOT / "player-dashboard/deployment/public-state/maintenance.json"
CONTROL = ROOT / "runtime/SPT/user/mods/zzz-OutlandsMaintenance/control.json"
ACK = CONTROL.with_name("ack.json")
COMPOSE = ROOT / "containers/stacks/spt-fika/compose.yaml"
DOCKER = ROOT / "containers/docker.sh"
NAMES = ("node01-spt-backend", "node01-fika-headless")
OWN_MODS = ("SPT/user/mods/zzz-CodexAiPopulationTuning/Codex.AiPopulationTuning.dll",
            "SPT/user/mods/zzz-CodexOpenScavTransits/Codex.OpenScavTransits.dll",
            "SPT/user/mods/zzz-CodexMinimalHardcore/Codex.MinimalHardcoreProfile.dll",
            "SPT/user/mods/zzz-CodexPrestigeRequirements/Codex.PrestigeRequirements.dll",
            "SPT/user/mods/zzz-OutlandsScavWar/Outlands.ScavWar.dll",
            "SPT/user/mods/zzz-OutlandsLocalQuestTurnIns/Outlands.LocalQuestTurnIns.dll",
            "SPT/user/mods/zzz-OutlandsMaintenance/Outlands.Maintenance.dll",
            "SPT/user/mods/zzz-OutlandsClientPackPolicy/Outlands.ClientPackPolicy.dll",
            "SPT/user/mods/zzz-OutlandsClientPackPolicy/policy.json",
            "SPT/user/mods/zzz-OutlandsClientPackPolicy/validated-sessions.json",
            "SPT/user/mods/zzz-OutlandsLiveContent/Outlands.LiveContent.dll",
            "SPT/user/mods/zzz-OutlandsLiveContent/settings.json",
            "SPT/user/mods/NarcoNet-Server/config.yaml",
            "SPT/user/mods/fika-server/assets/configs/fika.jsonc",
            "BepInEx/plugins/CodexDiagnostics/Codex.Diagnostics.Client.dll",
            "BepInEx/plugins/OutlandsRemoteQuests/Outlands.RemoteQuests.dll")


def now():
    return datetime.now(timezone.utc)


def archive_native_logs():
    """Keep warning evidence private; capture failure must not stop maintenance."""
    try:
        import native_log_archive
        result = native_log_archive.capture(ROOT / "runtime/Logs", PRIVATE / "native-log-archive")
        if result.get("errors") or result.get("skipped_unsafe"):
            print("Native warning archive incomplete; check private archive paths and permissions", flush=True)
        return result
    except Exception:
        # Do not print native content, private filenames, or exception payloads.
        print("Native warning archive unavailable; retrying on the next maintenance tick", flush=True)
        return None


def atomic_json(path, value, mode=0o600):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    if path.is_symlink():
        raise RuntimeError("Refusing a symlinked maintenance path")
    fd, temporary = tempfile.mkstemp(prefix=".maintenance-", dir=path.parent)
    try:
        with os.fdopen(fd, "w") as stream:
            os.fchmod(stream.fileno(), mode)
            json.dump(value, stream, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def read_json(path, fallback=None):
    if path.is_symlink():
        raise RuntimeError("Refusing a symlinked maintenance path")
    try:
        if path.stat().st_size > 1024 * 1024:
            raise ValueError("Oversized maintenance JSON")
        return json.loads(path.read_text())
    except FileNotFoundError:
        return fallback


def read_ack():
    try:
        return read_json(ACK, {})
    except (OSError, ValueError, RuntimeError):
        return {}


def save(state, message):
    atomic_json(PRIVATE / "state.json", state)
    # This directory contains only public, bounded maintenance status. It can be
    # mounted read-only as a directory so atomic replacement stays visible.
    atomic_json(PUBLIC, engine.public_status(now(), state, message), 0o644)
    print(message, flush=True)


def api(path, body=None):
    config = read_json(ROOT / "runtime/HeadlessConfig.json")
    base = config.get("BackendUrl")
    if base != "https://127.0.0.1:6969":
        raise RuntimeError("Unexpected pinned backend address")
    request = urllib.request.Request(base + path,
        data=json.dumps(body).encode() if body is not None else None,
        headers={"responsecompressed": "0", "requestcompressed": "0", "Content-Type": "application/json"})
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}),
        urllib.request.HTTPSHandler(context=ssl._create_unverified_context()))
    with opener.open(request, timeout=5) as response:
        data = response.read(2 * 1024 * 1024 + 1)
    if len(data) > 2 * 1024 * 1024:
        raise RuntimeError("Oversized backend response")
    return json.loads(data)


def observe():
    try:
        start = time.monotonic()
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
            calls = [pool.submit(api, path, body) for path, body in (
                ("/fika/headless/get", None), ("/fika/presence/get", None), ("/fika/location/raids", {}))]
            values = [call.result(timeout=7) for call in calls]
        if time.monotonic() - start > 10:
            raise RuntimeError("Game observation exceeded its freshness budget")
        profile = read_json(ROOT / "runtime/HeadlessConfig.json")["ProfileId"]
        return engine.idle_observation(*values, profile, now())
    except Exception:
        return {"idle": False, "atUtc": engine.iso(now()), "reason": "Live game state is unavailable"}


def notify(message):
    response = api("/fika/notification/push", {"type": 3, "notificationIcon": 0, "notification": message})
    if not isinstance(response, dict) or response.get("err") != 0:
        raise RuntimeError("Notification was rejected")


def write_lease(state):
    if not state.get("leaseId"):
        raise RuntimeError("Maintenance lease ID is missing")
    from datetime import timedelta
    atomic_json(CONTROL, {"schemaVersion": 1, "leaseId": state["leaseId"],
        "expiresAtUtc": engine.iso(now() + timedelta(seconds=90)), "draining": True,
        "message": "Daily maintenance is waiting for current raids to finish. New raids will reopen when the host is ready."})


@contextmanager
def lease_pump(state):
    stop = threading.Event()
    failures = []
    def refresh():
        while not stop.wait(10):
            try:
                write_lease(state)
                atomic_json(PUBLIC, engine.public_status(now(), state,
                    "Maintenance is restoring the server and headless host"), 0o644)
            except Exception as error:
                failures.append(error)
                return
    write_lease(state)
    thread = threading.Thread(target=refresh, daemon=True)
    thread.start()
    try:
        yield failures
    finally:
        stop.set()
        thread.join(timeout=12)


def release_lease(state):
    current = read_json(CONTROL, {})
    if current.get("leaseId") == state.get("leaseId"):
        # Expiry is safer than deleting another operation's control file.
        atomic_json(CONTROL, {"schemaVersion": 1, "leaseId": state["leaseId"],
                              "expiresAtUtc": engine.iso(now()), "draining": False,
                              "message": "Maintenance finished"})


def docker(*arguments, timeout=45):
    result = subprocess.run([str(DOCKER), *arguments], capture_output=True, text=True, timeout=timeout)
    if result.returncode:
        raise RuntimeError("Docker maintenance command failed (exit " + str(result.returncode) + ")")
    return result.stdout


def inspect():
    data = docker("inspect", "--format", "{{json .}}", *NAMES)
    rows = [json.loads(line) for line in data.splitlines() if line.strip()]
    if len(rows) != 2 or {row.get("Name", "").lstrip("/") for row in rows} != set(NAMES):
        raise RuntimeError("Both expected game containers must exist")
    return {row["Name"].lstrip("/"): row for row in rows}


def identity(rows):
    return {name: {"id": row["Id"], "image": row["Image"]} for name, row in rows.items()}


def verify_identity(rows, expected):
    if identity(rows) != expected:
        raise RuntimeError("Game container identity changed during maintenance")


def stopped(rows):
    return all(row["State"].get("Running") is False and row["State"].get("Status") == "exited"
               and not row["State"].get("OOMKilled") and row["State"].get("ExitCode") != 137
               for row in rows.values())


def backup(state):
    rows = inspect()
    verify_identity(rows, state["containerIdentity"])
    if not stopped(rows):
        raise RuntimeError("Quiescent backup requires both game containers to be cleanly stopped")
    parent = ROOT / "linux/backups"
    parent.mkdir(parents=True, mode=0o700, exist_ok=True)
    destination = Path(tempfile.mkdtemp(prefix="daily-" + now().strftime("%Y%m%dT%H%M%SZ") + "-", dir=parent))
    files = set()
    # Enumerate bounded state/config roots; never sweep game assets or Wine.
    for relative in ("runtime/SPT/user/profiles", "runtime/SPT/user/certs", "runtime/SPT/SPT_Data/configs", "runtime/BepInEx/config"):
        folder = ROOT / relative
        files.update(path for path in folder.rglob("*") if path.is_file())
    for folder in (ROOT / "runtime/SPT/user/mods").iterdir():
        if not folder.is_dir() or folder.is_symlink():
            continue
        for name in ("config", "Config", "configs", "Loader", "Presets"):
            config = folder / name
            if config.is_dir() and not config.is_symlink():
                files.update(path for path in config.rglob("*") if path.is_file() and
                             path.suffix.lower() in (".json", ".jsonc", ".cfg", ".yaml", ".yml"))
    files.update(ROOT / path for path in ("runtime/HeadlessConfig.json", "linux/version-lock.json",
                 "containers/stacks/spt-fika/compose.yaml"))
    files.update(ROOT / "runtime" / relative for relative in OWN_MODS if (ROOT / "runtime" / relative).is_file())
    manifest = {"schemaVersion": 1, "createdAtUtc": engine.iso(now()), "kind": "quiescent daily maintenance",
                "containerIdentity": state["containerIdentity"], "gameAssetsIncluded": False, "files": {}}
    archive = destination / "state.tar.gz"
    total = 0
    with tarfile.open(archive, "w:gz", dereference=False) as target:
        for path in sorted(files):
            if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(ROOT):
                raise RuntimeError("Backup encountered an unexpected path")
            data = path.read_bytes()
            total += len(data)
            if len(data) > 64 * 1024 * 1024 or total > 1024 * 1024 * 1024:
                raise RuntimeError("Backup exceeded its state-only size limit")
            relative = str(path.relative_to(ROOT))
            manifest["files"][relative] = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
                                           "mode": stat.S_IMODE(path.stat().st_mode)}
            target.add(path, arcname=relative, recursive=False)
    os.chmod(archive, 0o600)
    with tarfile.open(archive, "r:gz") as source:
        members = source.getmembers()
        if {member.name for member in members} != set(manifest["files"]):
            raise RuntimeError("Backup archive membership mismatch")
        for member in members:
            if not member.isfile():
                raise RuntimeError("Backup archive contains a non-file member")
            data = source.extractfile(member).read()
            row = manifest["files"][member.name]
            if len(data) != row["bytes"] or hashlib.sha256(data).hexdigest() != row["sha256"]:
                raise RuntimeError("Backup archive hash mismatch")
    manifest["archiveSha256"] = hashlib.sha256(archive.read_bytes()).hexdigest()
    atomic_json(destination / "manifest.json", manifest)
    return str(destination)


def ready(expected):
    try:
        rows = inspect()
        verify_identity(rows, expected)
        healthy = all(row["State"].get("Running") is True and
            row["State"].get("Health", {}).get("Status") == "healthy" for row in rows.values())
        version = api("/singleplayer/settings/version")
        observed = str(version.get("Version", ""))
        pinned = observed == "SPT 4.0.13" or observed.startswith("SPT 4.0.13 ")
        return healthy and pinned and observe()["idle"]
    except Exception:
        return False


def start_same(state):
    rows = inspect()
    verify_identity(rows, state["containerIdentity"])
    # Existing containers preserve the exact recorded image IDs, even if a local
    # tag/Compose file was edited elsewhere. Never pull, build, or recreate here.
    docker("start", state["containerIdentity"][NAMES[0]]["id"])
    deadline = time.monotonic() + 600
    while time.monotonic() < deadline:
        rows = inspect()
        verify_identity(rows, state["containerIdentity"])
        backend = rows[NAMES[0]]["State"]
        if backend.get("Running") and backend.get("Health", {}).get("Status") == "healthy":
            break
        time.sleep(5)
    else:
        raise RuntimeError("Backend readiness timed out")
    docker("start", state["containerIdentity"][NAMES[1]]["id"])
    while time.monotonic() < deadline:
        if ready(state["containerIdentity"]):
            return
        time.sleep(5)
    raise RuntimeError("Headless readiness timed out")


def transaction(state, recovery=False):
    if recovery:
        state["phase"] = "recovering"
        save(state, "Recovering the same game containers after interrupted maintenance")
    else:
        if not engine.fresh_ack(read_ack(), now(), state["leaseId"]) or not observe()["idle"]:
            state.update(idleSinceUtc=None, idleLastUtc=None, idleSamples=0)
            save(state, "A final fresh check deferred the restart")
            return
        rows = inspect()
        if not all(row["State"].get("Running") is True for row in rows.values()):
            raise RuntimeError("Game services must both be running before scheduled maintenance")
        state["containerIdentity"] = identity(rows)
        state["phase"] = "restarting"  # durable intent precedes the first stop
        save(state, "Idle confirmed; restarting the game services")
    with lease_pump(state) as failures:
        try:
            if not recovery:
                # Inspect/save above can take time. With the lease pump now active,
                # recheck the ack, pre-lease admissions, and every live source at
                # the final boundary before the first stop.
                if (failures or not engine.fresh_ack(read_ack(), now(), state["leaseId"]) or
                        not observe()["idle"]):
                    state.update(phase="draining", idleSinceUtc=None, idleLastUtc=None, idleSamples=0)
                    save(state, "A final fresh check deferred the restart; current raids may finish")
                    return
                try:
                    notify("All raids finished. The server is restarting now; reconnect shortly.")
                except Exception:
                    state.update(phase="draining", idleSinceUtc=None, idleLastUtc=None, idleSamples=0)
                    save(state, "Restart deferred because its final player notice could not be delivered")
                    return
                if (failures or not engine.fresh_ack(read_ack(), now(), state["leaseId"]) or
                        not observe()["idle"]):
                    state.update(phase="draining", idleSinceUtc=None, idleLastUtc=None, idleSamples=0)
                    save(state, "A final fresh check deferred the restart; current raids may finish")
                    return
                archive_native_logs()
                docker("stop", "--time", "45", state["containerIdentity"][NAMES[1]]["id"], timeout=60)
                # Capture shutdown warnings before Fika's next startup prunes logs.
                archive_native_logs()
                docker("stop", "--time", "90", state["containerIdentity"][NAMES[0]]["id"], timeout=105)
                state["backupPath"] = backup(state)
                save(state, "Quiescent backup verified; bringing the same game services online")
            if failures:
                raise RuntimeError("Maintenance admission lease could not be refreshed")
            start_same(state)
            if failures:
                raise RuntimeError("Maintenance admission lease could not be refreshed")
            if recovery:
                state.update(phase="failed", lastResult="Maintenance was interrupted; availability restored with the same game containers")
            else:
                state.update(phase="complete", lastRestartAtUtc=engine.iso(now()),
                             lastResult="Backup verified; server and headless ready")
            save(state, state["lastResult"])
        except Exception as error:
            state.update(phase="recovering", lastResult="Maintenance failed; restoring availability of the same game containers")
            save(state, state["lastResult"])
            # A following timer tick performs durable recovery. No profile rollback,
            # unsafe forced kill, replacement image, or native service fallback.
            raise RuntimeError(state["lastResult"]) from error
    release_lease(state)
    try:
        notify("The server and headless host are back online. Maintenance was interrupted and needs administrator review."
               if recovery else "Server maintenance finished. The server and headless host are ready for your next raid.")
    except Exception:
        print("Game services are ready; the completion notification could not be delivered", flush=True)


def project_content():
    # Only this exact authored status file crosses into the read-only dashboard.
    import sys
    sys.path.insert(0, str(ROOT / "player-dashboard"))
    import content_status
    try:
        path = ROOT / "runtime/SPT/user/mods/zzz-OutlandsLiveContent/status.json"
        value = content_status.sanitize(read_json(path, {}))
    except (OSError, ValueError, TypeError, KeyError, RuntimeError):
        value = content_status.unavailable()
    atomic_json(PUBLIC.with_name("content.json"), value, 0o644)


def tick():
    os.umask(0o077)
    project_content()
    import diagnostics_status
    atomic_json(ROOT / "player-dashboard/deployment/public-state/headless-diagnostics.json",
        diagnostics_status.snapshot(ROOT / "runtime/Logs/OutlandsRaidDiagnostics/current.json"), 0o644)
    PRIVATE.mkdir(parents=True, exist_ok=True, mode=0o700)
    with (PRIVATE / "worker.lock").open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return 0
        archive_native_logs()
        try:
            client_updates.deliver(ROOT, notify, lambda p, b: atomic_json(p, json.loads(b), 0o644 if p.parent.name == "public-state" else 0o600))
        except Exception:
            print("Client update announcement pending; retrying on the next maintenance tick", flush=True)
        state = read_json(PRIVATE / "state.json", engine.initial())
        if not isinstance(state, dict) or state.get("schemaVersion") != 1:
            raise RuntimeError("Maintenance state is invalid; refusing unsafe recovery")
        ack = read_ack()
        if state.get("phase") == "draining":
            write_lease(state)
        observation = observe() if state.get("phase") == "draining" else None
        state, action = engine.decide(now(), state, ack, observation)
        if action["kind"] == "begin_drain":
            state["leaseId"] = str(uuid.uuid4())
        save(state, action["message"])
        if action["kind"] == "notify":
            notify(action["message"])
            state = engine.notice_sent(state, action["minutes"])
            save(state, action["message"])
        elif action["kind"] == "begin_drain":
            write_lease(state)
            try:
                notify(action["message"])
            except Exception:
                print("Admission is paused; the maintenance notice could not be delivered", flush=True)
        elif action["kind"] in ("restart", "recover"):
            transaction(state, recovery=action["kind"] == "recover")
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tick", action="store_true", help="Run one serialized maintenance decision")
    args = parser.parse_args()
    if not args.tick:
        parser.error("Use --tick; installation is a separate explicit operation")
    try:
        return tick()
    except Exception as error:
        print("Maintenance deferred or recovering: " + str(error), flush=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
