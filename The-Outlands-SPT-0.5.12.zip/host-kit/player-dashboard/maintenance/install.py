#!/usr/bin/env python3
"""Install node-01's reviewed user maintenance timer. Does not restart game containers."""
import argparse
import os
from pathlib import Path
import subprocess

SOURCE = Path(__file__).resolve().parent


def quoted(path):
    value = str(path)
    if any(character in value for character in "\r\n\0"):
        raise ValueError("Invalid service path")
    return '"' + value.replace("%", "%%").replace("\\", "\\\\").replace('"', '\\"') + '"'


def unit_contents():
    directory = str(SOURCE.parents[1])
    if not Path(directory).is_absolute() or any(character in directory for character in "\r\n\0"):
        raise ValueError("Invalid working directory")
    # Directory settings take the complete raw value; unlike ExecStart, literal
    # surrounding quotes become part of the path and make it non-absolute.
    directory = directory.replace("%", "%%")
    service = """[Unit]
Description=Node-01 SPT announced idle maintenance

[Service]
Type=oneshot
WorkingDirectory=WORKSPACE
ExecStart=/usr/bin/python3 WORKER --tick
Environment=PYTHONDONTWRITEBYTECODE=1
UMask=0077
TimeoutStartSec=15min
KillMode=control-group
StandardOutput=journal
StandardError=journal
""".replace("WORKSPACE", directory).replace("WORKER", quoted(SOURCE / "worker.py"))
    timer = """[Unit]
Description=Check node-01 SPT maintenance schedule every 15 seconds

[Timer]
OnBootSec=30s
OnUnitInactiveSec=15s
AccuracySec=1s
Persistent=false
Unit=node01-spt-maintenance.service

[Install]
WantedBy=timers.target
"""
    return {"node01-spt-maintenance.service": service, "node01-spt-maintenance.timer": timer}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--install", action="store_true", help="Write units, reload the user manager, and enable the timer")
    args = parser.parse_args()
    destination = Path.home() / ".config/systemd/user"
    units = unit_contents()
    if not args.install:
        print("Review only. With --install, the following user units will be written to " + str(destination))
        for contents in units.values():
            print(contents)
        return 0
    if os.geteuid() == 0:
        raise SystemExit("Run as node-01, without sudo; this is a user timer.")
    destination.mkdir(parents=True, exist_ok=True)
    for name, contents in units.items():
        path = destination / name
        if path.is_symlink():
            raise SystemExit("Refusing a symlinked unit: " + str(path))
        path.write_text(contents)
        path.chmod(0o644)
    subprocess.run(["systemctl", "--user", "daemon-reload"], check=True)
    subprocess.run(["systemctl", "--user", "enable", "--now", "node01-spt-maintenance.timer"], check=True)
    print("User timer enabled. Missing admission-guard acknowledgement keeps maintenance inactive.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
