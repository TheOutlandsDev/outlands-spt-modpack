#!/usr/bin/env python3
"""Verify and restore one checkpoint into a NEW staging folder, never the live host."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import tarfile


def restore(checkpoint, destination):
    checkpoint, destination = Path(checkpoint), Path(destination)
    if destination.exists() or destination.is_symlink(): raise ValueError('Restore destination must be new')
    if checkpoint.is_symlink(): raise ValueError('Symlinked checkpoint refused')
    manifest_path=checkpoint/'manifest.json'; archive=checkpoint/'state.tar.gz'
    if manifest_path.is_symlink()or archive.is_symlink()or manifest_path.stat().st_size>4*1024*1024 or archive.stat().st_size>1024*1024*1024:
        raise ValueError('Unsafe checkpoint files')
    manifest=json.loads(manifest_path.read_bytes()); rows=manifest['files']
    if not isinstance(rows,dict)or not 1<=len(rows)<=10000: raise ValueError('Invalid state file count')
    if hashlib.sha256(archive.read_bytes()).hexdigest()!=manifest['archiveSha256']: raise ValueError('Archive checksum mismatch')
    data_files={};total=0
    with tarfile.open(archive,'r:gz')as tar:
        members=tar.getmembers()
        if len(members)!=len(rows)or{m.name for m in members}!=set(rows):raise ValueError('Archive membership mismatch')
        for member in members:
            path=PurePosixPath(member.name);row=rows[member.name]
            if (not member.isfile()or path.is_absolute()or '\\'in member.name or ':'in member.name or
                any(part in ('..','.')for part in path.parts)or str(path)!=member.name or
                type(row.get('bytes'))is not int or not 0<=row['bytes']<=64*1024*1024 or
                member.size!=row['bytes']or not re.fullmatch('[0-9a-f]{64}',row.get('sha256',''))):raise ValueError('Unsafe archive member')
            total+=member.size
            if total>1024*1024*1024:raise ValueError('Restored state exceeds limit')
            data=tar.extractfile(member).read()
            if hashlib.sha256(data).hexdigest()!=row['sha256']:raise ValueError('State file checksum mismatch')
            data_files[member.name]=data
    # Nothing is written until every member and hash passes validation.
    destination.mkdir(parents=True,mode=0o700)
    for name,data in data_files.items():
        path=destination/name;path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
        with path.open('xb')as stream:os.chmod(path,0o600);stream.write(data)
    return dict(schemaVersion=1,verified=True,filesRestored=len(data_files),restoredBytes=total,liveFilesChanged=False)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--checkpoint',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    print(json.dumps(restore(args.checkpoint,args.output)))
