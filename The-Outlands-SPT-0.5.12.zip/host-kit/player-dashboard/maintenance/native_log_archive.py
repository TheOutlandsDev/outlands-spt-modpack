"""Private, bounded snapshots of native warning logs before Fika removes sessions.

Only native errors/maperrors are copied. Original logs are never edited. Reads
are best-effort snapshots of live files, and oversized files retain a marked
byte tail. This is observability, not inventory or gameplay repair.
"""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import uuid

OWNER = "outlands.native-warning-archive.v1"
SESSION = re.compile(r"^log_(\d{4}\.\d{2}\.\d{2})_(\d{1,2})-(\d{2})-(\d{2})_((?:\d{1,6}\.){4}\d{1,6})$")
FILES = ("errors.log", "maperrors.log")
MANIFEST = "manifest.json"
MARKER = ".outlands-native-session.json"
MAX_MANIFEST_BYTES = 32 * 1024
MAX_FILE_BYTES = 512 * 1024
SOURCE_SESSIONS = 4
DIRECTORY_FLAGS = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
FILE_FLAGS = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK


def _timestamp(name):
    match = SESSION.fullmatch(name)
    if not match:
        return None
    date, hour, minute, second, _version = match.groups()
    try:
        return datetime.strptime(f"{date}_{hour}-{minute}-{second}", "%Y.%m.%d_%H-%M-%S")
    except ValueError:
        return None


def _path(path):
    path = Path(path)
    if ".." in path.parts:
        raise ValueError("Archive paths must not contain parent traversal")
    return path.absolute()


def _directory(path, create=False):
    """Open every component without following symlinks, including ancestors."""
    fd = os.open(path.anchor, DIRECTORY_FLAGS)
    try:
        for part in path.parts[1:]:
            if create:
                try:
                    os.mkdir(part, 0o700, dir_fd=fd)
                except FileExistsError:
                    pass
            child = os.open(part, DIRECTORY_FLAGS, dir_fd=fd)
            os.close(fd)
            fd = child
        return fd
    except BaseException:
        os.close(fd)
        raise


def _regular(fd, name, limit):
    child = os.open(name, FILE_FLAGS, dir_fd=fd)
    try:
        info = os.fstat(child)
        if not stat.S_ISREG(info.st_mode) or info.st_size > limit:
            raise ValueError("Unsafe or oversized archive metadata")
        return os.read(child, limit + 1)
    finally:
        os.close(child)


def _json(fd, name, limit):
    return json.loads(_regular(fd, name, limit))


def _atomic(fd, name, payload):
    try:
        info = os.stat(name, dir_fd=fd, follow_symlinks=False)
        if not stat.S_ISREG(info.st_mode):
            raise ValueError("Refusing unsafe archive destination")
    except FileNotFoundError:
        pass
    temporary = ".native-log-" + uuid.uuid4().hex
    child = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=fd)
    try:
        with os.fdopen(child, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, name, src_dir_fd=fd, dst_dir_fd=fd)
        os.fsync(fd)
    finally:
        try:
            os.unlink(temporary, dir_fd=fd)
        except FileNotFoundError:
            pass


def _encoded(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")


def _private(fd):
    if stat.S_IMODE(os.fstat(fd).st_mode) != 0o700:
        os.fchmod(fd, 0o700)


def _private_file(fd, name):
    child = os.open(name, FILE_FLAGS, dir_fd=fd)
    try:
        if not stat.S_ISREG(os.fstat(child).st_mode):
            raise ValueError("Refusing unsafe private metadata")
        if stat.S_IMODE(os.fstat(child).st_mode) != 0o600:
            os.fchmod(child, 0o600)
    finally:
        os.close(child)


def _owned(fd, name):
    marker = _json(fd, MARKER, 512)
    return marker == {"owner": OWNER, "session": name}


def _archive_session(root_fd, name):
    try:
        os.mkdir(name, 0o700, dir_fd=root_fd)
        created = True
    except FileExistsError:
        created = False
    fd = os.open(name, DIRECTORY_FLAGS, dir_fd=root_fd)
    try:
        if created:
            _atomic(fd, MARKER, _encoded({"owner": OWNER, "session": name}))
        elif not _owned(fd, name):
            raise ValueError("Refusing unowned archive session")
        _private(fd)
        _private_file(fd, MARKER)
        return fd
    except BaseException:
        os.close(fd)
        raise


def _snapshot(source_fd, source_name, max_bytes):
    fd = os.open(source_name, FILE_FLAGS, dir_fd=source_fd)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode):
            raise ValueError("Refusing special native log")
        offset = max(0, before.st_size - max_bytes)
        data = os.pread(fd, max_bytes, offset)
        after = os.fstat(fd)
        return data, {
            "sha256": hashlib.sha256(data).hexdigest(),
            "captured_bytes": len(data),
            "source_bytes_before": before.st_size,
            "source_bytes_after": after.st_size,
            "source_mtime_ns": after.st_mtime_ns,
            "tail_offset_bytes": offset,
            "truncated": offset != 0,
            "live_changed_during_read": (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns),
            "snapshot": "best-effort-live-file",
        }
    finally:
        os.close(fd)


def _existing_payload_matches(fd, name, metadata, max_bytes):
    try:
        data = _regular(fd, name, MAX_FILE_BYTES)
        file_fd = os.open(name, FILE_FLAGS, dir_fd=fd)
        try:
            if stat.S_IMODE(os.fstat(file_fd).st_mode) != 0o600:
                os.fchmod(file_fd, 0o600)
        finally:
            os.close(file_fd)
        return hashlib.sha256(data).hexdigest() == metadata["sha256"]
    except FileNotFoundError:
        return False


def _prune(root_fd, name):
    fd = os.open(name, DIRECTORY_FLAGS, dir_fd=root_fd)
    try:
        if not _owned(fd, name):
            raise ValueError("Refusing unowned archive pruning")
        names = os.listdir(fd)
        if any(entry not in (*FILES, MARKER) for entry in names):
            raise ValueError("Refusing archive session with unexpected contents")
        for entry in names:
            if not stat.S_ISREG(os.stat(entry, dir_fd=fd, follow_symlinks=False).st_mode):
                raise ValueError("Refusing unsafe archive pruning")
        for entry in names:
            os.unlink(entry, dir_fd=fd)
    finally:
        os.close(fd)
    os.rmdir(name, dir_fd=root_fd)


def capture(log_root: Path, archive_root: Path, keep_sessions=8, max_file_bytes=512 * 1024):
    """Snapshot newest four native sessions; return counts without log contents.

    At most eight owned sessions, two files per session and 512 KiB per file
    are retained. No network calls or original log modifications occur. Unsafe
    filesystem entries are skipped and counted. Invalid caller bounds raise
    ValueError. Archive ownership/metadata failures refuse the capture.
    """
    if type(keep_sessions) is not int or not 1 <= keep_sessions <= 8:
        raise ValueError("keep_sessions must be between one and eight")
    if type(max_file_bytes) is not int or not 1 <= max_file_bytes <= MAX_FILE_BYTES:
        raise ValueError("max_file_bytes exceeds the bounded archive policy")
    source_path, archive_path = _path(log_root), _path(archive_root)
    if source_path == archive_path or source_path in archive_path.parents or archive_path in source_path.parents:
        raise ValueError("Native logs and private archive must have separate roots")
    counts = {key: 0 for key in ("sessions_seen", "sessions_captured", "files_written", "files_unchanged",
                                "files_truncated", "sessions_pruned", "skipped_unsafe", "errors")}
    source_root_fd = archive_fd = None
    try:
        source_root_fd = _directory(source_path)
        archive_fd = _directory(archive_path, create=True)
        _private(archive_fd)
        try:
            manifest = _json(archive_fd, MANIFEST, MAX_MANIFEST_BYTES)
            if not isinstance(manifest, dict) or manifest.get("owner") != OWNER or not isinstance(manifest.get("sessions"), dict):
                raise ValueError("Unrecognized archive manifest")
            if len(manifest["sessions"]) > 12 or any(_timestamp(name) is None for name in manifest["sessions"]):
                raise ValueError("Unsafe archive manifest sessions")
        except FileNotFoundError:
            manifest = {"owner": OWNER, "schemaVersion": 1, "sessions": {}}
        if _manifest_exists(archive_fd):
            _private_file(archive_fd, MANIFEST)
        old_manifest = _encoded(manifest)
        entries = []
        for name in os.listdir(source_root_fd):
            stamp = _timestamp(name)
            if stamp is None:
                continue
            info = os.stat(name, dir_fd=source_root_fd, follow_symlinks=False)
            if not stat.S_ISDIR(info.st_mode):
                counts["skipped_unsafe"] += 1
                continue
            entries.append((stamp, name))
        entries.sort(reverse=True)
        for _stamp, name in entries[:min(SOURCE_SESSIONS, keep_sessions)]:
            counts["sessions_seen"] += 1
            session_fd = destination_fd = None
            try:
                session_fd = os.open(name, DIRECTORY_FLAGS, dir_fd=source_root_fd)
                before_entry = manifest["sessions"].get(name, {})
                if not isinstance(before_entry, dict):
                    raise ValueError("Invalid archive session metadata")
                files = dict(before_entry.get("files", {}))
                if any(key not in FILES for key in files):
                    raise ValueError("Invalid archived file metadata")
                source_names = set(os.listdir(session_fd))
                for canonical in FILES:
                    prefixed = name[4:] + " " + canonical
                    source_name = prefixed if prefixed in source_names else canonical
                    if source_name not in source_names:
                        continue
                    try:
                        data, metadata = _snapshot(session_fd, source_name, max_file_bytes)
                        if destination_fd is None:
                            destination_fd = _archive_session(archive_fd, name)
                        if _existing_payload_matches(destination_fd, canonical, metadata, max_file_bytes):
                            counts["files_unchanged"] += 1
                        else:
                            _atomic(destination_fd, canonical, data)
                            counts["files_written"] += 1
                        counts["files_truncated"] += int(metadata["truncated"])
                        prior = files.get(canonical)
                        if not isinstance(prior, dict) or any(prior.get(key) != value for key, value in metadata.items()):
                            metadata["captured_at_utc"] = datetime.now(timezone.utc).isoformat()
                            files[canonical] = metadata
                    except (OSError, ValueError, TypeError):
                        counts["skipped_unsafe"] += 1
                if files:
                    manifest["sessions"][name] = {"files": files}
                    counts["sessions_captured"] += 1
            except (OSError, ValueError, TypeError):
                counts["skipped_unsafe"] += 1
            finally:
                if destination_fd is not None:
                    os.close(destination_fd)
                if session_fd is not None:
                    os.close(session_fd)
        # Only sessions carrying our exact marker and in our bounded manifest
        # can be removed. Foreign directories and original logs are untouched.
        # Also recognize marker-owned sessions left by an interrupted capture
        # before manifest replacement. Never adopt or prune unmarked folders.
        owned = set(manifest["sessions"])
        for name in os.listdir(archive_fd):
            if _timestamp(name) is None:
                continue
            session_fd = None
            try:
                session_fd = os.open(name, DIRECTORY_FLAGS, dir_fd=archive_fd)
                if _owned(session_fd, name):
                    owned.add(name)
            except (OSError, ValueError, TypeError):
                pass
            finally:
                if session_fd is not None:
                    os.close(session_fd)
        retained = sorted(owned, key=lambda name: (_timestamp(name), name), reverse=True)
        for name in retained[keep_sessions:]:
            try:
                _prune(archive_fd, name)
                manifest["sessions"].pop(name, None)
                counts["sessions_pruned"] += 1
            except FileNotFoundError:
                manifest["sessions"].pop(name, None)
            except (OSError, ValueError):
                counts["errors"] += 1
        encoded = _encoded(manifest)
        if len(encoded) > MAX_MANIFEST_BYTES:
            raise ValueError("Archive manifest bound exceeded")
        if encoded != old_manifest or not _manifest_exists(archive_fd):
            _atomic(archive_fd, MANIFEST, encoded)
    except (OSError, ValueError, TypeError):
        counts["errors"] += 1
    finally:
        if archive_fd is not None:
            os.close(archive_fd)
        if source_root_fd is not None:
            os.close(source_root_fd)
    return counts


def _manifest_exists(fd):
    try:
        return stat.S_ISREG(os.stat(MANIFEST, dir_fd=fd, follow_symlinks=False).st_mode)
    except FileNotFoundError:
        return False
