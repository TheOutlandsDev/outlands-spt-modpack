"""Pure scheduling and admission decisions for the node-01 maintenance worker."""
from copy import deepcopy
from datetime import datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

ZONE = ZoneInfo("America/New_York")
WARNING_MINUTES = (30, 15, 5, 1)
ACTIVE_PHASES = ("draining", "restarting", "recovering")


def utc(value):
    if isinstance(value, str):
        value = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if not isinstance(value, datetime):
        raise TypeError("A timestamp is required")
    if value.tzinfo is None:
        raise ValueError("An aware timestamp is required")
    return value.astimezone(timezone.utc)


def iso(value):
    return utc(value).isoformat()


def initial():
    return {"schemaVersion": 1, "phase": "idle", "cycleDate": None,
            "targetAtUtc": None, "sentWarnings": [], "leaseId": None,
            "idleSinceUtc": None, "idleLastUtc": None, "idleSamples": 0,
            "lastRestartAtUtc": None, "lastResult": None}


def target_on(day):
    return datetime.combine(day, time(5), ZONE).astimezone(timezone.utc)


def next_target(now, state):
    now = utc(now)
    if state.get("phase") in ACTIVE_PHASES and state.get("targetAtUtc"):
        return utc(state["targetAtUtc"])
    target = target_on(now.astimezone(ZONE).date())
    if restarted_today(now, state):
        return target_on(now.astimezone(ZONE).date() + timedelta(days=1))
    return target if now < target else target_on(now.astimezone(ZONE).date() + timedelta(days=1))


def restarted_today(now, state):
    try:
        return utc(state["lastRestartAtUtc"]).astimezone(ZONE).date() == utc(now).astimezone(ZONE).date()
    except (ValueError, KeyError, TypeError):
        return False


def fresh_ack(ack, now, lease_id=None):
    try:
        age = (utc(now) - utc(ack["checkedAtUtc"])).total_seconds()
        valid = (type(ack.get("schemaVersion")) is int and ack["schemaVersion"] == 1 and
                 ack.get("loaded") is True and -5 <= age <= 30)
        if lease_id is not None:
            valid = (valid and ack.get("leaseId") == lease_id and ack.get("draining") is True and
                     type(ack.get("inFlightAdmissions")) is int and ack["inFlightAdmissions"] == 0)
        return bool(valid)
    except (ValueError, TypeError, KeyError, AttributeError):
        return False


def idle_observation(headless, presence, raids, profile_id, observed_at):
    """Unknown data is busy. Never treat a missing headless or stale match as idle."""
    result = {"idle": False, "atUtc": iso(observed_at), "reason": "Unverified game state"}
    if not isinstance(headless, dict) or not isinstance(headless.get("headlesses"), dict):
        return result
    host = headless["headlesses"].get(profile_id)
    if not isinstance(host, dict) or not isinstance(host.get("WebSocket"), dict):
        return result
    if (type(host["WebSocket"].get("State")) is not int or host["WebSocket"]["State"] != 2 or
            type(host.get("State")) is not int or host["State"] != 1 or
            not isinstance(host.get("Players"), list) or host["Players"] or
            host.get("RequesterSessionID") is not None or host.get("HasNotifiedRequester") is not None or
            host.get("CurrentMatch") is not None):
        result["reason"] = "Headless is busy, loading, or unavailable"
        return result
    if not isinstance(raids, list) or raids:
        result["reason"] = "A raid or retained match is present"
        return result
    if not isinstance(presence, list) or any(not isinstance(row, dict) or
            type(row.get("activity")) is not int or row["activity"] not in range(5)
            for row in presence):
        return result
    if any(row["activity"] == 1 for row in presence):
        result["reason"] = "A player is still in a raid"
        return result
    return {"idle": True, "atUtc": iso(observed_at), "reason": "All live sources report idle"}


def decide(now, previous, ack=None, observation=None):
    """Return a new durable state and an action; no I/O, notices, or random IDs."""
    now = utc(now)
    state = deepcopy(previous)
    phase = state.get("phase")
    if phase in ("restarting", "recovering"):
        return state, {"kind": "recover", "message": "Recovering an interrupted maintenance operation"}
    if phase == "draining":
        at = None
        try:
            at = utc(observation["atUtc"])
        except (TypeError, KeyError, ValueError):
            pass
        verified = (fresh_ack(ack, now, state.get("leaseId")) and at is not None and
                    -5 <= (now - at).total_seconds() <= 20 and observation.get("idle") is True)
        if not verified:
            state.update(idleSinceUtc=None, idleLastUtc=None, idleSamples=0)
            return state, {"kind": "wait", "message": "Waiting for every raid to finish and fresh idle confirmation"}
        try:
            gap = (now - utc(state["idleLastUtc"])).total_seconds()
        except (KeyError, TypeError, ValueError):
            gap = 999
        if not 0 < gap <= 35:
            state.update(idleSinceUtc=iso(now), idleSamples=0)
        state["idleLastUtc"] = iso(now)
        state["idleSamples"] = int(state.get("idleSamples", 0)) + 1
        elapsed = (now - utc(state["idleSinceUtc"])).total_seconds()
        if state["idleSamples"] >= 3 and elapsed >= 30:
            return state, {"kind": "restart", "message": "Idle confirmed; backing up and restarting the game services"}
        return state, {"kind": "wait", "message": "Confirming stable idle before maintenance"}

    today = now.astimezone(ZONE).date()
    target = target_on(today)
    if state.get("cycleDate") != today.isoformat():
        state.update(phase="idle", cycleDate=today.isoformat(), targetAtUtc=iso(target),
                     sentWarnings=[], leaseId=None, idleSinceUtc=None, idleLastUtc=None, idleSamples=0)
    if restarted_today(now, state):
        state["phase"] = "complete"
        return state, {"kind": "idle", "message": "The game host already restarted today; next maintenance is tomorrow at 5:00 AM Eastern"}
    if state["phase"] in ("complete", "failed", "skipped", "canceled"):
        return state, {"kind": "idle", "message": "Next maintenance is scheduled for 5:00 AM Eastern"}
    if not fresh_ack(ack, now) or (ack.get("draining") is True and ack.get("leaseId") != state.get("leaseId")):
        state["phase"] = "activation_required"
        return state, {"kind": "blocked", "message": "Maintenance requires its server admission guard to be loaded and reporting"}
    if now < target - timedelta(minutes=30):
        state["phase"] = "idle"
        return state, {"kind": "idle", "message": "Daily maintenance is scheduled for 5:00 AM Eastern"}
    if now > target + timedelta(seconds=90) or (now >= target and not state["sentWarnings"]):
        state.update(phase="skipped", lastResult="Skipped: scheduled warnings were missed; no catch-up restart")
        return state, {"kind": "skip", "message": state["lastResult"]}
    if now >= target:
        state["phase"] = "draining"
        return state, {"kind": "begin_drain", "message": "Scheduled maintenance: current raids may finish; new raids are paused"}
    state["phase"] = "announcing"
    due = [minutes for minutes in WARNING_MINUTES
           if now >= target - timedelta(minutes=minutes) and minutes not in state["sentWarnings"]]
    if due:
        minutes = min(due)
        return state, {"kind": "notify", "minutes": minutes,
                       "message": "Server maintenance at 5:00 AM Eastern (in approximately " + str(minutes) +
                                  " minute" + ("s" if minutes != 1 else "") + "). Active raids may finish before the restart."}
    return state, {"kind": "wait", "message": "Restart warnings are active; existing play continues"}


def notice_sent(state, minutes):
    state = deepcopy(state)
    state["sentWarnings"] = sorted(set(state.get("sentWarnings", [])) |
                                   {value for value in WARNING_MINUTES if value >= minutes}, reverse=True)
    return state


def public_status(now, state, message):
    return {"schemaVersion": 1, "nextRestartAtUtc": iso(next_target(now, state)),
            "timezone": "America/New_York", "scheduleLabel": "Daily at 5:00 AM Eastern",
            "state": state.get("phase", "unknown"), "message": message,
            "lastRestartAtUtc": state.get("lastRestartAtUtc"), "lastResult": state.get("lastResult"),
            "checkedAtUtc": iso(now), "warningMinutes": list(WARNING_MINUTES)}
