"""Real filesystem fixtures for private, bounded native-warning retention."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import tempfile
import unittest

import native_log_archive as archive


class NativeLogArchiveTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="outlands-native-archive-test-")
        self.root = Path(self.temporary.name)
        self.logs = self.root / "runtime" / "Logs"
        self.logs.mkdir(parents=True)
        self.destination = self.root / "private" / "native-log-archive"

    def tearDown(self):
        self.temporary.cleanup()

    def session(self, minute=0, content=b"native warning\n", map_content=None):
        name = f"log_2026.10.26_9-{minute:02d}-00_0.16.9.0.40087"
        path = self.logs / name
        path.mkdir(exist_ok=True)
        if content is not None:
            (path / (name[4:] + " errors.log")).write_bytes(content)
        if map_content is not None:
            (path / (name[4:] + " maperrors.log")).write_bytes(map_content)
        return path

    def capture(self, **kwargs):
        return archive.capture(self.logs, self.destination, **kwargs)

    def manifest(self):
        return json.loads((self.destination / "manifest.json").read_text())

    def test_preserved_after_source_removed_and_original_never_changed(self):
        source = self.session(content=b"UtilityOperationEvent not found\n", map_content=b"map error\n")
        originals = {p.name: (p.read_bytes(), p.stat().st_mtime_ns, stat.S_IMODE(p.stat().st_mode)) for p in source.iterdir()}
        counts = self.capture()
        self.assertEqual(counts["files_written"], 2)
        self.assertEqual(counts["errors"], 0)
        for path in source.iterdir():
            self.assertEqual((path.read_bytes(), path.stat().st_mtime_ns, stat.S_IMODE(path.stat().st_mode)), originals[path.name])
        shutil.rmtree(source)
        self.assertEqual(self.capture()["files_written"], 0)
        self.assertEqual((self.destination / source.name / "errors.log").read_bytes(), b"UtilityOperationEvent not found\n")
        self.assertEqual(len(self.manifest()["sessions"]), 1)

    def test_only_allowed_logs_and_newest_four_valid_sessions(self):
        for minute in range(7):
            source = self.session(minute)
            (source / "profile.json").write_text("private profile must not be copied")
            (source / "inventory.log").write_text("private inventory must not be copied")
            (source / "random errors.log").write_text("unrecognized prefix must not be copied")
        wrong = self.logs / "log_2026.02.31_9-00-00_0.16.9.0.40087"
        wrong.mkdir()
        (wrong / "errors.log").write_text("invalid session")
        diagnostic = self.logs / "OutlandsRaidDiagnostics"
        diagnostic.mkdir()
        (diagnostic / "errors.log").write_text("not a native session")
        counts = self.capture()
        self.assertEqual(counts["sessions_seen"], 4)
        sessions = self.manifest()["sessions"]
        self.assertEqual(sorted(sessions), sorted(self.session(i).name for i in range(3, 7)))
        filenames = {p.name for p in self.destination.rglob("*") if p.is_file()}
        self.assertEqual(filenames, {"manifest.json", "errors.log", archive.MARKER})

    def test_rotation_retains_eight_sessions_and_at_most_eight_mib_payload(self):
        for minute in range(12):
            self.session(minute, b"e" * archive.MAX_FILE_BYTES, b"m" * archive.MAX_FILE_BYTES)
            counts = self.capture()
            self.assertEqual(counts["errors"], 0)
        sessions = self.manifest()["sessions"]
        self.assertEqual(len(sessions), 8)
        self.assertNotIn(self.session(0).name, sessions)
        self.assertEqual(len(list(self.destination.glob("log_*"))), 8)
        size = sum(p.stat().st_size for p in self.destination.rglob("*.log"))
        self.assertEqual(size, 8 * 2 * archive.MAX_FILE_BYTES)
        self.assertLessEqual((self.destination / "manifest.json").stat().st_size, archive.MAX_MANIFEST_BYTES)
        self.assertEqual(len(list(self.logs.glob("log_*"))), 12)

    def test_smaller_retention_does_not_recopy_pruned_sessions(self):
        for minute in range(4):
            self.session(minute)
        self.capture(keep_sessions=2)
        second = self.capture(keep_sessions=2)
        self.assertEqual(second["files_written"], 0)
        self.assertEqual(second["sessions_pruned"], 0)
        self.assertEqual(len(self.manifest()["sessions"]), 2)

    def test_tail_truncation_is_explicit_and_bounded(self):
        payload = b"prefix not retained\n" + bytes(range(256)) * 16
        source = self.session(content=payload)
        self.capture(max_file_bytes=1024)
        stored = self.destination / source.name / "errors.log"
        self.assertEqual(stored.read_bytes(), payload[-1024:])
        metadata = self.manifest()["sessions"][source.name]["files"]["errors.log"]
        self.assertTrue(metadata["truncated"])
        self.assertEqual(metadata["tail_offset_bytes"], len(payload) - 1024)
        self.assertEqual(metadata["source_bytes_before"], len(payload))
        self.assertEqual(metadata["captured_bytes"], 1024)
        self.assertEqual(metadata["sha256"], hashlib.sha256(payload[-1024:]).hexdigest())
        self.assertEqual(metadata["snapshot"], "best-effort-live-file")
        self.assertEqual((source / (source.name[4:] + " errors.log")).read_bytes(), payload)

    def test_unchanged_content_does_not_rewrite_payload_or_manifest(self):
        source = self.session()
        self.capture()
        files = [self.destination / "manifest.json", self.destination / source.name / "errors.log"]
        before = [(p.stat().st_ino, p.stat().st_mtime_ns) for p in files]
        counts = self.capture()
        self.assertEqual(counts["files_written"], 0)
        self.assertEqual(counts["files_unchanged"], 1)
        self.assertEqual(before, [(p.stat().st_ino, p.stat().st_mtime_ns) for p in files])

    def test_lower_file_bound_shrinks_existing_payload(self):
        source = self.session(content=b"prefix" + b"x" * 4096)
        self.capture(max_file_bytes=4096)
        self.assertEqual((self.destination / source.name / "errors.log").stat().st_size, 4096)
        counts = self.capture(max_file_bytes=1024)
        self.assertEqual(counts["files_written"], 1)
        self.assertEqual((self.destination / source.name / "errors.log").stat().st_size, 1024)
        self.assertTrue(self.manifest()["sessions"][source.name]["files"]["errors.log"]["truncated"])

    def test_live_append_refreshes_snapshot_but_preserves_source(self):
        source = self.session(content=b"first\n")
        self.capture()
        log = source / (source.name[4:] + " errors.log")
        with log.open("ab") as stream:
            stream.write(b"second\n")
        self.assertEqual(self.capture()["files_written"], 1)
        self.assertEqual((self.destination / source.name / "errors.log").read_bytes(), b"first\nsecond\n")
        self.assertEqual(log.read_bytes(), b"first\nsecond\n")

    def test_source_symlink_and_fifo_are_skipped_without_following_or_blocking(self):
        source = self.session(content=None)
        secret = self.root / "secret.txt"
        secret.write_text("do not copy")
        (source / "errors.log").symlink_to(secret)
        os.mkfifo(source / "maperrors.log")
        counts = self.capture()
        self.assertEqual(counts["files_written"], 0)
        self.assertEqual(counts["skipped_unsafe"], 2)
        self.assertEqual(secret.read_text(), "do not copy")
        self.assertTrue((source / "errors.log").is_symlink())
        self.assertTrue(stat.S_ISFIFO((source / "maperrors.log").stat().st_mode))

    def test_source_directory_symlink_and_symlink_ancestor_are_refused(self):
        outside = self.root / "outside"
        outside.mkdir()
        (outside / "errors.log").write_text("not native")
        name = "log_2026.10.26_9-00-00_0.16.9.0.40087"
        (self.logs / name).symlink_to(outside, target_is_directory=True)
        self.assertEqual(self.capture()["skipped_unsafe"], 1)
        linked_root = self.root / "linked-logs"
        linked_root.symlink_to(self.logs, target_is_directory=True)
        counts = archive.capture(linked_root, self.root / "other-private")
        self.assertEqual(counts["errors"], 1)
        self.assertFalse((self.root / "other-private").exists())

    def test_unsafe_archive_destination_and_manifest_are_refused(self):
        self.session()
        outside = self.root / "outside"
        outside.mkdir()
        self.destination.parent.mkdir()
        self.destination.symlink_to(outside, target_is_directory=True)
        self.assertEqual(self.capture()["errors"], 1)
        self.assertEqual(list(outside.iterdir()), [])
        self.destination.unlink()
        self.destination.mkdir()
        secret = outside / "untouched"
        secret.write_text("unchanged")
        (self.destination / "manifest.json").symlink_to(secret)
        self.assertEqual(self.capture()["errors"], 1)
        self.assertEqual(secret.read_text(), "unchanged")
        self.assertTrue((self.destination / "manifest.json").is_symlink())

    def test_pruning_never_removes_unowned_directories_or_symlink_targets(self):
        self.destination.mkdir(parents=True)
        foreign = self.destination / "log_2026.10.26_8-00-00_0.16.9.0.40087"
        foreign.mkdir()
        (foreign / "errors.log").write_text("foreign")
        outside = self.root / "outside"
        outside.mkdir()
        (outside / "keep").write_text("safe")
        link = self.destination / "log_2026.10.26_7-00-00_0.16.9.0.40087"
        link.symlink_to(outside, target_is_directory=True)
        for minute in range(10):
            self.session(minute)
            self.capture(keep_sessions=2)
        self.assertEqual((foreign / "errors.log").read_text(), "foreign")
        self.assertEqual((outside / "keep").read_text(), "safe")
        self.assertTrue(link.is_symlink())

    def test_private_permissions_and_counts_do_not_expose_contents_or_paths(self):
        source = self.session(content=b"SECRET player inventory detail\n")
        counts = self.capture()
        for path in [self.destination, self.destination / source.name]:
            self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o700)
        for path in self.destination.rglob("*"):
            if path.is_file():
                self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o600)
        self.assertTrue(all(type(value) is int for value in counts.values()))
        self.assertNotIn("SECRET", json.dumps(counts))
        self.assertNotIn(str(self.root), json.dumps(counts))
        self.assertNotIn("SECRET", (self.destination / "manifest.json").read_text())

    def test_interrupted_capture_orphan_is_safely_pruned(self):
        self.destination.mkdir(parents=True)
        orphan_name = "log_2026.10.25_9-00-00_0.16.9.0.40087"
        orphan = self.destination / orphan_name
        orphan.mkdir(mode=0o700)
        (orphan / archive.MARKER).write_text(json.dumps({"owner": archive.OWNER, "session": orphan_name}))
        (orphan / "errors.log").write_bytes(b"orphan from interrupted capture")
        for minute in range(2):
            self.session(minute)
        counts = self.capture(keep_sessions=2)
        self.assertEqual(counts["sessions_pruned"], 1)
        self.assertFalse(orphan.exists())
        self.assertEqual(len(list(self.destination.glob("log_*"))), 2)

    def test_unsafe_payload_destination_is_not_overwritten(self):
        source = self.session()
        self.capture()
        destination = self.destination / source.name / "errors.log"
        destination.unlink()
        outside = self.root / "outside-secret"
        outside.write_text("untouched secret")
        destination.symlink_to(outside)
        counts = self.capture()
        self.assertEqual(counts["files_written"], 0)
        self.assertGreater(counts["skipped_unsafe"], 0)
        self.assertTrue(destination.is_symlink())
        self.assertEqual(outside.read_text(), "untouched secret")

    def test_owned_private_permissions_are_repaired_without_payload_rewrite(self):
        source = self.session()
        self.capture()
        destination = self.destination / source.name
        inode = (destination / "errors.log").stat().st_ino
        for path in [self.destination, destination]:
            path.chmod(0o755)
        for path in [self.destination / "manifest.json", destination / "errors.log", destination / archive.MARKER]:
            path.chmod(0o644)
        counts = self.capture()
        self.assertEqual(counts["files_written"], 0)
        self.assertEqual((destination / "errors.log").stat().st_ino, inode)
        for path in [self.destination, destination]:
            self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o700)
        for path in [self.destination / "manifest.json", destination / "errors.log", destination / archive.MARKER]:
            self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o600)

    def test_plain_native_names_are_supported(self):
        source = self.session(content=None)
        (source / "errors.log").write_text("native error")
        (source / "maperrors.log").write_text("native map error")
        self.assertEqual(self.capture()["files_written"], 2)

    def test_invalid_bounds_and_parent_traversal_are_refused(self):
        for value in (0, 9, True, -1):
            with self.assertRaises(ValueError):
                self.capture(keep_sessions=value)
        for value in (0, archive.MAX_FILE_BYTES + 1, True):
            with self.assertRaises(ValueError):
                self.capture(max_file_bytes=value)
        with self.assertRaises(ValueError):
            archive.capture(self.logs / ".." / "Logs", self.destination)
        with self.assertRaises(ValueError):
            archive.capture(self.logs, self.logs / "archive")
        self.assertFalse(self.destination.exists())


if __name__ == "__main__":
    unittest.main()
