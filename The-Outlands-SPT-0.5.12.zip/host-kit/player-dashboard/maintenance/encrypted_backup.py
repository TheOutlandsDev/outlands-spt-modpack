#!/usr/bin/env python3
"""Seal verified game-state checkpoints with GnuPG; never upload keys or plaintext."""
import argparse
import base64
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import secrets
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[2]
MAX_ARCHIVE = 1024 * 1024 * 1024
MAX_ENVELOPE = MAX_ARCHIVE + 8 * 1024 * 1024


def atomic(path, data):
    if path.is_symlink() or path.parent.is_symlink():
        raise ValueError('Symlinked backup output refused')
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, temp = tempfile.mkstemp(prefix='.outlands-backup-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            os.fchmod(stream.fileno(), 0o600)
            stream.write(data); stream.flush(); os.fsync(stream.fileno())
        os.replace(temp, path)
    finally:
        if os.path.exists(temp): os.unlink(temp)


def ordinary(path, limit):
    if path.is_symlink() or not path.is_file() or not 0 < path.stat().st_size <= limit:
        raise ValueError('Expected bounded ordinary backup input')
    data = path.read_bytes()
    if len(data) > limit: raise ValueError('Backup input grew beyond limit')
    return data


def key_path(root):
    return root / 'player-dashboard/deployment/backups/Outlands-Recovery-Key.txt'


def create_key(root):
    path = key_path(root)
    if path.exists() or path.is_symlink():
        load_key(root)
        return path
    atomic(path, base64.urlsafe_b64encode(secrets.token_bytes(32)).rstrip(b'=') + b'\n')
    return path


def load_key(root):
    path = key_path(root)
    data = ordinary(path, 128).strip()
    if len(data) != 43 or any(c not in b'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_' for c in data):
        raise ValueError('Recovery key format is invalid')
    if path.stat().st_mode & 0o077: raise ValueError('Recovery key must be owner-only')
    return data


def gpg(data, key, decrypt=False):
    # The standard OpenPGP format supports recovery independently of this script.
    # stdin carries the key; it never appears in argv, logs, metadata or uploads.
    with tempfile.TemporaryDirectory(prefix='outlands-gpg-') as temp:
        os.chmod(temp, 0o700)
        source = Path(temp) / 'input'; target = Path(temp) / 'output'
        source.write_bytes(data); source.chmod(0o600)
        arguments = ['/usr/bin/gpg', '--no-options', '--homedir', temp, '--batch', '--yes',
                     '--pinentry-mode', 'loopback', '--no-symkey-cache', '--passphrase-fd', '0',
                     '--output', str(target)]
        arguments += ['--decrypt'] if decrypt else ['--symmetric', '--cipher-algo', 'AES256', '--compress-algo', 'none']
        try:
            result = subprocess.run([*arguments, str(source)], input=key + b'\n', capture_output=True, timeout=120)
        finally:
            subprocess.run(['/usr/bin/gpgconf', '--homedir', temp, '--kill', 'gpg-agent'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)
        if result.returncode != 0:
            raise ValueError('Backup authentication/decryption failed' if decrypt else 'Backup encryption failed')
        return ordinary(target, MAX_ENVELOPE)


def prepare_latest(root=ROOT):
    if not key_path(root).exists(): return None
    key = load_key(root)
    candidates = sorted((root / 'linux/backups').glob('daily-*/manifest.json'), key=lambda p:p.stat().st_mtime, reverse=True)
    if not candidates: raise ValueError('No verified game-state checkpoint is available')
    manifest_path = candidates[0]
    manifest = json.loads(ordinary(manifest_path, 4 * 1024 * 1024))
    archive = manifest_path.with_name('state.tar.gz')
    raw = ordinary(archive, MAX_ARCHIVE)
    if hashlib.sha256(raw).hexdigest() != manifest.get('archiveSha256'):
        raise ValueError('Checkpoint archive differs from its verified manifest')
    certificate_name = 'runtime/SPT/user/certs/certificate.pfx'
    certificate = root / certificate_name
    supplement = ordinary(certificate, 1024 * 1024) if certificate_name not in manifest.get('files', {}) and certificate.exists() else None
    supplement_sha = hashlib.sha256(supplement).hexdigest() if supplement else None
    outbox = root / 'player-dashboard/deployment/backups/outbox'
    outbox.mkdir(parents=True, exist_ok=True, mode=0o700)
    name = manifest_path.parent.name + '.tar.gpg'
    encrypted = outbox / name
    metadata_path = outbox / 'latest.json'
    old = json.loads(ordinary(metadata_path, 16384)) if metadata_path.exists() else {}
    if old.get('sourceArchiveSha256') == manifest['archiveSha256'] and encrypted.exists() and old.get('supplementalTlsSha256') == supplement_sha:
        if hashlib.sha256(ordinary(encrypted, MAX_ENVELOPE)).hexdigest() != old.get('encryptedSha256'):
            raise ValueError('Encrypted outbox was altered')
        return old
    # Include the verified manifest inside the encrypted envelope so its private
    # filenames and profile IDs never leave node-01 in public metadata.
    import io, tarfile
    output = io.BytesIO()
    entries = [('manifest.json', ordinary(manifest_path, 4 * 1024 * 1024)), ('state.tar.gz', raw)]
    if supplement: entries.append(('server-tls-certificate.pfx', supplement))
    with tarfile.open(fileobj=output, mode='w') as package:
        for label, data in entries:
            info = tarfile.TarInfo(label); info.size=len(data); info.mode=0o600
            package.addfile(info, io.BytesIO(data))
    sealed = gpg(output.getvalue(), key)
    if gpg(sealed, key, decrypt=True) != output.getvalue():
        raise ValueError('Encryption recovery check failed')
    atomic(encrypted, sealed)
    metadata = dict(schemaVersion=1, backupId=manifest_path.parent.name, sourceCreatedAtUtc=manifest['createdAtUtc'],
        preparedAtUtc=datetime.now(timezone.utc).isoformat(), encryptedFile=name, encryptedBytes=len(sealed),
        encryptedSha256=hashlib.sha256(sealed).hexdigest(), sourceArchiveSha256=manifest['archiveSha256'],
        recoveryTestPassed=True, includesServerTlsIdentity=bool(supplement or certificate_name in manifest.get('files', {})),
        supplementalTlsSha256=supplement_sha, encryption='OpenPGP AES256', requiresSeparateRecoveryKey=True)
    atomic(metadata_path, (json.dumps(metadata, indent=2)+'\n').encode())
    return metadata


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--create-key',action='store_true'); parser.add_argument('--prepare-latest',action='store_true')
    args=parser.parse_args()
    if args.create_key:
        create_key(ROOT); print('Owner-only recovery key ready. Save a separate off-node copy; never upload it with backups.')
    if args.prepare_latest:
        result=prepare_latest(ROOT)
        print(json.dumps(result or {'configured':False}))
    if not(args.create_key or args.prepare_latest): parser.error('Select --create-key or --prepare-latest')

if __name__=='__main__': main()
