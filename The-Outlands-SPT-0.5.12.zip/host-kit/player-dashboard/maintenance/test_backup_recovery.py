import hashlib
import io
import json
from pathlib import Path
import tarfile
import tempfile
import unittest

import encrypted_backup
import recovery


class RecoveryTests(unittest.TestCase):
    def fixture(self,root,name='runtime/SPT/user/profiles/example.json',payload=b'{"characters":{}}'):
        folder=root/'checkpoint';folder.mkdir();archive=folder/'state.tar.gz'
        with tarfile.open(archive,'w:gz')as tar:
            info=tarfile.TarInfo(name);info.size=len(payload);tar.addfile(info,io.BytesIO(payload))
        manifest=dict(files={name:dict(bytes=len(payload),sha256=hashlib.sha256(payload).hexdigest())},archiveSha256=hashlib.sha256(archive.read_bytes()).hexdigest(),createdAtUtc='2026-10-25T12:00:00+00:00')
        (folder/'manifest.json').write_text(json.dumps(manifest));return folder

    def test_restore_exact_bytes_to_new_private_folder(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);checkpoint=self.fixture(root);dest=root/'restore';result=recovery.restore(checkpoint,dest)
            self.assertEqual(result['filesRestored'],1);self.assertEqual((dest/'runtime/SPT/user/profiles/example.json').read_bytes(),b'{"characters":{}}')
            self.assertEqual(dest.stat().st_mode&0o777,0o700)
            with self.assertRaises(ValueError):recovery.restore(checkpoint,dest)

    def test_traversal_and_corruption_are_refused_before_writes(self):
        for name in ['../outside','/tmp/outside','runtime/../outside']:
            with tempfile.TemporaryDirectory()as temp:
                root=Path(temp);checkpoint=self.fixture(root,name);dest=root/'restore'
                with self.assertRaises(ValueError):recovery.restore(checkpoint,dest)
                self.assertFalse(dest.exists())
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);checkpoint=self.fixture(root);(checkpoint/'state.tar.gz').write_bytes(b'broken');dest=root/'restore'
            with self.assertRaises(ValueError):recovery.restore(checkpoint,dest)
            self.assertFalse(dest.exists())

    def test_encrypted_checkpoint_roundtrip_tamper_and_key_boundaries(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);keypath=encrypted_backup.create_key(root);key=encrypted_backup.load_key(root)
            self.assertEqual(keypath.stat().st_mode&0o777,0o600);self.assertEqual(encrypted_backup.create_key(root),keypath)
            sealed=encrypted_backup.gpg(b'private state fixture',key)
            self.assertNotIn(b'private state fixture',sealed);self.assertEqual(encrypted_backup.gpg(sealed,key,True),b'private state fixture')
            with self.assertRaises(ValueError):encrypted_backup.gpg(sealed[:-1]+bytes([sealed[-1]^1]),key,True)
            keypath.chmod(0o644)
            with self.assertRaises(ValueError):encrypted_backup.load_key(root)

    def test_manual_outbox_contains_encrypted_manifest_and_state(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);checkpoint=self.fixture(root);target=root/'linux/backups/daily-fixture';target.parent.mkdir(parents=True);checkpoint.rename(target)
            encrypted_backup.create_key(root);metadata=encrypted_backup.prepare_latest(root)
            self.assertTrue(metadata['recoveryTestPassed']);out=root/'player-dashboard/deployment/backups/outbox'
            self.assertFalse((out/'manifest.json').exists());self.assertFalse((out/'state.tar.gz').exists())
            sealed=(out/metadata['encryptedFile']).read_bytes();self.assertEqual(hashlib.sha256(sealed).hexdigest(),metadata['encryptedSha256'])
            plain=encrypted_backup.gpg(sealed,encrypted_backup.load_key(root),True)
            with tarfile.open(fileobj=io.BytesIO(plain))as tar:self.assertEqual(tar.getnames(),['manifest.json','state.tar.gz'])
            self.assertEqual(encrypted_backup.prepare_latest(root),metadata)

    def test_tls_identity_is_sealed_with_older_checkpoint(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);checkpoint=self.fixture(root);target=root/'linux/backups/daily-fixture';target.parent.mkdir(parents=True);checkpoint.rename(target)
            certificate=root/'runtime/SPT/user/certs/certificate.pfx';certificate.parent.mkdir(parents=True);certificate.write_bytes(b'private certificate fixture')
            encrypted_backup.create_key(root);metadata=encrypted_backup.prepare_latest(root)
            self.assertTrue(metadata['includesServerTlsIdentity'])
            sealed=(root/'player-dashboard/deployment/backups/outbox'/metadata['encryptedFile']).read_bytes()
            plain=encrypted_backup.gpg(sealed,encrypted_backup.load_key(root),True)
            with tarfile.open(fileobj=io.BytesIO(plain))as tar:
                self.assertEqual(tar.extractfile('server-tls-certificate.pfx').read(),certificate.read_bytes())
            self.assertEqual(encrypted_backup.prepare_latest(root),metadata)
