# Reuse an existing private Homepage Hub

The existing node dashboard includes a read-only player page at `/play/`.
The player page uses the same HTTPS origin, status APIs and bounded updater
downloads. No new port, service, game listener, access grant or Docker API is
needed. Game HTTPS/WebSockets and raid UDP continue directly to the game host.

Generate private deployment links outside source control:

```sh
python3 hub-integration/render.py --portal-origin https://your-node.your-tailnet.ts.net:8446 --output deployment/hub-links
```

On the Hub host, read its applicable AGENTS.md and inspect its actual Homepage
version, config mounts and custom category code. Back up the current config,
then merge the generated `Outlands SPT` group into `services.yaml`. Preserve all
other apps, widgets, artwork, credentials, access controls and category mappings.
Never replace the whole file with the snippet. Custom category navigation may
need an existing Game Operations mapping or a new group mapping to display it.
Use the installed version's supported config reload; do not upgrade the image.

If the existing private front proxy supports native Nginx locations, optionally
merge the two exact `/spt` redirect locations from the snippet. Validate the
complete configuration before a graceful reload. They point at the existing
private player page and carry no API keys or player data. No broad `/api`,
WebSocket or game reverse proxy is needed for these shortcuts. Skip this optional
step if Nginx is not the existing frontend or if `/spt` is already occupied.

Verify the owner and one approved player can follow the player-page link; check
phone/desktop layout, public download, existing updater download, copy address,
calendar, maintenance and stale/offline handling. Verify an unapproved identity
does not gain node access merely by seeing a bookmark. A local browser check
cannot establish remote player authorization or successful raid UDP transport.
Revert only the merged config/custom category changes to roll back.

Keep the player portal separate from privileged Fika administration. Native
SPT's embedded status page and a separately deployed Fika WebApp are different
systems. Do not install a current Fika WebApp against this frozen server without
verifying the matching release/API contracts and its authentication/roles.
Fika API keys belong only on trusted backend services. Account/profile editing,
headless control, file managers and admin consoles do not belong in the player
page. No public Funnel or router forwarding is required.
