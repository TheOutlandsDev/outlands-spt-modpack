#!/usr/bin/env python3
"""Prepare a NEW private Homepage link bundle; never edit server or network state."""
import argparse
import hashlib
import json
import re
from pathlib import Path
import urllib.parse


def private_origin(value):
    url = urllib.parse.urlsplit(value)
    if (url.scheme != 'https' or not url.hostname or not url.hostname.endswith('.ts.net') or not re.fullmatch(r'[a-z0-9-]+(?:\.[a-z0-9-]+)+', url.hostname) or
        url.username or url.password or url.query or url.fragment or url.path not in ('', '/') or
        any(c in value for c in '\r\n')):
        raise ValueError('Use an approved HTTPS Tailscale origin without a path or credentials')
    # Validate malformed/out-of-range ports too.
    _ = url.port
    authority = url.hostname + (':' + str(url.port) if url.port else '')
    return 'https://' + authority


def render(origin, destination):
    origin, destination = private_origin(origin), Path(destination)
    if destination.exists() or destination.is_symlink(): raise ValueError('Output must be a new folder')
    destination.mkdir(parents=True, mode=0o700)
    links = [('Play Outlands', origin + '/play/', 'Install, update and join · approved Tailscale players'),
             ('SPT Live Raids', origin + '/', 'Players, raids, AI metrics and maintenance · read-only'),
             ('SPT Client and SelfHost', 'https://github.com/TheOutlandsDev/outlands-spt-modpack', 'Matching downloads and authored source · public'),
             ('SPT Access and Help', 'https://discord.gg/cNqhhUdFW', 'Request approval and get setup help')]
    # JSON strings are valid YAML scalars; emit data only, with no YAML tags or API credentials.
    lines = ['- Outlands SPT:']
    for name, href, description in links:
        lines += ['    - ' + name + ':', '        href: ' + json.dumps(href), '        description: ' + json.dumps(description), '        target: _blank']
    files = {'services.outlands-spt.yaml': '\n'.join(lines) + '\n',
             'nginx-spt-shortcut.conf': '# OPTIONAL: merge into the existing private HTTPS server only.\n'
                + '# This is a redirect to the existing player portal, not a game/API proxy.\n'
                + 'location = /spt { return 302 ' + origin + '/play/; }\n'
                + 'location = /spt/ { return 302 ' + origin + '/play/; }\n',
             'LINKS.json': json.dumps({'schemaVersion': 1, 'portal': origin + '/play/', 'dashboard': origin + '/',
                'changesGameNetworking': False, 'changesAccessPolicy': False, 'addsProxy': False,
                'links': [{'name': n, 'url': h} for n, h, _ in links]}, indent=2) + '\n'}
    for name, body in files.items():
        path=destination/name; path.write_text(body); path.chmod(0o600)
    (destination/'SHA256SUMS').write_text(''.join(hashlib.sha256(body.encode()).hexdigest() + '  ' + name + '\n' for name, body in sorted(files.items())))
    (destination/'SHA256SUMS').chmod(0o600)
    return destination


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--portal-origin', required=True); parser.add_argument('--output', type=Path, required=True)
    args=parser.parse_args(); render(args.portal_origin, args.output)
    print('Private link bundle prepared. Review and merge on the existing Hub host; nothing was deployed.')
