'use strict';
(() => {
  const $ = id => document.getElementById(id);
  const text = (id, value) => { $(id).textContent = value; };
  const json = async path => {
    const response = await fetch(path, {cache: 'no-store', signal: AbortSignal.timeout(6000)});
    if (!response.ok) throw new Error('Unavailable');
    return response.json();
  };
  const approvedHttps = raw => {
    const u = new URL(raw);
    if (u.protocol !== 'https:' || u.username || u.password || u.search || u.hash) throw new Error('Invalid address');
    return u;
  };
  async function refresh() {
    try {
      const s = await json('/api/status');
      const game = s.services.filter(x => x.name === 'SPT backend' || x.name === 'Fika headless');
      const healthy = !s.stale && game.length === 2 && game.every(x => x.status === 'healthy');
      text('server-status', healthy ? 'Server and headless online' : 'Server status needs attention');
      $('server-dot').className = 'dot ' + (healthy ? 'healthy' : 'degraded');
      text('player-count', s.stale ? 'Presence may be stale' : `${s.summary.onlinePlayers} online · ${s.summary.activeRaids} active raids`);
      $('launcher-url').value = approvedHttps(s.server.backendUrl).href.replace(/\/$/, '');
      $('copy-url').disabled = false;
    } catch {
      text('server-status', 'Live status unavailable'); text('player-count', 'Open Live server for details');
      $('server-dot').className = 'dot'; $('copy-url').disabled = true;
    }
  }
  async function extras() {
    const results = await Promise.allSettled([json('/play/release.json'), json('/api/client-update'), json('/api/content'), json('/api/maintenance')]);
    const [release, pack, content, maintenance] = results;
    if (release.status === 'fulfilled') {
      try {
        const r = release.value, u = approvedHttps(r.downloadUrl);
        if (u.hostname !== 'github.com' || !/^\/TheOutlandsDev\/outlands-spt-modpack\/raw\/refs\/heads\/main\/The-Outlands-SPT-\d+\.\d+\.\d+\.zip$/.test(u.pathname)) throw new Error('Unexpected download');
        $('installer-link').href = u.href;
        text('release-detail', `Complete Client + SelfHost package ${r.version}. Pinned author downloads; legitimate game files are supplied by you.`);
      } catch { text('release-detail', 'Open GitHub to check the current complete download.'); }
    }
    if (pack.status === 'fulfilled' && pack.value.available && pack.value.version) text('approved-pack', `Approved client pack: ${pack.value.version}. Keep your shortcut and use it every session.`);
    if (content.status === 'fulfilled' && content.value.available && content.value.day?.theme) text('content-detail', `${content.value.day.theme}. Halloween stays active; see the live calendar for today’s hotspots.`);
    if (maintenance.status === 'fulfilled' && typeof maintenance.value.message === 'string') text('maintenance-detail', maintenance.value.message);
  }
  $('copy-url').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText($('launcher-url').value); text('copy-url', 'Copied'); }
    catch { $('launcher-url').focus(); $('launcher-url').select(); text('copy-url', 'Select and copy the address'); }
  });
  refresh(); extras();
  setInterval(() => { if (!document.hidden) { refresh(); extras(); } }, 15000);
})();
