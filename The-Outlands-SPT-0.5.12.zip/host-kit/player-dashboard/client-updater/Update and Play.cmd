@echo off
setlocal
call "%~dp0Outlands Client Updater.cmd" -Launch %*
exit /b %ERRORLEVEL%
