#requires -Version 5.1
# Disposable filesystem fixtures and a WScript.Shell adapter; no real desktop edits.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$tokens = $null; $errors = $null
$ast = [Management.Automation.Language.Parser]::ParseFile((Join-Path $PSScriptRoot 'Install-PlayOutlands.ps1'), [ref]$tokens, [ref]$errors)
if ($errors.Count) { throw ($errors | Out-String) }
foreach ($statement in $ast.EndBlock.Statements) {
    if ($statement -is [Management.Automation.Language.FunctionDefinitionAst] -or
        ($statement -is [Management.Automation.Language.AssignmentStatementAst] -and $statement.Left.Extent.Text.StartsWith('$script:'))) {
        . ([scriptblock]::Create($statement.Extent.Text))
    }
}
$checks = 1
function Check([bool]$Value, [string]$Message) { if (-not $Value) { throw $Message }; $script:checks++ }
function Reject([scriptblock]$Action) {
    $rejected = $false
    try { & $Action | Out-Null } catch { $rejected = $true }
    Check $rejected 'Unsafe or incomplete install was accepted.'
}
$fixture = Join-Path ([IO.Path]::GetTempPath()) ('outlands-shortcut-' + [Guid]::NewGuid().ToString('N'))
try {
    $root = Join-Path $fixture 'SPT & Co-op (Fixture)'
    $source = Join-Path $fixture 'Extracted Download'
    $desktop = Join-Path $fixture 'User Desktop'
    foreach ($path in @($root, $source, $desktop)) { [IO.Directory]::CreateDirectory($path) | Out-Null }
    foreach ($name in @('EscapeFromTarkov.exe', 'SPT.Launcher.exe')) { [IO.File]::WriteAllText((Join-Path $root $name), 'fixture executable') }
    foreach ($name in $ShortcutFiles) { Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination (Join-Path $source $name) }
    $shell = [pscustomobject]@{}
    $shell | Add-Member ScriptMethod CreateShortcut {
        param($path)
        $link = [pscustomobject]@{ Path = $path; TargetPath = ''; Arguments = ''; WorkingDirectory = ''; IconLocation = ''; Description = ''; WindowStyle = 0 }
        $link | Add-Member ScriptMethod Save { [IO.File]::WriteAllText($this.Path, ($this | ConvertTo-Json)) }
        return $link
    }
    $installed = Install-OutlandsShortcut $root $source $desktop $shell
    $destination = Join-Path $root 'Outlands Client Updater'
    $link = Get-Content -LiteralPath $installed -Raw | ConvertFrom-Json
    Check ($link.TargetPath -eq (Join-Path $destination 'Update and Play.cmd')) 'Shortcut bypassed updater or points to the downloaded folder.'
    Check ($link.Arguments -eq '' -and $link.WorkingDirectory -eq $destination) 'Shortcut interpolated shell arguments or lost working directory.'
    Check ($link.IconLocation -eq ((Join-Path $root 'EscapeFromTarkov.exe') + ',0')) 'Incorrect game icon.'
    Check (@(Get-ChildItem -LiteralPath $destination -File).Count -eq 7) 'Installed package is incomplete.'
    foreach ($name in $ShortcutFiles) {
        Check ((Get-FileHash -LiteralPath (Join-Path $source $name)).Hash -ceq (Get-FileHash -LiteralPath (Join-Path $destination $name)).Hash) 'Copied updater differs from reviewed source.'
    }
    [IO.File]::WriteAllText($installed, 'previous shortcut fixture')
    Install-OutlandsShortcut $root $destination $desktop $shell | Out-Null
    $saved = @(Get-ChildItem -LiteralPath (Join-Path $destination 'shortcut-backups') -File)
    Check ($saved.Count -eq 1 -and [IO.File]::ReadAllText($saved[0].FullName) -ceq 'previous shortcut fixture') 'Previous shortcut was not preserved.'
    $before = [IO.File]::ReadAllText($installed)
    Remove-Item -LiteralPath (Join-Path $source 'client-policy.json')
    Reject { Install-OutlandsShortcut $root $source $desktop $shell }
    Check ([IO.File]::ReadAllText($installed) -ceq $before) 'Incomplete package replaced a working shortcut.'
    Remove-Item -LiteralPath (Join-Path $root 'SPT.Launcher.exe')
    Reject { Install-OutlandsShortcut $root $destination $desktop $shell }
    Check (-not (Test-Path -LiteralPath (Join-Path $root 'BepInEx'))) 'Shortcut installer modified game mods.'
    Write-Host ($checks.ToString() + ' shortcut checks passed (COM adapter; actual Windows desktop test pending).')
} finally {
    if (Test-Path -LiteralPath $fixture) { Remove-Item -LiteralPath $fixture -Recurse -Force }
}
