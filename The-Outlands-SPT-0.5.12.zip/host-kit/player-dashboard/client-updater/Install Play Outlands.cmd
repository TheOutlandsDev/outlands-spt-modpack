@echo off
setlocal
set "OUTLANDS_POWERSHELL=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if defined PROCESSOR_ARCHITEW6432 set "OUTLANDS_POWERSHELL=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
"%OUTLANDS_POWERSHELL%" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-PlayOutlands.ps1" %*
set "OUTLANDS_RESULT=%ERRORLEVEL%"
pause
exit /b %OUTLANDS_RESULT%
