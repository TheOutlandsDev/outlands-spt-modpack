#requires -Version 5.1
[CmdletBinding()]
param([string]$GamePath)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$script:ShortcutFiles = @('Update-Outlands.ps1', 'Outlands Client Updater.cmd', 'Update and Play.cmd',
    'README.txt', 'client-policy.json', 'Install Play Outlands.cmd', 'Install-PlayOutlands.ps1')

function Assert-ShortcutPath([string]$Path) {
    $cursor = [IO.Path]::GetFullPath($Path)
    while ($cursor) {
        if (Test-Path -LiteralPath $cursor) {
            $item = Get-Item -LiteralPath $cursor -Force
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw 'Use an ordinary folder, without junctions or symlinks: ' + $cursor
            }
        }
        $parent = [IO.Path]::GetDirectoryName($cursor)
        if ($parent -eq $cursor) { break }
        $cursor = $parent
    }
}

function Test-ShortcutGameFolder([string]$Path) {
    return (-not [string]::IsNullOrWhiteSpace($Path) -and
        (Test-Path -LiteralPath (Join-Path $Path 'EscapeFromTarkov.exe') -PathType Leaf) -and
        (Test-Path -LiteralPath (Join-Path $Path 'SPT.Launcher.exe') -PathType Leaf))
}

function Install-OutlandsShortcut([string]$Root, [string]$Source, [string]$Desktop, $Shell) {
    $rootPath = [IO.Path]::GetFullPath($Root)
    if (-not (Test-ShortcutGameFolder $rootPath)) { throw 'Select the SPT folder containing EscapeFromTarkov.exe and SPT.Launcher.exe.' }
    Assert-ShortcutPath $rootPath
    Assert-ShortcutPath $Source
    $destination = Join-Path $rootPath 'Outlands Client Updater'
    $shortcut = Join-Path $Desktop 'Play Outlands.lnk'
    Assert-ShortcutPath $destination
    Assert-ShortcutPath $shortcut
    foreach ($name in $script:ShortcutFiles) {
        $file = Join-Path $Source $name
        Assert-ShortcutPath $file
        if (-not (Test-Path -LiteralPath $file -PathType Leaf) -or (Get-Item -LiteralPath $file).Length -eq 0) {
            throw 'Extract the complete updater ZIP before installing. Missing file: ' + $name
        }
        Assert-ShortcutPath (Join-Path $destination $name)
    }
    [IO.Directory]::CreateDirectory($destination) | Out-Null
    [IO.Directory]::CreateDirectory($Desktop) | Out-Null
    foreach ($name in $script:ShortcutFiles) {
        $sourceFile = Join-Path $Source $name
        $targetFile = Join-Path $destination $name
        if (-not [string]::Equals([IO.Path]::GetFullPath($sourceFile), [IO.Path]::GetFullPath($targetFile), [StringComparison]::OrdinalIgnoreCase)) {
            Copy-Item -LiteralPath $sourceFile -Destination $targetFile -Force
        }
        if ((Get-FileHash -LiteralPath $sourceFile -Algorithm SHA256).Hash -cne (Get-FileHash -LiteralPath $targetFile -Algorithm SHA256).Hash) {
            throw 'Updater copy verification failed. Extract the ZIP and run the installer again.'
        }
    }
    # Target the existing CMD directly. No game path is interpolated into shell
    # arguments; the updater discovers its parent SPT folder automatically.
    $temporary = Join-Path $Desktop ('.outlands-' + [Guid]::NewGuid().ToString('N') + '.lnk')
    try {
        $link = $Shell.CreateShortcut($temporary)
        $link.TargetPath = Join-Path $destination 'Update and Play.cmd'
        $link.Arguments = ''
        $link.WorkingDirectory = $destination
        $link.IconLocation = (Join-Path $rootPath 'EscapeFromTarkov.exe') + ',0'
        $link.Description = 'Check approved Outlands updates, then open the SPT launcher.'
        $link.WindowStyle = 1
        $link.Save()
        if (-not (Test-Path -LiteralPath $temporary -PathType Leaf)) { throw 'Windows did not save the desktop shortcut.' }
        if (Test-Path -LiteralPath $shortcut) {
            if (-not (Test-Path -LiteralPath $shortcut -PathType Leaf)) { throw 'Play Outlands.lnk is not an ordinary file.' }
            $backups = Join-Path $destination 'shortcut-backups'
            Assert-ShortcutPath $backups
            [IO.Directory]::CreateDirectory($backups) | Out-Null
            $saved = Join-Path $backups ([Guid]::NewGuid().ToString('N') + '.lnk')
            Copy-Item -LiteralPath $shortcut -Destination $saved
            if ((Get-FileHash -LiteralPath $shortcut).Hash -cne (Get-FileHash -LiteralPath $saved).Hash) { throw 'Previous shortcut backup verification failed.' }
            [IO.File]::Replace($temporary, $shortcut, [NullString]::Value)
        } else { [IO.File]::Move($temporary, $shortcut) }
    } finally {
        if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force }
    }
    return $shortcut
}

try {
    if ($env:OS -ne 'Windows_NT') { throw 'Run Install Play Outlands.cmd on your Windows player PC.' }
    if ([string]::IsNullOrWhiteSpace($GamePath)) {
        $candidate = Split-Path -Parent $PSScriptRoot
        if (Test-ShortcutGameFolder $candidate) { $GamePath = $candidate }
        else {
            Add-Type -AssemblyName System.Windows.Forms
            $picker = New-Object Windows.Forms.FolderBrowserDialog
            $picker.Description = 'Select your modded SPT folder containing SPT.Launcher.exe. Do not select the live BSG game.'
            $picker.ShowNewFolderButton = $false
            try {
                if ($picker.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) { throw 'Shortcut installation canceled.' }
                $GamePath = $picker.SelectedPath
            } finally { $picker.Dispose() }
        }
    }
    $desktop = [Environment]::GetFolderPath([Environment+SpecialFolder]::DesktopDirectory)
    if ([string]::IsNullOrWhiteSpace($desktop)) { throw 'Windows could not locate your desktop folder.' }
    $shell = New-Object -ComObject WScript.Shell
    try { $installed = Install-OutlandsShortcut $GamePath $PSScriptRoot $desktop $shell }
    finally { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($shell) }
    Write-Host ('Created: ' + $installed) -ForegroundColor Green
    Write-Host 'Connect Tailscale and close the game and launchers. Use Play Outlands on your desktop to update and open SPT.'
    Write-Host 'The updater is stored in your SPT folder. Keep that folder in place. No Administrator rights are needed.'
    exit 0
} catch {
    Write-Host ('Shortcut not installed: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
