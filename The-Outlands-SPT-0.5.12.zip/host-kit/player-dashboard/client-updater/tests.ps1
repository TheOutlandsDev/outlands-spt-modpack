#requires -Version 5.1
# Isolated tests of the real production functions. Never include in the player ZIP.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$tokens = $null; $parseErrors = $null
$source = Join-Path $PSScriptRoot 'Update-Outlands.ps1'
$ast = [Management.Automation.Language.Parser]::ParseFile($source, [ref]$tokens, [ref]$parseErrors)
if ($parseErrors.Count -ne 0) { throw ($parseErrors | Out-String) }
# Import definitions and pinned constants, without calling the CLI or its exit.
foreach ($statement in $ast.EndBlock.Statements) {
    if ($statement -is [Management.Automation.Language.FunctionDefinitionAst] -or
        ($statement -is [Management.Automation.Language.AssignmentStatementAst] -and $statement.Left.Extent.Text.StartsWith('$script:'))) {
        . ([scriptblock]::Create($statement.Extent.Text))
    }
}
$checks = 1
function Check([bool]$Ok, [string]$Label) { if (-not $Ok) { throw $Label }; $script:checks++ }
function Reject([scriptblock]$Action, [string]$Label) {
    $rejected = $false
    try { & $Action | Out-Null } catch { $rejected = $true }
    Check $rejected $Label
}
function Clone($Value) { return ($Value | ConvertTo-Json -Depth 12 | ConvertFrom-Json) }
function Zip-Bytes($Entries) {
    Add-Type -AssemblyName System.IO.Compression
    $memory = New-Object IO.MemoryStream
    $zip = New-Object IO.Compression.ZipArchive($memory, [IO.Compression.ZipArchiveMode]::Create, $true)
    try {
        foreach ($spec in $Entries) {
            $entry = $zip.CreateEntry($spec.name, [IO.Compression.CompressionLevel]::Optimal)
            if (@($spec.PSObject.Properties.Name) -contains 'attributes') { $entry.ExternalAttributes = $spec.attributes }
            $stream = $entry.Open()
            try { $stream.Write($spec.data, 0, $spec.data.Length) } finally { $stream.Dispose() }
        }
    }
    finally { $zip.Dispose() }
    try { return ,$memory.ToArray() } finally { $memory.Dispose() }
}
$dataA = [Text.Encoding]::UTF8.GetBytes('authored fixture DLL bytes')
$dataB = [Text.Encoding]::UTF8.GetBytes('authored fixture installation text')
$fixtureTargets = @('BepInEx/plugins/OutlandsRemoteQuests/Outlands.RemoteQuests.dll', 'BepInEx/plugins/OutlandsRemoteQuests/INSTALL.txt')
$compat = @($Compatibility.Keys | Sort-Object | ForEach-Object { [pscustomobject]@{ path = $_; sha256 = $Compatibility[$_] } })
$policy = [pscustomobject]@{ schemaVersion = 1; updaterVersion = '1.1.0'; channel = 'node-01'; packageId = 'outlands-client-pack';
    managedPaths = $fixtureTargets; baseFiles = $compat }
Check ((Test-ClientPolicy $policy).managedPaths.Count -eq 2) 'Locally approved target policy loaded.'
$jsonPolicy = Convert-JsonBytes ([Text.Encoding]::UTF8.GetBytes(($policy | ConvertTo-Json -Depth 12)))
Check ((Test-ClientPolicy $jsonPolicy).baseFiles.Count -eq 3) 'Local policy survives real JSON integer roundtrip.'
foreach ($change in @(
    { param($p) $p.schemaVersion = $true },
    { param($p) $p.updaterVersion = '1.0.0' },
    { param($p) $p.managedPaths = @() },
    { param($p) $p.managedPaths[0] = 'SPT/user/profiles/player.json' },
    { param($p) $p.managedPaths[0] = 'BepInEx/config/com.fika.core.cfg' },
    { param($p) $p.managedPaths[0] = 'BepInEx/plugins/spt/spt-core.dll' },
    { param($p) $p.managedPaths[0] = 'BepInEx/plugins/Fika/Fika.Headless.dll' },
    { param($p) $p.managedPaths[0] = 'BepInEx/plugins/FikaDynamicAI/FikaDynamicAI.dll' },
    { param($p) $p.managedPaths[0] = 'BepInEx/plugins/CodexDiagnostics/Diagnostics.dll' },
    { param($p) $p.managedPaths[0] = 'BepInEx/plugins/Other/Debug.PDB' },
    { param($p) $p.managedPaths[1] = $p.managedPaths[0].ToUpperInvariant() },
    { param($p) $p.baseFiles[0].sha256 = ('0' * 64) },
    { param($p) $p.baseFiles[0].path = 'BepInEx/config/user-secret.cfg' }
)) {
    $badPolicy = Clone $policy; & $change $badPolicy
    Reject { Test-ClientPolicy $badPolicy } 'Unsafe local client policy rejected.'
}
Test-ClientPolicy $policy | Out-Null
$entries = @([pscustomobject]@{ name = $Targets[0]; data = $dataA }, [pscustomobject]@{ name = $Targets[1]; data = $dataB })
$zipBytes = Zip-Bytes $entries
$manifest = [pscustomobject]@{
    schemaVersion = 1; channel = 'node-01'; bundleVersion = '2026.10.23.1'; generatedAtUtc = '2026-10-23T12:00:00Z'
    compatibility = [pscustomobject]@{ sptVersion = '4.0.13'; eftVersion = '0.16.9.40087'; fikaVersion = '2.2.5'; files = $compat }
    packages = @([pscustomobject]@{ id = 'outlands-client-pack'; version = '2026.10.23.1'; url = '/downloads/outlands-client-pack.zip';
        sha256 = (Get-BytesHash $zipBytes); size = $zipBytes.Length; files = @(
            [pscustomobject]@{ path = $Targets[0]; sha256 = (Get-BytesHash $dataA); size = $dataA.Length },
            [pscustomobject]@{ path = $Targets[1]; sha256 = (Get-BytesHash $dataB); size = $dataB.Length }) })
}
$package = Test-Manifest $manifest
Check ($package.version -eq '2026.10.23.1') 'Valid manifest accepted.'
$jsonBytes = [Text.Encoding]::UTF8.GetBytes(($manifest | ConvertTo-Json -Depth 12))
$roundTripPackage = Test-Manifest (Convert-JsonBytes $jsonBytes)
Check ($roundTripPackage.version -eq '2026.10.23.1') 'Actual JSON decode-to-production manifest validation accepts integer schema.'
$longSchema = Clone $manifest; $longSchema.schemaVersion = [long]1
Check ((Test-Manifest $longSchema).version -eq '2026.10.23.1') 'Int64 schema 1 accepted.'
$payloads = Read-Package $zipBytes $package
Check ($payloads.Count -eq 2 -and (Get-BytesHash $payloads[$Targets[0]]) -eq (Get-BytesHash $dataA)) 'Valid package returns exact authored bytes.'
Check ((Get-BytesHash ([Text.Encoding]::ASCII.GetBytes('abc'))) -eq 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad') 'Known SHA256 vector.'
foreach ($path in @('../bad', '/rooted', 'C:/drive', 'BepInEx\plugins\bad.dll', 'file:stream', 'a/../b', 'a/./b',
    'a//b', 'a/CON.txt', 'a/NUL', 'a/COM1.dll', 'a/b.', 'a/b ', 'a/b/', "a/$([char]1)b")) {
    Reject { Assert-SafeRelative $path } ('Unsafe path rejected: ' + $path)
}
Reject { Get-TrustedBytes 'https://example.invalid/payload.zip' 10 } 'Absolute unapproved URL rejected before network.'
Reject { Get-TrustedBytes '//example.invalid/payload.zip' 10 } 'Protocol-relative URL rejected before network.'
Reject { Get-TrustedBytes '/downloads/../payload.zip' 10 } 'Download traversal rejected before network.'
Reject { Get-TrustedBytes '/downloads/file.zip?redirect=other' 10 } 'Download query rejected before network.'

foreach ($change in @(
    { param($m) $m.schemaVersion = 2 },
    { param($m) $m.schemaVersion = $true },
    { param($m) $m.schemaVersion = [double]1.0 },
    { param($m) $m.schemaVersion = '1' },
    { param($m) $m.channel = 'other-host' },
    { param($m) $m.compatibility.fikaVersion = '9.9.9' },
    { param($m) $m.compatibility.files[0].sha256 = ('0' * 64) },
    { param($m) $m.compatibility.files[1] = $m.compatibility.files[0] },
    { param($m) $m.packages[0].url = 'https://example.invalid/mod.zip' },
    { param($m) $m.packages[0].version = 'not-a-version' },
    { param($m) $m.packages[0].files[0].path = 'SPT/user/profiles/example.json' },
    { param($m) $m.packages[0].files[1].path = $m.packages[0].files[0].path },
    { param($m) $m.packages[0].files[0].size = 134217729 },
    { param($m) $m.packages[0].files[0].sha256 = 'BAD' },
    { param($m) $m.packages[0].size = '123' }
)) {
    $bad = Clone $manifest; & $change $bad
    Reject { Test-Manifest $bad } 'Invalid manifest rejected.'
}
$damaged = [byte[]]$zipBytes.Clone(); $damaged[0] = $damaged[0] -bxor 1
Reject { Read-Package $damaged $package } 'Corrupted ZIP rejected.'
$wrongFile = Clone $package; $wrongFile.files[0].sha256 = ('0' * 64)
Reject { Read-Package $zipBytes $wrongFile } 'Per-file hash mismatch rejected.'
$badArchives = @(
    @($entries[0], $entries[0]),
    @($entries[0], [pscustomobject]@{ name = '../escape.dll'; data = $dataB }),
    @($entries[0], [pscustomobject]@{ name = 'BepInEx/plugins/OtherMod.dll'; data = $dataB }),
    @($entries[0], $entries[1], [pscustomobject]@{ name = 'extra.txt'; data = $dataB }),
    @($entries[0], [pscustomobject]@{ name = $Targets[1]; data = $dataB; attributes = 1024 }),
    @($entries[0], [pscustomobject]@{ name = $Targets[1]; data = $dataB; attributes = -1610612736 })
)
foreach ($badEntries in $badArchives) {
    $bytes = Zip-Bytes $badEntries; $spec = Clone $package
    $spec.sha256 = Get-BytesHash $bytes; $spec.size = $bytes.Length
    Reject { Read-Package $bytes $spec } 'Unsafe ZIP entries rejected even with a matching ZIP hash.'
}
$bombData = New-Object byte[] 1048576
$bomb = Zip-Bytes @([pscustomobject]@{ name = $Targets[0]; data = $bombData }, $entries[1])
$bombSpec = Clone $package; $bombSpec.sha256 = Get-BytesHash $bomb; $bombSpec.size = $bomb.Length
$bombSpec.files[0].size = $bombData.Length; $bombSpec.files[0].sha256 = Get-BytesHash $bombData
Reject { Read-Package $bomb $bombSpec } 'Excessive compression ratio rejected.'

if ($env:OS -eq 'Windows_NT') { Assert-GameClosed }
else {
    # Adapt only Windows path construction/process discovery for disposable Linux
    # fixtures; transaction, hashes, atomic writes, and rollback stay production.
    function Get-ChildPath([string]$Root, [string]$Relative) {
        Assert-SafeRelative $Relative
        return [IO.Path]::GetFullPath((Join-Path $Root $Relative))
    }
    function Assert-GameClosed { }
    Write-Host 'Portable filesystem fixtures use a Unix path/process adapter; Windows-specific behavior remains untested.'
}
& {
    $fixture = Join-Path ([IO.Path]::GetTempPath()) ('outlands-updater-tests-' + [Guid]::NewGuid().ToString('N'))
    $work = Join-Path $fixture 'work'; $backup = Join-Path $fixture 'backup'
    [IO.Directory]::CreateDirectory($work) | Out-Null
    [IO.Directory]::CreateDirectory($backup) | Out-Null
    try {
        Install-BytesAtomic $fixture $Targets[0] $dataA $work
        Install-BytesAtomic $fixture $Targets[1] $dataB $work
        Check (@(Get-ManagedStatus $fixture $package | Where-Object { -not $_.current }).Count -eq 0) 'Windows managed status is idempotent.'
        Assert-NoUnexpectedPlugins $fixture
        Check $true 'Exact managed DLL inventory accepted.'
        foreach ($extraPath in @('BepInEx/plugins/OtherAddon.dll', 'BepInEx/plugins/Fika/Fika.Headless.dll',
            'BepInEx/plugins/FikaDynamicAI/FikaDynamicAI.dll', 'BepInEx/plugins/CodexDiagnostics/Diagnostics.dll',
            'BepInEx/core/UnknownCore.dll', 'BepInEx/patchers/UnknownPreloader.dll', 'BepInEx/patchers/nested/UnknownPreloader.dll')) {
            $extra = Get-ChildPath $fixture $extraPath
            [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($extra)) | Out-Null
            [IO.File]::WriteAllBytes($extra, $dataA)
            Reject { Assert-NoUnexpectedPlugins $fixture } 'Unknown or host-only DLL blocks a verified match.'
            Check (Test-Path -LiteralPath $extra -PathType Leaf) 'Unknown DLL was reported without deletion.'
            [IO.File]::Delete($extra)
        }
        $baseFixturePaths = @('BepInEx/core/ApprovedBase.dll', 'BepInEx/patchers/nested/ApprovedPreloader.dll')
        $baseFixturePolicy = Clone $policy
        foreach ($relative in $baseFixturePaths) {
            $baseFixturePolicy.baseFiles += [pscustomobject]@{ path = $relative; sha256 = (Get-BytesHash $dataA) }
            $approved = Get-ChildPath $fixture $relative
            [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($approved)) | Out-Null
            [IO.File]::WriteAllBytes($approved, $dataA)
        }
        Test-ClientPolicy $baseFixturePolicy | Out-Null
        Assert-NoUnexpectedPlugins $fixture
        Check $true 'Exact approved core and nested patcher DLLs remain allowed.'
        foreach ($relative in $baseFixturePaths) { [IO.File]::Delete((Get-ChildPath $fixture $relative)) }
        Test-ClientPolicy $policy | Out-Null
        $journalEntries = @()
        foreach ($spec in $package.files) {
            $saved = Get-ChildPath $backup ('files/' + $spec.path)
            [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($saved)) | Out-Null
            [IO.File]::WriteAllBytes($saved, $payloads[$spec.path])
            $replacement = [Text.Encoding]::UTF8.GetBytes('replacement fixture')
            $journalEntries += [pscustomobject]@{ path = $spec.path; existedBefore = $true; previousSha256 = $spec.sha256; installedSha256 = (Get-BytesHash $replacement); applied = $false }
        }
        Install-BytesAtomic $fixture $Targets[0] $replacement $work
        $journalEntries[0].applied = $true
        $journal = [pscustomobject]@{ schemaVersion = 1; status = 'applying'; createdAtUtc = '2026-10-23T12:00:00Z'; packageVersion = '1.0.2'; files = $journalEntries }
        Restore-Transaction $fixture $backup $journal $work
        Check ($journal.status -eq 'rolled-back' -and @(Get-ManagedStatus $fixture $package | Where-Object { -not $_.current }).Count -eq 0) 'Windows interrupted transaction restores both originals.'
        $appeared = [pscustomobject]@{ schemaVersion = 1; status = 'applying'; createdAtUtc = '2026-10-23T12:00:00Z'; packageVersion = '1.0.2'; files = @(
            [pscustomobject]@{ path = $Targets[0]; existedBefore = $false; previousSha256 = $null; installedSha256 = (Get-BytesHash $dataA); applied = $false },
            [pscustomobject]@{ path = $Targets[1]; existedBefore = $true; previousSha256 = (Get-BytesHash $dataB); installedSha256 = (Get-BytesHash $dataB); applied = $false }) }
        Restore-Transaction $fixture $backup $appeared $work
        Check ((Get-LocalHash (Get-ChildPath $fixture $Targets[0])) -eq (Get-BytesHash $dataA)) 'Windows recovery preserves a matching file that appeared before our commit.'
        Write-JsonAtomic (Join-Path $fixture 'test.json') ([pscustomobject]@{ first = 1 })
        Write-JsonAtomic (Join-Path $fixture 'test.json') ([pscustomobject]@{ first = 2 })
        Check ((Convert-JsonBytes ([IO.File]::ReadAllBytes((Join-Path $fixture 'test.json')))).first -eq 2) 'Windows JSON atomic replace.'

        # The real baseline has 351 managed files. Exercise the production parser,
        # ZIP reader and partial-commit rollback at that scale with tiny fixtures.
        $bulkPaths = @($fixtureTargets[0])
        for ($index = 1; $index -lt 351; $index++) { $bulkPaths += ('BepInEx/plugins/FixtureAssets/{0:000}.json' -f $index) }
        $bulkPolicy = Clone $policy; $bulkPolicy.managedPaths = $bulkPaths
        Test-ClientPolicy $bulkPolicy | Out-Null
        Reject { Install-BytesAtomic $fixture $fixtureTargets[1] $dataB $work } 'Legacy INSTALL is forbidden as a new full-pack write.'
        $legacyControl = Join-Path $fixture 'legacy-control'
        $legacyBackup = Join-Path $legacyControl 'backups/previous'
        foreach ($relative in $fixtureTargets) {
            $saved = Get-ChildPath $legacyBackup ('files/' + $relative)
            [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($saved)) | Out-Null
            [IO.File]::WriteAllBytes($saved, $payloads[$relative])
        }
        $legacy = Clone $journal; $legacy.status = 'applying'; $legacy.files[1].applied = $true
        [IO.File]::WriteAllBytes((Get-ChildPath $fixture $fixtureTargets[1]), $replacement)
        Write-JsonAtomic (Join-Path $legacyBackup 'transaction.json') $legacy
        $legacyPending = @(Get-PendingTransactions $legacyControl)
        Check ($legacyPending.Count -eq 1 -and $legacyPending[0].journal.files.Count -eq 2) 'Full policy recognizes the exact historical two-file journal.'
        Restore-Transaction $fixture $legacyBackup $legacyPending[0].journal $work
        Check ((Get-LocalHash (Get-ChildPath $fixture $fixtureTargets[1])) -eq (Get-BytesHash $dataB)) 'Legacy INSTALL restores only through a verified rollback.'
        $bulkSpecs = @(); $bulkZipEntries = @(); $oldSpecs = @(); $bulkJournalEntries = @()
        $bulkRoot = Join-Path $fixture 'bulk'; $bulkBackup = Join-Path $fixture 'bulk-backup'
        foreach ($relative in $bulkPaths) {
            $newBytes = [Text.Encoding]::UTF8.GetBytes('approved new fixture: ' + $relative)
            $oldBytes = [Text.Encoding]::UTF8.GetBytes('previous fixture: ' + $relative)
            $newHash = Get-BytesHash $newBytes; $oldHash = Get-BytesHash $oldBytes
            $bulkSpecs += [pscustomobject]@{ path = $relative; size = $newBytes.Length; sha256 = $newHash }
            $oldSpecs += [pscustomobject]@{ path = $relative; size = $oldBytes.Length; sha256 = $oldHash }
            $bulkZipEntries += [pscustomobject]@{ name = $relative; data = $newBytes }
            Install-BytesAtomic $bulkRoot $relative $oldBytes $work
            $saved = Get-ChildPath $bulkBackup ('files/' + $relative)
            [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($saved)) | Out-Null
            [IO.File]::WriteAllBytes($saved, $oldBytes)
            $bulkJournalEntries += [pscustomobject]@{ path = $relative; existedBefore = $true;
                previousSha256 = $oldHash; installedSha256 = $newHash; applied = $false }
        }
        $bulkZip = Zip-Bytes $bulkZipEntries
        $bulkManifest = Clone $manifest
        $bulkManifest.packages[0].files = $bulkSpecs
        $bulkManifest.packages[0].sha256 = Get-BytesHash $bulkZip
        $bulkManifest.packages[0].size = $bulkZip.Length
        $bulkPackage = Test-Manifest (Convert-JsonBytes ([Text.Encoding]::UTF8.GetBytes(($bulkManifest | ConvertTo-Json -Depth 12))))
        $bulkPayloads = Read-Package $bulkZip $bulkPackage
        Check ($bulkPayloads.Count -eq 351) 'Full-size 351-file policy/manifest/archive validated.'
        for ($index = 0; $index -lt 176; $index++) {
            $relative = $bulkJournalEntries[$index].path
            Install-BytesAtomic $bulkRoot $relative $bulkPayloads[$relative] $work
            $bulkJournalEntries[$index].applied = $true
        }
        $bulkJournal = [pscustomobject]@{ schemaVersion = 1; status = 'applying'; createdAtUtc = '2026-10-23T12:00:00Z';
            packageVersion = '2026.10.23.1'; files = $bulkJournalEntries }
        [IO.Directory]::CreateDirectory($bulkBackup) | Out-Null
        Restore-Transaction $bulkRoot $bulkBackup $bulkJournal $work
        $oldPackage = Clone $bulkPackage; $oldPackage.files = $oldSpecs
        Check ($bulkJournal.status -eq 'rolled-back' -and @(Get-ManagedStatus $bulkRoot $oldPackage | Where-Object { -not $_.current }).Count -eq 0) '351 originals intact after rolling back a partial 176-file commit.'
        foreach ($relative in $bulkPaths) { Install-BytesAtomic $bulkRoot $relative $bulkPayloads[$relative] $work }
        Check (@(Get-ManagedStatus $bulkRoot $bulkPackage | Where-Object { -not $_.current }).Count -eq 0) 'Complete 351-file sync verifies every target.'
        Test-ClientPolicy $policy | Out-Null
    }
    finally { if (Test-Path -LiteralPath $fixture -PathType Container) { [IO.Directory]::Delete($fixture, $true) } }
}
Write-Host "Updater production-function tests: $checks checks passed. Engine: $($PSVersionTable.PSVersion)."
