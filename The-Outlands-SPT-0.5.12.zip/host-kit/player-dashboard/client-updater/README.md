# Windows full client updater

Download package/updater engine 1.2.0 (local policy contract 1.1.0) ships `Update-Outlands.ps1`, `Outlands Client Updater.cmd`,
`Update and Play.cmd`, `README.txt`, a generated **local** `client-policy.json`, and `Install Play Outlands.cmd` /
`Install-PlayOutlands.ps1`. The installer keeps these seven files under the
selected SPT folder, verifies their copied bytes, and creates the current user's
**Play Outlands** desktop shortcut with the EFT icon. The shortcut targets
`Update and Play.cmd` directly, without interpolated shell arguments or elevation.
An existing shortcut is backed up locally before replacement. Reinstall after
moving the SPT folder. Windows COM/desktop behavior still requires a Windows smoke test.
It runs with built-in Windows PowerShell 5.1/.NET, without a package manager,
GitHub token, game download, or elevated privileges. Test files stay outside the
player ZIP. Vendor DLLs/assets and generated full-pack archives stay in local deployment
and on the tailnet. The generated policy contains only path/hash metadata and
is included with the authored updater in the private GitHub archive.

The user selects an existing matching SPT folder or the updater discovers one
beside the script/current directory. It requires `EscapeFromTarkov.exe` and exact
compiled EFT/SPT/Fika compatibility hashes. Every additional base file listed in
the local policy is hash-verified too. Base files are never updated by this tool.

The policy ships alongside the updater, not in the mutable server manifest.
Schema 1 requires `updaterVersion: "1.1.0"`, `channel: "node-01"`, `managedPaths`
(exact forward-slash plugin/asset paths), and `baseFiles` (`path`, `sha256`). An
optional `packageId` must be `outlands-client-pack`. Managed paths cannot include
server files, profiles, personal `BepInEx/config`, base SPT/Fika libraries,
headless-only plugins, or PDBs. Base verification may include the game executable,
main assembly, BepInEx core/patcher DLLs, SPT plugin DLLs, and Fika Core. The three
compiled pins cannot be overridden. New managed paths require a new reviewed
updater/policy release. Hashes at approved managed paths may change in future
server-approved packs.

The sync manifest comes from `/downloads/client-sync-manifest.json` at the fixed private
Tailscale origin `https://your-server.your-tailnet.ts.net:8446`. Redirects are refused,
certificate validation stays enabled, proxy/default credentials are disabled,
and downloads are bounded. Schema 1 retains three compatibility pins and one
package: `outlands-client-pack`, relative URL `/downloads/outlands-client-pack.zip`,
version, ZIP `size`/`sha256`, and each file's `path`/`size`/`sha256`. The sync package adds
`fileTransport: "sha256-v1"`. Each file is fetched only from
`/downloads/client-file-<sha256>.bin` at that same HTTPS origin. The original
`client-manifest.json` and full ZIP remain available to older updaters. Its exact target
set must match local policy. An optional maintenance message is informational.

`-Mode Status` changes no files. Default `Update` synchronizes changed/missing
managed files; matching installations are idempotent. `Repair` revalidates and
reinstalls all approved files, recovering tracked interrupted writes first.
`-Launch` opens the existing `SPT.Launcher.exe` only after complete verification.
The game, headless client, and SPT/BSG launchers must be closed for updates.
An exclusive lock prevents simultaneous updater instances. Older quest-only
receipts migrate to the full pack; full-pack receipts block downgrades.

The updater inventories DLLs throughout `BepInEx/plugins`, `BepInEx/core`, and
`BepInEx/patchers`, including nested directories. Only exact-policy managed DLL
paths and verified base DLL paths are allowed. Extra addons, old duplicate DLLs,
unapproved preloader/core libraries, Fika Headless, FikaDynamicAI, and diagnostics
are explicitly reported and block a verified match/launch. Users move unapproved
DLLs outside those three directories themselves; none are removed automatically.
Reparse directories are refused before recursive inventory.

Limits: 500 managed files; 256 MiB ZIP; 512 MiB expansion; 128 MiB per file;
1 MiB policy/manifest/journal/receipt. Individual-file sync stages and hash-verifies all changed files before any
target writes; their combined size remains bounded by the expanded-pack limit.
Only changed targets are backed up and replaced. Verified downloads are cached
under `.outlands-client-updater/cache/<sha256>.bin`, rechecked before reuse, and
retained across retries. Corrupt cache entries are discarded. A failed file
download cannot trigger a full-ZIP fallback or launch the game. The retained
legacy ZIP reader also verifies each decompressed member. Paths reject roots,
traversal, backslashes, ADS, reserved Windows names, ZIP links/reparse flags,
duplicate/unlisted entries, and compression bombs. The baseline is about 200 MB;
the bounded memory approach avoids partial untrusted extraction or dependencies.

Writes use same-volume temporary files and atomic replacement. Originals receive
verified backups and a transaction journal. Failure restores recorded commits
only, refusing unrelated intervening changes. Unrecorded files are preserved and
checked against the pack. Backups remain without pruning. Rollback deletes only
a previously absent managed file recorded as installed with the matching hash.
No game/profile API is called.

Run isolated tests with the game/launchers closed:

```powershell
powershell.exe -NoProfile -File .\tests.ps1
```

Tests import production functions through the PowerShell parser without invoking
the updater CLI. They cover real JSON decoding, local policy, manifest contracts,
archive/path/hash attacks, plugin inventory, idempotent status, and interrupted
rollback in disposable fixtures. Portable PowerShell on Linux uses a Unix path/
process adapter for filesystem fixtures. It does not prove Windows PowerShell
5.1 execution, Windows replacement semantics, dialogs, process discovery, or a
complete player update. An actual Windows smoke test remains necessary.

## Release publication and launch gate

`ops/publish-client-bundle.py` verifies the explicitly approved inventory against
node-01, builds the legacy full pack, and writes immutable content-addressed
client blobs before publishing the new sync manifest last. Existing blobs are
verified, never overwritten with different content; older ones stay available
for clients already downloading a fixed release. Nothing serves raw runtime
paths. Recurate only after reviewing and activating a compatible baseline.

Play Outlands checks all managed and base hashes each run. A current client
downloads only metadata. Changed clients fetch only missing/different files;
Repair reinstalls all managed files, reusing verified cache entries. The updater
rechecks the release before readiness and launch. A release change stops launch
and asks the user to rerun. This is a per-file retry cache, not partial-byte HTTP
resume. Cache/backups are retained; operators can remove them with the updater
closed when disk space is needed. No automatic updater self-replacement occurs: 
existing players install this updater package once to enable the new transport.

Run `tests-sync.ps1` for production orchestration fixtures, including no-op,
selective downloads, verified cache reuse, bad bytes, running-game refusal,
partial apply rollback, and release changes. A Windows smoke test is still needed.
