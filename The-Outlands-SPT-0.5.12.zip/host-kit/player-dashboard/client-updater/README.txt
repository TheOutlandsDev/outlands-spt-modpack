PLAY OUTLANDS 1.2.0 - CHECK AND SYNC BEFORE PLAY
Updater engine 1.2.0; base compatibility and approved client files unchanged.
For existing Windows SPT 4.0.13 / EFT 0.16.9.40087 / Fika 2.2.5 clients.

CONNECT TAILSCALE FIRST. CLOSE THE GAME AND ALL SPT/BSG LAUNCHERS.

1. Extract the complete ZIP to a normal folder. Do not run it inside the ZIP.
2. Double-click Install Play Outlands.cmd. Select your existing modded SPT folder
   if prompted. It stores the updater in that game's Outlands Client Updater
   folder and creates Play Outlands on your current Windows user's desktop.
3. Connect Tailscale, close the game/launchers, and use Play Outlands every time.
   It compares the required files with node-01, downloads only changed/missing
   files, verifies the match, then opens SPT Launcher.

Installation needs no Administrator rights. The shortcut uses the game icon.
If the desktop shortcut already exists, a copy is retained under the updater's
shortcut-backups folder before it is replaced. Re-run the installer if the game
folder moves. You can remove the extracted download after installation if it is
outside the game's installed Outlands Client Updater folder. Keep the installed
folder in place. Installation itself does not run the updater or modify mods.

Update and Play.cmd still works directly. Keep all seven shipped files together,
including client-policy.json. A failed update or compatibility check blocks launch.

This version synchronizes the server-approved HUMAN client plugin DLLs, support
assets, and mod-local gameplay presets in the full pack. It checks exact base
EFT/SPT/Fika libraries too. It reports MATCH VERIFIED only after every approved
file matches and no extra plugin DLLs are present. Restart the game after updates.

The pack includes Remote Quests: accept eligible new quests remotely, but turn
in items/money/weapon assemblies, complete quests, and reroll only at a local
active trader. Shops and services keep their restrictions.

Double-click Outlands Client Updater.cmd to check/install without launching.
Command Prompt examples, run inside the extracted updater folder:

  "Outlands Client Updater.cmd" -GamePath "D:\Games\SPT" -Mode Status
  "Outlands Client Updater.cmd" -GamePath "D:\Games\SPT" -Mode Repair
  "Update and Play.cmd" -GamePath "D:\Games\SPT"

Status changes no files. Exit code 0 means current/ready, 2 means an update is
available in Status mode, and 1 means stopped/error. Repair verifies/reinstalls all approved files, using verified cached downloads,
and recovers interrupted updater transactions. Completed downloads survive retries.

Updates come only from https://your-server.your-tailnet.ts.net:8446 over Tailscale.
The updater never asks for passwords or GitHub tokens. It downloads no game files
and changes no profiles, saves, launcher settings, or credentials. It does not
change personal graphics/network settings under BepInEx/config. Its exact approved
file paths are listed in the shipped client-policy.json. Server changes at those
paths are synchronized; adding new approved paths requires a new updater/policy.

Extra/unapproved DLLs in BepInEx/plugins, BepInEx/core, or BepInEx/patchers and
host-only Fika.Headless, FikaDynamicAI, or diagnostic plugins block a verified
match and launch. The updater displays their exact paths. Move those DLLs outside
these three directories manually and rerun; the updater never deletes them.
It cannot fix a different EFT/SPT/Fika base: use the matching base client first.

Originals and recovery records remain under your SPT folder:
  .outlands-client-updater\backups\<timestamp-and-id>\
If an update fails, the updater restores its original managed files when safe.
If interrupted, close the game and rerun Repair. If another program modified the
same files, it stops and displays the backup location instead of overwriting them.

If Tailscale/HTTPS or compatibility checks fail, no package is installed and the
launcher is not opened. Use your matching modded SPT folder, not the live BSG game.
Windows may display its normal downloaded-script security prompt. Do not run this
updater as Administrator. Junctions, symlinks, and redirected game folders are refused.

Install this updated shortcut package once even if Play Outlands is already on
your desktop. Afterward use that shortcut every time. Direct SPT.Launcher.exe
does not run file sync. A current installation downloads no mod payloads.
Changed files are individually SHA-256 checked before any replacement; only
changed originals are backed up. If the server release changes during the check,
launch stops: run Play Outlands again. The game/SPT/Fika base remains frozen and
is verified separately; use the matching full installer for base repairs.
