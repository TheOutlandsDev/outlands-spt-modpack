#requires -Version 5.1
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$tokens = $null; $errors = $null
$ast = [Management.Automation.Language.Parser]::ParseFile((Join-Path $PSScriptRoot 'Update-Outlands.ps1'), [ref]$tokens, [ref]$errors)
if ($errors.Count) { throw ($errors | Out-String) }
foreach ($statement in $ast.EndBlock.Statements) {
    if ($statement -is [Management.Automation.Language.FunctionDefinitionAst] -or
        ($statement -is [Management.Automation.Language.AssignmentStatementAst] -and $statement.Left.Extent.Text.StartsWith('$script:'))) {
        . ([scriptblock]::Create($statement.Extent.Text))
    }
}
$checks = 1
function Check([bool]$Value, [string]$Label) { if (-not $Value) { throw $Label }; $script:checks++ }
$good = [pscustomobject]@{ schemaVersion = 1; origin = 'https://game.example-tailnet.ts.net:8446' }
Check ((Test-ServerProfile $good) -ceq $good.origin) 'Valid approved origin failed.'
foreach ($originValue in @('http://game.example-tailnet.ts.net:8446', 'https://evil.example',
    'https://game.example-tailnet.ts.net.evil.example:8446', 'https://user:password@game.example-tailnet.ts.net:8446',
    'https://game.example-tailnet.ts.net:8446/downloads', 'https://game.example-tailnet.ts.net:8446?token=fixture',
    'https://game.example-tailnet.ts.net:8446#fragment', 'not a URI')) {
    $rejected = $false
    try { Test-ServerProfile ([pscustomobject]@{schemaVersion = 1; origin = $originValue}) | Out-Null } catch { $rejected = $true }
    Check $rejected 'Unapproved origin accepted.'
}
foreach ($profile in @([pscustomobject]@{schemaVersion = $true; origin = $good.origin},
    [pscustomobject]@{schemaVersion = 2; origin = $good.origin},
    [pscustomobject]@{schemaVersion = 1; origin = $good.origin; accessKey = 'fictional'},
    [pscustomobject]@{schemaVersion = 1})) {
    $rejected = $false
    try { Test-ServerProfile $profile | Out-Null } catch { $rejected = $true }
    Check $rejected 'Unsupported profile contract accepted.'
}
Check ($script:Origin -ceq '') 'Public script must not fall back to a live or example server.'
Write-Host ($checks.ToString() + ' private-origin contract checks passed; no network requests or profile writes.')
