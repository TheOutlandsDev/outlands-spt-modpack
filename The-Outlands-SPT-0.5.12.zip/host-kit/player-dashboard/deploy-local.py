#!/usr/bin/env python3
"""Stage only dashboard build source for Dockhand, then deploy through Docker."""
import json
import shutil
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
workspace = root.parent
context = workspace / 'containers/build-contexts/player-dashboard'
stack = workspace / 'containers/stacks/player-dashboard'
context.mkdir(parents=True, exist_ok=True)
stack.mkdir(parents=True, exist_ok=True)
source_files = ('app.py', 'content_status.py', 'diagnostics_status.py', 'Dockerfile', '.dockerignore', 'web/index.html', 'web/styles.css', 'web/app.js', 'web/play.html', 'web/play.css', 'web/play.js', 'web/release.json')
for relative in source_files:
    source = root / relative
    if source.is_symlink() or not source.is_file():
        raise SystemExit('Expected ordinary source file missing: ' + relative)
    destination = context / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
compose = (root / 'compose.yaml').read_text()
compose = compose.replace('context: ${DASHBOARD_SOURCE_DIR:-.}', 'context: ' + json.dumps(str(context)))
for filename, target in [('config.json', '/run/config/dashboard.json'), ('fika_api_key', '/run/secrets/fika_api_key'),
                         ('downloads', '/run/downloads'), ('public-state', '/run/public-state')]:
    original = '${DASHBOARD_SOURCE_DIR:-.}/deployment/' + filename + ':' + target + ':ro'
    replacement = str(root / 'deployment' / filename) + ':' + target + ':ro'
    compose = compose.replace(original, json.dumps(replacement))
if '${DASHBOARD_SOURCE_DIR' in compose:
    raise SystemExit('Unresolved deployment path; compose source changed.')
path = stack / 'compose.yaml'
(root / 'deployment/downloads').mkdir(parents=True, exist_ok=True)
(root / 'deployment/public-state').mkdir(parents=True, exist_ok=True)
path.write_text(compose)
wrapper = workspace / 'containers/docker.sh'
command = [str(wrapper)] if wrapper.exists() else ['docker']
subprocess.run(command + ['compose', '-f', str(path), 'up', '-d', '--build'], check=True)
print('Source-only build context staged; local config and API key stay outside Dockhand mounts.')
