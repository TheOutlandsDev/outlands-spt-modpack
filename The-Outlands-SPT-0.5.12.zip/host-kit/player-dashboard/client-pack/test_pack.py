"""Synthetic pack tests: no installed game mutations, live API calls, or installers."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import build


class PackTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.runtime = self.root / "runtime"
        self.contents = {
            "EscapeFromTarkov.exe": b"fixture game executable",
            "EscapeFromTarkov_Data/Managed/Assembly-CSharp.dll": b"fixture game assembly",
            "BepInEx/core/BepInEx.dll": b"fixture base",
            "BepInEx/patchers/Patcher.dll": b"fixture patcher",
            "BepInEx/plugins/spt/spt-core.dll": b"fixture spt",
            "BepInEx/plugins/Fika/Fika.Core.dll": b"fixture fika",
            "BepInEx/plugins/Fika/Fika.Headless.dll": b"host only",
            "BepInEx/plugins/FikaDynamicAI/FikaDynamicAI.dll": b"host only",
            "BepInEx/plugins/CodexDiagnostics/Diagnostics.dll": b"host only",
            "BepInEx/plugins/Demo/Demo.dll": b"managed demo plugin",
            "BepInEx/plugins/Demo/gameplay.json": b'{"difficulty":"tactical"}',
            "BepInEx/plugins/SAIN/Presets/ConfigSettings.json": b'{"preset":"fixture"}',
            "BepInEx/plugins/Demo.pdb": b"debug excluded",
            "BepInEx/config/preferences.cfg": b"personal preferences excluded",
        }
        for relative, data in self.contents.items():
            self.write(relative, data)

    def write(self, relative, data):
        path = self.runtime / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        return path

    def inventory(self):
        return build.inventory(self.runtime, curated_at="2026-10-23T23:00:00+00:00")

    def test_exact_human_selection_and_base_verification(self):
        value = self.inventory()
        managed = [entry["path"] for entry in value["managedFiles"]]
        self.assertEqual(managed, sorted(("BepInEx/plugins/Demo/Demo.dll", "BepInEx/plugins/Demo/gameplay.json",
                                         "BepInEx/plugins/SAIN/Presets/ConfigSettings.json")))
        self.assertEqual(len(value["baseFiles"]), 6)
        self.assertFalse(value["selection"]["personalBepInExConfigIncluded"])

    def test_deterministic_zip_manifest_and_policy(self):
        approved = self.inventory()
        first, policy = build.build(self.runtime, approved, self.root / "first")
        second, other = build.build(self.runtime, approved, self.root / "second")
        self.assertEqual(first, second)
        self.assertEqual(policy, other)
        self.assertEqual(first["packages"][0]["sha256"], hashlib.sha256((self.root / "first/outlands-client-pack.zip").read_bytes()).hexdigest())
        self.assertEqual(policy["managedPaths"], [row["path"] for row in approved["managedFiles"]])
        self.assertEqual(len(policy["baseFiles"]), len(approved["baseFiles"]))
        with zipfile.ZipFile(self.root / "first/outlands-client-pack.zip") as archive:
            self.assertEqual(archive.namelist(), policy["managedPaths"])
            for row in approved["managedFiles"]:
                self.assertEqual(hashlib.sha256(archive.read(row["path"])).hexdigest(), row["sha256"])
                self.assertEqual(archive.getinfo(row["path"]).date_time, (2026, 10, 23, 0, 0, 0))

    def test_new_changed_or_missing_files_require_recuration(self):
        for operation in ("new", "changed", "missing"):
            with self.subTest(operation=operation):
                approved = self.inventory()
                path = self.runtime / "BepInEx/plugins/Demo/Demo.dll"
                original = path.read_bytes()
                if operation == "new":
                    changed = self.write("BepInEx/plugins/new.dll", b"new plugin")
                elif operation == "changed":
                    path.write_bytes(b"changed plugin")
                else:
                    path.unlink()
                with self.assertRaises(build.Refused):
                    build.validate(self.runtime, approved)
                if operation == "new":
                    changed.unlink()
                else:
                    path.write_bytes(original)

    def test_base_drift_also_requires_recuration(self):
        approved = self.inventory()
        self.write("BepInEx/patchers/Patcher.dll", b"changed base")
        with self.assertRaises(build.Refused):
            build.validate(self.runtime, approved)

    def test_symlinks_and_symlink_ancestry_refused(self):
        path = self.runtime / "BepInEx/plugins/Demo/Demo.dll"
        path.unlink()
        path.symlink_to(self.runtime / "EscapeFromTarkov.exe")
        with self.assertRaises(build.Refused):
            self.inventory()

    def test_windows_case_collision_refused(self):
        self.write("BepInEx/plugins/demo/DEMO.dll", b"colliding plugin")
        with self.assertRaises(build.Refused):
            self.inventory()

    def test_unsafe_windows_paths_refused(self):
        for relative in ("../profile.json", "/absolute", "C:/file", "plugins/CON.dll", "plugins/item.",
                         "plugins/trailing /file", "plugins/../file", "plugins/a\\b", "plugins//file"):
            with self.subTest(path=relative), self.assertRaises(build.Refused):
                build.safe_relative(relative)

    def test_populated_credentials_and_known_binary_secret_refused(self):
        for data in (b'{"apiKey":"private"}', b'{"nested":{"access_token":"private"}}', b'{"Cookie":"private"}'):
            self.write("BepInEx/plugins/Demo/gameplay.json", data)
            with self.assertRaises(build.Refused):
                self.inventory()
        self.write("BepInEx/plugins/Demo/gameplay.json", b'{"apiKey":""}')
        self.inventory()
        self.write("BepInEx/plugins/Demo/Demo.dll", b"binary contains opaque-local-secret")
        with self.assertRaises(build.Refused):
            build.inventory(self.runtime, secrets=[b"opaque-local-secret"])

    def test_jsonc_comments_preserve_urls_and_reject_malformed(self):
        value = build.jsonc('{/* comment */"asset":"https://example.invalid/file",// another\n"active":true}')
        self.assertEqual(value["asset"], "https://example.invalid/file")
        self.write("BepInEx/plugins/Demo/gameplay.json", b'{malformed')
        with self.assertRaises(build.Refused):
            self.inventory()

    def test_file_count_size_and_empty_file_limits(self):
        with patch.dict(build.LIMITS, files=2), self.assertRaises(build.Refused):
            self.inventory()
        with patch.dict(build.LIMITS, fileBytes=3), self.assertRaises(build.Refused):
            self.inventory()
        with patch.dict(build.LIMITS, expandedBytes=3), self.assertRaises(build.Refused):
            self.inventory()
        self.write("BepInEx/plugins/empty.asset", b"")
        with self.assertRaises(build.Refused):
            self.inventory()

    def test_zip_limit_refuses_oversized_output(self):
        approved = self.inventory()
        with patch.dict(build.LIMITS, zipBytes=3), self.assertRaises(build.Refused):
            build.build(self.runtime, approved, self.root / "output")
        self.assertFalse((self.root / "output/outlands-client-pack.zip").exists())

    def test_packaging_detects_source_change_after_inventory_validation(self):
        approved = self.inventory()
        original = build.credential_scan
        changed = False
        def scan(relative, data, secrets=()):
            nonlocal changed
            original(relative, data, secrets)
            if not changed and relative.endswith("Demo.dll"):
                changed = True
                (self.runtime / relative).write_bytes(b"changed during build")
        with patch.object(build, "credential_scan", side_effect=scan), self.assertRaises(build.Refused):
            build.build(self.runtime, approved, self.root / "output")
        self.assertFalse((self.root / "output/outlands-client-pack.zip").exists())

    def test_final_archive_entry_hash_is_independently_checked(self):
        approved = self.inventory()
        original = zipfile.ZipFile.writestr
        def corrupt(archive, info, data, **kwargs):
            return original(archive, info, b"corrupt payload", **kwargs)
        with patch.object(zipfile.ZipFile, "writestr", corrupt), self.assertRaises(build.Refused):
            build.build(self.runtime, approved, self.root / "output")


if __name__ == "__main__":
    unittest.main()
