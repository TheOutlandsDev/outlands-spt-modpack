import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

spec = importlib.util.spec_from_file_location('client_updates', Path(__file__).parents[1] / 'client_updates.py')
updates = importlib.util.module_from_spec(spec)
spec.loader.exec_module(updates)


def manifest():
    return {'schemaVersion': 1, 'bundleVersion': '2026.10.25.1', 'packages': [
        {'id': 'outlands-client-pack', 'version': '2026.10.24.3', 'sha256': 'c' * 64, 'files': [
            {'path': 'BepInEx/plugins/A/a.dll', 'size': 20, 'sha256': 'a' * 64},
            {'path': 'BepInEx/plugins/A/settings.json', 'size': 30, 'sha256': 'b' * 64}]}]}


class ClientUpdateTests(unittest.TestCase):
    def test_content_identity_ignores_transport_version_and_order(self):
        old = manifest()
        new = copy.deepcopy(old)
        new['bundleVersion'] = '2026.10.25.2'
        new['packages'][0]['sha256'] = 'f' * 64
        new['packages'][0]['version'] = '2026.10.25.1'
        new['packages'][0]['files'].reverse()
        self.assertEqual(updates.identity(old)['fingerprint'], updates.identity(new)['fingerprint'])
        new['packages'][0]['files'][0]['sha256'] = 'd' * 64
        self.assertNotEqual(updates.identity(old)['fingerprint'], updates.identity(new)['fingerprint'])

    def test_invalid_and_duplicate_paths_refused(self):
        for path in ['BepInEx/plugins/../secret', 'BepInEx/plugins/a\\b', '/etc/passwd', 'BepInEx/plugins/a\nsecret']:
            m = manifest(); m['packages'][0]['files'][0]['path'] = path
            with self.assertRaises(ValueError): updates.identity(m)
        m = manifest(); m['packages'][0]['files'].append(m['packages'][0]['files'][0])
        with self.assertRaises(ValueError): updates.identity(m)

    def test_outbox_restart_retry_dedup_and_crash_recovery(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); deployment = root / 'player-dashboard/deployment'; downloads = deployment / 'downloads'
            downloads.mkdir(parents=True)
            def atomic(p, data): p.write_bytes(data)
            old = manifest()
            (downloads / 'client-sync-manifest.json').write_text(json.dumps(old))
            updates.publication(root, old, None, atomic)
            sent = []
            updates.deliver(root, sent.append, atomic)
            self.assertEqual(sent, []) # First baseline and routine restarts are quiet.
            relabeled = copy.deepcopy(old); relabeled['packages'][0]['version'] = '2026.10.25.1'
            updates.publication(root, relabeled, old, atomic)
            self.assertEqual(updates.read(deployment / 'public-state/client-update.json')['version'], '2026.10.25.1')
            self.assertFalse(updates.read(deployment / 'client-update.json')['pending'])
            new = copy.deepcopy(old); new['packages'][0]['files'][1]['sha256'] = 'e' * 64
            (downloads / 'client-sync-manifest.json').write_text(json.dumps(new))
            # Simulate committed manifest followed by power loss before outbox update.
            def offline(message): raise OSError('backend restarting')
            with self.assertRaises(OSError): updates.deliver(root, offline, atomic)
            self.assertTrue(updates.read(deployment / 'client-update.json')['pending'])
            updates.deliver(root, sent.append, atomic)
            updates.deliver(root, sent.append, atomic)
            updates.publication(root, new, new, atomic)
            updates.deliver(root, sent.append, atomic)
            self.assertEqual(len(sent), 1)
            self.assertIn('Finish your current raid', sent[0])
            self.assertIn('AND SPT Launcher', sent[0])
            self.assertIn('Play Outlands', sent[0])
            public = updates.read(deployment / 'public-state/client-update.json')
            self.assertTrue(public['changed'])
            self.assertNotIn('pending', public)

    def test_dashboard_projection_is_bounded_and_drops_private_fields(self):
        app_spec = importlib.util.spec_from_file_location('updates_dashboard', Path(__file__).parents[1] / 'app.py')
        app = importlib.util.module_from_spec(app_spec); app_spec.loader.exec_module(app)
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            data = dict(schemaVersion=1, version='2026.10.24.3', fingerprint='f' * 64, managedFiles=351,
                        changed=True, message='<script>private</script>', profiles=['secret'])
            (root / 'client-update.json').write_text(json.dumps(data))
            result = app.client_update_status(root)
            self.assertTrue(result['available']); self.assertNotIn('private', json.dumps(result)); self.assertNotIn('secret', json.dumps(result))
            (root / 'client-update.json').write_text('x' * 5000)
            self.assertFalse(app.client_update_status(root)['available'])
