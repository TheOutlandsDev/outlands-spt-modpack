import json
from pathlib import Path
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer

sys.path.insert(0, str(Path(__file__).parents[1] / 'hub-integration'))
import render
from test_app import app, config


class PlayerPortalTests(unittest.TestCase):
    def test_readonly_routes_use_security_headers_and_never_serve_source(self):
        server=ThreadingHTTPServer(('127.0.0.1',0), app.handler_for(app.Dashboard(config())))
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        base='http://127.0.0.1:'+str(server.server_port)
        try:
            for route in ['/play','/play/','/play/play.css','/play/play.js','/play/release.json']:
                with urllib.request.urlopen(base+route)as response:
                    self.assertEqual(response.status,200)
                    self.assertEqual(response.headers['X-Content-Type-Options'],'nosniff')
                    self.assertIn("frame-ancestors 'none'",response.headers['Content-Security-Policy'])
                    self.assertGreater(len(response.read()),10)
            for route in ['/play/../../deployment/fika_api_key','/play/app.py','/play/server-profile.json']:
                with self.assertRaises(urllib.error.HTTPError)as error:urllib.request.urlopen(base+route)
                self.assertEqual(error.exception.code,404)
            with self.assertRaises(urllib.error.HTTPError)as error:
                urllib.request.urlopen(urllib.request.Request(base+'/play/',data=b'{}'))
            self.assertEqual(error.exception.code,501)
        finally:server.shutdown();server.server_close();thread.join()

    def test_hub_bundle_rejects_unexpected_origins_and_preserves_existing_output(self):
        for value in ['http://node.example.ts.net','https://node.example.com','https://u:p@node.example.ts.net',
                      'https://node.example.ts.net/path','https://node.example.ts.net?token=private',
                      'https://node.example.ts.net/#x','https://node.example.ts.net\nanything']:
            with self.assertRaises(ValueError):render.private_origin(value)
        with tempfile.TemporaryDirectory()as temp:
            output=Path(temp)/'links';render.render('https://node.example.ts.net:8446/',output)
            values=json.loads((output/'LINKS.json').read_text())
            self.assertFalse(values['changesGameNetworking']);self.assertFalse(values['changesAccessPolicy'])
            self.assertEqual(len(values['links']),4)
            self.assertIn('location = /spt/',(output/'nginx-spt-shortcut.conf').read_text())
            with self.assertRaises(ValueError):render.render('https://node.example.ts.net',output)
            self.assertEqual(output.stat().st_mode&0o777,0o700)
