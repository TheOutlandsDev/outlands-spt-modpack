import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

SPEC = importlib.util.spec_from_file_location("narconet_policy", Path(__file__).resolve().parents[1] / "ops/configure-narconet-client-policy.py")
policy = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(policy)

ORIGINAL = b'''syncPaths:
  - name: "Client plugins"
    path: BepInEx/plugins
    enabled: true
    enforced: false
    silent: false
    restartRequired: true

exclusions:
  # existing rules retained
  - "BepInEx/plugins/CodexDiagnostics"
  - "BepInEx/plugins/Fika/Fika.Headless*"
  - "BepInEx/plugins/Fika/LICENSE-HEADLESS*"
  - "BepInEx/plugins/spt"
'''


class NarcoNetPolicyTests(unittest.TestCase):
    def test_only_adds_missing_host_directory_and_preserves_approved_sync(self):
        result, added = policy.desired(ORIGINAL)
        self.assertEqual(added, ["BepInEx/plugins/FikaDynamicAI"])
        insertion = b'  # Host-only plugins must never sync onto human clients.\n  - "BepInEx/plugins/FikaDynamicAI"\n'
        self.assertEqual(result.replace(insertion, b"", 1), ORIGINAL)
        self.assertEqual(policy.desired(result), (result, []))

    def test_all_host_only_rules_are_added_and_crlf_is_preserved(self):
        source = b'syncPaths:\r\nexclusions:\r\n  - "unrelated"\r\n'
        result, added = policy.desired(source)
        self.assertEqual(tuple(added), policy.REQUIRED)
        self.assertNotIn(b"\n", result.replace(b"\r\n", b""))
        self.assertTrue(result.endswith(b'  - "unrelated"\r\n'))

    def test_ambiguous_yaml_is_refused_without_mutations(self):
        for raw in (b"syncPaths:\nexclusions: []\n", ORIGINAL + b"exclusions:\n",
                    ORIGINAL + b"other: yes\n", ORIGINAL + b"  - &anchor something\n"):
            with self.subTest(raw=raw), self.assertRaises(policy.Refused):
                policy.desired(raw)

    def workspace(self, directory):
        root = Path(directory)
        target = root / policy.CONFIG
        target.parent.mkdir(parents=True)
        target.write_bytes(ORIGINAL)
        target.chmod(0o640)
        return root, target

    def test_apply_backs_up_exact_bytes_mode_and_is_idempotent(self):
        with tempfile.TemporaryDirectory() as directory:
            root, target = self.workspace(directory)
            check = policy.operate(root)
            self.assertTrue(check["changed"])
            self.assertFalse((root / "linux").exists())
            self.assertEqual(target.read_bytes(), ORIGINAL)
            result = policy.operate(root, True)
            saved = Path(result["backup"])
            self.assertEqual((saved / "config.yaml").read_bytes(), ORIGINAL)
            self.assertEqual(json.loads((saved / "manifest.json").read_text())["mode"], 0o640)
            self.assertEqual(target.stat().st_mode & 0o777, 0o640)
            self.assertEqual(target.read_bytes(), policy.desired(ORIGINAL)[0])
            self.assertFalse(policy.operate(root, True)["changed"])
            self.assertEqual(len(list((root / "linux/backups").iterdir())), 1)

    def test_backup_failure_does_not_change_live_config(self):
        with tempfile.TemporaryDirectory() as directory:
            root, target = self.workspace(directory)
            with patch.object(policy, "atomic", side_effect=OSError("fixture backup failure")):
                with self.assertRaises(OSError):
                    policy.operate(root, True)
            self.assertEqual(target.read_bytes(), ORIGINAL)

    def test_symlinked_config_and_backup_ancestry_are_refused(self):
        with tempfile.TemporaryDirectory() as directory:
            root, target = self.workspace(directory)
            original = target.with_suffix(".original")
            target.rename(original)
            target.symlink_to(original)
            with self.assertRaises(policy.Refused):
                policy.operate(root, True)
            target.unlink()
            original.rename(target)
            (root / "linux").symlink_to(root / "runtime")
            with self.assertRaises(policy.Refused):
                policy.operate(root, True)
            self.assertEqual(target.read_bytes(), ORIGINAL)


if __name__ == "__main__":
    unittest.main()
