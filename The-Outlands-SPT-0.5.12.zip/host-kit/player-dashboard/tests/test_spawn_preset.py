import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

spec = importlib.util.spec_from_file_location('spawn', Path(__file__).parents[1] / 'ops/spawn_preset.py')
spawn = importlib.util.module_from_spec(spec)
spec.loader.exec_module(spawn)


class SpawnPresetTests(unittest.TestCase):
    def row(self, document, path, expected, value):
        desired = copy.deepcopy(document)
        cursor = desired
        for key in path[:-1]:
            cursor = cursor[key]
        cursor[path[-1]] = value
        return dict(path='SPT/user/mods/zzz-CodexAiPopulationTuning/config/config.json', expectedSemanticSha256=spawn.semantic(document),
                    valueSemanticSha256=spawn.semantic(desired), changes=[dict(path=path, expected=expected, value=value)])

    def test_changes_one_leaf_and_preserves_other_settings(self):
        doc = {'maxBotCap': {'rezervbase': 23, 'default': 18}, 'difficulty': 'unchanged'}
        row = self.row(doc, ['maxBotCap', 'rezervbase'], 23, 27)
        result = spawn.transform(doc, row)
        self.assertEqual(result['maxBotCap'], {'rezervbase': 27, 'default': 18})
        self.assertEqual(result['difficulty'], 'unchanged')
        self.assertEqual(doc['maxBotCap']['rezervbase'], 23)
        self.assertEqual(spawn.transform(result, row), result)

    def test_drift_bad_fingerprint_duplicate_and_bad_expected_are_refused(self):
        doc = {'n': 1, 'unrelated': 'preserve'}
        row = self.row(doc, ['n'], 1, 2)
        for bad in [dict(doc, unrelated='different'), dict(doc, n=3)]:
            with self.assertRaises(ValueError):
                spawn.transform(bad, row)
        for mode in ['hash', 'duplicate', 'expected']:
            bad = copy.deepcopy(row)
            if mode == 'hash': bad['valueSemanticSha256'] = '0' * 64
            elif mode == 'duplicate': bad['changes'] *= 2
            else: bad['changes'][0]['expected'] = 9
            with self.assertRaises(ValueError):
                spawn.transform(doc, bad)

    def test_shipped_preset_increases_actual_groups_and_bounded_reinforcements(self):
        preset = json.loads(spawn.SOURCE.read_text())
        self.assertEqual(preset['requiredPopulationModule'], '0.2.0')
        self.assertEqual(len(preset['caps']), 12)
        self.assertEqual({r['path'] for r in preset['files']}, spawn.TARGETS)
        small = {'factory4_day', 'factory4_night', 'sandbox', 'sandbox_high'}
        change = preset['files'][0]['changes'][0]
        self.assertEqual(change['path'], ['Maps'])
        for name, before in change['expected'].items():
            after = change['value'][name]
            delta = 2 if name in small or name == 'laboratory' else 6
            self.assertEqual(preset['caps'][name]['after'] - preset['caps'][name]['before'], delta)
            self.assertLessEqual(preset['caps'][name]['after'], 44)
            self.assertEqual(after['BotMaxAdd'] - before['BotMaxAdd'], delta)
            self.assertFalse(after['TouchZeroSlotWaves'])
            self.assertEqual(after['RaiderBossChanceFloor'], before['PmcBossChanceFloor'])
            self.assertEqual(after['RaiderBossChanceAdd'], before['PmcBossChanceAdd'])
            if name == 'laboratory':
                self.assertEqual({k:v for k,v in before.items() if k not in {'BotMaxAdd','BotMaxCap','RaiderBossChanceFloor','RaiderBossChanceAdd'}},
                                 {k:v for k,v in after.items() if k not in {'BotMaxAdd','BotMaxCap','RaiderBossChanceFloor','RaiderBossChanceAdd'}})
                continue
            self.assertEqual(after['AssaultWaveMinimumSlotsMin'], 1 if name in small else 2)
            self.assertGreaterEqual(after['PmcReinforcementTimeScale'], 0.65)
            self.assertLessEqual(after['PmcReinforcementTimeScale'], 0.75)
            self.assertLessEqual(after['PmcOpeningEscortMinimum'], 2)
            self.assertLessEqual(after['AssaultWaveSlotsMaxCap'], 5)
            self.assertEqual(after['PmcBossChanceAdd'], 0)
            self.assertEqual(after['AssaultWaveSlotAdd'], before['AssaultWaveSlotAdd'])
            allowed = {'BotMaxAdd','BotMaxCap','AssaultWaveMinimumSlotsMin','AssaultWaveSlotsMaxCap',
                       'PmcReinforcementTimeScale','PmcOpeningEscortMinimum','PmcReinforcementEscortMinimum',
                       'PmcBossChanceFloor','PmcBossChanceAdd','BotSpawnPeriodCheckMaxSeconds','RaiderBossChanceFloor','RaiderBossChanceAdd'}
            self.assertEqual({k:v for k,v in before.items() if k not in allowed},
                             {k:v for k,v in after.items() if k not in allowed})

    def test_prepare_is_read_only_and_rejects_unknown_targets_and_links(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            doc = {'n': 1}
            rows = [self.row(doc, ['n'], 1, 2)]
            for row, name in zip(rows, sorted(spawn.TARGETS)):
                row['path'] = name
                p = root / name
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(json.dumps(doc))
            preset = dict(schemaVersion=1, files=rows)
            prepared = spawn.prepare(root, preset)
            self.assertEqual(len(prepared), 1)
            self.assertTrue(all(json.loads(p.read_text()) == doc for p in prepared))
            guarded = dict(preset, requiredPopulationDllSha256=hashlib.sha256(b'matching module').hexdigest())
            with self.assertRaises(ValueError): spawn.prepare(root, guarded)
            module = root / 'SPT/user/mods/zzz-CodexAiPopulationTuning/Codex.AiPopulationTuning.dll'
            module.write_bytes(b'old module')
            with self.assertRaises(ValueError): spawn.prepare(root, guarded)
            module.write_bytes(b'matching module')
            self.assertEqual(spawn.prepare(root, guarded), prepared)
            bad = copy.deepcopy(preset)
            bad['files'][0]['path'] = 'SPT/user/profiles/player.json'
            with self.assertRaises(ValueError): spawn.prepare(root, bad)
            p = root / rows[0]['path']
            p.unlink()
            outside = root / 'outside.json'
            outside.write_text(json.dumps(doc))
            p.symlink_to(outside)
            with self.assertRaises(ValueError): spawn.prepare(root, preset)
