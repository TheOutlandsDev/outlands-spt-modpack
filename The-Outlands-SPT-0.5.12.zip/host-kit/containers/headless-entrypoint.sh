#!/usr/bin/env bash
set -euo pipefail
exec 9>/run/spt/headless.lock
flock -n 9 || { echo 'Another headless process holds the deployment lock.' >&2; exit 1; }
exec 8>/run/spt/prefix.lock
flock -n 8 || { echo 'The BSG Launcher or another headless process holds the Wine prefix lock.' >&2; exit 1; }
cd "$SPT_RUNTIME"
mapfile -t config < <(python3 - <<'PY'
import json
from pathlib import Path
c = json.loads(Path('HeadlessConfig.json').read_text())
print(c['ProfileId'])
print(c['BackendUrl'])
PY
)
ready=false
for attempt in {1..120}; do
    if curl --silent --fail --insecure --max-time 3 -H 'responsecompressed: 0' \
        "${config[1]}/fika/presence/get" >/dev/null; then
        ready=true
        break
    fi
    sleep 2
done
[[ "$ready" == true ]] || { echo 'Backend did not become ready.' >&2; exit 1; }
# Send the BepInEx log to Docker stdout for Dockhand's live log viewer.
touch BepInEx/LogOutput.log
tail -n 0 -F BepInEx/LogOutput.log &
exec xvfb-run -a -s '-screen 0 1024x768x24 -nolisten tcp' \
    /usr/lib/x86_64-linux-gnu/wine/wine "$SPT_RUNTIME/EscapeFromTarkov.exe" \
    "-token=${config[0]}" "-config={'BackendUrl':'${config[1]}','Version':'live'}" \
    -nographics -batchmode -logfile /tmp/fika-unity.log --enable-console true
