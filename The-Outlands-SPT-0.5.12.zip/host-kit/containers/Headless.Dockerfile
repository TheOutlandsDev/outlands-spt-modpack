FROM ubuntu:26.04
RUN apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
    wine64 xvfb xauth fonts-liberation ca-certificates python3 curl util-linux tzdata \
    libgnutls30t64 libvulkan1 libgl1 libgl1-mesa-dri \
    && mkdir -p /home/outlands && chown 1000:1000 /home/outlands \
    && rm -rf /var/lib/apt/lists/*
COPY headless-entrypoint.sh /usr/local/bin/headless-entrypoint
COPY healthcheck.py /usr/local/bin/spt-healthcheck
RUN chmod 755 /usr/local/bin/headless-entrypoint /usr/local/bin/spt-healthcheck
ENV HOME=/home/outlands WINEARCH=win64 WINEDEBUG=-all TZ=America/New_York \
    WINEDLLOVERRIDES="winhttp=n,b;mscoree,mshtml="
USER 1000:1000
ENTRYPOINT ["/usr/local/bin/headless-entrypoint"]
