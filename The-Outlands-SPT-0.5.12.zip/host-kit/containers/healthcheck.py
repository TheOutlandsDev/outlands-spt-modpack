#!/usr/bin/env python3
import json
import os
import ssl
import sys
import urllib.request
from pathlib import Path

cfg = json.loads((Path(os.environ['SPT_RUNTIME']) / 'HeadlessConfig.json').read_text())
mode = sys.argv[1]
path = '/fika/presence/get' if mode == 'backend' else '/fika/headless/get'
request = urllib.request.Request(cfg['BackendUrl'] + path, headers={'responsecompressed': '0'})
try:
    with urllib.request.urlopen(request, context=ssl._create_unverified_context(), timeout=8) as response:
        data = json.load(response)
    if mode == 'headless':
        host = data.get('headlesses', {}).get(cfg['ProfileId'], {})
        if host.get('WebSocket', {}).get('State') != 2 or host.get('State') not in (1, 2):
            raise RuntimeError('Configured Fika headless is not connected')
except Exception as exc:
    print(str(exc))
    sys.exit(1)
print('Fika backend ready' if mode == 'backend' else 'Fika headless connected')
