#!/usr/bin/env bash
set -euo pipefail
exec 9>/run/spt/backend.lock
flock -n 9 || { echo 'Another backend holds the deployment lock.' >&2; exit 1; }
cd "$SPT_RUNTIME/SPT"
exec /opt/dotnet/dotnet SPT.Server.Linux.dll
