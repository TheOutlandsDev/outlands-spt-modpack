FROM ubuntu:26.04
RUN apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
    ca-certificates libicu78 libssl3t64 zlib1g python3 curl util-linux tzdata \
    && rm -rf /var/lib/apt/lists/*
COPY backend-entrypoint.sh /usr/local/bin/backend-entrypoint
COPY healthcheck.py /usr/local/bin/spt-healthcheck
RUN chmod 755 /usr/local/bin/backend-entrypoint /usr/local/bin/spt-healthcheck
ENV DOTNET_ROOT=/opt/dotnet DOTNET_NOLOGO=1 DOTNET_CLI_TELEMETRY_OPTOUT=1 TZ=America/New_York
USER 1000:1000
ENTRYPOINT ["/usr/local/bin/backend-entrypoint"]
