#!/usr/bin/env bash
# Always use this host's local daemon. sg handles the current desktop session
# until the user next logs in with their new Docker group membership.
set -euo pipefail
export DOCKER_HOST=unix:///var/run/docker.sock
if docker info >/dev/null 2>&1; then
    exec docker "$@"
fi
command_text="$(python3 - "$@" <<'PY'
import shlex
import sys
print(shlex.join(['docker', *sys.argv[1:]]))
PY
)"
exec sg docker -c "$command_text"
