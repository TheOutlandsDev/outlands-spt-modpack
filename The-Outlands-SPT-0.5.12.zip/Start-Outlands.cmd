@echo off
call "%~dp0installer\Start-Outlands.cmd" %*
