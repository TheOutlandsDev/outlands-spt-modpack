# Host your own Outlands setup

You may run your own independent server using the public original code and
installer. You do not need access to the maintained Outlands server to self-host.
Your players still need legitimate compatible game/SPT installations and matching
versions. Downloaded third-party mods retain their individual terms.

## Reconstruct the public baseline

Follow [installer setup](../installer/README.md), choose **SelfHost**, and use its
matching release ZIP, author-download plan and installation lock. Supply your
own compatible SPT 4.0.13 / EFT 0.16.9.40087 base. Keep the game, installer cache,
backups and runtime separate from your public Git checkout.

The public reconstruction is beta. It fetches pinned author/archive files and
builds four WTT DLLs locally. Those declared rebuilt hashes differ from the
maintained server's originals. Host and players must use the same reconstruction
release; do not mix the public client with another host's fixed private baseline.
The public Client mode also contains plugins not permitted by the hosted human
policy. [Recorded comparison](../host-kit/HOSTED-COMPATIBILITY.json) explains why
these are separate baselines. This guide does not certify a fresh shared raid.

## Apply current original Outlands policies

The [host kit](../host-kit/README.md) publishes the newer authored code: remote
quest acceptance/local turn-ins, automatic headless Scav War, fixed role-specific
plugin validation, player dashboard, Play Outlands and scheduled idle maintenance.
Compile against your own matching references, inspect output, and install only
reviewed authored DLLs. Experimental older custom-tools are not enabled by this
step. Configure [the gameplay profile](../host-kit/GAMEPLAY.md) deliberately.

Generate a new human pack and role-specific hash baseline from the actual files
you decide to host. Keep private profiles, personal config, headless-only plugins,
credentials, diagnostics and unrelated runtime assets out of human distribution.
Do not use the archived hosted hashes with your rebuilt DLLs. Give every player
the same reviewed update package and private HTTPS origin.

## Network and ownership

Install Tailscale on your own host and players. Configure the backend listener,
advertised server URL and headless connection for your host's interface/address.
The backend and raid host can be separate machines; each must advertise its own
reachable address. Use your own Fika headless profile and verify ownership with a
legitimate EFT install on the headless machine. Never copy another operator's
profile, API key, Wine prefix, launcher credentials or certificate private key.

Approve the users/devices that may play, and grant access only to the game
backend TCP port, raid host UDP port and read-only player portal that you choose.
The reference deployment uses TCP 6969, UDP 25565 and private HTTPS 8446. Keep
Docker/Dockhand/admin consoles local or operator-only. Review your Tailscale
policy: membership alone is not the intended authorization boundary. This guide
does not change firewall, Tailscale settings, account roles or access grants.

Start the backend, confirm the approved mod/policy load output, then start the
headless client and wait for Ready. Publish your private connection profile only
to approved players. Make profile/config backups before changing versions. Test
local launch, a remote player, asset transfer, a shared Ground Zero raid,
extraction/save persistence, headless relaunch and a second raid.

References: [Fika headless requirements](https://wiki.project-fika.com/advanced-features/headless-client/remote-headless-client),
[Tailscale device approval](https://tailscale.com/docs/features/access-control/device-management/device-approval),
[machine sharing](https://tailscale.com/docs/features/sharing), and
[access controls](https://tailscale.com/docs/features/access-control).
