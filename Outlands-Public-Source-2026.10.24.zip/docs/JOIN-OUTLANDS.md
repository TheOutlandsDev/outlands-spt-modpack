# Join the approved Outlands server

1. Join [Outlands Discord](https://discord.gg/cNqhhUdFW) and ask for SPT access.
   Wait for maintainer approval. A GitHub download, Discord membership or an SPT
   account does not itself approve a device for the hosted server.
2. Supply your own legitimate compatible EFT/SPT installation. The maintained
   baseline is SPT 4.0.13, EFT 0.16.9.40087, Fika Core 2.2.5 and the exact mod set
   supplied by the approved host. Never install SPT over the retail BSG game.
3. Install [Tailscale](https://tailscale.com/download). The maintainer privately
   provides the appropriate machine share/invite and access approval. Do not
   publish invites, auth keys, email addresses, device IDs or access screenshots.
4. Follow the maintainer's matching client-pack instructions. **The public 0.4.0
   installer is not a verified exact client for the current hosted baseline.**
   It contains additional/different plugins. Do not launch it at the hosted server
   and assume that matching EFT/SPT version numbers are sufficient.
5. Download Play Outlands from the public [host kit](../host-kit/README.md) or the
   approved host's private dashboard. Public bootstrap users need the host's
   private `server-profile.json` beside the updater; it is not a password or an
   access grant. Use the host's matching reviewed policy and base-file guidance.
6. Extract the ZIP and run **Install Play Outlands.cmd** once. Select the existing
   modded SPT folder. It creates **Play Outlands** on your Windows desktop, with
   no Administrator rights. Connect Tailscale, close the game/launchers and use
   that shortcut every time. It updates/verifies approved files before opening
   SPT Launcher. Missing profile, wrong base, changed/extra DLLs or failed HTTPS
   checks stop launch. Do not override these checks to join.
7. Use the launcher URL and your own game profile provided by the approved host.
   Human players must not copy headless-only plugins or another machine's Fika
   Force IP / Force Bind IP. For this deployment select **Use Headless Host**.
8. Start with a two-player Ground Zero raid. Verify loading, AI, extraction,
   inventory/quest persistence and another raid after the headless host relaunches.

The game backend, raid UDP and dashboard remain within approved Tailscale access.
Public source/installer publication does not enable public Internet hosting or
router port forwarding. No enrollment keys or live connection endpoints are in
this guide. Send redacted troubleshooting details privately in Discord; public
issues are for reproducible code/install problems without personal data.
