# The Outlands SPT — Build 0.4.0 · SPT 4.0.13

## Join Outlands or host your own

- **Join the maintained Outlands server:** [request approval and follow the player guide](docs/JOIN-OUTLANDS.md). Public downloads do not grant server access. Ask in [Outlands Discord](https://discord.gg/cNqhhUdFW); device access and connection profiles are provided privately.
- **Host independently:** [self-hosting guide](docs/SELF-HOSTING.md), using your own compatible legitimate game installation, server addresses, credentials and player approvals.
- **Current hosting source:** [public host kit](host-kit/README.md), including Play Outlands, remote quests, fixed client matching, Scav War, dashboard and scheduled maintenance.
- **For videos and sharing:** [public distribution policy](docs/PUBLIC-DISTRIBUTION.md) and [recording checklist](docs/VIDEO-GUIDE.md).

**Compatibility notice:** the public 0.4.0 reconstruction and the hosted client snapshot are different baselines. Do not assume this installer is an exact client for the maintained server. Its rebuilt WTT DLLs and additional plugins can fail hosted validation; use the approved host's matching instructions. See [the recorded comparison](host-kit/HOSTED-COMPATIBILITY.json). Independent hosts and their own players can use the same public release together.

The Outlands SPT is a custom Tarkov/Fika experience with Outlands mods, assets and gameplay settings.

**[Download the 0.4.0 installer beta](https://github.com/TheOutlandsDev/outlands-spt-modpack/releases/tag/v0.4.0-source-installer-spt4.0.13)**, extract the ZIP outside your game folder and run **Start-Outlands.cmd**. Choose **Client** for an independent server using that same 0.4.0 release or **SelfHost** for the complete client/server mod trees and assets. Supply your own compatible legitimate EFT/SPT installation.

**No manual mod imports are required.** The installer downloads pinned author files and verified archived originals, then applies the deployed Outlands components and sanitized settings. Four unavailable WTT DLLs are compiled locally from pinned author source using a portable Microsoft compiler. No global development-tool installation is required.

Client reconstruction covers **592 files**; SelfHost covers **2,857 files**. Both modes were reconstructed from empty staging folders using verified cached original downloads, without importing installed mod files. File audits, reproducible build checks and synthetic installation/backup tests passed. **A fresh launch, remote first-connect asset transfer and shared raid still need testing.** The original live setup was reported working by its owner and was not changed by this packaging work.

- [Install and troubleshoot](installer/README.md)
- [Join over Tailscale or self-host](installer/PLAYING.md)
- [Pinned downloads and build recipes](installer/download-plan.json)
- [Source-built DLL provenance](installer/SOURCE-BUILD-PROVENANCE.json), [coverage](installer/BUILD-STATUS.json) and [validation](installer/VALIDATION.json)
- [Release changes](installer/CHANGES.md), [earlier documented changes](docs/CHANGES.md) and [custom Outlands source](custom-tools)
- [Attribution and sharing terms](installer/THIRD-PARTY-NOTICES.md)

Target: **SPT 4.0.13 / EFT 0.16.9.40087 / Fika client 2.2.5 / Fika server author release 2.2.4**. SPT commit: `2891fd41fd07b6150a2192ac0d24adb93eb72862`. The Fika server's `2.0.9` assembly metadata differs from its matching 2.2.4 author package.

The four locally built WTT DLLs have declared new hashes. Armory matches 35 client and 91 server canonical methods; its client references installed SPT reflection 4.0.13 instead of the original 4.0.11. Backport matches all 45 client methods and 78 server raw methods; the final server method matches after proven compiler-temporary normalization. Author source is unchanged apart from recorded Windows checkout line endings. These static comparisons do not establish a multiplayer playtest.

Private server/webapp addresses, Tailscale access, accounts and credentials are configured privately. The public installer ships owner outputs, factual settings and tools. It excludes retail/base SPT files, personal profiles and third-party mod binaries/assets. Downloaded files keep their authors' terms; do not republish the assembled cache/stage or a private companion installer.

The installer preserves the three deployed Outlands components and observed layout. Earlier optional experiments in `custom-tools` are development references and are not activated. The already-disabled Revival artifacts are omitted. Existing technical namespaces are retained for compatibility; [AI-use and provenance](docs/AI-USE.md) records the earlier development process.

Releases 0.2.0 and 0.3.0 are historical partial reconstruction kits. The old 0.1.0-dev.1 ZIP/checksum were withdrawn after the artwork audit. Use the current installer and its matching lock together.

