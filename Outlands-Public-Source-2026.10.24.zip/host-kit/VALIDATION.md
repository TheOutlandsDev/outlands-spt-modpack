# Public host-kit validation scope

Prepared 2026-10-24 from original Outlands authored source. The installed hosted
setup, network permissions, game files and private runtime are unchanged.

Public changes remove live endpoints, add explicit workspace/SDK inputs for
compilation and require an independently supplied Tailscale HTTPS server profile
for the public updater. The example profile has no live server and grants no
access. Original game/plugin API integration and compatibility pins remain.

The upstream hosted version had 90 updater-function checks, 17 shortcut adapter
checks, 36 dashboard/publisher/NarcoNet tests, 25 maintenance tests, 52 admission
checks and 31 fixed-role policy checks. Public-variant reruns and compilation are
recorded in VALIDATION.json. Fixture tests do not operate real player profiles,
install plugins, launch game processes, enroll Tailscale devices or change access.

Public file hashes describe source/metadata and an authored-script bootstrap.
No game, SDK, vendor assembly, third-party payload, profile, private connection
origin, credential or raw host log is included. Dependency assemblies temporarily
used by local compiler fixtures are excluded from the public tree/archive.

A source build or Ready idle headless is not a multiplayer test. Fresh Windows
COM desktop setup, approved-client update, remote asset transfer, two-player
Ground Zero extraction/save persistence and a subsequent raid remain required.
The public 0.4.0 reconstruction has a different baseline from the current hosted
snapshot. Rebuilt self-host DLLs need a regenerated local manifest and CRC policy.
