# Hosted gameplay profile and independent-host choices

The intended starting point is 2–3 players with steady tactical fights. Preserve
this baseline for the first test before increasing bot populations or AI ranges.

- SPT 4.0.13 / EFT 0.16.9.40087, Fika Core 2.2.5 and server author release 2.2.4.
- Use Headless Host, AI amount/difficulty As Online, bosses enabled, Tagged and
  Cursed disabled, and the existing reviewed SAIN/population/LootingBots presets.
- Outlands.ScavWar forces Scav War for headless requests; the UI checkbox may
  remain unticked. Player-hosted raids are outside that policy's scope.
- Headless FikaDynamicAI 1.0.1: 175 m range, High scan rate, Ignore Sniper true,
  60 FPS host cap and Medium network send rate. Do not install FDA on humans.
  Distant Scav War fights can pause outside the activation range.
- Halloween and autumn enabled with zombie infection, including both Ground Zero
  ranges and Factory variants. The authored Halloween helper records the pinned
  configuration changes; review it against your own SPT files while stopped.
  Customs/Interchange use a 50% minimum and Ground Zero level 21+ a 25% minimum;
  startup randomization and event/boss spawns can exceed ordinary bot limits.
- Remote Quests: eligible new quests can be accepted away from inactive traders;
  turn-ins, required items and completion remain local. Shops/services retain
  their normal location restrictions. Install the matching client patch and
  server local-turn-in guard together.
- Ground Zero first for the modded progression. Verify extraction, quest/inventory
  saving, headless restart and a second raid before changing tuning.

These are configuration facts and original policies, not a vendor mod bundle.
Each host needs its own reconstructed dependencies, approved player policy and
fresh multiplayer test. Network, graphics, keybinds and personal settings stay
per-device. Do not distribute headless credentials or another player's save.
