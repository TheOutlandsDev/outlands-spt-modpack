# Play Outlands public bootstrap 1.2.0

See README.txt for players and [host setup](../../README.md) for operators.
This public variant reads `server-profile.json` supplied by the approved host;
it contains schemaVersion 1 and a Tailscale HTTPS origin. The example is inert.
No live address, access key, game file or third-party payload is published.

The existing updater engine/local-policy contract remains 1.1.0. It verifies
27 base files and the exact 351-file hosted snapshot when used with that policy.
That published path/hash policy is an archived compatibility description, not a
claim that the public 0.4.0 reconstruction is identical or already raid-tested.
For an independent host, curate its own baseline and regenerate its policy and
server CRC32C rules from the same exact files. New managed paths need a reviewed
updater/policy release. Do not put personal BepInEx/config into the shared pack.

The installer creates Play Outlands on the current user's desktop, targets
Update and Play.cmd, verifies copied updater bytes and backs up an old shortcut.
It optionally copies a supplied private server profile, refusing to overwrite an
installed profile with one from another folder. No profile is needed to create
the shortcut, but launch fails before downloading anything until one is supplied.

The transactional updater preserves its original size/path/hash/reparse guards,
backups and interrupted-update recovery. Unknown plugin/core/patcher DLLs are
reported rather than deleted. Existing launcher/account settings are preserved.
No admin privileges, GitHub credentials or Tailscale enrollment are requested.

Tests import production functions without invoking the CLI. Shortcut tests use a
WScript.Shell adapter; actual Windows COM and a player update remain pending.
