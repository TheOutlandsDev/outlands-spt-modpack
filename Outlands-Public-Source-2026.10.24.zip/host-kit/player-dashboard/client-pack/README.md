# Curated human-client baseline

The node-01 client pack synchronizes the existing modded human SPT installation.
`inventory.json` is an explicitly reviewed snapshot of filenames, sizes, and
SHA-256 hashes. It contains no vendor payloads or credentials and may be archived
with authored source. New, missing, or changed runtime files require explicit
review and recuration before a pack can be built.

All ordinary files under `runtime/BepInEx/plugins` are managed, including mod
DLLs, assets, mod-local gameplay JSON, and SAIN presets, except `spt/`, `Fika/`,
`FikaDynamicAI/`, `CodexDiagnostics/`, and `.pdb` files. The Fika directory contains
the separately verified core and the headless-only client. The human pack must
never install the headless host, its AI-distance controller, or diagnostics.
`BepInEx/config` is excluded: graphics, keybind, personal UI, and network preferences
remain per-player. Server AI population and other server settings remain on the
headless/backend host. This distinction permits intended preferences while
requiring matching gameplay plugins/assets and their included local defaults.

The policy verifies base files without redistributing them: the game executable,
Assembly-CSharp, every BepInEx core DLL, every patcher DLL, SPT client DLLs, and
Fika.Core. This includes mod-specific MoreBots, UnityToolkit, and WTT patchers;
they must already exist in the matching baseline. A clean SPT installation that
lacks these prerequisites requires the existing approved installation procedure.
The updater does not download EFT, change the live BSG installation, or repair
base dependencies. Its original three compiled compatibility pins remain fixed.

Build and review locally:

```sh
python3 build.py --curate
python3 -m unittest -v test_pack.py
python3 build.py --output /tmp/outlands-client-pack
```

The output contains `outlands-client-pack.zip`, its checksum,
`client-manifest.json`, and `client-policy.json`. The policy is shipped with the
authored Windows updater and approves exact managed paths; the manifest supplies
their exact approved hashes and sizes. Unknown DLLs are reported and block
launch, with no automatic deletion. Limits are 500 managed files, 128 MiB per
file, 512 MiB expanded, and 256 MiB ZIP. ZIP entries use fixed timestamps and
permissions for reproducibility. Every entry is verified after creation.

Sources must be ordinary files without symlinked ancestry, Windows path hazards,
or case collisions. Configs are checked for populated credential fields, and all
payloads are scanned for the locally known Fika API key without logging it. The
builder rejects source drift during packaging. Excluded server data, profiles,
Wine, personal config, and game assets never enter the ZIP.

**Vendor binaries and the full ZIP remain local and on the private Tailscale
download route. Do not upload them to GitHub.** The private GitHub archive may
contain authored updater code and its hash-only policy, source inventory, tests,
and documentation. A live Windows update/join check is still needed to prove the
player's actual installation matches; building this pack does not establish an
in-raid test result.
