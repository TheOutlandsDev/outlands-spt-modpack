# Daily announced maintenance

This host-only Python standard-library worker checks a daily **5:00 AM
America/New_York** schedule. Eastern daylight-saving changes are calculated with
the IANA time zone. A systemd user timer checks every 15 seconds, survives logout
and reboot through the host's existing user linger setting, and needs no Codex
session. It never upgrades SPT, EFT, Fika, third-party mods, or Docker images.

Warnings use Fika's native notification route at 30, 15, 5, and 1 minute. Late
startup skips older warnings instead of sending a burst. A restart without a
previous successful warning is skipped, as is an overdue cycle that never began
draining. There is no automatic catch-up restart after boot. Once draining has
begun, existing raids may finish with **no deadline**; new raids stay paused.
When every raid has finished, a final native notice precedes stopping; a failed
final notice defers the stop. A best-effort completion notice follows readiness.
Its failure cannot turn a verified successful restart into a failure. A delayed
cycle that finishes on a later local day prevents a second restart that day.

The server admission module must first be installed and activated while idle.
Until a fresh acknowledgement reports it loaded, status is `activation_required`
and the worker cannot announce or stop game services. Activation is a separate
operator step; the installer does not restart games.

## Admission and idle checks

The server module reads `runtime/SPT/user/mods/zzz-OutlandsMaintenance/control.json`
and writes `ack.json` beside it. A UUID lease lasts 90 seconds, refreshed every
10 seconds during long maintenance operations and every timer tick while waiting.
Only a fresh acknowledgement with the same UUID, `draining: true`, and an integer
`inFlightAdmissions: 0` permits a restart. An admission that began before the
lease must finish before the worker can stop games. Invalid API data or
acknowledgement fails closed.

The worker queries three fresh direct sources: the expected headless WebSocket
must be connected and READY, its player list empty and current match absent;
its `RequesterSessionID` and `HasNotifiedRequester` fields must both be absent or
null (Fika omits null JSON properties), covering the admission-to-loading gap
before a match is registered;
`POST /fika/location/raids` must return an empty list; presence must report no
player in a raid. Loading, an unrecognized state, a retained match, or unavailable
data defers maintenance. It requires three idle observations over at least 30
seconds, then rechecks immediately before stopping. The admission gate closes
the race between observing idle and a new headless raid starting. This deployment
uses Headless Host. The admission gate does not support direct player-hosted
raids; raw matches/presence still defer maintenance for them, but new direct-host
admissions cannot receive the same race guarantee. Use Headless Host throughout.

## Stop, backup, and recovery

Before the first stop, private durable state records maintenance intent and both
existing container/image IDs. Headless stops first (45-second grace), then the
backend (90-second SIGINT grace). A forced-kill exit or OOM prevents claiming a
clean backup. The worker snapshots stopped profiles and configs, the authored
mod binaries if present, version-lock and Compose metadata into a private
`linux/backups/daily-*/state.tar.gz`, then reads every archive entry back and
checks its hash against the manifest. Game assets, dependencies, and Wine are
excluded. Backups can contain credentials/profile information and stay local.

The **same existing containers** start again: backend healthy first, then
headless. This preserves the Dockhand-adopted Compose stack and recorded image
IDs; it never pulls, builds, recreates containers, calls Compose down, or enables
the old native services. Readiness requires both healthy, SPT 4.0.13, and the
expected headless READY with fresh idle sources. The total start deadline is ten
minutes. The admission lease is released only after readiness; otherwise it
expires safely. Interrupted maintenance is recovered on the following tick by
starting the same recorded containers. Profiles are never automatically rolled
back, and intentionally stopped services do not trigger recovery without this
worker's prior durable intent. Successful recovery remains a failed/interrupted
maintenance result, rather than claiming that its backup/restart completed.

Private state and its single-instance lock live in ignored
`deployment/maintenance/`. Only a bounded status projection lives in
`deployment/public-state/maintenance.json`. Mount that directory read-only for
the dashboard; it contains no socket, control channel, API key, or profiles.

## Review, install, and verify

From this source directory, run isolated tests; they do not call the live server,
send notifications, or stop containers:

```sh
python3 -m unittest -v test_maintenance.py
python3 install.py
```

After reviewing the units, install as node-01, without sudo:

```sh
python3 install.py --install
systemctl --user status node01-spt-maintenance.timer
journalctl --user -u node01-spt-maintenance.service -n 30
```

The existing `containers/docker.sh` pins the local Unix Docker socket and uses
`sg docker` for the older desktop session's group membership. Do not add
`NoNewPrivileges=yes` to this user service while it needs that group transition.
The dashboard never receives the Docker socket. Disable future checks with
`systemctl --user disable --now node01-spt-maintenance.timer`; a running operation
should normally finish, and its durable recovery state must be retained.
