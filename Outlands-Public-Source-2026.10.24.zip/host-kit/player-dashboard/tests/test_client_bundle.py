"""Full-pack publication fixtures. No game services or installed files are changed."""
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

spec = importlib.util.spec_from_file_location("bundle", Path(__file__).parents[1] / "ops/publish-client-bundle.py")
bundle = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bundle)


def legacy_package(extra=None, duplicate=False):
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w") as archive:
        archive.writestr(bundle.CLIENT_FILES[0], b"MZfixture authored plugin")
        archive.writestr(bundle.CLIENT_FILES[1], b"Outlands Remote Quests 1.0.1\nTest instructions\n")
        if extra:
            archive.writestr(extra, b"unexpected")
        if duplicate:
            archive.writestr(bundle.CLIENT_FILES[0], b"MZduplicate")
    return output.getvalue()


class ClientBundleTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / "player-dashboard"
        self.downloads = self.source / "deployment/downloads"
        self.downloads.mkdir(parents=True)
        legacy = legacy_package()
        (self.downloads / bundle.LEGACY_FILES[0]).write_bytes(legacy)
        (self.downloads / bundle.LEGACY_FILES[1]).write_text(bundle.digest(legacy) + "  " + bundle.LEGACY_FILES[0] + "\n")
        (self.source / "client-updater").mkdir()
        for name in bundle.UPDATER_FILES:
            (self.source / "client-updater" / name).write_text("OutlandsClientUpdater/1.1.0 fixture " + name)
        files = {"EscapeFromTarkov.exe": b"game fixture",
            "EscapeFromTarkov_Data/Managed/Assembly-CSharp.dll": b"assembly fixture",
            "BepInEx/core/BepInEx.dll": b"core fixture", "BepInEx/patchers/Patcher.dll": b"patcher fixture",
            "BepInEx/plugins/spt/spt-core.dll": b"spt fixture", "BepInEx/plugins/Fika/Fika.Core.dll": b"fika fixture",
            "BepInEx/plugins/Example/Example.dll": b"MZmanaged fixture",
            "BepInEx/plugins/Example/settings.json": b'{"difficulty":"fixture"}',
            "BepInEx/config/personal.cfg": b"excluded personal preferences"}
        for relative, data in files.items():
            path = self.root / "runtime" / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
        lock = self.root / "linux/version-lock.json"
        lock.parent.mkdir()
        lock.write_text(json.dumps({"versions": {"SPT": "4.0.13", "EFT": "0.16.9.40087", "Fika.Core": "2.2.5"}}))
        self.inventory = bundle.pack.inventory(self.root / "runtime", curated_at="2026-10-23T23:00:00+00:00")
        (self.source / "client-pack").mkdir()
        (self.source / "client-pack/inventory.json").write_bytes(bundle.pack.canonical(self.inventory))
        policy = {"schemaVersion": 1, "updaterVersion": "1.1.0", "channel": "node-01",
            "managedPaths": [row["path"] for row in self.inventory["managedFiles"]],
            "baseFiles": [{"path": row["path"], "sha256": row["sha256"]} for row in self.inventory["baseFiles"]]}
        (self.source / "client-updater/client-policy.json").write_bytes(bundle.pack.canonical(policy))
        pins = {relative: hashlib.sha256((self.root / "runtime" / relative).read_bytes()).hexdigest() for relative in bundle.pack.PINS}
        active = patch.object(bundle.pack, "PINS", pins)
        active.start()
        self.addCleanup(active.stop)

    def snapshot(self):
        return {str(path.relative_to(self.root)): path.read_bytes() for path in self.root.rglob("*") if path.is_file()}

    def test_prepare_is_read_only_and_packages_exact_nine_authored_sources(self):
        before = self.snapshot()
        artifacts, manifest = bundle.prepare(self.root, "2026.10.23.1")
        again, _ = bundle.prepare(self.root, "2026.10.23.1")
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(set(artifacts), set(bundle.PUBLICATION_ORDER))
        self.assertEqual(artifacts, again)
        self.assertEqual(manifest["packages"][0]["id"], "outlands-client-pack")
        self.assertEqual(len(manifest["packages"][0]["files"]), 2)
        self.assertEqual(manifest["packages"][0]["sha256"], bundle.digest(artifacts["outlands-client-pack.zip"]))
        with zipfile.ZipFile(io.BytesIO(artifacts["outlands-client-updater.zip"])) as archive:
            self.assertEqual(set(archive.namelist()), {"Outlands Client Updater/" + name for name in bundle.UPDATER_FILES})
            self.assertFalse(any(name.lower().endswith(".dll") for name in archive.namelist()))
        self.assertEqual(json.loads(artifacts["client-manifest.json"]), manifest)

    def test_policy_mismatch_or_absence_is_rejected_without_copying(self):
        path = self.source / "client-updater/client-policy.json"
        value = json.loads(path.read_text())
        value["managedPaths"].append("BepInEx/plugins/unreviewed.dll")
        path.write_text(json.dumps(value))
        with self.assertRaises(ValueError):
            bundle.prepare(self.root, "2026.10.23.1")
        path.unlink()
        with self.assertRaises(ValueError):
            bundle.prepare(self.root, "2026.10.23.1")
        self.assertFalse(path.exists())

    def test_inventory_and_base_drift_fail_closed(self):
        for relative in ("BepInEx/plugins/Example/Example.dll", "BepInEx/plugins/Fika/Fika.Core.dll"):
            path = self.root / "runtime" / relative
            original = path.read_bytes()
            path.write_bytes(b"changed")
            with self.assertRaises(ValueError):
                bundle.prepare(self.root, "2026.10.23.1")
            path.write_bytes(original)

    def test_known_secret_is_not_publishable_in_updater(self):
        secret = b"opaque-test-key-never-ship"
        (self.source / "deployment/fika_api_key").write_bytes(secret)
        (self.source / "client-updater/README.txt").write_bytes(secret)
        with self.assertRaises(ValueError):
            bundle.prepare(self.root, "2026.10.23.1")

    def test_legacy_malformed_or_checksum_mismatch_is_rejected(self):
        for name in ("EscapeFromTarkov.exe", "../profile.json", "BepInEx/plugins/vendor.dll"):
            with self.assertRaises(ValueError):
                bundle.inspect_package(legacy_package(name))
        with self.assertWarns(UserWarning):
            duplicate = legacy_package(duplicate=True)
        with self.assertRaises(ValueError):
            bundle.inspect_package(duplicate)
        (self.downloads / bundle.LEGACY_FILES[1]).write_text("bad-checksum")
        with self.assertRaises(ValueError):
            bundle.prepare(self.root, "2026.10.23.1")

    def test_publish_stages_first_manifest_last_and_preserves_legacy(self):
        artifacts, _ = bundle.prepare(self.root, "2026.10.23.1")
        legacy = {name: (self.downloads / name).read_bytes() for name in bundle.LEGACY_FILES}
        order = []
        original = bundle.os.replace
        def replace(source, target):
            order.append(Path(target).name)
            return original(source, target)
        with patch.object(bundle.os, "replace", side_effect=replace):
            bundle.publish(self.downloads, artifacts)
        self.assertEqual(order, list(bundle.PUBLICATION_ORDER))
        for name, contents in artifacts.items():
            self.assertEqual((self.downloads / name).read_bytes(), contents)
            self.assertEqual((self.downloads / name).stat().st_mode & 0o777, 0o600)
        self.assertEqual(legacy, {name: (self.downloads / name).read_bytes() for name in bundle.LEGACY_FILES})
        self.assertEqual(set(path.name for path in self.downloads.iterdir()), set(bundle.HTTP_FILES))

    def test_staging_failure_does_not_replace_any_artifact(self):
        artifacts, _ = bundle.prepare(self.root, "2026.10.23.1")
        for name in bundle.PUBLICATION_ORDER:
            (self.downloads / name).write_bytes(b"previous")
        before = {path.name: path.read_bytes() for path in self.downloads.iterdir()}
        original = bundle.tempfile.mkstemp
        calls = 0
        def fail(**kwargs):
            nonlocal calls
            calls += 1
            if calls == 3:
                raise OSError("fixture disk failure")
            return original(**kwargs)
        with patch.object(bundle.tempfile, "mkstemp", side_effect=fail), self.assertRaises(OSError):
            bundle.publish(self.downloads, artifacts)
        self.assertEqual(before, {path.name: path.read_bytes() for path in self.downloads.iterdir()})

    def test_symlinked_download_target_is_refused(self):
        artifacts, _ = bundle.prepare(self.root, "2026.10.23.1")
        outside = self.root / "outside"
        outside.write_bytes(b"do not touch")
        (self.downloads / "client-manifest.json").symlink_to(outside)
        with self.assertRaises(ValueError):
            bundle.publish(self.downloads, artifacts)
        self.assertEqual(outside.read_bytes(), b"do not touch")

    def test_bundle_version_matches_windows_contract(self):
        for version in ("v1.0.0", "test.1", "1", "1.2.3.4.5", "10000.1.1"):
            with self.assertRaises(ValueError):
                bundle.prepare(self.root, version)

    def test_atomic_helper_rejects_symlink_and_replaces_with_private_permissions(self):
        target = self.root / "manifest.json"
        target.write_bytes(b"old")
        bundle.atomic(target, b"new")
        self.assertEqual(target.read_bytes(), b"new")
        self.assertEqual(target.stat().st_mode & 0o777, 0o600)
        target.unlink()
        target.symlink_to(self.downloads / bundle.LEGACY_FILES[0])
        with self.assertRaises(ValueError):
            bundle.atomic(target, b"unsafe")


if __name__ == "__main__":
    unittest.main()
