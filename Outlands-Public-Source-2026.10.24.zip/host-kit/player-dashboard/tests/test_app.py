import importlib.util
import json
import os
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path


spec = importlib.util.spec_from_file_location("dashboard_app", Path(__file__).parents[1] / "app.py")
app = importlib.util.module_from_spec(spec)
spec.loader.exec_module(app)


def fixture():
    return {
        "presence": [{"nickname": "Alice", "level": 12, "activity": 1, "activityStartedTimestamp": 1,
                      "raidInformation": {"location": "bigmap", "side": 0}},
                     {"nickname": "Dedicated", "level": 1, "activity": 0}],
        "players": {"players": [{"profileId": "alice", "nickname": "Alice", "level": 12},
                                {"profileId": "headless", "nickname": "Dedicated", "level": 1},
                                {"profileId": "offline", "nickname": "Stored profile", "level": 99}]},
        "raids": [{"serverId": "headless", "isHeadless": True, "location": "bigmap", "status": 2,
                   "side": 0, "players": {"headless": False, "alice": False}}],
        "headless": {"headlesses": {"headless": {"WebSocket": {"State": 2}, "State": 2,
                                                   "Players": ["alice", "left-earlier", "headless"]}}},
        "headless_names": {"headlessClients": [{"profileId": "headless", "nickname": "Dedicated", "state": 0}]},
        "version": {"Version": "SPT 4.0.13 - 2891fd"}, "dockhand": {"httpStatus": 200}}


def config():
    return {**app.DEFAULTS, "headlessProfileId": "headless"}


def normalize(data):
    sources = {name: {"data": value, "at": 100, "error": None} for name, value in data.items()}
    return app.normalize(config(), sources, 100)


class DashboardTests(unittest.TestCase):
    def test_presence_only_online_and_complete_match_remains_active(self):
        sources = {name: {"data": data, "at": 100, "error": None} for name, data in fixture().items()}
        report = app.normalize(config(), sources, 100)
        self.assertFalse(report["stale"])
        self.assertEqual(report["summary"], {"onlinePlayers": 1, "inRaidPlayers": 1, "activeRaids": 1})
        self.assertEqual([p["nickname"] for p in report["players"]], ["Alice"])
        self.assertEqual(report["raids"][0]["sourceStatus"], 2)
        self.assertEqual(report["raids"][0]["status"], "in_raid")
        self.assertEqual(report["raids"][0]["map"], "Customs")
        self.assertEqual(report["headless"][0]["players"], [{"id": "alice", "nickname": "Alice"}])
        self.assertEqual(report["players"][0]["lastSeen"], app.iso(100))
        self.assertFalse(report["raids"][0]["matchStalePossible"])

    def test_raid_presence_without_match_still_counts_player_in_raid(self):
        data = fixture()
        data["raids"] = []
        report = normalize(data)
        self.assertEqual(report["summary"], {"onlinePlayers": 1, "inRaidPlayers": 1, "activeRaids": 0})
        self.assertEqual(report["players"][0]["status"], "raid")
        self.assertEqual(report["players"][0]["map"], "Customs")
        self.assertIsNone(report["players"][0]["raidId"])

    def test_lingering_match_without_presence_is_not_an_online_raid_player(self):
        data = fixture()
        data["presence"] = []
        report = normalize(data)
        self.assertEqual(report["summary"], {"onlinePlayers": 0, "inRaidPlayers": 0, "activeRaids": 1})
        self.assertEqual(report["players"], [])
        self.assertEqual(len(report["raids"][0]["players"]), 1)
        self.assertTrue(report["raids"][0]["matchStalePossible"])
        self.assertFalse(report["stale"])

    def test_loading_host_and_menu_presence_do_not_claim_in_raid(self):
        data = fixture()
        data["presence"][0]["activity"] = 0
        data["presence"][0]["raidInformation"] = None
        data["raids"][0]["status"] = 0
        data["headless"]["headlesses"]["headless"]["State"] = 1
        report = normalize(data)
        self.assertEqual(report["headless"][0]["state"], "loading")
        self.assertTrue(report["headless"][0]["connected"])
        self.assertEqual(report["players"][0]["status"], "online")
        self.assertEqual(report["summary"]["inRaidPlayers"], 0)
        self.assertIsNone(report["players"][0]["raidId"])
        self.assertIsNone(report["players"][0]["map"])
        self.assertFalse(report["raids"][0]["matchStalePossible"])

    def test_all_nonraid_activities_ignore_lingering_match_membership(self):
        for activity in (0, 2, 3, 4):
            with self.subTest(activity=activity):
                data = fixture()
                data["presence"][0]["activity"] = activity
                report = normalize(data)
                self.assertEqual(report["players"][0]["status"], "online")
                self.assertEqual(report["summary"]["inRaidPlayers"], 0)
                self.assertEqual(len(report["raids"][0]["players"]), 1)

    def test_raw_headless_state_is_authoritative_and_caveat_is_not_global_stale(self):
        for socket, raw_state, expected in ((6, 2, "disconnected"), (2, 0, "starting"), (2, 2, "in_raid")):
            with self.subTest(socket=socket, raw_state=raw_state):
                data = fixture()
                data["headless"]["headlesses"]["headless"]["WebSocket"]["State"] = socket
                data["headless"]["headlesses"]["headless"]["State"] = raw_state
                report = normalize(data)
                self.assertEqual(report["headless"][0]["state"], expected)
                self.assertEqual(report["headless"][0]["connected"], socket == 2)
                self.assertEqual(report["raids"][0]["matchStalePossible"], socket != 2)
                self.assertFalse(report["stale"])
        data = fixture()
        data["headless"]["headlesses"] = {}
        self.assertTrue(normalize(data)["raids"][0]["matchStalePossible"])
        data["raids"] = []
        data["headless"]["headlesses"] = {"headless": {"WebSocket": {"State": 2}, "State": 1}}
        self.assertEqual(normalize(data)["headless"][0]["state"], "ready")

    def test_ambiguous_name_mapping_does_not_establish_online_match_identity(self):
        data = fixture()
        data["players"]["players"].append({"profileId": "other-alice", "nickname": "Alice", "level": 3})
        report = normalize(data)
        self.assertTrue(report["players"][0]["id"].startswith("presence-"))
        self.assertEqual(report["summary"]["inRaidPlayers"], 1)
        self.assertTrue(report["raids"][0]["matchStalePossible"])

    def test_metadata_failure_and_recovery_do_not_fabricate_presence_changes(self):
        data = fixture()
        failing = {"players"}

        def fetch(name):
            if name in failing:
                raise RuntimeError("Upstream unavailable or timed out")
            return data[name]

        dashboard = app.Dashboard(config(), fetch)
        dashboard.poll_once(100)
        self.assertTrue(dashboard.report["stale"])
        self.assertTrue(dashboard.report["players"][0]["id"].startswith("presence-"))
        failing.clear()
        dashboard.poll_once(105)
        self.assertEqual(dashboard.report["players"][0]["id"], "alice")
        self.assertFalse(dashboard.report["stale"])
        self.assertFalse(any(event["type"] in ("join", "leave") for event in dashboard.report["activity"]))
        failing.add("players")
        dashboard.poll_once(110)
        self.assertTrue(dashboard.report["stale"])
        self.assertFalse(any(event["type"] in ("join", "leave") for event in dashboard.report["activity"]))

    def test_headless_identity_recovery_does_not_fabricate_human_leave(self):
        data = fixture()
        failing = {"players", "headless_names"}

        def fetch(name):
            if name in failing:
                raise RuntimeError("Upstream unavailable or timed out")
            return data[name]

        dashboard = app.Dashboard(config(), fetch)
        dashboard.poll_once(100)
        self.assertTrue(dashboard.report["stale"])
        failing.clear()
        dashboard.poll_once(105)
        self.assertEqual([player["nickname"] for player in dashboard.report["players"]], ["Alice"])
        self.assertFalse(dashboard.report["stale"])
        self.assertFalse(any(event["type"] in ("join", "leave") for event in dashboard.report["activity"]))

    def test_failed_sources_preserve_data_and_no_false_leave_events(self):
        data = fixture()
        failing = set()

        def fetch(name):
            if name in failing:
                raise RuntimeError("Bearer secret-do-not-expose")
            return data[name]

        dashboard = app.Dashboard(config(), fetch)
        dashboard.poll_once(100)
        failing.update(("presence", "raids"))
        dashboard.poll_once(105)
        report = dashboard.report
        self.assertTrue(report["stale"])
        self.assertEqual(report["summary"]["onlinePlayers"], 1)
        self.assertEqual(report["summary"]["activeRaids"], 1)
        self.assertEqual(report["players"][0]["lastSeen"], app.iso(100))
        self.assertEqual(report["activity"], [])
        self.assertNotIn("secret-do-not-expose", json.dumps(report))
        failing.clear()
        data["presence"] = []
        data["raids"] = []
        dashboard.poll_once(110)
        self.assertFalse(dashboard.report["stale"])
        self.assertEqual({event["type"] for event in dashboard.report["activity"]}, {"leave", "raid_end"})

    def test_headless_api_ready_does_not_override_closed_raw_socket(self):
        data = fixture()
        data["headless"]["headlesses"]["headless"]["WebSocket"]["State"] = 6
        sources = {name: {"data": value, "at": 100} for name, value in data.items()}
        report = app.normalize(config(), sources, 100)
        self.assertEqual(report["headless"][0]["state"], "disconnected")
        self.assertFalse(report["headless"][0]["connected"])

    def test_http_surface_no_secrets_no_traversal_no_mutations(self):
        data = fixture()
        data["players"]["privateSecret"] = "sensitive-upstream-value"
        dashboard = app.Dashboard(config(), lambda name: data[name])
        dashboard.poll_once()
        server = ThreadingHTTPServer(("127.0.0.1", 0), app.handler_for(dashboard))
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        base = "http://127.0.0.1:" + str(server.server_port)
        try:
            with urllib.request.urlopen(base + "/api/status") as response:
                body = response.read().decode()
                self.assertEqual(response.headers["Cache-Control"], "no-store")
                self.assertIn("default-src 'self'", response.headers["Content-Security-Policy"])
                self.assertNotIn("Access-Control-Allow-Origin", response.headers)
                self.assertNotIn("sensitive-upstream-value", body)
                self.assertNotIn("Authorization", body)
            for path in ("/../app.py", "/%2e%2e/app.py", "/config.json", "/api/profiles"):
                with self.assertRaises(urllib.error.HTTPError) as error:
                    urllib.request.urlopen(base + path)
                self.assertEqual(error.exception.code, 404)
                error.exception.close()
            with self.assertRaises(urllib.error.HTTPError) as error:
                urllib.request.urlopen(urllib.request.Request(base + "/api/status", data=b"{}"))
            self.assertEqual(error.exception.code, 501)
            error.exception.close()
        finally:
            server.shutdown()
            server.server_close()
            thread.join()


class DownloadTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.root = Path(self.directory.name)
        self.zip_path = self.root / "outlands-remote-quests.zip"
        self.checksum_path = self.root / "outlands-remote-quests.sha256"
        self.zip_body = b"PK\x03\x04test client patch"
        self.checksum_body = b"0" * 64 + b"  outlands-remote-quests.zip\n"
        self.zip_path.write_bytes(self.zip_body)
        self.checksum_path.write_bytes(self.checksum_body)
        (self.root / "fika_api_key").write_text("secret-do-not-expose")
        dashboard = app.Dashboard(config())
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), app.handler_for(dashboard, download_root=self.root))
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base = "http://127.0.0.1:" + str(self.server.server_port)

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join()
        self.directory.cleanup()

    def assert_missing(self, path):
        with self.assertRaises(urllib.error.HTTPError) as error:
            urllib.request.urlopen(self.base + path)
        with error.exception as response:
            self.assertEqual(response.code, 404)
            self.assertEqual(response.read(), b'{"error":"Not found"}')

    def test_exact_release_get_and_head_preserve_bytes_and_headers(self):
        for filename, body, mime in ((self.zip_path.name, self.zip_body, "application/zip"),
                                     (self.checksum_path.name, self.checksum_body, "text/plain; charset=utf-8")):
            for method in ("GET", "HEAD"):
                with self.subTest(filename=filename, method=method):
                    request = urllib.request.Request(self.base + "/downloads/" + filename, method=method)
                    with urllib.request.urlopen(request) as response:
                        self.assertEqual(response.status, 200)
                        self.assertEqual(response.headers["Content-Type"], mime)
                        self.assertEqual(response.headers["Content-Length"], str(len(body)))
                        self.assertEqual(response.headers["Cache-Control"], "no-store")
                        self.assertEqual(response.headers["X-Content-Type-Options"], "nosniff")
                        self.assertEqual(response.read(), body if method == "GET" else b"")
                        if filename.endswith(".zip"):
                            self.assertEqual(response.headers["Content-Disposition"], 'attachment; filename="' + filename + '"')

    def test_no_listing_arbitrary_files_traversal_or_mutations(self):
        for path in ("/downloads", "/downloads/", "/downloads/fika_api_key",
                     "/downloads/../fika_api_key", "/downloads/%2e%2e/fika_api_key",
                     "/downloads/%6futlands-remote-quests.zip", "/downloads/outlands-remote-quests.zip/other",
                     "/run/secrets/fika_api_key"):
            with self.subTest(path=path):
                self.assert_missing(path)
        request = urllib.request.Request(self.base + "/downloads/" + self.zip_path.name, data=b"new release")
        with self.assertRaises(urllib.error.HTTPError) as error:
            urllib.request.urlopen(request)
        with error.exception as response:
            self.assertEqual(response.code, 501)
            self.assertNotIn(b"secret-do-not-expose", response.read())
        self.assertEqual(self.zip_path.read_bytes(), self.zip_body)

    def test_missing_oversize_and_symlink_files_are_not_downloaded(self):
        self.zip_path.unlink()
        self.assert_missing("/downloads/" + self.zip_path.name)
        with self.zip_path.open("wb") as release:
            release.truncate(app.DOWNLOADS["/downloads/" + self.zip_path.name][2] + 1)
        self.assert_missing("/downloads/" + self.zip_path.name)
        self.zip_path.unlink()
        self.zip_path.symlink_to(self.root / "fika_api_key")
        self.assert_missing("/downloads/" + self.zip_path.name)
        self.checksum_path.write_bytes(b"x" * 513)
        self.assert_missing("/downloads/" + self.checksum_path.name)
        self.checksum_path.unlink()
        self.assert_missing("/downloads/" + self.checksum_path.name)
        with urllib.request.urlopen(self.base + "/healthz") as response:
            self.assertEqual(response.status, 200)

    def test_new_update_assets_are_exact_and_reflect_atomic_replacements(self):
        assets = {"client-manifest.json": b'{"schemaVersion":1,"bundleVersion":"first"}',
                  "outlands-client-updater.zip": b"PK\x03\x04updater",
                  "outlands-client-pack.zip": b"PK\x03\x04full client pack",
                  "outlands-client-updater.sha256": b"a" * 64 + b"  outlands-client-updater.zip\n"}
        for name, data in assets.items():
            (self.root / name).write_bytes(data)
            with urllib.request.urlopen(self.base + "/downloads/" + name) as response:
                self.assertEqual(response.read(), data)
        replacement = self.root / "new-manifest"
        replacement.write_bytes(b'{"schemaVersion":1,"bundleVersion":"second"}')
        os.replace(replacement, self.root / "client-manifest.json")
        with urllib.request.urlopen(self.base + "/downloads/client-manifest.json") as response:
            self.assertEqual(json.load(response)["bundleVersion"], "second")
        for name in assets:
            (self.root / name).unlink()
            (self.root / name).symlink_to(self.root / "fika_api_key")
            self.assert_missing("/downloads/" + name)

    def test_special_files_are_refused_without_blocking(self):
        path = self.root / "client-manifest.json"
        os.mkfifo(path)
        self.assert_missing("/downloads/client-manifest.json")


class MaintenanceStatusTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.root = Path(self.directory.name)
        self.path = self.root / "maintenance.json"

    def tearDown(self):
        self.directory.cleanup()

    def write(self, **changes):
        data = {"schemaVersion": 1, "state": "draining", "checkedAtUtc": app.iso(1000),
                "message": "Waiting for existing raids to finish.", "nextRestartAtUtc": app.iso(1100),
                "timezone": "America/New_York", "scheduleLabel": "Daily at 5:00 AM Eastern",
                "secret": "do-not-expose", "profiles": [{"inventory": "private"}]}
        data.update(changes)
        self.path.write_text(json.dumps(data))

    def test_projection_includes_only_public_fresh_fields(self):
        self.write()
        result = app.maintenance_status(self.root, 1020)
        self.assertFalse(result["stale"])
        self.assertEqual(result["state"], "draining")
        self.assertEqual(result["message"], "Waiting for existing raids to finish.")
        self.assertNotIn("secret", result)
        self.assertNotIn("profiles", result)
        self.assertNotIn("do-not-expose", json.dumps(result))

    def test_stale_missing_malformed_and_symlink_cannot_claim_readiness(self):
        self.assertTrue(app.maintenance_status(self.root, 1020)["stale"])
        for changes in ({"checkedAtUtc": app.iso(800)}, {"checkedAtUtc": app.iso(1200)},
                        {"checkedAtUtc": "2026-10-23T05:00:00"}, {"schemaVersion": 2}):
            self.write(**changes)
            result = app.maintenance_status(self.root, 1020)
            self.assertTrue(result["stale"])
            self.assertEqual(result["state"], "unavailable")
        self.path.write_text("not json")
        self.assertTrue(app.maintenance_status(self.root, 1020)["stale"])
        self.path.unlink()
        private = self.root / "private"
        private.write_text('{"secret":"do-not-expose"}')
        self.path.symlink_to(private)
        self.assertTrue(app.maintenance_status(self.root, 1020)["stale"])

    def test_http_maintenance_surface_is_read_only(self):
        import time
        self.write(checkedAtUtc=app.iso(time.time()))
        dashboard = app.Dashboard(config())
        server = ThreadingHTTPServer(("127.0.0.1", 0), app.handler_for(dashboard, state_root=self.root))
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        base = "http://127.0.0.1:" + str(server.server_port)
        try:
            with urllib.request.urlopen(base + "/api/maintenance") as response:
                self.assertFalse(json.load(response)["stale"])
            with self.assertRaises(urllib.error.HTTPError) as error:
                urllib.request.urlopen(urllib.request.Request(base + "/api/maintenance", data=b"{}"))
            error.exception.close()
            self.assertEqual(error.exception.code, 501)
            self.assertEqual(json.loads(self.path.read_text())["state"], "draining")
        finally:
            server.shutdown(); server.server_close(); thread.join()


if __name__ == "__main__":
    unittest.main()
