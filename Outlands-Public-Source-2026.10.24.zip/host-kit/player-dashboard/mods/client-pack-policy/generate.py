#!/usr/bin/env python3
"""Generate fixed role CRC32C policy from the exact SHA256-verified client pack inventory."""
import argparse
import json
from pathlib import Path, PurePosixPath

from scan import ROOT, scan

HOST_PATHS = (
    "BepInEx/plugins/Fika/Fika.Headless.dll",
    "BepInEx/plugins/FikaDynamicAI/FikaDynamicAI.dll",
    "BepInEx/plugins/CodexDiagnosticsClient/Codex.Diagnostics.Client.dll",
)
HOST_GUIDS = {"com.fika.headless", "com.lacyway.fda", "codex.diagnostics.client"}
UI_OPTIONAL_ON_HEADLESS = {"outlands.remote-quests"}


def generate(inventory, output, evidence):
    value = json.loads(inventory.read_text())
    if value.get("schemaVersion") != 1 or value.get("packageId") != "outlands-client-pack":
        raise ValueError("Unsupported source inventory.")
    expected = {}
    for row in value["managedFiles"] + value["baseFiles"]:
        relative = row["path"]
        path = PurePosixPath(relative)
        if path.is_absolute() or ".." in path.parts or "\\" in relative:
            raise ValueError("Unsafe inventory path.")
        # Fika reports Chainloader.PluginInfos, not preloader patchers. Some
        # patchers intentionally reuse their companion plugin's BepInPlugin GUID.
        if path.suffix.lower() == ".dll" and path.parts[:2] == ("BepInEx", "plugins"):
            if relative in expected and expected[relative] != row["sha256"]:
                raise ValueError("Conflicting source inventory hash.")
            expected[relative] = row["sha256"]
    runtime = ROOT / "runtime"
    host_paths = [runtime / relative for relative in HOST_PATHS]
    # The diagnostics folder may retain an earlier spelling; identify only the
    # canonical authored diagnostics DLL if that exact default path is absent.
    if not host_paths[2].is_file():
        alternatives = list((runtime / "BepInEx/plugins").glob("**/*Diagnostics*.dll"))
        if len(alternatives) != 1:
            raise ValueError("Canonical host diagnostics DLL is ambiguous or missing.")
        host_paths[2] = alternatives[0]
    paths = [runtime / relative for relative in sorted(expected)]
    rows = scan(paths + host_paths)
    human, host, proof = {}, {}, []
    for row in rows:
        relative = Path(row["path"]).relative_to(runtime).as_posix()
        is_host = Path(row["path"]) in host_paths
        if not is_host and row["sha256"] != expected[relative]:
            raise ValueError("Canonical DLL changed after inventory generation: " + relative)
        for plugin in row["plugins"]:
            guid = plugin["guid"]
            target = host if is_host else human
            if guid in target:
                raise ValueError("Duplicate registered plugin GUID: " + guid)
            target[guid] = row["crc32c"]
            proof.append({"path": relative, **plugin, "sha256": row["sha256"], "crc32c": row["crc32c"],
                          "roleSource": "host" if is_host else "human"})
    if set(host) != HOST_GUIDS or set(human) & HOST_GUIDS:
        raise ValueError("Unsafe host-only plugin separation.")
    if not UI_OPTIONAL_ON_HEADLESS <= set(human):
        raise ValueError("Required human UI plugin is missing.")
    headless_required = {guid: crc for guid, crc in human.items() if guid not in UI_OPTIONAL_ON_HEADLESS}
    headless_required.update(host)
    policy = {"schemaVersion": 1, "sptVersion": "4.0.13", "fikaServerVersion": "2.2.4",
              "human": {"required": dict(sorted(human.items())), "optional": {}},
              "headless": {"required": dict(sorted(headless_required.items())),
                           "optional": {guid: human[guid] for guid in sorted(UI_OPTIONAL_ON_HEADLESS)}}}
    output.write_text(json.dumps(policy, indent=2) + "\n")
    evidence.write_text(json.dumps({"schemaVersion": 1, "sourceInventory": str(inventory),
                                   "plugins": sorted(proof, key=lambda item: (item["roleSource"], item["guid"]))}, indent=2) + "\n")
    print(f"Generated policy: human {len(human)} required; headless {len(headless_required)} required, {len(UI_OPTIONAL_ON_HEADLESS)} optional.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inventory", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--evidence", type=Path, required=True)
    args = parser.parse_args()
    generate(args.inventory.resolve(), args.output.resolve(), args.evidence.resolve())


if __name__ == "__main__":
    main()
