# Fixed client pack policy

This SPT 4.0.13 / Fika Server 2.2.4 mod validates the plugin DLLs that the running
client reports through Fika's normal client check. It compares exact plugin GUIDs
and CRC32C values against an approved immutable policy loaded at backend startup.
No first client can seed or change this baseline. Keep native Fika required and
optional mod lists empty: this callback supplies the authoritative version policy.

The policy classifies headless sessions using Fika's configured headless profile
IDs through `HeadlessHelper.IsHeadlessClient(sessionID)`. A client cannot acquire
that role by reporting a headless plugin or an updater receipt. Humans require
the full approved human plugin set, including Remote Quests and base SPT/Fika
plugins. Headless requires the common set and host-only Headless, Dynamic AI, and
diagnostics plugins. Remote Quests is optional on headless, with its hash checked
if present. Host-only or unknown plugins are forbidden on human clients.

The callback returns native `forbidden`, `missingRequired`, and `hashMismatch`
lists. Existing Fika clients display the installation error and exit after a
mismatch. This is accidental mismatch prevention, not an anti-cheat system:
reports come from the client. The updater independently verifies SHA256 for the
full approved files, including configs, assets, and patchers which Fika does not
report. An updater token alone is insufficient evidence of what a game loaded.

Generate the deployment policy from the same curated client pack inventory:

```sh
python3 player-dashboard/mods/client-pack-policy/generate.py --inventory player-dashboard/client-pack/inventory.json --output /tmp/outlands-client-policy.json --evidence /tmp/outlands-client-plugin-evidence.json
python3 player-dashboard/mods/client-pack-policy/build.py --output /tmp/outlands-client-pack-policy --test
```

`InspectPlugins.cs` reads BepInPlugin metadata through Cecil without executing
game code. It computes CRC32C (Castagnoli, not ordinary CRC32) and SHA256 from
each exact DLL. The generator rejects canonical files whose hashes have changed
since the pack inventory was made, duplicate plugin GUIDs, and unsafe host/human
separation. Native/helper DLLs without a plugin declaration remain covered by
the updater's SHA256 checks. `scan.py --files input.json --output output.json`
accepts a JSON array of absolute DLL paths for independent read-only inspection.

Install only the generated `Outlands.ClientPackPolicy.dll` and generated policy
as `policy.json` inside `runtime/SPT/user/mods/zzz-OutlandsClientPackPolicy/`.
Restart while all raids are finished. Missing, unreadable, duplicate, unsupported,
or incomplete policy data throws during loading instead of silently allowing
unchecked clients. Check startup for:

```text
[Outlands.ClientPackPolicy] Fixed human/headless plugin baselines enforced at client validation; configured headless profile IDs select the host role.
```

Tests exercise the actual Fika callback and native profile-based classifier with
in-memory fixtures, fixed hashes, headless UI exemption, spoofed role claims,
unknown/missing/mismatched plugins, first-client poisoning resistance, fail-closed
loading, and fresh-process mod discovery before Fika loads. They never contact
the live server or load real profiles. No HTTP management endpoint is added.
Policy changes require regeneration and a controlled idle backend restart.

NarcoNet must also exclude host-only plugins from its shared client file list.
Its existing optional plugin and patcher sync paths otherwise offer Dynamic AI
to humans after the updater has verified their files, conflicting with this
policy. `python3 player-dashboard/ops/configure-narconet-client-policy.py` checks
the exclusions without writes. Add `--apply` to back up the exact original YAML
under local `linux/backups/` and insert missing Dynamic AI, diagnostics, and
headless exclusions. Other sync settings and exclusion bytes are preserved.
The helper never restarts services; NarcoNet reads this YAML at backend startup,
so the change takes effect after a controlled idle backend restart. Daily
maintenance backups explicitly include the top-level NarcoNet `config.yaml`.

Source is MIT licensed. Referenced game, SPT, Fika, and Cecil assemblies remain
local under their existing licenses; they are not included in source publication.
