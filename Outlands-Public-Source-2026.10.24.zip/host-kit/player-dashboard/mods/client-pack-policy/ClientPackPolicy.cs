using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using FikaServer.Callbacks;
using FikaServer.Helpers;
using FikaServer.Models.Fika.Routes.Client.Check;
using SPTarkov.DI.Annotations;
using SPTarkov.Reflection.Patching;
using SPTarkov.Server.Core.DI;
using SPTarkov.Server.Core.Models.Common;
using SPTarkov.Server.Core.Models.Spt.Mod;
using SPTarkov.Server.Core.Models.Utils;
using SPTarkov.Server.Core.Utils;

namespace Outlands.ClientPackPolicy;

public record ModMetadata : AbstractModMetadata
{
    public override string ModGuid { get; init; } = "outlands.client-pack-policy";
    public override string Name { get; init; } = "Outlands Client Pack Policy";
    public override string Author { get; init; } = "TheOutlandsDev";
    public override List<string>? Contributors { get; init; }
    public override SemanticVersioning.Version Version { get; init; } = new(1, 0, 0);
    public override SemanticVersioning.Range SptVersion { get; init; } = new("=4.0.13");
    public override List<string>? Incompatibilities { get; init; }
    public override Dictionary<string, SemanticVersioning.Range>? ModDependencies { get; init; } = new() { ["Fika"] = new("=2.2.4") };
    public override string? Url { get; init; }
    public override bool? IsBundleMod { get; init; } = false;
    public override string License { get; init; } = "MIT";
}

public sealed class ValidationResponse
{
    [JsonPropertyName("forbidden")] public List<string> Forbidden { get; } = [];
    [JsonPropertyName("missingRequired")] public List<string> MissingRequired { get; } = [];
    [JsonPropertyName("hashMismatch")] public List<string> HashMismatch { get; } = [];
}

public sealed class ClientPolicy
{
    private static readonly string[] Core = ["com.fika.core", "com.SPT.custom", "com.SPT.singleplayer", "com.SPT.core", "com.SPT.debugging"];
    private static readonly string[] HostOnly = ["com.fika.headless", "com.lacyway.fda", "codex.diagnostics.client"];
    private sealed record Role(Dictionary<string, uint> Required, Dictionary<string, uint> Optional);
    private readonly Role _human;
    private readonly Role _headless;
    private ClientPolicy(Role human, Role headless) { _human = human; _headless = headless; }

    public static ClientPolicy Load(string path)
    {
        var file = new FileInfo(path);
        if (!file.Exists || file.Length > 524288) throw new InvalidDataException("Client pack policy is missing or too large.");
        using var document = JsonDocument.Parse(File.ReadAllBytes(path), new JsonDocumentOptions { MaxDepth = 8 });
        var root = document.RootElement;
        Keys(root, "schemaVersion", "sptVersion", "fikaServerVersion", "human", "headless");
        if (root.GetProperty("schemaVersion").GetInt32() != 1 || root.GetProperty("sptVersion").GetString() != "4.0.13" ||
            root.GetProperty("fikaServerVersion").GetString() != "2.2.4") throw new InvalidDataException("Unsupported client pack policy contract.");
        Role human = ReadRole(root.GetProperty("human")), headless = ReadRole(root.GetProperty("headless"));
        foreach (string guid in Core)
            if (!human.Required.ContainsKey(guid) || !headless.Required.ContainsKey(guid)) throw new InvalidDataException("Required base plugin contract is missing: " + guid);
        foreach (string guid in HostOnly)
            if (human.Required.ContainsKey(guid) || human.Optional.ContainsKey(guid) || !headless.Required.ContainsKey(guid))
                throw new InvalidDataException("Unsafe human/headless role separation: " + guid);
        if (!human.Required.ContainsKey("outlands.remote-quests") || !headless.Optional.ContainsKey("outlands.remote-quests"))
            throw new InvalidDataException("Remote quest role contract is missing.");
        foreach (var item in human.Required.Concat(human.Optional))
            if ((!headless.Required.TryGetValue(item.Key, out uint expected) && !headless.Optional.TryGetValue(item.Key, out expected)) || expected != item.Value)
                throw new InvalidDataException("Human/headless common plugin hashes disagree: " + item.Key);
        return new ClientPolicy(human, headless);
    }

    private static Role ReadRole(JsonElement element)
    {
        Keys(element, "required", "optional");
        var required = ReadHashes(element.GetProperty("required"));
        var optional = ReadHashes(element.GetProperty("optional"));
        if (required.Count == 0 || required.Keys.Any(optional.ContainsKey)) throw new InvalidDataException("Invalid client role plugin lists.");
        return new(required, optional);
    }

    private static Dictionary<string, uint> ReadHashes(JsonElement element)
    {
        if (element.ValueKind != JsonValueKind.Object) throw new InvalidDataException("Plugin hashes must be an object.");
        var result = new Dictionary<string, uint>(StringComparer.Ordinal);
        foreach (var field in element.EnumerateObject())
        {
            if (field.Name.Length == 0 || field.Name.Length > 160 || field.Name.Any(char.IsWhiteSpace) || field.Name.Any(char.IsControl) ||
                !field.Value.TryGetUInt32(out uint hash) || !result.TryAdd(field.Name, hash) || result.Count > 256)
                throw new InvalidDataException("Invalid or duplicate plugin hash contract.");
        }
        return result;
    }

    private static void Keys(JsonElement element, params string[] expected)
    {
        if (element.ValueKind != JsonValueKind.Object) throw new InvalidDataException("Expected a policy object.");
        var seen = new HashSet<string>(StringComparer.Ordinal);
        foreach (var property in element.EnumerateObject())
            if (!expected.Contains(property.Name, StringComparer.Ordinal) || !seen.Add(property.Name)) throw new InvalidDataException("Unexpected or duplicate policy field.");
        if (seen.Count != expected.Length) throw new InvalidDataException("Missing policy field.");
    }

    public ValidationResponse Validate(IReadOnlyDictionary<string, uint>? submitted, bool headless)
    {
        var result = new ValidationResponse();
        if (submitted == null || submitted.Count > 256 || submitted.Keys.Any(guid =>
                string.IsNullOrEmpty(guid) || guid.Length > 160 || guid.Any(char.IsControl) || guid.Any(char.IsWhiteSpace)))
        { result.Forbidden.Add("invalid-client-mod-report"); return result; }
        Role role = headless ? _headless : _human;
        foreach (var item in role.Required)
            if (!submitted.ContainsKey(item.Key)) result.MissingRequired.Add(item.Key);
        foreach (var item in submitted)
        {
            if (!role.Required.TryGetValue(item.Key, out uint expected) && !role.Optional.TryGetValue(item.Key, out expected))
                result.Forbidden.Add(item.Key);
            else if (item.Value != expected) result.HashMismatch.Add(item.Key);
        }
        result.Forbidden.Sort(StringComparer.Ordinal);
        result.MissingRequired.Sort(StringComparer.Ordinal);
        result.HashMismatch.Sort(StringComparer.Ordinal);
        return result;
    }
}

public static class ClientPolicyHooks
{
    private static ClientPolicy? _policy;
    private static Func<MongoId, bool>? _isHeadless;
    private static Func<ValidationResponse, string>? _serialize;
    public static void Configure(ClientPolicy policy, Func<MongoId, bool> isHeadless, Func<ValidationResponse, string> serialize)
    { _policy = policy; _isHeadless = isHeadless; _serialize = serialize; }
    public static string Check(IReadOnlyDictionary<string, uint>? report, MongoId sessionId)
    {
        if (_policy == null || _isHeadless == null || _serialize == null) throw new InvalidOperationException("Client pack policy is not initialized.");
        return _serialize(_policy.Validate(report, _isHeadless(sessionId)));
    }
}

[Injectable(TypePriority = OnLoadOrder.PostSptModLoader + 1000)]
public sealed class ClientPolicyLoader(IServiceProvider provider, ISptLogger<ClientPolicyLoader> logger) : IOnLoad
{
    private readonly ClientCheckPatch _patch = new();
    public Task OnLoad()
    {
        string directory = Path.GetDirectoryName(typeof(ClientPolicyLoader).Assembly.Location)
            ?? throw new InvalidOperationException("Client pack policy mod directory is unavailable.");
        ClientPolicy policy = ClientPolicy.Load(Path.Combine(directory, "policy.json"));
        // Method groups store targets inside System.Delegate. No Fika-typed field
        // or generated async state machine may force Fika loading during mod discovery.
        var headless = (HeadlessHelper?)provider.GetService(typeof(HeadlessHelper))
            ?? throw new InvalidOperationException("Fika headless profile service is unavailable.");
        var responses = (HttpResponseUtil?)provider.GetService(typeof(HttpResponseUtil))
            ?? throw new InvalidOperationException("SPT response helper is unavailable.");
        ClientPolicyHooks.Configure(policy, headless.IsHeadlessClient, responses.NoBody<ValidationResponse>);
        try
        {
            _patch.Enable();
            if (!_patch.IsActive) throw new InvalidOperationException("Client pack policy callback did not activate.");
        }
        catch { if (_patch.IsActive) _patch.Disable(); throw; }
        logger.Success("[Outlands.ClientPackPolicy] Fixed human/headless plugin baselines enforced at client validation; configured headless profile IDs select the host role.");
        return Task.CompletedTask;
    }
}

public sealed class ClientCheckPatch : AbstractPatch
{
    protected override MethodBase GetTargetMethod() => typeof(ClientCallbacks).GetMethod(nameof(ClientCallbacks.HandleCheckMods),
        [typeof(string), typeof(FikaCheckModRequestData), typeof(MongoId)])
        ?? throw new MissingMethodException("Fika 2.2.4 client mod callback was not found.");
    [PatchPrefix]
    public static bool Prefix(FikaCheckModRequestData? __1, MongoId __2, ref ValueTask<string> __result)
    {
        __result = new ValueTask<string>(ClientPolicyHooks.Check(__1, __2));
        return false;
    }
}
