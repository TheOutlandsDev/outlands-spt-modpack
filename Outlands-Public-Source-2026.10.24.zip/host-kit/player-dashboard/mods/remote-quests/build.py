#!/usr/bin/env python3
"""Compile the pinned client UI plugin and verify native call-site contracts locally."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import zipfile

SOURCE = Path(__file__).resolve().parent
ROOT = Path(os.environ.get("OUTLANDS_WORKSPACE", SOURCE.parents[2])).resolve()
PINNED = {
    "EscapeFromTarkov_Data/Managed/Assembly-CSharp.dll": "faef6f0b9f142f9d047495ec3dccfd5d6974ac048368dc7045955cf54b117982",
    "BepInEx/plugins/spt/spt-core.dll": "2b223747ec8e6b84947d96aac4ff3875cbdf6e130f0d1932399cfff8d382c4f3",
    "BepInEx/plugins/Fika/Fika.Core.dll": "6b56f43ac9fe6296537be8fbfe2f78da36da73842540602687ba9baba51f938b",
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    runtime = ROOT / "runtime"
    for relative, expected in PINNED.items():
        if hashlib.sha256((runtime / relative).read_bytes()).hexdigest() != expected:
            raise SystemExit(f"Version contract mismatch: {relative}")
    sdk = Path(os.environ.get("OUTLANDS_DOTNET_SDK", ROOT / ".build/dotnet-sdk-9.0.316"))
    dotnet = Path(os.environ.get("OUTLANDS_DOTNET", ROOT / (".build/dotnet-sdk-9.0.316/dotnet.exe" if os.name == "nt" else ".build/dotnet-sdk-9.0.316/dotnet")))
    csc = sdk / "sdk/9.0.316/Roslyn/bincore/csc.dll"
    environment = dict(os.environ, COMPlus_ReadyToRun="0")
    runtimeconfig = output / "build.runtimeconfig.json"
    runtimeconfig.write_text(json.dumps({"runtimeOptions": {"tfm": "net9.0", "framework": {
        "name": "Microsoft.NETCore.App", "version": "9.0.17"}}}) + "\n")

    def compile_sources(name, sources, references, executable=False, extra=()):
        arguments = ["-nologo", "-langversion:latest", "-deterministic+", "-nostdlib+",
                     f"-target:{'exe' if executable else 'library'}", f"-out:{output / (name + '.dll')}"]
        arguments += [f"-r:{path}" for path in references]
        arguments += list(extra)
        arguments += [str(SOURCE / name) for name in sources]
        response = output / (name + ".rsp")
        response.write_text("\n".join('"' + item + '"' for item in arguments) + "\n")
        subprocess.run([str(dotnet), "exec", "--runtimeconfig", str(runtimeconfig), str(csc),
                        "@" + str(response)], check=True, env=environment)

    managed = runtime / "EscapeFromTarkov_Data/Managed"
    client_refs = [managed / name for name in (
        "mscorlib.dll", "System.dll", "System.Core.dll", "netstandard.dll", "Assembly-CSharp.dll", "UnityEngine.dll",
        "UnityEngine.CoreModule.dll", "UnityEngine.UIModule.dll", "UnityEngine.UI.dll", "Sirenix.Serialization.dll", "Comfort.dll")]
    client_refs += [runtime / "BepInEx/core" / name for name in ("BepInEx.dll", "0Harmony.dll")]
    plugin_sources = ["QuestAccessPolicy.cs", "RemoteQuestsPlugin.cs", "TurnInPatches.cs"]
    compile_sources("Outlands.RemoteQuests", plugin_sources, client_refs)

    net_refs = sorted((sdk / "packs/Microsoft.NETCore.App.Ref/9.0.18/ref/net9.0").glob("*.dll"))
    compile_sources("TestPolicy", ["QuestAccessPolicy.cs", "TestPolicy.cs"], net_refs, executable=True)
    subprocess.run([str(dotnet), "exec", "--runtimeconfig", str(runtimeconfig), str(output / "TestPolicy.dll")], check=True)
    cecil = runtime / "SPT/Mono.Cecil.dll"
    (output / "Mono.Cecil.dll").write_bytes(cecil.read_bytes())
    compile_sources("InspectContracts", ["InspectContracts.cs"], [*net_refs, cecil], executable=True)
    subprocess.run([str(dotnet), "exec", "--runtimeconfig", str(runtimeconfig), str(output / "InspectContracts.dll"),
                    str(managed / "Assembly-CSharp.dll"), str(output / "Outlands.RemoteQuests.dll"),
                    str(runtime / "BepInEx/plugins/Fika/Fika.Core.dll")], check=True)
    # Execute production hooks against UI doubles using the .NET-compatible server
    # Harmony. The shipped plugin above always uses the actual Mono client references.
    # This harness validates patch installation and state transitions, not Unity drawing.
    server = runtime / "SPT"
    for dependency in ("0Harmony.dll", "MonoMod.Backports.dll", "MonoMod.Core.dll",
                       "MonoMod.ILHelpers.dll", "MonoMod.Iced.dll", "MonoMod.RuntimeDetour.dll",
                       "MonoMod.Utils.dll"):
        (output / dependency).write_bytes((server / dependency).read_bytes())
    compile_sources("TestNavigation", [*plugin_sources, "TestUiStubs.cs", "TestNavigation.cs"],
                    [*net_refs, server / "0Harmony.dll"], executable=True)
    subprocess.run([str(dotnet), "exec", "--runtimeconfig", str(runtimeconfig),
                    str(output / "TestNavigation.dll")], check=True)
    compile_sources("TestTurnIns", [*plugin_sources, "TestUiStubs.cs", "TestTurnIns.cs"],
                    [*net_refs, server / "0Harmony.dll"], executable=True)
    subprocess.run([str(dotnet), "exec", "--runtimeconfig", str(runtimeconfig),
                    str(output / "TestTurnIns.dll")], check=True)
    # Fixed ZIP metadata makes the player download reproducible. No game/vendor
    # libraries or test harness dependencies enter the release.
    archive = output / "outlands-remote-quests.zip"
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as package:
        for name, path in (("Outlands.RemoteQuests.dll", output / "Outlands.RemoteQuests.dll"),
                           ("INSTALL.txt", SOURCE / "INSTALL.txt")):
            info = zipfile.ZipInfo("BepInEx/plugins/OutlandsRemoteQuests/" + name, (2026, 10, 23, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            info.create_system = 3
            package.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    zip_sha = hashlib.sha256(archive.read_bytes()).hexdigest()
    (output / "outlands-remote-quests.zip.sha256").write_text(f"{zip_sha}  {archive.name}\n")
    evidence = {"pluginGuid": "outlands.remote-quests", "pluginVersion": "1.0.1", "versions": {
        "SPT": "4.0.13", "EFT": "0.16.9.40087", "Fika.Core": "2.2.5"}, "referenceHashes": PINNED,
        "pluginSha256": hashlib.sha256((output / "Outlands.RemoteQuests.dll").read_bytes()).hexdigest(),
        "policyTestsPassed": True, "nativeCallContractsPassed": True,
        "productionNavigationStubTestsPassed": True, "productionTurnInGuardTestsPassed": True,
        "releaseZipSha256": zip_sha, "gameUiTestPending": True}
    (output / "validation.json").write_text(json.dumps(evidence, indent=2) + "\n")
    print(f"Built and verified {output / 'Outlands.RemoteQuests.dll'}")
    print(f"Player ZIP SHA256: {zip_sha}")


if __name__ == "__main__":
    main()
