# Remote quest access

Outlands Remote Quests 1.0.1 is a small client UI plugin for the pinned SPT
4.0.13 / EFT 0.16.9.40087 / Fika 2.2.5 installation. Its BepInEx GUID is
`outlands.remote-quests`.

Traders who are unlocked and not banned remain selectable when their current
location makes them unavailable. Selecting one opens the normal Tasks screen,
including accepting eligible new quests. Item handovers, quest completion/rewards,
and rerolls require that quest's trader to be active locally. Away traders show
a disabled completion button labelled `Visit trader to turn in`; item handover
and reroll buttons are hidden. Their Trade and Services tabs are hidden until an
available trader is selected. Assortment
refresh and service discovery are skipped at those trader-screen call sites.
Locked traders, level/quest prerequisites, and quest progression are preserved.

The plugin does not change trader profile flags, the global `Available` getter,
server quest data, inventories, rewards, or the trader rotation. Native commerce,
flea, repair, and insurance availability continues to use the original flags.
The navigation exception is restricted to the trader screen and its cards/icons.
Separate turn-in guards check the actual quest's trader against the original
native `Available` flag before any controller mutation. Every concrete native
completion and handover implementation is guarded, including the base used by
Fika's in-raid quest controller. Remote refusals return native failure values,
so item removal, rewards, status changes, and Fika inventory packets do not run.
Missing or malformed trader metadata fails closed. New quest acceptance keeps
its native prerequisite checks and handlers.

## Build and validation

From the game workspace:

```sh
python3 player-dashboard/mods/remote-quests/build.py --output /tmp/outlands-remote-quests-build
```

The build checks the exact local game/SPT/Fika hashes, compiles against the
installed Mono/Unity client libraries, runs a complete eligibility/mode policy
table, and checks the native IL call sites with Mono.Cecil. It also checks that
the compiled plugin contains no trader flag/property writes, checks exact native
mutation methods and UI fields, and verifies Fika delegates to guarded native
actions and sends its packets only after success. The plugin checks
those version/hash contracts again at startup and removes all its own patches
if installation fails. A mismatched or updated client keeps native restrictions.
For assemblies loaded from memory by SPT, an empty assembly `Location` resolves
to the canonical file under BepInEx's game root; that file still receives the
same exact SHA256 verification. It does not search other installations.

The test build also executes the production navigation source against UI doubles
with the installed .NET server Harmony. It checks real Harmony installation,
transpiler replacements, remote commerce guards, locked/banned eligibility, tab
restoration when switching back to a local trader or closing, and unchanged
native availability. A separate harness executes the production turn-in hooks
with real Harmony and isolated controllers: away/local actions, handover inventory
protection, Fika success/failure propagation, missing metadata, UI refresh and
restoration, trader changes between rendering and clicking, and unmodified remote
acceptance. The game plugin uses the Mono client libraries; test doubles
and server libraries are never included in the player download.

The build also produces a deterministic `outlands-remote-quests.zip` and SHA256
file in the output folder using the checked-in `INSTALL.txt`. The ZIP contains
only the authored client DLL and installation text.

The actual Unity UI, accepting a quest, and local turn-ins require a player test. They have not
been proven by the headless client's startup or by these static checks.

## Install and test

Close each Windows game client. Extract the supplied 1.0.1 ZIP into the matching
SPT game folder and replace the 1.0.0 DLL/text when prompted. Keep one plugin DLL,
not additional old copies in other plugin folders. It contains only:

```text
BepInEx/plugins/OutlandsRemoteQuests/Outlands.RemoteQuests.dll
BepInEx/plugins/OutlandsRemoteQuests/INSTALL.txt
```

Restart the game. In Ground Zero, select an unlocked trader who is away. Tasks
should open, available quests should accept normally, and Trade/Services should
be absent. An away trader's item handovers, completion, and rerolls must be blocked.
Visit/select the quest's active local trader and confirm ordinary handovers,
completion, rerolls, and commerce tabs return. Locked
Jaeger/Ref and banned traders must remain locked. Verify an away trader's flea
offers and other commerce remain restricted. The client plugin needs no profile edit
or server restart; the separately deployed server guard supports the same rule.
This client plugin is needed by human players, not the headless
host; Fika must not require it from the headless host in its mod validation list.

To roll back, close the game and remove
`BepInEx/plugins/OutlandsRemoteQuests/Outlands.RemoteQuests.dll`. No profile restoration is
needed because the plugin makes no profile changes.
