// Test-only UI doubles. Never compile or distribute this file in the game plugin.
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;
namespace BepInEx {
 public static class Paths {public static string GameRootPath;}
 [AttributeUsage(AttributeTargets.Class)] public sealed class BepInPlugin:Attribute { public BepInPlugin(string a,string b,string c){} }
 [AttributeUsage(AttributeTargets.Class,AllowMultiple=true)] public sealed class BepInDependency:Attribute { public BepInDependency(string a,string b){} }
 public class BaseUnityPlugin {public TestLogger Logger=new TestLogger();}
 public class TestLogger { public void LogInfo(object o){} public void LogError(object o){} }
 public class PluginInfo {public string Location; public Metadata Metadata=new Metadata();}
 public class Metadata {public Version Version;}
}
namespace BepInEx.Bootstrap {public static class Chainloader {public static Dictionary<string,BepInEx.PluginInfo> PluginInfos=new Dictionary<string,BepInEx.PluginInfo>();}}
namespace UnityEngine {public class GameObject {public bool activeSelf=true;public void SetActive(bool value){activeSelf=value;}}}
namespace EFT {public class Profile {public Dictionary<string,TraderInfo> TradersInfo=new Dictionary<string,TraderInfo>();public bool TryGetTraderInfo(string id,out TraderInfo info)=>TradersInfo.TryGetValue(id,out info);public class TraderInfo {public bool Disabled;public bool Unlocked;public bool Banned;public bool Available=>!Disabled&&Unlocked&&!Banned;}}public enum ESessionMode {Regular}}
public class Tab { public bool Interactable=true;public UnityEngine.GameObject gameObject=new UnityEngine.GameObject();}
public class TraderClass {public EFT.Profile.TraderInfo Info;public int Refreshes;public Task RefreshAssortment(bool a,bool b){Refreshes++;return Task.CompletedTask;}}
public class TraderCard {public bool Selected;[MethodImpl(MethodImplOptions.NoInlining)]public void SetCardState(EFT.Profile.TraderInfo i){Selected=i.Available;} }
namespace EFT.UI {
 public class TraderScreensGroup {
  public enum ETraderMode {Trade,Tasks,Services}
  public TraderClass traderClass;
  public Tab _tradingTab=new Tab(),_servicesTab=new Tab();
  public ServicesScreen Services=new ServicesScreen();public ETraderMode ObservedMode;public int SelectedCount;
  public ETraderMode ETraderMode_0{get;set;}
  [MethodImpl(MethodImplOptions.NoInlining)]public void method_3(ETraderMode m){ObservedMode=m;}
  [MethodImpl(MethodImplOptions.NoInlining)]public void Close(){traderClass=null;}
  [MethodImpl(MethodImplOptions.NoInlining)]public void method_6(TraderClass t){if(!t.Info.Available)return;SelectedCount++;traderClass=t;t.RefreshAssortment(true,false);_servicesTab.Interactable=Services.CheckAvailableServices(t,EFT.ESessionMode.Regular);method_3(ETraderMode_0);}
  [MethodImpl(MethodImplOptions.NoInlining)]public void method_9(){traderClass.RefreshAssortment(false,true);}
 }
 public class ServicesScreen {public int Checks;public bool CheckAvailableServices(TraderClass t,EFT.ESessionMode m){Checks++;return true;}}
 public class TraderPanel {public EFT.Profile.TraderInfo Info;public bool CanOpen;[MethodImpl(MethodImplOptions.NoInlining)]public void method_0(){CanOpen=Info.Available;}}
 public class TraderAvatar {public EFT.Profile.TraderInfo Info;public bool BadgeVisible;[MethodImpl(MethodImplOptions.NoInlining)]public void method_0(){BadgeVisible=Info.Available;}}
}
namespace Comfort.Common {
 public interface IResult {bool Failed{get;}bool Succeed{get;}}
 public class FailedResult:IResult {public string Error;public FailedResult(string error,int code){Error=error;}public bool Failed=>true;public bool Succeed=>false;public Task<IResult> Task=>System.Threading.Tasks.Task.FromResult<IResult>(this);}
 public class SuccessfulResult:IResult {public bool Failed=>false;public bool Succeed=>true;}
}
namespace Diz.LanguageExtensions {public class Error {}}
public class GClass1522:Diz.LanguageExtensions.Error {public string Error;public GClass1522(string error){Error=error;}}
public struct GStruct154<T> {public T Value;public Diz.LanguageExtensions.Error Error;public bool Failed=>Error!=null;public bool Succeeded=>Error==null;public GStruct154(T value){Value=value;Error=null;}public GStruct154(Diz.LanguageExtensions.Error error){Value=default(T);Error=error;}}
public struct GStruct426<T> {public T Conditional;}
public class RawQuestClass {public string TraderId;}
public class QuestClass {public RawQuestClass Template;public EFT.Quests.EQuestStatus QuestStatus;public bool IsChangeAllowed;}
namespace EFT.InventoryLogic {public class Item {public bool Consumed;}}
namespace EFT.Quests {public enum EQuestStatus {Locked,AvailableForStart,Started,AvailableForFinish,Success,Fail,FailRestartable,MarkedAsFailed,Expired,AvailableAfter}public class ConditionItem {}public class ConditionHandoverItem:ConditionItem {public bool Money;}public class ConditionWeaponAssembly:ConditionItem {}public class ConditionProgressChecker {public bool HasItems=true;}}
public abstract class AbstractQuestControllerClass {
 public EFT.Profile Profile;public int Accepts,Finishes,Handovers;
 [MethodImpl(MethodImplOptions.NoInlining)]public virtual Task<Comfort.Common.IResult> AcceptQuest(QuestClass quest,bool network){Accepts++;quest.QuestStatus=EFT.Quests.EQuestStatus.Started;return Task.FromResult<Comfort.Common.IResult>(new Comfort.Common.SuccessfulResult());}
 public abstract Task<GStruct154<GStruct426<QuestClass>>> FinishQuest(QuestClass quest,bool network);
 public abstract Task<Comfort.Common.IResult> HandoverItem(QuestClass quest,EFT.Quests.ConditionItem condition,EFT.InventoryLogic.Item[] items,bool network);
 protected Task<GStruct154<GStruct426<QuestClass>>> Finish(QuestClass quest){Finishes++;quest.QuestStatus=EFT.Quests.EQuestStatus.Success;return Task.FromResult(new GStruct154<GStruct426<QuestClass>>(new GStruct426<QuestClass>{Conditional=quest}));}
 protected Task<Comfort.Common.IResult> Handover(EFT.InventoryLogic.Item[] items){Handovers++;foreach(var i in items)i.Consumed=true;return Task.FromResult<Comfort.Common.IResult>(new Comfort.Common.SuccessfulResult());}
}
public class LocalQuestControllerClass:AbstractQuestControllerClass {
 [MethodImpl(MethodImplOptions.NoInlining)]public override Task<GStruct154<GStruct426<QuestClass>>> FinishQuest(QuestClass quest,bool network)=>Finish(quest);
 [MethodImpl(MethodImplOptions.NoInlining)]public override Task<Comfort.Common.IResult> HandoverItem(QuestClass quest,EFT.Quests.ConditionItem condition,EFT.InventoryLogic.Item[] items,bool network)=>Handover(items);
}
public class GClass4007:LocalQuestControllerClass {
 [MethodImpl(MethodImplOptions.NoInlining)]public override Task<GStruct154<GStruct426<QuestClass>>> FinishQuest(QuestClass quest,bool network)=>Finish(quest);
 [MethodImpl(MethodImplOptions.NoInlining)]public override Task<Comfort.Common.IResult> HandoverItem(QuestClass quest,EFT.Quests.ConditionItem condition,EFT.InventoryLogic.Item[] items,bool network)=>Handover(items);
}
public class GClass4008:AbstractQuestControllerClass {
 [MethodImpl(MethodImplOptions.NoInlining)]public override Task<GStruct154<GStruct426<QuestClass>>> FinishQuest(QuestClass quest,bool network)=>Finish(quest);
 [MethodImpl(MethodImplOptions.NoInlining)]public override Task<Comfort.Common.IResult> HandoverItem(QuestClass quest,EFT.Quests.ConditionItem condition,EFT.InventoryLogic.Item[] items,bool network)=>Handover(items);
}
public class FikaClientQuestController:GClass4007 {
 public int SentPackets;
 public override async Task<GStruct154<GStruct426<QuestClass>>> FinishQuest(QuestClass quest,bool network){var result=await base.FinishQuest(quest,network);if(result.Succeeded)SentPackets++;return result;}
 public override async Task<Comfort.Common.IResult> HandoverItem(QuestClass quest,EFT.Quests.ConditionItem condition,EFT.InventoryLogic.Item[] items,bool network){var result=await base.HandoverItem(quest,condition,items,network);if(result.Succeed)SentPackets++;return result;}
}
namespace EFT.UI {
 public class DefaultUIButton {public bool Interactable=true;public UnityEngine.GameObject gameObject=new UnityEngine.GameObject();public string Header;public void SetHeaderText(string text){Header=text;}}
 public class QuestView {
  public QuestClass _quest;public AbstractQuestControllerClass _questController;public TraderClass _trader;
  public DefaultUIButton _button=new DefaultUIButton(),_buttonReRoll=new DefaultUIButton();public int Rerolls;
  [MethodImpl(MethodImplOptions.NoInlining)]public void ShowButtonBlock(){_button.gameObject.SetActive(true);_button.Interactable=true;_buttonReRoll.gameObject.SetActive(_quest.IsChangeAllowed);if(_quest.QuestStatus==EFT.Quests.EQuestStatus.AvailableForStart)_button.SetHeaderText("Accept");else if(_quest.QuestStatus==EFT.Quests.EQuestStatus.AvailableForFinish)_button.SetHeaderText("Complete");else _button.Interactable=false;}
  [MethodImpl(MethodImplOptions.NoInlining)]public Task StartQuest(QuestClass quest)=>_questController.AcceptQuest(quest,true);
  [MethodImpl(MethodImplOptions.NoInlining)]public async Task FinishQuest(QuestClass quest){await _questController.FinishQuest(quest,true);}
  [MethodImpl(MethodImplOptions.NoInlining)]public Task ShowChangeQuestConfirmation(){Rerolls++;return Task.CompletedTask;}
 }
 public class QuestObjectiveView {
  public QuestClass questClass;public AbstractQuestControllerClass abstractQuestControllerClass;public DefaultUIButton _handoverButton=new DefaultUIButton();public EFT.InventoryLogic.Item[] Items;
  [MethodImpl(MethodImplOptions.NoInlining)]public bool OnConditionChanged(EFT.Quests.ConditionProgressChecker checker){_handoverButton.gameObject.SetActive(checker.HasItems);return checker.HasItems;}
  [MethodImpl(MethodImplOptions.NoInlining)]public async Task method_2(QuestClass quest){await abstractQuestControllerClass.HandoverItem(quest,new EFT.Quests.ConditionItem(),Items,true);}
 }
}
