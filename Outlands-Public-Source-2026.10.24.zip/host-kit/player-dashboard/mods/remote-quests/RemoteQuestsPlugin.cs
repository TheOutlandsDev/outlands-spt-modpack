using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Threading.Tasks;
using BepInEx;
using BepInEx.Bootstrap;
using EFT;
using EFT.UI;
using HarmonyLib;

namespace Outlands.RemoteQuests
{
    [BepInPlugin(PluginGuid, "Outlands Remote Quests", "1.0.1")]
    [BepInDependency("com.SPT.core", "4.0.13")]
    [BepInDependency("com.fika.core", "2.2.5")]
    public sealed class RemoteQuestsPlugin : BaseUnityPlugin
    {
        public const string PluginGuid = "outlands.remote-quests";
        private Harmony _harmony;

        private void Awake()
        {
            _harmony = new Harmony(PluginGuid);
            try
            {
                VerifyPlugin("com.SPT.core", new Version(4, 0, 13),
                    "2b223747ec8e6b84947d96aac4ff3875cbdf6e130f0d1932399cfff8d382c4f3",
                    "BepInEx/plugins/spt/spt-core.dll");
                VerifyPlugin("com.fika.core", new Version(2, 2, 5),
                    "6b56f43ac9fe6296537be8fbfe2f78da36da73842540602687ba9baba51f938b",
                    "BepInEx/plugins/Fika/Fika.Core.dll");
                VerifyHash(ResolveAssemblyPath(typeof(TraderClass).Assembly.Location,
                    "EscapeFromTarkov_Data/Managed/Assembly-CSharp.dll"),
                    "faef6f0b9f142f9d047495ec3dccfd5d6974ac048368dc7045955cf54b117982");
                NavigationPatches.Install(_harmony);
                TurnInPatches.Install(_harmony);
                Logger.LogInfo("Remote quest acceptance active for SPT 4.0.13 / EFT 0.16.9.40087 / Fika 2.2.5. Item handovers, completion, and rerolls require the trader locally. Trader flags and commerce restrictions are unchanged.");
            }
            catch (Exception error)
            {
                _harmony.UnpatchSelf();
                Logger.LogError("Remote Quests disabled: runtime or UI contract mismatch. Native trader restrictions remain active. " + error);
            }
        }

        private static void VerifyPlugin(string guid, Version version, string hash, string relativePath)
        {
            if (!Chainloader.PluginInfos.TryGetValue(guid, out var plugin) ||
                plugin.Metadata.Version != version)
                throw new InvalidOperationException("Expected " + guid + " " + version);
            VerifyHash(ResolveAssemblyPath(plugin.Location, relativePath), hash);
        }

        // SPT's preloader can load Assembly-CSharp from memory, making Location empty.
        // Use its one canonical on-disk file; never search alternate game installations.
        internal static string ResolveAssemblyPath(string location, string relativePath)
        {
            if (!string.IsNullOrWhiteSpace(location)) return location;
            if (string.IsNullOrWhiteSpace(BepInEx.Paths.GameRootPath))
                throw new InvalidOperationException("BepInEx game root is unavailable for assembly verification.");
            return Path.Combine(BepInEx.Paths.GameRootPath, relativePath);
        }

        private static void VerifyHash(string path, string expected)
        {
            using (var stream = File.OpenRead(path))
            using (var hash = SHA256.Create())
            {
                var actual = BitConverter.ToString(hash.ComputeHash(stream)).Replace("-", "").ToLowerInvariant();
                if (actual != expected) throw new InvalidOperationException("Unexpected assembly: " + Path.GetFileName(path));
            }
        }
    }

    internal static class NavigationPatches
    {
        private static readonly MethodInfo NativeAvailable = AccessTools.PropertyGetter(typeof(Profile.TraderInfo), "Available");
        private static readonly MethodInfo NativeRefresh = AccessTools.Method(typeof(TraderClass), "RefreshAssortment", new[] { typeof(bool), typeof(bool) });
        private static readonly MethodInfo NativeServices = AccessTools.Method(typeof(ServicesScreen), "CheckAvailableServices", new[] { typeof(TraderClass), typeof(ESessionMode) });
        private static readonly MethodInfo SelectAvailable = AccessTools.Method(typeof(NavigationPatches), nameof(CanSelect));
        private static readonly MethodInfo GuardRefresh = AccessTools.Method(typeof(NavigationPatches), nameof(RefreshForLocalTrader));
        private static readonly MethodInfo GuardServices = AccessTools.Method(typeof(NavigationPatches), nameof(ServicesForLocalTrader));
        private static readonly FieldInfo TradingTab = AccessTools.Field(typeof(TraderScreensGroup), "_tradingTab");
        private static readonly FieldInfo ServicesTab = AccessTools.Field(typeof(TraderScreensGroup), "_servicesTab");
        private static readonly FieldInfo CurrentTrader = AccessTools.Field(typeof(TraderScreensGroup), "traderClass");
        private static readonly ConditionalWeakTable<TraderScreensGroup, HiddenTabs> Hidden = new ConditionalWeakTable<TraderScreensGroup, HiddenTabs>();

        public static void Install(Harmony harmony)
        {
            foreach (var required in new MemberInfo[] { NativeAvailable, NativeRefresh, NativeServices,
                SelectAvailable, GuardRefresh, GuardServices, TradingTab, ServicesTab, CurrentTrader })
                if (required == null) throw new MissingMemberException("A required trader UI member was not found.");

            // Install the navigation guard before making any additional trader cards selectable.
            harmony.Patch(Require(typeof(TraderScreensGroup), "method_3", typeof(TraderScreensGroup.ETraderMode)),
                prefix: Hook(nameof(ModePrefix)), postfix: Hook(nameof(ModePostfix)));
            harmony.Patch(Require(typeof(TraderScreensGroup), "Close"), prefix: Hook(nameof(ClosePrefix)));
            harmony.Patch(Require(typeof(TraderScreensGroup), "method_6", typeof(TraderClass)),
                transpiler: Hook(nameof(SelectionTranspiler)));
            harmony.Patch(Require(typeof(TraderScreensGroup), "method_9"),
                transpiler: Hook(nameof(RefreshTranspiler)));
            harmony.Patch(Require(typeof(TraderPanel), "method_0"), transpiler: Hook(nameof(AvailabilityTranspiler)));
            harmony.Patch(Require(typeof(TraderCard), "SetCardState", typeof(Profile.TraderInfo)),
                transpiler: Hook(nameof(AvailabilityTranspiler)));
            harmony.Patch(Require(typeof(TraderAvatar), "method_0"), transpiler: Hook(nameof(AvailabilityTranspiler)));
        }

        private static MethodInfo Require(Type type, string name, params Type[] args) =>
            AccessTools.Method(type, name, args) ?? throw new MissingMethodException(type.FullName, name);
        private static HarmonyMethod Hook(string name) => new HarmonyMethod(
            AccessTools.Method(typeof(NavigationPatches), name) ?? throw new MissingMethodException(name));

        internal static bool IsRemote(Profile.TraderInfo info) => info != null &&
            QuestAccessPolicy.IsRemote(info.Disabled, info.Unlocked, info.Banned);
        internal static bool CanSelect(Profile.TraderInfo info) => info != null &&
            QuestAccessPolicy.CanSelect(info.Available, info.Disabled, info.Unlocked, info.Banned);

        // Only the two patched trader-screen call sites use these wrappers.
        internal static Task RefreshForLocalTrader(TraderClass trader, bool force, bool useCache) =>
            IsRemote(trader.Info) ? Task.CompletedTask : trader.RefreshAssortment(force, useCache);
        internal static bool ServicesForLocalTrader(ServicesScreen screen, TraderClass trader, ESessionMode mode) =>
            !IsRemote(trader.Info) && screen.CheckAvailableServices(trader, mode);

        private static IEnumerable<CodeInstruction> AvailabilityTranspiler(IEnumerable<CodeInstruction> instructions) =>
            ReplaceCalls(instructions, new[] { NativeAvailable }, new[] { SelectAvailable });
        private static IEnumerable<CodeInstruction> SelectionTranspiler(IEnumerable<CodeInstruction> instructions) =>
            ReplaceCalls(instructions, new[] { NativeAvailable, NativeRefresh, NativeServices },
                new[] { SelectAvailable, GuardRefresh, GuardServices });
        private static IEnumerable<CodeInstruction> RefreshTranspiler(IEnumerable<CodeInstruction> instructions) =>
            ReplaceCalls(instructions, new[] { NativeRefresh }, new[] { GuardRefresh });

        private static IEnumerable<CodeInstruction> ReplaceCalls(IEnumerable<CodeInstruction> source,
            MethodInfo[] originals, MethodInfo[] replacements)
        {
            var instructions = source.ToList();
            var counts = new int[originals.Length];
            foreach (var instruction in instructions)
                for (var index = 0; index < originals.Length; index++)
                    if (instruction.Calls(originals[index]))
                    {
                        instruction.opcode = OpCodes.Call;
                        instruction.operand = replacements[index];
                        counts[index]++;
                    }
            if (counts.Any(count => count != 1))
                throw new InvalidOperationException("Unexpected trader UI call layout; refusing partial navigation patch.");
            return instructions;
        }

        private static void ModePrefix(TraderScreensGroup __instance, ref TraderScreensGroup.ETraderMode __0)
        {
            if (IsRemote(((TraderClass)CurrentTrader.GetValue(__instance))?.Info))
            {
                __0 = (TraderScreensGroup.ETraderMode)QuestAccessPolicy.SelectMode(true, (int)__0);
                __instance.ETraderMode_0 = __0;
                HideCommerce(__instance);
            }
            else RestoreTabs(__instance, false);
        }

        private static void ModePostfix(TraderScreensGroup __instance)
        {
            if (IsRemote(((TraderClass)CurrentTrader.GetValue(__instance))?.Info)) HideCommerce(__instance);
        }

        private static void ClosePrefix(TraderScreensGroup __instance) => RestoreTabs(__instance, true);

        private static void HideCommerce(TraderScreensGroup group)
        {
            var trading = (Tab)TradingTab.GetValue(group);
            var services = (Tab)ServicesTab.GetValue(group);
            Hidden.GetValue(group, _ => new HiddenTabs(trading, services));
            trading.Interactable = false;
            services.Interactable = false;
            trading.gameObject.SetActive(false);
            services.gameObject.SetActive(false);
        }

        private static void RestoreTabs(TraderScreensGroup group, bool closing)
        {
            if (!Hidden.TryGetValue(group, out var saved)) return;
            var trading = (Tab)TradingTab.GetValue(group);
            var services = (Tab)ServicesTab.GetValue(group);
            trading.gameObject.SetActive(saved.TradingActive);
            services.gameObject.SetActive(saved.ServicesActive);
            trading.Interactable = saved.TradingInteractable;
            // method_6 has already calculated services availability for the newly selected local trader.
            if (closing) services.Interactable = saved.ServicesInteractable;
            Hidden.Remove(group);
        }

        private sealed class HiddenTabs
        {
            internal readonly bool TradingActive, ServicesActive, TradingInteractable, ServicesInteractable;
            internal HiddenTabs(Tab trading, Tab services)
            {
                TradingActive = trading.gameObject.activeSelf;
                ServicesActive = services.gameObject.activeSelf;
                TradingInteractable = trading.Interactable;
                ServicesInteractable = services.Interactable;
            }
        }
    }
}
