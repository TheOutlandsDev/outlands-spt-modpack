#!/usr/bin/env python3
"""Build the maintenance admission gate against the locally pinned SPT/Fika libraries."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

SOURCE = Path(__file__).resolve().parent
ROOT = Path(os.environ.get("OUTLANDS_WORKSPACE", SOURCE.parents[2])).resolve()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--test", action="store_true")
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    core = ROOT / "runtime/SPT"
    fika = core / "user/mods/fika-server"
    sdk = Path(os.environ.get("OUTLANDS_DOTNET_SDK", ROOT / ".build/dotnet-sdk-9.0.316"))
    dotnet = Path(os.environ.get("OUTLANDS_DOTNET", ROOT / (".build/dotnet-sdk-9.0.316/dotnet.exe" if os.name == "nt" else ".build/dotnet-sdk-9.0.316/dotnet")))
    csc = sdk / "sdk/9.0.316/Roslyn/bincore/csc.dll"
    references = sorted((sdk / "packs/Microsoft.NETCore.App.Ref/9.0.18/ref/net9.0").glob("*.dll"))
    if not references or not csc.is_file():
        raise SystemExit("The local .NET 9 reference pack/compiler is unavailable.")
    references += [core / name for name in (
        "SPTarkov.Common.dll", "SPTarkov.DI.dll", "SPTarkov.Reflection.dll",
        "SPTarkov.Server.Core.dll", "SemanticVersioning.dll", "0Harmony.dll",
    )]
    references += [fika / "FikaServer.dll", fika / "FikaShared.dll"]
    for path in references:
        if not path.is_file():
            raise SystemExit(f"Missing local reference: {path}")

    runtimeconfig = output / "Outlands.Maintenance.Tests.runtimeconfig.json"
    runtimeconfig.write_text(json.dumps({"runtimeOptions": {
        "tfm": "net9.0", "frameworks": [
            {"name": "Microsoft.NETCore.App", "version": "9.0.17"},
            {"name": "Microsoft.AspNetCore.App", "version": "9.0.17"},
        ]
    }}) + "\n")
    environment = dict(os.environ, COMPlus_ReadyToRun="0")

    def compile_sources(name, sources, extra=()):
        arguments = ["-nologo", "-nullable:enable", "-langversion:latest", "-deterministic+",
                     f"-target:{'exe' if name.endswith('.Tests') else 'library'}",
                     f"-out:{output / (name + '.dll')}"]
        arguments += [f"-r:{path}" for path in (*references, *extra)]
        arguments += [str(path) for path in sources]
        response = output / (name + ".rsp")
        response.write_text("\n".join('"' + arg + '"' for arg in arguments) + "\n")
        subprocess.run([str(dotnet), "exec", "--runtimeconfig", str(runtimeconfig), str(csc),
                        "@" + str(response)], check=True, env=environment)

    compile_sources("Outlands.Maintenance", [SOURCE / "Maintenance.cs"])
    if args.test:
        compile_sources("Outlands.Maintenance.Tests", [SOURCE / "TestPolicy.cs"],
                        [output / "Outlands.Maintenance.dll"])
        subprocess.run([str(dotnet), str(output / "Outlands.Maintenance.Tests.dll"), str(ROOT)],
                       check=True, env=environment)
    artifact = output / "Outlands.Maintenance.dll"
    print(f"Built {artifact}\nSHA256 {hashlib.sha256(artifact.read_bytes()).hexdigest()}")


if __name__ == "__main__":
    main()
