# Persistent Scav War for the node-01 headless host

This small server mod enables Scav War for every Fika headless raid, without
requiring a Windows client plugin or ticking the checkbox each time. The client
checkbox can still appear unchecked: the host applies this policy after receiving
the request. Unticking it does not disable the host policy.

The patch changes only `StartHeadlessRequest.BotSettings.IsScavWars` immediately
before Fika sends the headless start message. It preserves bot amount, difficulty,
bosses, Tagged and Cursed, event, weather, map, and player settings. Normal Fika
availability checks and the original start method still run.

This policy is pinned to SPT 4.0.13 and Fika Server 2.2.4. Recheck the hook and
models before changing either version. It does not change raids hosted directly
by a player's game client.

Build and run the isolated tests from the SPT workspace:

```sh
python3 player-dashboard/mods/scav-war/build.py --output /tmp/outlands-scav-war --test
```

The build uses the already installed local libraries and .NET compiler; it
downloads nothing. Tests check settings preservation and exercise Harmony on the
real Fika method using an isolated service with no headless clients or sockets.
They do not start a raid or contact the live server.

To install while no raid is running, put only the generated `Outlands.ScavWar.dll`
in `runtime/SPT/user/mods/zzz-OutlandsScavWar/`, then restart the SPT backend. The
startup log must contain:

```text
[Outlands.ScavWar] Scav War is enforced for every Fika headless raid; hook active.
```

The loader checks that Harmony registered the hook. A real raid is still needed
to confirm the resulting AI behavior. To revert, remove that mod directory and
restart the backend while idle. No profiles or game binaries are replaced.

Reference sources:

- [Fika 2.2.4 headless start method](https://github.com/project-fika/Fika-Server-CSharp/blob/v2.2.4/FikaServer/Services/Headless/HeadlessService.cs)
- [Fika 2.2.4 request model](https://github.com/project-fika/Fika-Server-CSharp/blob/v2.2.4/FikaServer/Models/Fika/Routes/Headless/StartHeadlessRequest.cs)
- [SPT 4.0.13 bot settings model](https://github.com/sp-tarkov/server-csharp/blob/4.0.13/Libraries/SPTarkov.Server.Core/Models/Eft/Match/RaidSettings.cs)

Source in this directory is MIT licensed. Game, SPT, and Fika assemblies remain
local and retain their own licenses.
