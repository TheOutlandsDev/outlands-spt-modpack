using System;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Loader;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading.Tasks;
using FikaServer.Models.Fika.Routes.Headless;
using FikaServer.Services.Headless;
using Outlands.ScavWar;
using SPTarkov.Server.Core.Models.Utils;

internal static class Program
{
    private static async Task Main(string[] args)
    {
        string core = Path.Combine(args[0], "runtime", "SPT");
        AssemblyLoadContext.Default.Resolving += (_, name) =>
        {
            foreach (string folder in new[] { core, Path.Combine(core, "user", "mods", "fika-server") })
            {
                string file = Path.Combine(folder, name.Name + ".dll");
                if (File.Exists(file)) return AssemblyLoadContext.Default.LoadFromAssemblyPath(file);
            }
            return null;
        };
        await Run();
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private static async Task Run()
    {
        const string fixture = """
            {"headlessSessionID":"000000000000000000000001","locationId":"factory4_day",
             "metabolismDisabled":false,"botSettings":{"isScavWars":false,"botAmount":"AsOnline"},
             "wavesSettings":{"botAmount":"AsOnline","botDifficulty":"AsOnline","isBosses":true,"isTaggedAndCursed":false},
             "timeAndWeatherSettings":{"hourOfDay":18,"isRandomWeather":true},"useEvent":true}
            """;
        StartHeadlessRequest request = JsonSerializer.Deserialize<StartHeadlessRequest>(fixture)!;
        JsonNode expected = JsonNode.Parse(JsonSerializer.Serialize(request))!;
        expected["botSettings"]!["isScavWars"] = true;
        HeadlessScavWarPatch.Prefix(request);
        Require(JsonNode.DeepEquals(expected, JsonNode.Parse(JsonSerializer.Serialize(request))),
            "Policy must change only isScavWars, preserving every other serialized setting.");
        HeadlessScavWarPatch.Prefix(request);
        Require(JsonNode.DeepEquals(expected, JsonNode.Parse(JsonSerializer.Serialize(request))), "Policy must be idempotent.");

        var missing = new StartHeadlessRequest();
        HeadlessScavWarPatch.Prefix(missing);
        Require(missing.BotSettings?.IsScavWars == true, "Missing botSettings must get Scav War enabled.");
        try
        {
            HeadlessScavWarPatch.Prefix(null!);
            throw new Exception("Null request must fail before changing anything.");
        }
        catch (ArgumentNullException) { }

        var metadata = new ModMetadata();
        Require(metadata.SptVersion.IsSatisfied(new SemanticVersioning.Version(4, 0, 13)), "SPT version pin must accept 4.0.13.");
        Require(!metadata.SptVersion.IsSatisfied(new SemanticVersioning.Version(4, 0, 14)), "SPT version pin must reject a changed version.");
        Require(metadata.ModDependencies!["Fika"].IsSatisfied(new SemanticVersioning.Version(2, 2, 4)), "Fika pin must accept 2.2.4.");
        Require(!metadata.ModDependencies["Fika"].IsSatisfied(new SemanticVersioning.Version(2, 2, 5)), "Fika pin must reject a changed version.");

        // Exercise the real Harmony hook on the real Fika method. This isolated service
        // has no registered headless clients or sockets, so its normal guard returns
        // without starting a raid or accessing the running server.
        var logger = DispatchProxy.Create<ISptLogger<HeadlessService>, NoOpLogger>();
        var service = new HeadlessService(logger, null!, null!, null!, null!);
        var patch = new HeadlessScavWarPatch();
        patch.Enable();
        try
        {
            Require(patch.IsActive, "Harmony hook must be active.");
            var hooked = JsonSerializer.Deserialize<StartHeadlessRequest>(fixture)!;
            string? result = await service.StartHeadlessRaid("000000000000000000000001", "000000000000000000000002", hooked);
            Require(result == null && service.HeadlessClients.Count == 0, "Isolated hook test must not start a raid.");
            Require(hooked.BotSettings?.IsScavWars == true, "Real Fika start method must run the prefix.");
        }
        finally
        {
            patch.Disable();
        }
        Console.WriteLine("PASS: serialized-field preservation, idempotence, missing/null request guards, exact version pins, and real Fika Harmony hook.");
    }

    private static void Require(bool condition, string message)
    {
        if (!condition) throw new Exception(message);
    }
}

public class NoOpLogger : DispatchProxy
{
    protected override object? Invoke(MethodInfo? method, object?[]? args) => null;
}
