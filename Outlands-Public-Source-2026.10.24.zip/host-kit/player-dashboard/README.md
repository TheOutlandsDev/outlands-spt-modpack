# Outlands player dashboard and host policies

Public source companion to the Outlands modpack. See [host-kit setup](../README.md).
The dashboard is read-only; live endpoints, profiles, API keys, runtime files and
backups are supplied locally by each host and are never included here.

Modules: client updater and Play Outlands setup, curated client pack builder,
fixed human/headless plugin validation, persistent headless Scav War, remote
quest acceptance with local turn-ins, and announced idle daily maintenance.

Historical container names and the `node-01` channel identify the original
protocol; they are not an invitation, network address or pre-approved account.
Each independent host creates its own policy/manifest and private server profile.
Do not install the archived hosted human policy on a rebuilt self-host modpack.

The private player package is separate from the public source installer. It must
be distributed only after approval and contains the host's reviewed policy plus
its private server-profile.json. The example profile is not a working server.
