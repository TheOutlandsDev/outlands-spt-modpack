#!/usr/bin/env python3
"""Read-only SPT/Fika dashboard. No game, profile, or Docker mutations."""
import concurrent.futures
import copy
import hashlib
import json
import mimetypes
import os
import re
import ssl
import stat
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


WEB_ROOT = Path(__file__).resolve().parent / "web"
DOWNLOAD_ROOT = Path("/run/downloads")
PUBLIC_STATE_ROOT = Path("/run/public-state")
DOWNLOADS = {"/downloads/outlands-remote-quests.zip": ("outlands-remote-quests.zip", "application/zip", 16 * 1024 * 1024),
             "/downloads/outlands-remote-quests.sha256": ("outlands-remote-quests.sha256", "text/plain; charset=utf-8", 512),
             "/downloads/client-sync-manifest.json": ("client-sync-manifest.json", "application/json; charset=utf-8", 1024 * 1024),
             "/downloads/client-manifest.json": ("client-manifest.json", "application/json; charset=utf-8", 1024 * 1024),
             "/downloads/outlands-client-pack.zip": ("outlands-client-pack.zip", "application/zip", 256 * 1024 * 1024),
             "/downloads/outlands-client-updater.zip": ("outlands-client-updater.zip", "application/zip", 2 * 1024 * 1024),
             "/downloads/outlands-client-updater.sha256": ("outlands-client-updater.sha256", "text/plain; charset=utf-8", 512)}
ACTIVITIES = {0: "In menu", 1: "In raid", 2: "In stash", 3: "In hideout", 4: "Browsing flea"}
MAPS = {"bigmap": "Customs", "factory4_day": "Factory", "factory4_night": "Factory",
        "interchange": "Interchange", "laboratory": "Laboratory", "labyrinth": "Labyrinth",
        "lighthouse": "Lighthouse", "rezervbase": "Reserve", "sandbox": "Ground Zero",
        "sandbox_high": "Ground Zero", "shoreline": "Shoreline", "tarkovstreets": "Streets of Tarkov",
        "woods": "Woods"}
DEFAULTS = {"serverName": "node-01 SPT/Fika", "backendUrl": "https://127.0.0.1:6969",
            "headlessProfileId": "", "managementUrl": "http://127.0.0.1:3000/",
            "pollSeconds": 5, "bind": "127.0.0.1", "port": 3010}


def iso(timestamp=None):
    return datetime.fromtimestamp(time.time() if timestamp is None else timestamp, timezone.utc).isoformat()


def label(value, default="Unknown"):
    return str(value)[:160] if value is not None and str(value) else default


def map_name(value):
    return MAPS.get(str(value).lower(), label(value, "Unknown map")) if value else None


def load_config():
    config = dict(DEFAULTS)
    path = Path(os.environ.get("DASHBOARD_CONFIG_FILE", "/app/config.json"))
    if path.exists():
        config.update(json.loads(path.read_text()))
    parsed = urllib.parse.urlsplit(config["backendUrl"])
    if parsed.scheme not in ("http", "https") or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError("backendUrl must be an HTTP(S) URL without credentials, query, or fragment")
    config["pollSeconds"] = max(1, float(config["pollSeconds"]))
    config["port"] = int(config["port"])
    return config


def normalize(config, sources, now=None):
    """Normalize only reported presence and raid membership; inventories are never online counts."""
    now = time.time() if now is None else now
    errors = [f"{name}: {entry['error']}" for name, entry in sources.items() if entry.get("error")]

    def value(name, fallback):
        return sources.get(name, {}).get("data", fallback)

    presence = value("presence", [])
    metadata = value("players", {}).get("players", [])
    raw_headless = value("headless", {}).get("headlesses", {})
    headless_metadata = value("headless_names", {}).get("headlessClients", [])
    known_headless = set(raw_headless)
    if config.get("headlessProfileId"):
        known_headless.add(config["headlessProfileId"])
    headless_names = {str(row["profileId"]): label(row.get("nickname"), "Headless")
                      for row in headless_metadata if isinstance(row, dict) and row.get("profileId")}
    known_headless.update(headless_names)
    metadata_by_id = {str(row["profileId"]): row for row in metadata
                      if isinstance(row, dict) and row.get("profileId")}
    metadata_by_name = {}
    for ident, row in metadata_by_id.items():
        metadata_by_name.setdefault(row.get("nickname"), []).append((ident, row))
    excluded_names = {row.get("nickname") for ident, row in metadata_by_id.items() if ident in known_headless}
    excluded_names.update(headless_names.values())

    def player_name(ident):
        return label(metadata_by_id.get(ident, {}).get("nickname"), "Player " + ident[:8])

    raids = []
    raid_for_player = {}
    raid_for_headless = {}
    for row in value("raids", []):
        if not isinstance(row, dict) or not row.get("serverId"):
            continue
        ident = str(row["serverId"])
        members = row.get("players", {})
        member_ids = list(members) if isinstance(members, dict) else members if isinstance(members, list) else []
        humans = [{"id": str(pid), "nickname": player_name(str(pid))}
                  for pid in member_ids if str(pid) not in known_headless and not (row.get("isHeadless") and str(pid) == ident)]
        headless_id = ident if row.get("isHeadless") or ident in known_headless else None
        source_status = row.get("status")
        raid = {"id": ident, "map": map_name(row.get("location")),
                # COMPLETE is also the headless loading-completed notification, not match deletion.
                "status": "in_raid" if source_status in (1, 2) else "open",
                "sourceStatus": source_status, "players": humans, "headlessId": headless_id,
                "startedAt": None}
        raids.append(raid)
        for human in humans:
            raid_for_player[human["id"]] = (raid, row)
        if headless_id:
            known_headless.add(headless_id)
            raid_for_headless[headless_id] = raid

    players = []
    seen_names = {}
    presence_name_counts = Counter(row.get("nickname") for row in presence if isinstance(row, dict))
    online_presence_ids = set()
    for row in presence:
        if not isinstance(row, dict):
            continue
        nickname = label(row.get("nickname"))
        matches = metadata_by_name.get(row.get("nickname"), [])
        matched_id, meta = matches[0] if len(matches) == 1 and presence_name_counts[row.get("nickname")] == 1 else (None, {})
        if matched_id in known_headless or nickname in excluded_names:
            continue
        occurrence = seen_names.get(nickname, 0)
        seen_names[nickname] = occurrence + 1
        ident = (matched_id if occurrence == 0 else None) or "presence-" + hashlib.sha256((nickname + ":" + str(occurrence)).encode()).hexdigest()[:16]
        if matched_id is not None:
            online_presence_ids.add(matched_id)
        in_raid = row.get("activity") == 1
        raid, raid_row = raid_for_player.get(ident, (None, {})) if in_raid else (None, {})
        raid_info = row.get("raidInformation") or {}
        side = raid_info.get("side", raid_row.get("side")) if in_raid else None
        players.append({"id": ident, "nickname": nickname, "level": row.get("level", meta.get("level")),
                        "side": {0: "PMC", 1: "SCAV"}.get(side), "status": "raid" if in_raid else "online",
                        "activity": ACTIVITIES.get(row.get("activity"), "Reported online"),
                        "map": (map_name(raid_info.get("location")) or (raid["map"] if raid else None)) if in_raid else None,
                        "raidId": raid["id"] if raid else None,
                        # Observation time of this presence report, never its activity timestamp.
                        "lastSeen": iso(sources["presence"]["at"]) if sources.get("presence", {}).get("at") else None})

    for raid in raids:
        assigned = raw_headless.get(raid["headlessId"], {}) if raid["headlessId"] else None
        missing_host = assigned is not None and assigned.get("WebSocket", {}).get("State") != 2
        unknown_member = any(player["id"] not in online_presence_ids for player in raid["players"])
        raid["matchStalePossible"] = bool(missing_host or unknown_member)

    headless = []
    for ident in sorted(known_headless):
        row = raw_headless.get(ident, {})
        connected = row.get("WebSocket", {}).get("State") == 2
        raid = raid_for_headless.get(ident)
        if not connected:
            state = "disconnected"
        elif row.get("State") == 2:
            state = "in_raid"
        elif row.get("State") == 1:
            state = "loading" if raid else "ready"
        else:
            state = "starting"
        headless.append({"id": ident, "name": headless_names.get(ident, "Headless"), "state": state,
                         "connected": connected, "players": list(raid["players"]) if raid else [],
                         "raidId": raid["id"] if raid else None, "map": raid["map"] if raid else None})

    def fresh(name):
        entry = sources.get(name, {})
        return bool(entry.get("at") is not None and not entry.get("error") and
                    now - entry["at"] <= max(15, float(config["pollSeconds"]) * 3))

    required = ("presence", "players", "raids", "headless", "version", "dockhand", "headless_names")
    stale = any(not fresh(name) for name in required)
    version = value("version", {}).get("Version")
    configured = config.get("headlessProfileId")
    checked_headless = [h for h in headless if h["id"] == configured] if configured else headless
    live_headless = [h for h in checked_headless if h["connected"]]
    healthy_headless = [h for h in live_headless if h["state"] != "starting"]
    services = [
        {"name": "SPT backend", "status": "healthy" if fresh("version") else "degraded" if version else "unknown",
         "detail": label(version, "Version endpoint unavailable")},
        {"name": "Fika headless", "status": "healthy" if fresh("headless") and healthy_headless else "degraded",
         "detail": "Connected; " + ", ".join(h["state"] for h in live_headless) if live_headless else "No ready headless WebSocket reported"},
        {"name": "Dockhand", "status": "healthy" if fresh("dockhand") else "degraded",
         "detail": "Local management HTTP available" if fresh("dockhand") else "Local management HTTP unavailable"},
    ]
    return {"updatedAt": iso(now), "stale": stale,
            "server": {"name": config["serverName"], "version": version, "backendUrl": config["backendUrl"],
                       "uptimeSeconds": None, "managementUrl": config["managementUrl"]},
            "summary": {"onlinePlayers": len(players), "inRaidPlayers": sum(p["status"] == "raid" for p in players), "activeRaids": len(raids)},
            "players": sorted(players, key=lambda player: player["nickname"].casefold()), "raids": raids,
            "headless": headless, "services": services, "activity": [], "errors": errors}


class Dashboard:
    def __init__(self, config, fetcher=None):
        self.config = config
        self.fetcher = fetcher or self.fetch
        self.lock = threading.Lock()
        self.sources = {}
        self.events = []
        self.previous = None
        self.previous_identity_ready = False
        self.raid_started = {}
        self.event_id = 0
        self.stop_event = threading.Event()
        self.report = normalize(config, {})
        self.report_at = time.time()

    def fetch(self, name):
        base = self.config["backendUrl"].rstrip("/")
        paths = {"presence": "/fika/presence/get", "players": "/fika/api/players",
                 "raids": "/fika/location/raids", "headless": "/fika/headless/get",
                 "headless_names": "/fika/api/headless", "version": "/singleplayer/settings/version"}
        url = "http://127.0.0.1:3000/" if name == "dockhand" else base + paths[name]
        headers = {"responsecompressed": "0", "requestcompressed": "0"}
        if name in ("players", "headless_names"):
            try:
                key = Path(os.environ.get("FIKA_API_KEY_FILE", "/run/secrets/fika_api_key")).read_text().strip()
            except OSError:
                raise RuntimeError("API key file unavailable") from None
            if not key:
                raise RuntimeError("API key file is empty")
            headers["Authorization"] = "Bearer " + key
        body = b"{}" if name == "raids" else None
        if body:
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(url, data=body, headers=headers, method="POST" if body else "GET")
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}),
                                             urllib.request.HTTPSHandler(context=ssl._create_unverified_context()))
        try:
            with opener.open(request, timeout=4) as response:
                if name == "dockhand":
                    return {"httpStatus": response.status}
                data = json.loads(response.read(2 * 1024 * 1024 + 1))
        except urllib.error.HTTPError as exc:
            raise RuntimeError(f"HTTP {exc.code}") from None
        except (TimeoutError, urllib.error.URLError):
            raise RuntimeError("Upstream unavailable or timed out") from None
        except (ValueError, UnicodeError):
            raise RuntimeError("Invalid upstream JSON") from None
        expected = list if name in ("presence", "raids") else dict
        if not isinstance(data, expected):
            raise RuntimeError("Unexpected upstream response shape")
        if name in ("players", "headless_names"):
            field = "players" if name == "players" else "headlessClients"
            if not isinstance(data.get(field), list):
                raise RuntimeError("Unexpected upstream response shape")
        if name == "headless" and not isinstance(data.get("headlesses"), dict):
            raise RuntimeError("Unexpected upstream response shape")
        if name == "version" and not isinstance(data.get("Version"), str):
            raise RuntimeError("Unexpected upstream response shape")
        return data

    def poll_once(self, now=None):
        now = time.time() if now is None else now
        names = ("presence", "players", "raids", "headless", "headless_names", "version", "dockhand")
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(names)) as executor:
            futures = {executor.submit(self.fetcher, name): name for name in names}
            for future in concurrent.futures.as_completed(futures):
                name = futures[future]
                try:
                    data = future.result()
                    self.sources[name] = {"data": data, "at": now, "error": None}
                except Exception as exc:
                    # Never expose exception text from arbitrary transports (it may include credentials).
                    allowed = str(exc) if isinstance(exc, RuntimeError) and str(exc) in (
                        "API key file unavailable", "API key file is empty", "Upstream unavailable or timed out",
                        "Invalid upstream JSON", "Unexpected upstream response shape") else "Upstream request failed"
                    if isinstance(exc, RuntimeError) and str(exc).startswith("HTTP ") and str(exc)[5:].isdigit():
                        allowed = str(exc)
                    self.sources.setdefault(name, {})["error"] = allowed
        report = normalize(self.config, self.sources, now)
        self.update_events(report, now)
        report["activity"] = list(reversed(self.events))
        with self.lock:
            self.report = report
            self.report_at = now
        self.previous = copy.deepcopy(report)
        self.previous_identity_ready = all(self.sources.get(name, {}).get("at") is not None
                                           for name in ("players", "headless_names"))

    def update_events(self, report, now):
        def event(kind, message):
            self.event_id += 1
            self.events.append({"id": str(self.event_id), "type": kind, "message": message, "at": iso(now)})

        if self.previous is not None:
            def presence_keys(players):
                # Presence has names, not IDs. Recovering ID metadata must not fabricate joins/leaves.
                occurrences = Counter()
                keyed = {}
                for player in players:
                    name = player["nickname"]
                    keyed[(name, occurrences[name])] = player
                    occurrences[name] += 1
                return keyed

            before = presence_keys(self.previous["players"])
            after = presence_keys(report["players"])
            presence_reliable = (not report["stale"] and self.previous_identity_ready and
                                 all(self.sources.get(name, {}).get("at") is not None and
                                     not self.sources[name].get("error") for name in ("presence", "players")))
            if presence_reliable:
                for ident in after.keys() - before.keys():
                    event("join", after[ident]["nickname"] + " appeared in Fika presence")
                for ident in before.keys() - after.keys():
                    event("leave", before[ident]["nickname"] + " left Fika presence")
                for ident in after.keys() & before.keys():
                    if (after[ident]["activity"], after[ident]["map"]) != (before[ident]["activity"], before[ident]["map"]):
                        event("activity", after[ident]["nickname"] + ": " + after[ident]["activity"])
            old_raids = {r["id"]: r for r in self.previous["raids"]}
            new_raids = {r["id"]: r for r in report["raids"]}
            for ident in new_raids.keys() - old_raids.keys():
                self.raid_started[ident] = iso(now)
                event("raid_start", "Raid session started on " + label(new_raids[ident]["map"], "unknown map"))
            for ident in old_raids.keys() - new_raids.keys():
                self.raid_started.pop(ident, None)
                event("raid_end", "Raid session ended on " + label(old_raids[ident]["map"], "unknown map"))
        for raid in report["raids"]:
            raid["startedAt"] = self.raid_started.get(raid["id"])
        self.events = self.events[-100:]

    def snapshot(self):
        with self.lock:
            report = copy.deepcopy(self.report)
            report_at = self.report_at
        if time.time() - report_at > max(15, self.config["pollSeconds"] * 3):
            report["stale"] = True
        return report

    def run(self):
        while not self.stop_event.is_set():
            started = time.monotonic()
            try:
                self.poll_once()
            except Exception:
                with self.lock:
                    self.report["stale"] = True
                    self.report["errors"] = ["Dashboard normalization failed; retaining last known data"]
            self.stop_event.wait(max(0.1, self.config["pollSeconds"] - (time.monotonic() - started)))


def bounded_file(path, limit):
    """Read one ordinary file without following a final symlink, including during replacement."""
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
    fd = os.open(path, flags)
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_size > limit:
            raise ValueError("Not an eligible public file")
        body = stream.read(limit + 1)
    if len(body) > limit:
        raise ValueError("Public file exceeds limit")
    return body


def maintenance_status(state_root=PUBLIC_STATE_ROOT, now=None):
    """Only a bounded public projection crosses from the maintenance worker to HTTP."""
    now = time.time() if now is None else now
    result = {"schemaVersion": 1, "state": "unavailable", "stale": True,
              "message": "Maintenance status is not available.", "timezone": "America/New_York"}
    try:
        data = json.loads(bounded_file(state_root / "maintenance.json", 16 * 1024))
        if not isinstance(data, dict) or data.get("schemaVersion") != 1:
            return result
        stamp = datetime.fromisoformat(data["checkedAtUtc"].replace("Z", "+00:00"))
        if stamp.tzinfo is None or not -30 <= now - stamp.timestamp() <= 150:
            return result
        for field in ("state", "message", "scheduleLabel", "lastResult"):
            if isinstance(data.get(field), str):
                result[field] = data[field][:300 if field == "message" else 120]
        for field in ("nextRestartAtUtc", "lastRestartAtUtc", "checkedAtUtc"):
            if isinstance(data.get(field), str):
                date = datetime.fromisoformat(data[field].replace("Z", "+00:00"))
                if date.tzinfo is not None:
                    result[field] = date.astimezone(timezone.utc).isoformat()
        result["stale"] = False
    except (OSError, ValueError, TypeError, KeyError, AttributeError):
        pass
    return result


def content_calendar(state_root=PUBLIC_STATE_ROOT, now=None):
    import content_status
    now = time.time() if now is None else now
    try:
        data = json.loads(bounded_file(state_root / "content.json", 16 * 1024))
        if not isinstance(data, dict) or data.get("available") is not True or data.get("schemaVersion") != 1:
            return content_status.unavailable()
        stamp = content_status.timestamp(data["checkedAtUtc"])
        if not -30 <= now - stamp.timestamp() <= 150:
            return content_status.unavailable()
        # Revalidate the projected fields and discard any unexpected additions.
        def plan(d):
            return {"Day": d["date"], "Theme": d["theme"], "Hotspots": d["hotspots"]}
        raw = {"schemaVersion": 1, "timezone": data["timezone"], "rolloverHour": data["rolloverHour"],
               "activeSinceUtc": data["activeSinceUtc"], "day": plan(data["day"]), "maps": data["maps"],
               "nextSevenDays": [plan(d) for d in data["nextSevenDays"]]}
        return content_status.sanitize(raw, datetime.fromtimestamp(now, timezone.utc))
    except (OSError, ValueError, TypeError, KeyError, AttributeError):
        return content_status.unavailable()


def handler_for(dashboard, web_root=WEB_ROOT, download_root=DOWNLOAD_ROOT, state_root=PUBLIC_STATE_ROOT):
    class Handler(BaseHTTPRequestHandler):
        def response_headers(self, status, length, mime, cache="no-store", headers=None):
            self.send_response(status)
            self.send_header("Content-Type", mime)
            self.send_header("Content-Length", str(length))
            self.send_header("Cache-Control", cache)
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
            self.send_header("Referrer-Policy", "no-referrer")
            for key, value in (headers or {}).items():
                self.send_header(key, value)
            self.end_headers()

        def send(self, status, body, mime="application/json; charset=utf-8", cache="no-store", headers=None):
            self.response_headers(status, len(body), mime, cache, headers)
            if self.command != "HEAD":
                self.wfile.write(body)

        def download(self, candidate, filename, mime, limit):
            try:
                fd = os.open(candidate, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0))
                stream = os.fdopen(fd, "rb")
                info = os.fstat(stream.fileno())
                if not stat.S_ISREG(info.st_mode) or info.st_size > limit:
                    stream.close()
                    return self.send(404, b'{"error":"Not found"}')
            except OSError:
                return self.send(404, b'{"error":"Not found"}')
            # A descriptor pins one release across an atomic replacement. Large
            # client packs stream in bounded chunks without occupying pack-size RAM.
            with stream:
                headers = {"Content-Disposition": 'attachment; filename="' + filename + '"'} if mime == "application/zip" else None
                self.response_headers(200, info.st_size, mime, headers=headers)
                if self.command == "HEAD":
                    return
                remaining = info.st_size
                try:
                    while remaining:
                        data = stream.read(min(64 * 1024, remaining))
                        if not data:
                            break
                        self.wfile.write(data)
                        remaining -= len(data)
                except (BrokenPipeError, ConnectionResetError):
                    pass

        def do_GET(self):
            path = urllib.parse.urlsplit(self.path).path
            if path == "/api/status":
                return self.send(200, json.dumps(dashboard.snapshot(), ensure_ascii=False).encode())
            if path == "/healthz":
                return self.send(200, json.dumps({"status": "ok", "stale": dashboard.snapshot()["stale"]}).encode())
            if path == "/api/content":
                return self.send(200, json.dumps(content_calendar(state_root)).encode())
            if path == "/api/maintenance":
                return self.send(200, json.dumps(maintenance_status(state_root)).encode())
            if path in DOWNLOADS:
                filename, mime, limit = DOWNLOADS[path]
                # The directory is read-only; only the listed public assets route.
                return self.download(download_root / filename, filename, mime, limit)
            # Only content-addressed published client blobs can route. No arbitrary
            # filenames, subdirectories, decoding, profiles, or runtime paths.
            match = re.fullmatch(r"/downloads/client-file-([0-9a-f]{64})\.bin", path)
            if match:
                name = "client-file-" + match[1] + ".bin"
                return self.download(download_root / name, name, "application/octet-stream", 128 * 1024 * 1024)
            # Explicit public assets only; config, Python source, and secret paths never route here.
            allowed = {"/": "index.html", "/index.html": "index.html", "/app.js": "app.js",
                       "/style.css": "style.css", "/styles.css": "styles.css", "/favicon.svg": "favicon.svg"}
            asset = allowed.get(path)
            candidate = (web_root / asset).resolve() if asset else None
            if candidate is None or not candidate.is_relative_to(web_root.resolve()) or not candidate.is_file():
                return self.send(404, b'{"error":"Not found"}')
            return self.send(200, candidate.read_bytes(), mimetypes.guess_type(asset)[0] or "application/octet-stream", "no-cache")

        def do_HEAD(self):
            return self.do_GET()

        def log_message(self, *_args):
            pass

    return Handler


def main():
    config = load_config()
    dashboard = Dashboard(config)
    poller = threading.Thread(target=dashboard.run, daemon=True)
    poller.start()
    servers = [ThreadingHTTPServer((address.strip(), config["port"]), handler_for(dashboard))
               for address in str(config["bind"]).split(",") if address.strip()]
    if not servers:
        raise ValueError("No bind addresses configured")
    for server in servers[:-1]:
        threading.Thread(target=server.serve_forever, daemon=True).start()
    try:
        servers[-1].serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        dashboard.stop_event.set()
        for server in servers:
            server.server_close()


if __name__ == "__main__":
    main()
