#requires -Version 5.1
# Exercise the actual sync and updater orchestration on disposable installations.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$tokens = $null; $errors = $null
$source = Join-Path $PSScriptRoot 'Update-Outlands.ps1'
$ast = [Management.Automation.Language.Parser]::ParseFile($source, [ref]$tokens, [ref]$errors)
if ($errors.Count) { throw ($errors | Out-String) }
foreach ($statement in $ast.EndBlock.Statements) {
    if ($statement -is [Management.Automation.Language.FunctionDefinitionAst] -or
        ($statement -is [Management.Automation.Language.AssignmentStatementAst] -and $statement.Left.Extent.Text.StartsWith('$script:'))) {
        . ([scriptblock]::Create($statement.Extent.Text))
    }
}
$checks = 0
function Check([bool]$Ok, [string]$Label) { if (-not $Ok) { throw $Label }; $script:checks++ }
function Reject([scriptblock]$Action, [string]$Label) {
    $failed = $false
    try { & $Action | Out-Null } catch { $failed = $true }
    Check $failed $Label
}
function Clone($Value) { return ($Value | ConvertTo-Json -Depth 12 | ConvertFrom-Json) }
# Only Windows path construction, platform discovery and process launching are
# adapted on Linux. Hashing, network selection, writes, journal and rollback use
# the production functions. Windows filesystem/COM behavior needs a PC test.
if ($env:OS -ne 'Windows_NT') {
    function Get-ChildPath([string]$Root, [string]$Relative) {
        Assert-SafeRelative $Relative
        return [IO.Path]::GetFullPath((Join-Path $Root $Relative))
    }
    $invokeText = (Get-Command Invoke-Updater).Definition.Replace("`$env:OS -eq 'Windows_NT'", '$true')
    Set-Item Function:Invoke-Updater ([scriptblock]::Create($invokeText))
}
$fixture = Join-Path ([IO.Path]::GetTempPath()) ('outlands-sync-fixture-' + [Guid]::NewGuid().ToString('N'))
[IO.Directory]::CreateDirectory($fixture) | Out-Null
$script:closed = $true; $script:launches = 0; $script:requests = @(); $script:remote = @{}; $script:failInstall = $false
function Assert-GameClosed { Assert-True $script:closed 'Fixture game is running.' }
function Start-Process { param($FilePath, $WorkingDirectory) $script:launches++; Check ($FilePath -eq (Join-Path $fixture 'SPT.Launcher.exe')) 'Exact existing launcher selected.' }
function Get-TrustedBytes([string]$RelativePath, [long]$Maximum) {
    $script:requests += $RelativePath
    Assert-True $script:remote.ContainsKey($RelativePath) ('Unexpected transfer: ' + $RelativePath)
    $data = $script:remote[$RelativePath]
    Assert-True ($data.LongLength -le $Maximum) 'Fixture bounded download exceeded.'
    return ,$data
}
function Initialize-ServerProfile { $script:Origin = 'https://example.tailnet.ts.net:8446' }
function Read-ClientPolicy { return (Test-ClientPolicy $script:fixturePolicy) }
function Run-Updater {
    try { return (Invoke-Updater) }
    finally { if ($script:Lock) { $script:Lock.Dispose(); $script:Lock = $null } }
}
try {
    # Synthetic pinned base lets the real compatibility verifier run unchanged.
    $script:Compatibility = @{}
    foreach ($path in @('EscapeFromTarkov_Data/Managed/Assembly-CSharp.dll', 'BepInEx/plugins/spt/spt-core.dll', 'BepInEx/plugins/Fika/Fika.Core.dll')) {
        $data = [Text.Encoding]::UTF8.GetBytes('frozen base: ' + $path)
        $script:Compatibility[$path] = Get-BytesHash $data
        $target = Get-ChildPath $fixture $path
        [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target)) | Out-Null
        [IO.File]::WriteAllBytes($target, $data)
    }
    [IO.File]::WriteAllText((Join-Path $fixture 'EscapeFromTarkov.exe'), 'owned game fixture')
    [IO.File]::WriteAllText((Join-Path $fixture 'SPT.Launcher.exe'), 'launcher fixture')
    $compat = @($Compatibility.Keys | Sort-Object | ForEach-Object { [pscustomobject]@{ path = $_; sha256 = $Compatibility[$_] } })
    $paths = @('BepInEx/plugins/Fixture/Gameplay.dll', 'BepInEx/plugins/Fixture/preset.json', 'BepInEx/plugins/Fixture/asset.bundle')
    $files = @()
    foreach ($path in $paths) {
        $data = [Text.Encoding]::UTF8.GetBytes('approved content: ' + $path)
        $hash = Get-BytesHash $data
        $files += [pscustomobject]@{ path = $path; size = $data.Length; sha256 = $hash }
        $script:remote['/downloads/client-file-' + $hash + '.bin'] = $data
        $target = Get-ChildPath $fixture $path
        [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target)) | Out-Null
        [IO.File]::WriteAllBytes($target, $data)
    }
    $script:fixturePolicy = [pscustomobject]@{ schemaVersion = 1; updaterVersion = '1.1.0'; channel = 'node-01'; managedPaths = $paths; baseFiles = $compat }
    $manifest = [pscustomobject]@{ schemaVersion = 1; channel = 'node-01'; bundleVersion = '2026.10.24.3'; generatedAtUtc = '2026-10-24T14:00:00Z';
        compatibility = [pscustomobject]@{ sptVersion = '4.0.13'; eftVersion = '0.16.9.40087'; fikaVersion = '2.2.5'; files = $compat };
        packages = @([pscustomobject]@{ id = 'outlands-client-pack'; version = '2026.10.24.2'; url = '/downloads/outlands-client-pack.zip';
            size = 100; sha256 = ('a' * 64); files = $files; fileTransport = 'sha256-v1' }) }
    $script:remote[$ManifestPath] = [Text.Encoding]::UTF8.GetBytes(($manifest | ConvertTo-Json -Depth 12))
    $Mode = 'Update'; $Launch = $true; $GamePath = $fixture
    Check ((Run-Updater) -eq 0) 'Matching installation launches successfully.'
    Check ($script:launches -eq 1 -and @($script:requests | Where-Object { $_ -like '*client-file-*' }).Count -eq 0) 'Matching installation downloads no payloads.'
    # Alter one file, remove another; current DLL must never transfer or replace.
    $unchanged = Get-ChildPath $fixture $paths[0]
    $unchangedTime = (Get-Item -LiteralPath $unchanged).LastWriteTimeUtc
    [IO.File]::WriteAllText((Get-ChildPath $fixture $paths[1]), 'previous gameplay preset')
    [IO.File]::Delete((Get-ChildPath $fixture $paths[2]))
    $script:requests = @()
    Check ((Run-Updater) -eq 0) 'Changed and missing files are repaired before launch.'
    $transfers = @($script:requests | Where-Object { $_ -like '*client-file-*' })
    Check ($transfers.Count -eq 2) 'Exactly two changed/missing files transferred.'
    Check ((Get-Item -LiteralPath $unchanged).LastWriteTimeUtc -eq $unchangedTime) 'Unchanged file was not replaced.'
    $control = Join-Path $fixture '.outlands-client-updater'
    $journals = @(Get-ChildItem -LiteralPath (Join-Path $control 'backups') -Filter transaction.json -Recurse)
    $journal = Convert-JsonBytes ([IO.File]::ReadAllBytes($journals[0].FullName))
    Check (@($journal.files).Count -eq 2 -and $journal.status -eq 'committed') 'Backup/journal includes only changed files.'
    Check (@(Get-ManagedStatus $fixture $manifest.packages[0] | Where-Object { -not $_.current }).Count -eq 0) 'All managed hashes match after sync.'
    [IO.File]::Delete((Get-ChildPath $fixture $paths[2])); $script:requests = @()
    Check ((Run-Updater) -eq 0) 'Missing file repairs from verified cache.'
    Check (@($script:requests | Where-Object { $_ -like '*client-file-*' }).Count -eq 0) 'Completed file cache avoids repeated transfer.'
    # A corrupt cache must be discarded and a bad remote response must not launch.
    $blob = Join-Path (Join-Path $control 'cache') ($files[2].sha256 + '.bin')
    [IO.File]::WriteAllText($blob, 'bad cache')
    [IO.File]::Delete((Get-ChildPath $fixture $paths[2]))
    $remotePath = '/downloads/client-file-' + $files[2].sha256 + '.bin'
    $approved = $script:remote[$remotePath]; $script:remote[$remotePath] = [Text.Encoding]::UTF8.GetBytes('wrong bytes')
    $before = $script:launches
    Reject { Run-Updater } 'Corrupt download blocks update.'
    Check ($script:launches -eq $before -and -not (Test-Path -LiteralPath (Get-ChildPath $fixture $paths[2]))) 'Failed transfer leaves client and launcher untouched.'
    $script:remote[$remotePath] = $approved
    Check ((Run-Updater) -eq 0) 'Retry after failed transfer succeeds.'
    $Mode = 'Repair'; $script:requests = @(); Check ((Run-Updater) -eq 0) 'Repair verifies/reinstalls all managed files.'
    Check (@($script:requests | Where-Object { $_ -like '*client-file-*' }).Count -eq 1) 'Repair reuses two cached files and downloads only previously uncached DLL.'
    $Mode = 'Update'; $script:closed = $false; $before = $script:launches
    Reject { Run-Updater } 'Running game prevents synchronization.'
    Check ($script:launches -eq $before) 'Running game blocks launch.'
    $script:closed = $true
    # Fail the second real replacement; the first must roll back before exit.
    $installFunction = (Get-Command Install-BytesAtomic).ScriptBlock
    function Install-BytesAtomic([string]$Root, [string]$Relative, [byte[]]$Bytes, [string]$Work, [switch]$Recovery) {
        if (-not $Recovery) {
            $script:installCount++
            if ($script:installCount -eq 2) { throw 'Fixture replacement interruption.' }
        }
        & $installFunction $Root $Relative $Bytes $Work -Recovery:$Recovery
    }
    [IO.File]::WriteAllText((Get-ChildPath $fixture $paths[1]), 'old preset retained on failure')
    [IO.File]::WriteAllText((Get-ChildPath $fixture $paths[2]), 'old asset retained on failure')
    $previous1 = Get-LocalHash (Get-ChildPath $fixture $paths[1])
    $previous2 = Get-LocalHash (Get-ChildPath $fixture $paths[2])
    $script:installCount = 0; $before = $script:launches
    Reject { Run-Updater } 'Partial apply failure is reported.'
    Check ($script:launches -eq $before) 'Partial apply failure does not launch.'
    Check ((Get-LocalHash (Get-ChildPath $fixture $paths[1])) -ceq $previous1 -and
        (Get-LocalHash (Get-ChildPath $fixture $paths[2])) -ceq $previous2) 'Both original changed files intact after automatic rollback.'
    Set-Item Function:Install-BytesAtomic $installFunction
    Check ((Run-Updater) -eq 0) 'Next run completes cleanly after rollback.'
    $Mode = 'Status'; $Launch = $false; $script:requests = @()
    Check ((Run-Updater) -eq 0 -and @($script:requests | Where-Object { $_ -like '*client-file-*' }).Count -eq 0) 'Status is read-only and downloads no payloads.'
    $Mode = 'Update'; $Launch = $true
    $bad = Clone $manifest; $bad.packages[0].sha256 = ('b' * 64)
    $script:remote[$ManifestPath] = [Text.Encoding]::UTF8.GetBytes(($bad | ConvertTo-Json -Depth 12))
    Reject { Assert-ReleaseCurrent $manifest.packages[0] } 'Release changed during transfer is refused.'
    $bad = Clone $manifest; $bad.packages[0].fileTransport = 'arbitrary-url'
    Reject { Test-Manifest $bad } 'Unknown file transport refused.'
    Check (@(Get-ChangedFiles $manifest.packages[0] @(Get-ManagedStatus $fixture $manifest.packages[0])).Count -eq 0) 'No changed targets after successful repair.'
    Write-Host "Individual-file sync orchestration: $checks checks passed. Engine $($PSVersionTable.PSVersion)."
}
finally {
    if ($script:Lock) { $script:Lock.Dispose(); $script:Lock = $null }
    if (Test-Path -LiteralPath $fixture) { [IO.Directory]::Delete($fixture, $true) }
}
