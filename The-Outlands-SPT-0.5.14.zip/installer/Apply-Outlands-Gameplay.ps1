[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$SptRoot,[switch]$Apply,[switch]$Check)
$ErrorActionPreference='Stop'
function Read-Json([string]$Text) {
    if((Get-Command ConvertFrom-Json).Parameters.ContainsKey('DateKind')) {return ConvertFrom-Json -InputObject $Text -DateKind String}
    return ConvertFrom-Json -InputObject $Text
}
function Equal-Json($A,$B) {return (ConvertTo-Json -InputObject $A -Depth 100 -Compress) -ceq (ConvertTo-Json -InputObject $B -Depth 100 -Compress)}
function Sha([string]$Path) {return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()}
function Child($Value,$Key) {if($Key -is [string]) {return ,($Value.PSObject.Properties[$Key].Value)};return ,($Value[[int]$Key])}
$base=[IO.Path]::GetFullPath($SptRoot).TrimEnd('\','/')
$manifest=Read-Json ([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'base-config-overrides.json')))
if($manifest.schemaVersion -ne 1) {throw 'Unknown gameplay patch schema.'}
$prepared=@();$different=@()
foreach($row in $manifest.files) {
    if($row.path -cnotin @('SPT/SPT_Data/configs/weather.json','SPT/SPT_Data/configs/seasonalevents.json')) {throw 'Unknown gameplay patch target.'}
    $path=[IO.Path]::GetFullPath((Join-Path $base $row.path))
    if(-not $path.StartsWith($base+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) {throw 'Unsafe game configuration path.'}
    $ancestor=$path
    while($ancestor) {
        if(Test-Path -LiteralPath $ancestor) {if((Get-Item -LiteralPath $ancestor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Linked game configurations are unsupported.'}}
        $ancestor=[IO.Path]::GetDirectoryName($ancestor)
    }
    $document=Read-Json ([IO.File]::ReadAllText($path));$needsWrite=$false
    foreach($change in $row.changes) {
        $cursor=$document
        for($i=0;$i -lt $change.path.Count-1;$i++) {$cursor=Child $cursor $change.path[$i]}
        $key=$change.path[-1];$current=Child $cursor $key
        if(Equal-Json $current $change.value) {continue}
        $different+=$row.path+':'+($change.path -join '.')
        if($Check) {continue}
        $knownPrevious=$false
        if($null -ne $change.PSObject.Properties['previous']) {foreach($prior in @($change.previous)) {if(Equal-Json $current $prior) {$knownPrevious=$true}}}
        if(-not (Equal-Json $current $change.expected) -and -not $knownPrevious) {throw 'An existing gameplay setting differs from both the baseline and the requested preset; review it before applying.'}
        if($key -is [string]) {$cursor.PSObject.Properties[$key].Value=$change.value}else{$cursor[[int]$key]=$change.value}
        $needsWrite=$true
    }
    $prepared+=@{path=$path;relative=$row.path;before=(Sha $path);text=($document|ConvertTo-Json -Depth 100);changed=$needsWrite}
}
if($Check) {if($different.Count){throw ('Gameplay preset differs: '+($different -join ', '))};Write-Output 'Seasonal/weather gameplay preset matches.';exit 0}
if(-not $Apply) {Write-Output ('Gameplay patch preview: '+$different.Count+' changed leaves; no installation changed.');exit 0}
if(Get-Process -ErrorAction SilentlyContinue|Where-Object{$_.ProcessName -match 'EscapeFromTarkov|SPT.Server|SPT.Launcher|SPT-Fika'}) {throw 'Close the game, launcher and server before changing gameplay settings.'}
$backup=Join-Path $base ('Outlands-backups/gameplay-'+[Guid]::NewGuid().ToString('N'))
foreach($item in $prepared|Where-Object{$_.changed}) {
    $saved=Join-Path $backup $item.relative;New-Item -ItemType Directory -Force -Path (Split-Path -Parent $saved)|Out-Null
    Copy-Item -LiteralPath $item.path -Destination $saved
    if((Sha $saved) -ne $item.before -or (Sha $item.path) -ne $item.before) {throw 'Gameplay backup changed; no configuration was written.'}
}
foreach($item in $prepared|Where-Object{$_.changed}) {[IO.File]::WriteAllText($item.path,$item.text,(New-Object Text.UTF8Encoding($false)))}
Write-Output 'Verified gameplay backups saved; Christmas/winter settings applied; Halloween and zombies are disabled.'
exit 0
