"""Bounded, read-only player projection of the server's startup content calendar."""
from datetime import datetime, timezone, timedelta
import json
import math
import re
from zoneinfo import ZoneInfo

MAX_STATUS_BYTES = 64 * 1024

MAPS = frozenset(('bigmap', 'woods', 'shoreline', 'interchange', 'rezervbase', 'lighthouse',
                  'tarkovstreets', 'sandbox', 'sandbox_high', 'laboratory', 'factory4_day', 'factory4_night'))
THEMES = frozenset(('Supply lanes', 'Patrol surge', 'Containment patrol', 'Smuggler routes',
                    'Boss sightings', 'Outbreak hunt', 'Recovery runs', 'Winter patrol', 'Holiday patrol'))
CAMPAIGNS = frozenset(('Reconnaissance', 'Supply push', 'Containment', 'Recovery', 'Winter operations'))


def timestamp(value):
    if not isinstance(value, str):
        raise ValueError("Invalid timestamp")
    parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
    if parsed.tzinfo is None:
        raise ValueError('Missing timezone')
    return parsed.astimezone(timezone.utc)


def bounded_text(value, maximum):
    if not isinstance(value, str) or not 1 <= len(value) <= maximum or any(ord(c) < 32 for c in value) or '<' in value or '>' in value:
        raise ValueError('Invalid briefing text')
    return value


def modifiers(data):
    if not isinstance(data, dict):
        raise ValueError('Missing map modifiers')
    result = {}
    for source, target, maximum in [('PmcChanceBonus', 'pmcChanceBonus', 7),
                                   ('PmcAdvanceSeconds', 'pmcAdvanceSeconds', 45),
                                   ('ScavAdvanceSeconds', 'scavAdvanceSeconds', 45),
                                   ('BossChanceBonus', 'bossChanceBonus', 10)]:
        value = data.get(source)
        if type(value) is not int or not 0 <= value <= maximum:
            raise ValueError('Invalid event modifier')
        result[target] = value
    loot = data.get('LootMultiplier')
    if type(loot) not in (int, float) or not math.isfinite(loot) or not 1 <= loot <= 1.05:
        raise ValueError('Invalid loot multiplier')
    result['lootMultiplier'] = loot
    return result


def day_plan(data, rich=False):
    if not isinstance(data, dict) or data.get('Theme') not in THEMES:
        raise ValueError('Unknown theme')
    day = data.get('Day', '')
    if not isinstance(day, str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}', day):
        raise ValueError('Invalid calendar day')
    datetime.strptime(day, '%Y-%m-%d')
    maps = data.get('Hotspots')
    if not isinstance(maps, list) or len(maps) != 2 or len(set(maps)) != 2 or not all(m in MAPS for m in maps):
        raise ValueError('Invalid hotspots')
    result = {'date': day, 'theme': data['Theme'], 'hotspots': maps}
    if rich:
        if data.get('Campaign') not in CAMPAIGNS:
            raise ValueError('Unknown campaign')
        result.update(campaign=data['Campaign'], briefing=bounded_text(data.get('Briefing'), 320))
        infection = data.get('Infection')
        if type(infection) is not int or not 0 <= infection <= 75:
            raise ValueError('Invalid forecast infection')
        result['infection'] = infection
        challenges = data.get('Challenges')
        if not isinstance(challenges, list) or len(challenges) != 3:
            raise ValueError('Missing squad challenges')
        result['challenges'] = [bounded_text(v, 180) for v in challenges]
        operations = data.get('Operations')
        if not isinstance(operations, list) or len(operations) != 2:
            raise ValueError('Missing operations')
        result['operations'] = []
        for index, operation in enumerate(operations):
            if not isinstance(operation, dict) or operation.get('Map') != maps[index] or operation.get('Role') != ('Primary', 'Secondary')[index]:
                raise ValueError('Invalid operation assignment')
            result['operations'].append({'map': operation['Map'], 'role': operation['Role'],
                                         'title': bounded_text(operation.get('Title'), 64),
                                         'modifiers': modifiers(operation.get('Modifiers'))})
    return result


def sanitize(data, now=None):
    now = datetime.now(timezone.utc) if now is None else now
    if not isinstance(data, dict) or data.get('schemaVersion') != 1:
        raise ValueError('Unknown calendar schema')
    if data.get('timezone') != 'America/New_York' or data.get('rolloverHour') != 5:
        raise ValueError('Unexpected schedule')
    since = timestamp(data['activeSinceUtc'])
    if since > now.replace(microsecond=0) and (since - now).total_seconds() > 30:
        raise ValueError('Future activation')
    version = data.get('eventVersion', '1.0.0')
    if version not in ('1.0.0', '1.1.0', '1.2.0', '1.3.0'):
        raise ValueError('Unknown event version')
    rich = version in ('1.1.0', '1.2.0', '1.3.0')
    result = {'schemaVersion': 1, 'eventVersion': version, 'available': True, 'checkedAtUtc': now.isoformat(),
              'activeSinceUtc': since.isoformat(), 'day': day_plan(data['day'], rich),
              'timezone': 'America/New_York', 'rolloverHour': 5,
              'message': 'Themes change after the 5 AM Eastern restart, once all raids finish.',
              'maps': {}, 'nextSevenDays': []}
    if version == '1.3.0':
        seasonal = data.get('seasonal', {})
        if not isinstance(seasonal, dict) or seasonal.get('eventName') not in ('Christmas', 'Halloween'):
            raise ValueError('Invalid seasonal policy')
        for field in ('christmasEnabled', 'halloweenEnabled', 'zombiesEnabled'):
            if type(seasonal.get(field)) is not bool:
                raise ValueError('Missing native seasonal state')
        if seasonal.get('weather') not in ('WINTER', 'AUTUMN'):
            raise ValueError('Unknown seasonal weather')
        if seasonal['eventName'] == 'Christmas' and (not seasonal['christmasEnabled'] or seasonal['halloweenEnabled'] or seasonal['zombiesEnabled'] or seasonal['weather'] != 'WINTER'):
            raise ValueError('Christmas native state does not match policy')
        result['seasonal'] = {k: seasonal[k] for k in ('eventName', 'christmasEnabled', 'halloweenEnabled', 'zombiesEnabled', 'weather')}
    maps = data.get('maps', {})
    if not isinstance(maps, dict) or len(maps) > len(MAPS):
        raise ValueError('Invalid map status')
    for name, row in maps.items():
        if name not in MAPS or not isinstance(row, dict):
            raise ValueError('Unexpected map')
        rate = row.get('infection')
        if type(rate) is not int or not 0 <= rate <= 75 or type(row.get('hotspot')) is not bool:
            raise ValueError('Invalid map values')
        result['maps'][name] = {'infection': rate, 'hotspot': row['hotspot']}
        if rich:
            for field, maximum in [('botCap', 128), ('pmcWavesAdjusted', 512), ('scavWavesAdjusted', 512), ('bossWavesAdjusted', 512)]:
                value = row.get(field)
                if type(value) is not int or not 0 <= value <= maximum:
                    raise ValueError('Invalid applied map status')
                result['maps'][name][field] = value
        if version in ('1.2.0', '1.3.0'):
            reinforcement = row.get('scavReinforcementWaves')
            if type(reinforcement) is not int or not 0 <= reinforcement <= 6 or row.get('scavWarEnabled') is not False:
                raise ValueError('Invalid reinforcement/Scav relationship policy')
            result['maps'][name].update(scavReinforcementWaves=reinforcement, scavWarEnabled=False)
    if result.get('seasonal', {}).get('eventName') == 'Christmas' and (result['day'].get('infection') != 0 or any(r['infection'] != 0 for r in result['maps'].values())):
        raise ValueError('Christmas must have no infection')
    future = data.get('nextSevenDays', [])
    if not isinstance(future, list) or len(future) != 7:
        raise ValueError('Missing seven-day schedule')
    result['nextSevenDays'] = [day_plan(day, rich) for day in future]
    if result.get('seasonal', {}).get('eventName') == 'Christmas' and any(d.get('infection') != 0 for d in result['nextSevenDays']):
        raise ValueError('Christmas forecast must have no infection')
    start = datetime.strptime(result['day']['date'], '%Y-%m-%d').date()
    if any(day['date'] != (start + timedelta(days=i)).isoformat() for i, day in enumerate(result['nextSevenDays'], 1)):
        raise ValueError('Forecast must contain seven consecutive future days')
    local = now.astimezone(ZoneInfo('America/New_York'))
    expected = local.date() - timedelta(days=local.hour < 5)
    if start > expected:
        raise ValueError('Calendar day is in the future')
    result['rolloverPending'] = start < expected
    return result


def from_projection(data, now):
    """Revalidate the same allowlist without trusting extra projected fields."""
    def plan(d):
        raw = {'Day': d['date'], 'Theme': d['theme'], 'Hotspots': d['hotspots']}
        if data.get('eventVersion') in ('1.1.0', '1.2.0', '1.3.0'):
            raw.update(Campaign=d['campaign'], Briefing=d['briefing'], Challenges=d['challenges'], Infection=d['infection'],
                       Operations=[{'Map': op['map'], 'Role': op['role'], 'Title': op['title'],
                                    'Modifiers': {k[0].upper() + k[1:]: v for k, v in op['modifiers'].items()}}
                                   for op in d['operations']])
        return raw
    raw = {'schemaVersion': 1, 'eventVersion': data.get('eventVersion', '1.0.0'),
           'timezone': data['timezone'], 'rolloverHour': data['rolloverHour'],
           'activeSinceUtc': data['activeSinceUtc'], 'day': plan(data['day']), 'maps': data['maps'],
           'nextSevenDays': [plan(d) for d in data['nextSevenDays']]}
    if data.get('eventVersion') == '1.3.0':
        raw['seasonal'] = data.get('seasonal')
    return sanitize(raw, now)


def unavailable():
    return {'schemaVersion': 1, 'available': False, 'message': 'The content calendar is not available yet.'}
