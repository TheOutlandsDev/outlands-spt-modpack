import copy
import importlib.util
from datetime import datetime, timezone, timedelta
import json
from pathlib import Path
import sys
import tempfile
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import app
import content_status

class ContentTests(unittest.TestCase):
    def setUp(self):
        self.now = datetime(2026, 10, 24, 12, tzinfo=timezone.utc)
        day = {'Day': '2026-10-24', 'Theme': 'Outbreak hunt', 'Hotspots': ['woods', 'bigmap']}
        self.raw = {'schemaVersion': 1, 'activeSinceUtc': self.now.isoformat(), 'day': day,
                    'timezone': 'America/New_York', 'rolloverHour': 5,
                    'maps': {'sandbox': {'infection': 10, 'hotspot': False, 'botCap': 23}},
                    'nextSevenDays': [dict(day, Day=(self.now.date() + timedelta(days=i)).isoformat()) for i in range(1, 8)]}

    def test_public_projection_removes_unrelated_data(self):
        self.raw['apiKey'] = 'must-not-leak'
        self.raw['maps']['sandbox']['profileId'] = 'must-not-leak'
        result = content_status.sanitize(self.raw, self.now)
        self.assertNotIn('must-not-leak', json.dumps(result))
        self.assertEqual(result['maps'], {'sandbox': {'infection': 10, 'hotspot': False}})
        self.assertEqual(len(result['nextSevenDays']), 7)

    def test_invalid_calendar_contract_is_refused(self):
        variants = []
        for key, value in [('schemaVersion', 2), ('timezone', 'UTC'), ('rolloverHour', 0),
                           ('nextSevenDays', []), ('maps', {'unknown': {'infection': 5, 'hotspot': True}}),
                           ('activeSinceUtc', '2027-01-01T00:00:00Z'), ('activeSinceUtc', False)]:
            bad = copy.deepcopy(self.raw); bad[key] = value; variants.append(bad)
        for key, value in [('Theme', '<script>'), ('Hotspots', ['woods', 'woods']), ('Day', '2026-02-30')]:
            bad = copy.deepcopy(self.raw); bad['day'][key] = value; variants.append(bad)
        for bad in variants:
            with self.subTest(data=bad), self.assertRaises((ValueError, TypeError)):
                content_status.sanitize(bad, self.now)

    def test_public_api_requires_fresh_bounded_ordinary_projection(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / 'content.json'
            self.assertFalse(app.content_calendar(root, self.now.timestamp())['available'])
            good = content_status.sanitize(self.raw, self.now)
            path.write_text(json.dumps(good))
            self.assertTrue(app.content_calendar(root, self.now.timestamp())['available'])
            self.assertFalse(app.content_calendar(root, self.now.timestamp() + 151)['available'])
            path.write_text('x' * (content_status.MAX_STATUS_BYTES + 1))
            self.assertFalse(app.content_calendar(root, self.now.timestamp())['available'])
            path.unlink(); (root / 'other.json').write_text(json.dumps(good)); path.symlink_to(root / 'other.json')
            self.assertFalse(app.content_calendar(root, self.now.timestamp())['available'])

    def rich(self):
        raw = copy.deepcopy(self.raw)
        raw['eventVersion'] = '1.1.0'
        for day in [raw['day'], *raw['nextSevenDays']]:
            day.update(Campaign='Containment', Briefing='Recover supplies and extract together.', Infection=30,
                       Challenges=['Recover provisions.', 'Cover your teammate.', 'Extract together.'],
                       Operations=[{'Map': m, 'Role': role, 'Title': 'Recovery corridor',
                                    'Modifiers': {'PmcChanceBonus': 4, 'PmcAdvanceSeconds': 30,
                                                  'ScavAdvanceSeconds': 15, 'BossChanceBonus': 0,
                                                  'LootMultiplier': 1.04}}
                                   for m, role in zip(day['Hotspots'], ['Primary', 'Secondary'])])
        raw['maps']['sandbox'].update(pmcWavesAdjusted=0, scavWavesAdjusted=0, bossWavesAdjusted=0)
        return raw

    def test_rich_operations_round_trip_and_private_fields_dropped(self):
        raw = self.rich()
        raw['day']['Operations'][0]['profileId'] = 'must-not-leak'
        raw['day']['Operations'][0]['Modifiers']['apiKey'] = 'must-not-leak'
        result = content_status.sanitize(raw, self.now)
        self.assertEqual(result, content_status.from_projection(result, self.now))
        self.assertNotIn('must-not-leak', json.dumps(result))
        self.assertEqual(result['day']['operations'][0]['modifiers']['lootMultiplier'], 1.04)
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'content.json'; path.write_text(json.dumps(result))
            self.assertTrue(app.content_calendar(Path(d), self.now.timestamp())['available'])

    def test_invalid_effects_briefings_assignments_and_forecast_refused(self):
        for field, value in [('PmcChanceBonus', 8), ('PmcChanceBonus', True), ('ScavAdvanceSeconds', 46),
                             ('LootMultiplier', float('nan')), ('LootMultiplier', 1.2)]:
            raw = self.rich(); raw['day']['Operations'][0]['Modifiers'][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError): content_status.sanitize(raw, self.now)
        for key, value in [('Campaign', 'unknown'), ('Briefing', '<script>'), ('Challenges', ['x']),
                           ('Operations', [])]:
            raw = self.rich(); raw['day'][key] = value
            with self.subTest(field=key), self.assertRaises(ValueError): content_status.sanitize(raw, self.now)
        raw = self.rich(); raw['day']['Operations'][0]['Map'] = 'sandbox'
        with self.assertRaises(ValueError): content_status.sanitize(raw, self.now)
        raw = self.rich(); raw['nextSevenDays'][1]['Day'] = raw['nextSevenDays'][0]['Day']
        with self.assertRaises(ValueError): content_status.sanitize(raw, self.now)

    def test_delayed_maintenance_keeps_active_plan_and_marks_rollover_pending(self):
        raw = self.rich()
        self.assertFalse(content_status.sanitize(raw, self.now)['rolloverPending'])
        later = self.now + timedelta(days=1)
        result = content_status.sanitize(raw, later)
        self.assertTrue(result['rolloverPending'])
        self.assertEqual(result['day']['date'], '2026-10-24')

    def test_dst_rollover_uses_five_am_eastern(self):
        raw = self.rich(); raw['day']['Day'] = '2026-10-31'
        for i, day in enumerate(raw['nextSevenDays'], 1): day['Day'] = (datetime(2026, 10, 31) + timedelta(days=i)).date().isoformat()
        self.assertFalse(content_status.sanitize(raw, datetime(2026, 11, 1, 9, 59, tzinfo=timezone.utc))['rolloverPending'])
        self.assertTrue(content_status.sanitize(raw, datetime(2026, 11, 1, 10, 0, tzinfo=timezone.utc))['rolloverPending'])

    def test_reinforcement_policy_round_trip_requires_scav_war_off(self):
        raw = self.rich(); raw['eventVersion'] = '1.2.0'
        raw['maps']['sandbox'].update(scavReinforcementWaves=3, scavWarEnabled=False)
        result = content_status.sanitize(raw, self.now)
        self.assertEqual(result, content_status.from_projection(result, self.now))
        self.assertEqual(result['maps']['sandbox']['scavReinforcementWaves'], 3)
        for value in (True, None, 0):
            raw['maps']['sandbox']['scavWarEnabled'] = value
            with self.assertRaises(ValueError): content_status.sanitize(raw, self.now)

    def test_christmas_native_state_and_projection_round_trip(self):
        raw = self.rich(); raw['eventVersion'] = '1.3.0'
        raw['seasonal'] = dict(eventName='Christmas', christmasEnabled=True, halloweenEnabled=False, zombiesEnabled=False, weather='WINTER', private='must-not-leak')
        raw['maps']['sandbox'].update(infection=0, scavReinforcementWaves=3, scavWarEnabled=False)
        for day in [raw['day'], *raw['nextSevenDays']]:
            day.update(Infection=0, Theme='Holiday patrol', Campaign='Winter operations')
        result = content_status.sanitize(raw, self.now)
        self.assertEqual(result, content_status.from_projection(result, self.now))
        self.assertNotIn('must-not-leak', json.dumps(result))
        for key, value in [('christmasEnabled', False), ('halloweenEnabled', True), ('zombiesEnabled', True), ('weather', 'AUTUMN')]:
            bad = copy.deepcopy(raw); bad['seasonal'][key] = value
            with self.subTest(key=key), self.assertRaises(ValueError): content_status.sanitize(bad, self.now)
        bad = copy.deepcopy(raw); bad['nextSevenDays'][0]['Infection'] = 30
        with self.assertRaises(ValueError): content_status.sanitize(bad, self.now)
        raw['maps']['sandbox']['infection'] = 10
        with self.assertRaises(ValueError): content_status.sanitize(raw, self.now)

    def test_seasonal_preset_turns_off_all_halloween_sources(self):
        spec = importlib.util.spec_from_file_location('outlands_seasons', Path(__file__).resolve().parents[1] / 'ops/halloween.py')
        helper = importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
        halloween = dict(type='HALLOWEEN', name='halloween', enabled=True, settings=dict(enableSummoning=True, replaceBotHostility=True, removeEntryRequirement=['laboratory'], zombieSettings=dict(enabled=True, mapInfectionAmount=dict(Woods=60))))
        christmas = dict(type='CHRISTMAS', name='christmas', enabled=False, settings=dict(christmasLootBoostAmount=0.03))
        january = dict(type='CHRISTMAS', name='christmas January', enabled=True, settings={})
        april = dict(type='APRILFOOLS', enabled=True, settings=dict(zombieSettings=dict(enabled=True, mapInfectionAmount=dict(laboratory=100))))
        raw = dict(events=[halloween, christmas, january, april], keep=dict(santaChance=25))
        weather = dict(overrideSeason=1, keep='unchanged'); original = copy.deepcopy(raw)
        result = helper.desired(raw, weather)
        self.assertEqual(raw, original)
        events = result['seasonalevents.json']['events']
        self.assertEqual([e.get('name') for e in events if e['enabled']], ['christmas'])
        self.assertFalse(events[0]['settings']['zombieSettings']['enabled'])
        self.assertFalse(events[0]['settings']['replaceBotHostility'])
        self.assertEqual(events[0]['settings']['removeEntryRequirement'], [])
        self.assertEqual(events[0]['settings']['zombieSettings']['mapInfectionAmount']['Woods'], 0)
        self.assertFalse(events[3]['settings']['zombieSettings']['enabled'])
        for flag in ('adjustBotAppearances', 'enableChristmasHideout', 'enableSanta', 'enableRundansEvent', 'enableKhorvodEvent'):
            self.assertIs(events[1]['settings'][flag], True)
        self.assertEqual(result['weather.json']['overrideSeason'], 2)
        self.assertEqual(events[1]['settings']['christmasLootBoostAmount'], 0.03)
        self.assertEqual(result['seasonalevents.json']['keep'], raw['keep'])
        self.assertEqual(helper.desired(result['seasonalevents.json'], result['weather.json']), result)
        with self.assertRaises(helper.Refused): helper.desired(raw, weather, event='unknown')
        raw['events'].append(copy.deepcopy(christmas))
        with self.assertRaises(helper.Refused): helper.desired(raw, weather)


if __name__ == '__main__': unittest.main()

