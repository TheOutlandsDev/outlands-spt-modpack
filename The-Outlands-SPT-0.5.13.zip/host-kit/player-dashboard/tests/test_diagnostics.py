from datetime import datetime,timezone
import importlib.util,json
from pathlib import Path
import tempfile,unittest
spec=importlib.util.spec_from_file_location('diagnostics',Path(__file__).parents[1]/'diagnostics_status.py');d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
def fixture():
 return dict(schemaVersion=1,checkedAtUtc=datetime.fromtimestamp(100,timezone.utc).isoformat(),performance=dict(fps=60,avg_frame_ms=16.7,p95_frame_ms=22,max_frame_ms=100,hitches_over_50ms=1),raid=dict(in_raid=True,available=True,map='sandbox',bot_instances_created=10,registered_bots=10,alive_bots=8,active_bots=5,fda_sleeping_bots=2,other_inactive_bots=1,dead_registered_bots=2,active_bots_with_goal_enemy=3,sleeping_count_available=True),unityErrors=0,measurementErrors=0,droppedSnapshots=0,writerErrors=0)
class DiagnosticsTests(unittest.TestCase):
 def test_counts_are_fresh_and_public_projection_drops_identifiers(self):
  x=fixture();x.update(profileId='secret',runId='secret',error='private');x['raid']['players']=['secret'];v=d.normalize(x,100)
  self.assertTrue(v['available']);self.assertEqual(v['raid']['fda_sleeping_bots'],2);self.assertNotIn('secret',json.dumps(v));self.assertNotIn('private',json.dumps(v))
 def test_stale_invalid_future_nonfinite_and_impossible_counts_refused(self):
  for now in [200,70]:self.assertFalse(d.normalize(fixture(),now)['available'])
  for key,value in [('fps',float('nan')),('fps',float('inf')),('fps',True),('p95_frame_ms',-1)]:
   x=fixture();x['performance'][key]=value;self.assertFalse(d.normalize(x,100)['available'])
  x=fixture();x['raid']['active_bots']=3000;self.assertFalse(d.normalize(x,100)['available'])
 def test_runtime_map_case_is_normalized_without_exposing_unknown_maps(self):
  for raw_map,expected in [('RezervBase','rezervbase'),('TarkovStreets','tarkovstreets'),('sandbox','sandbox'),('private-profile-secret',None),({'profileId':'secret'},None),(['secret'],None), (None,None)]:
   with self.subTest(raw_map=raw_map):
    x=fixture();x['raid']['map']=raw_map;v=d.normalize(x,100)
    self.assertTrue(v['available']);self.assertEqual(v['raid']['map'],expected);self.assertNotIn('secret',json.dumps(v))
 def test_idle_has_no_invented_zero_bot_counts(self):
  x=fixture();x['raid']={'in_raid':False,'available':True};v=d.normalize(x,100)
  self.assertTrue(v['available']);self.assertNotIn('alive_bots',v['raid'])
 def test_missing_oversize_and_symlink_files_cannot_claim_readiness(self):
  with tempfile.TemporaryDirectory()as temp:
   root=Path(temp);p=root/'metrics.json';self.assertFalse(d.snapshot(p,100)['available']);p.write_text(json.dumps(fixture()));self.assertTrue(d.snapshot(p,100)['available']);link=root/'link';link.symlink_to(p);self.assertFalse(d.snapshot(link,100)['available']);p.write_text('x'*20000);self.assertFalse(d.snapshot(p,100)['available'])

 def test_combat_counts_are_bounded_and_drop_positions_and_identities(self):
  x=fixture();x['raid']['combat']={k:2 for k in ('moving_bots','motion_samples','bots_with_visible_enemy','bots_with_shootable_enemy','weapon_ready_bots','bots_with_ammunition','weapon_shot_events_total')};x['raid']['combat'].update(roles={'secret-profile':2},positions=['private'])
  v=d.normalize(x,100);self.assertEqual(v['raid']['combat']['moving_bots'],2);self.assertNotIn('secret',json.dumps(v));self.assertNotIn('private',json.dumps(v))
  for bad in (-1,True,4096):
   x['raid']['combat']['moving_bots']=bad;self.assertFalse(d.normalize(x,100)['available'])

 def test_combat_policy_survives_worker_then_http_projection(self):
  x=fixture();x['combatPolicy']={'sain_ai_vs_ai_limits_disabled':True,'errors':0,'private':'must-not-leak'}
  worker_projection=d.normalize(x,100);http_projection=d.normalize(worker_projection,100)
  self.assertEqual(worker_projection,http_projection)
  self.assertTrue(http_projection['combatPolicy']['sainAiVsAiLimitsDisabled']);self.assertNotIn('must-not-leak',json.dumps(http_projection))
