# Outlands live content 1.2.0

A server-only calendar pinned to SPT 4.0.13. Halloween stays enabled. Seven daily
themes rotate pairs of hotspot maps; the map pairs shift each week. The active
calendar day rolls at 5 AM America/New_York, including DST. Settings apply once
after post-database processing at server startup. Existing announced maintenance
waits for all raids before restarting, so raids never change theme midway.

| Day | Theme | Primary hotspot changes |
| --- | --- | --- |
| Monday | Supply lanes | PMC chance +3 points, later PMC waves up to 20s earlier, location loot chance +5% |
| Tuesday | Patrol surge | PMC chance +6 points, later PMC waves up to 45s earlier |
| Wednesday | Containment patrol | PMC chance +4 points, later PMC waves up to 30s earlier, location loot chance +2% |
| Thursday | Smuggler routes | PMC chance +4 points, later PMC waves up to 20s earlier, location loot chance +5% |
| Friday | Boss sightings | Enabled named boss chance +10 points, PMC chance +3 points, later PMC waves up to 20s earlier, loot chance +2% |
| Saturday | Outbreak hunt | Infection 35%, PMC chance +4 points, later PMC waves up to 30s earlier, loot chance +3% |
| Sunday | Recovery runs | Infection 15%, PMC chance +3 points, later PMC waves up to 15s earlier, loot chance +4% |

The four weekly campaign phases are Reconnaissance, Supply push, Containment and
Recovery. Supply push and Containment add one PMC chance point, with an absolute
maximum of seven. The secondary map receives half the encounter/timing/loot
bonus, rounded down for integer values. Map pairs still shift weekly.

Each day has two named operations, a briefing and three optional squad goals;
theme-specific goals and rotating teamwork goals add variety. These are self
assessed group challenges, not persistent quests, tracked achievements or bonus
payouts. Normal trader quests and their rewards remain unchanged.

On eligible timed ordinary Scav waves, later spawn windows move earlier by
15/30/45/15/15/30/15 seconds Monday through Sunday (half on the secondary map).
Existing -1/-1 engine-managed waves retain their behavior. Current Lighthouse
and Woods waves use that engine-managed timing, so today's Scav adjustment count
is zero. The dashboard reports actual adjusted counts instead of claiming extra
spawns. All PMC and boss chance bonuses preserve disabled zero-chance waves;
early waves stay early, and moved windows never start before 120 seconds.

Normal maps use exactly 15% infection, Ground Zero 10%, Labs 60%, ordinary hotspots
30%. Crowd spawns are capped at six, with at least 180 seconds per-player cooldown.
Infected initial wave chance is capped at the map infection value, infected
Tagilla at 5%; infected waves and generated PMC waves respect existing bot caps. The mod does not add
bot slots, compound wave counts, raise skill/accuracy, reset profiles or grant
money/items. Location loot chance increases are capped at 5% on the primary map
and 2.5% on the secondary; these multiply existing location chance modifiers and
do not guarantee an item or increase quest payouts. Economy trade prices, existing Flea Simulator repair, trader unlocks
and standard repeatable quests remain intact. These are conservative initial
values; fight pacing still needs real raid measurements.

Scav/infected hostility is explicitly reciprocal, including missing map rows.
The native 4.0.13 hostility helper's discarded Append result is not relied on.
Normal relationships remain intact. Matching Remote Quests 1.0.3 separately guards Scav
loyalty and revenge; install that matching DLL on clients and the headless host.

Install Outlands.LiveContent.dll and settings.json in
SPT/user/mods/zzz-OutlandsLiveContent/. status.json is generated locally, is not
part of the installation lock, and contains only public calendar data. The
maintenance worker validates and projects it to the read-only player dashboard.
The operations board lets players preview every day in the seven-day forecast,
then return to the active plan. Forecasts are not active mid-raid. If maintenance
is delayed, the board keeps the old active plan and labels rollover as waiting.
Actual startup counters report adjusted PMC/Scav/boss waves and map AI caps;
they are not live bot counts, guaranteed encounters or evidence of attacks.
The daily checkpoint now includes this DLL and settings for recovery.
No API for changing settings is exposed. Disable via Enabled:false and restart
at an idle boundary. Removing the mod restores native processing on next start.

Build with build.py --output PATH --test using matching local SPT/Fika references.
Pure calendar/DST/bounds and typed-hostility tests run offline against actual SPT
model types. Use a fresh isolated backend for integration, then a Ground Zero
Scav test (infected kill, friendly-Scav response, extraction/Fence standing) and
a two-player combat test before declaring the experience proven.


Version 1.2.0 adds bounded regular Scav reinforcement waves using each map's
existing enabled Scav zones and difficulty. Groups contain 1–2 bots, with 60-second
windows starting every four minutes: six waves on larger maps (through minute 24),
three on Ground Zero, two on Factory, none on Labs. Existing disabled waves are
never activated. Native spawn placement and population checks still apply;
a scheduled wave does not guarantee a live spawn when the map is already full.
The existing PMC patrol schedule remains active alongside these Scav waves.
Scav War is disabled by the separate 1.2.0 host policy. Reciprocal Scav/infected
hostility and infected-kill reputation protection remain active. Real movement,
firing, reinforcements and performance require raid acceptance with combat telemetry.
