using System;
using System.Collections.Generic;
using System.Linq;
using Mono.Cecil;
using Mono.Cecil.Cil;

// Run against the pinned local game and the newly built host-only plugin. No
// game source or assets are included in the authored release.
class InspectAnimationContracts
{
    static int Checks;
    static void Require(bool value, string message) { Checks++; if (!value) throw new Exception(message); }
    static MethodDefinition Method(TypeDefinition type, string name) { return type.Methods.Single(m => m.Name == name); }
    static IEnumerable<MethodReference> Calls(MethodDefinition method)
    {
        return method.Body.Instructions.Where(i => i.OpCode == OpCodes.Call || i.OpCode == OpCodes.Callvirt || i.OpCode == OpCodes.Newobj).Select(i => (MethodReference)i.Operand);
    }
    static bool CallsType(MethodDefinition method, string type, string name) { return Calls(method).Any(m => m.DeclaringType.FullName == type && m.Name == name); }
    static IEnumerable<TypeDefinition> Flatten(TypeDefinition type) { yield return type; foreach (var child in type.NestedTypes.SelectMany(Flatten)) yield return child; }
    static bool IsCanUseGate(MethodDefinition method)
    {
        var i = method.Body.Instructions.Where(x => x.OpCode != OpCodes.Nop).ToArray();
        return i.Length > 3 && i[0].OpCode == OpCodes.Ldarg_0 && i[1].OpCode == OpCodes.Ldfld &&
            i[1].Operand is FieldReference f && f.DeclaringType.FullName == "BotSecondWeaponData" && f.Name == "CanUse" &&
            (i[2].OpCode == OpCodes.Brtrue_S || i[2].OpCode == OpCodes.Brtrue) && i[3].OpCode == OpCodes.Ret;
    }
    static void Main(string[] args)
    {
        using (var game = AssemblyDefinition.ReadAssembly(args[0]))
        using (var plugin = AssemblyDefinition.ReadAssembly(args[1]))
        using (var sain = AssemblyDefinition.ReadAssembly(args[2]))
        {
            var types = game.MainModule.Types.SelectMany(Flatten).ToArray();
            var magazine = types.Single(t => t.FullName == "BotMagazineChecker");
            var secondary = types.Single(t => t.FullName == "BotSecondWeaponData");
            Require(magazine.BaseType.FullName == "GClass429" && secondary.BaseType.FullName == "GClass429", "Cosmetic owner base changed.");
            var ownerField = types.Single(t => t.FullName == "GClass429").Fields.Single(f => f.Name == "BotOwner_0");
            Require(ownerField.IsPublic && ownerField.FieldType.FullName == "EFT.BotOwner", "Cosmetic owner field changed.");
            var update = Method(magazine, "ManualUpdate");
            Require(update.ReturnType.FullName == "System.Void" && update.Parameters.Count == 0, "Magazine hook signature changed.");
            var allowed = new HashSet<string> {
                "BotDifficultySettingsClass::get_FileSettings", "UnityEngine.Time::get_time", "GClass856::GreateRandom",
                "EFT.BotOwner::get_WeaponManager", "BotWeaponManager::get_ShootController", "EFT.IFirearmHandsController::CheckAmmo"
            };
            foreach (var call in Calls(update)) Require(allowed.Contains(call.DeclaringType.FullName + "::" + call.Name), "Magazine checker gained a functional side effect: " + call);
            Require(CallsType(update, "EFT.IFirearmHandsController", "CheckAmmo"), "Magazine inspection caller changed.");
            foreach (var instruction in update.Body.Instructions.Where(i => i.OpCode == OpCodes.Stfld))
                Require(((FieldReference)instruction.Operand).FullName == "System.Single BotMagazineChecker::NextPosibleCheckMagazine", "Magazine checker gained state mutation.");
            var checkAmmo = update.Body.Instructions.Single(i => i.Operand is MethodReference m && m.DeclaringType.FullName == "EFT.IFirearmHandsController" && m.Name == "CheckAmmo");
            Require(checkAmmo.Next.OpCode == OpCodes.Pop, "Magazine caller now depends on inspection result.");
            Require(update.Body.Instructions.Any(i => i.Operand is FieldReference f && f.Name == "CAN_CHECK_MAGAZINE"), "Native magazine opt-out changed.");

            var ctor = Method(secondary, ".ctor");
            Require(ctor.Parameters.Count == 1 && ctor.Parameters[0].ParameterType.FullName == "EFT.BotOwner", "Secondary constructor changed.");
            Require(ctor.Body.Instructions.Any(i => i.Operand is FieldReference f && f.Name == "CAN_WATCH_SECOND_WEAPON"), "Native secondary opt-out changed.");
            Require(secondary.Fields.Single(f => f.Name == "CanUse").FieldType.FullName == "System.Boolean", "Secondary behavior gate changed.");
            foreach (var name in new[] { "StartDo", "ManualUpdate", "Apply" }) Require(IsCanUseGate(Method(secondary, name)), "Secondary entry no longer honors native opt-out: " + name);
            foreach (var instruction in Method(secondary, "ManualUpdate").Body.Instructions.Where(i => i.Operand is MethodReference m && m.DeclaringType.FullName == "EFT.IFirearmHandsController" && (m.Name == "CheckAmmo" || m.Name == "ExamineWeapon")))
                Require(instruction.Next.OpCode == OpCodes.Pop, "Secondary inspection now consumes a functional result.");
            var create = types.Single(t => t.FullName == "EFT.BotOwner").Methods.Single(m => m.Name == "Create" && m.Parameters.Count == 6);
            var instructions = create.Body.Instructions;
            int ownerAssigned = instructions.ToList().FindIndex(i => i.Operand is MethodReference m && m.Name == "set_GetPlayer");
            int behaviorCreated = instructions.ToList().FindIndex(i => i.OpCode == OpCodes.Newobj && i.Operand is MethodReference m && m.DeclaringType.FullName == "BotSecondWeaponData");
            int aiAssigned = instructions.ToList().FindIndex(i => i.Operand is MethodReference m && m.Name == "SetOwnerToAIData");
            Require(aiAssigned >= 0 && ownerAssigned > aiAssigned && behaviorCreated > ownerAssigned, "AI owner unavailable when behavior constructor hook executes.");

            var implementation = plugin.MainModule.Types.Single(t => t.FullName == "Codex.Diagnostics.Client.AnimationRecovery");
            var methods = implementation.Methods.Where(m => m.HasBody).ToArray();
            var forbidden = new HashSet<string> { "SetTriggerPressed", "ReloadMag", "ReloadWithAmmo", "ReloadCylinderMagazine", "QuickReloadMag", "ReloadGrenadeLauncher", "CheckChamber", "ChangeToMain", "ChangeToSecond", "OnUtilityOperationStartEvent", "OnIdleStartEvent", "ExamineWeapon" };
            foreach (var method in methods) foreach (var call in Calls(method)) Require(!forbidden.Contains(call.Name), "Policy unexpectedly touches a functional weapon path: " + call);
            var mutation = methods.SelectMany(m => m.Body.Instructions).Where(i => i.OpCode == OpCodes.Stfld && i.Operand is FieldReference f && f.DeclaringType.FullName == "BotSecondWeaponData").Select(i => ((FieldReference)i.Operand).Name).ToArray();
            Require(mutation.Length == 1 && mutation[0] == "CanUse", "Policy mutates unexpected native bot state.");
            Require(CallsType(Method(implementation, "BeforeMagazineCheck"), "Codex.Diagnostics.Client.AnimationRecovery", "Eligible"), "Magazine ownership gate missing.");
            Require(CallsType(Method(implementation, "AfterSecondaryConstructor"), "Codex.Diagnostics.Client.AnimationRecovery", "Eligible"), "Secondary ownership gate missing.");
            var playerType = types.Single(t => t.FullName == "EFT.Player");
            var shot = playerType.Methods.Single(m => m.Name == "OnMakingShot");
            Require(shot.ReturnType.FullName == "System.Void" && shot.Parameters.Select(p => p.ParameterType.FullName).SequenceEqual(new[] { "IWeapon", "UnityEngine.Vector3" }), "Frozen weapon-shot event contract changed.");
            var globals = sain.MainModule.Types.Single(t => t.FullName == "SAIN.Preset.GlobalSettings.GlobalSettingsClass");
            Require(globals.Fields.Single(f => f.Name == "Instance").IsStatic, "SAIN active global instance is no longer static");
            var handler = sain.MainModule.Types.Single(t => t.FullName == "SAIN.Plugin.PresetHandler");
            Require(handler.Fields.Single(f => f.Name == "LoadedPreset").IsStatic, "SAIN selected preset field changed");
            var preset = sain.MainModule.Types.Single(t => t.FullName == "SAIN.Preset.SAINPresetClass");
            Require(preset.Properties.Single(p => p.Name == "GlobalSettings").PropertyType.FullName == globals.FullName, "SAIN active preset settings contract changed");
            var general = globals.Fields.Single(f => f.Name == "General").FieldType.Resolve();
            var limiter = general.Fields.Single(f => f.Name == "AILimit").FieldType.Resolve();
            foreach (var name in new[] { "LimitAIvsAIGlobal", "LimitAIvsAIVision", "LimitAIvsAIHearing" }) {
                var field = limiter.Fields.Single(f => f.Name == name);
                Require(field.IsPublic && !field.IsStatic && field.FieldType.FullName == "System.Boolean", "SAIN limiter contract changed: " + name);
            }
            var pluginType = plugin.MainModule.Types.Single(t => t.FullName == "Codex.Diagnostics.Client.Plugin");
            var raidSnapshot = Method(pluginType, "Raid");
            var raidType = Calls(raidSnapshot).Where(c => c.Name == ".ctor").Select(c => c.DeclaringType.Resolve()).Single(t => t.Properties.Any(p => p.Name == "alive_bots"));
            Require(raidType.Properties.Any(p => p.Name == "combat"), "Actual raid snapshot must emit combat counters, not only calculate them");
            Require(Calls(raidSnapshot).Where(c => c.Name == ".ctor").Select(c => c.DeclaringType.Resolve()).Any(t => t.Properties.Any(p => p.Name == "weapon_shot_events_total") && t.Properties.Any(p => p.Name == "moving_bots")), "Actual emitted combat object must include movement and shot events");
            Console.WriteLine("Frozen native cosmetic patrol contracts: " + Checks + " checks passed. Gameplay validation remains pending.");
        }
    }
}
