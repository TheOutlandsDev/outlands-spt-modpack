#!/usr/bin/env python3
"""Build host-only metrics against the exact local frozen game/Fika assemblies."""
import argparse,hashlib,json,os,subprocess
from pathlib import Path
SOURCE=Path(__file__).resolve().parent;ROOT=SOURCE.parents[2]
PINS={'BepInEx/plugins/FikaDynamicAI/FikaDynamicAI.dll':'58c4e117609a677e1095dfe0cea29ef9253c416f95722634c5942ab01d7e6236','EscapeFromTarkov_Data/Managed/Assembly-CSharp.dll':'faef6f0b9f142f9d047495ec3dccfd5d6974ac048368dc7045955cf54b117982','BepInEx/plugins/Fika/Fika.Core.dll':'6b56f43ac9fe6296537be8fbfe2f78da36da73842540602687ba9baba51f938b'}

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args();out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
 runtime=ROOT/'runtime';sdk=ROOT/'MAINSPT/Tools/dotnet-sdk-9.0.316';dotnet=ROOT/'linux/dotnet/dotnet';env=dict(os.environ,COMPlus_ReadyToRun='0');config=out/'tests.runtimeconfig.json';config.write_text(json.dumps({'runtimeOptions':{'tfm':'net9.0','framework':{'name':'Microsoft.NETCore.App','version':'9.0.17'}}}))
 for rel,digest in PINS.items():
  if hashlib.sha256((runtime/rel).read_bytes()).hexdigest()!=digest:raise ValueError('Frozen diagnostic contract mismatch: '+rel)
 def compile(name,sources,refs,exe=False):
  arguments=['-nologo','-langversion:latest','-deterministic+','-nostdlib+','-target:'+('exe'if exe else'library'),'-out:'+str(out/(name+'.dll'))]+['-r:'+str(p)for p in refs]+[str(SOURCE/p)for p in sources];rsp=out/(name+'.rsp');rsp.write_text('\n'.join('"'+a+'"'for a in arguments));subprocess.run([str(dotnet),'exec','--runtimeconfig',str(config),str(sdk/'sdk/9.0.316/Roslyn/bincore/csc.dll'),'@'+str(rsp)],check=True,env=env)
 managed=runtime/'EscapeFromTarkov_Data/Managed';refs=[managed/n for n in ['mscorlib.dll','System.dll','System.Core.dll','netstandard.dll','Assembly-CSharp.dll','UnityEngine.dll','UnityEngine.CoreModule.dll','Newtonsoft.Json.dll','Comfort.dll']]+[runtime/'BepInEx/core'/n for n in ['BepInEx.dll','0Harmony.dll']]+[runtime/'BepInEx/plugins/Fika/Fika.Core.dll',runtime/'BepInEx/plugins/FikaDynamicAI/FikaDynamicAI.dll']
 compile('Codex.Diagnostics.Client',['Plugin.cs','Metrics.cs','BoundedWriter.cs','AnimationRecovery.cs','AnimationRecoveryPolicy.cs'],refs)
 netrefs=sorted((sdk/'packs/Microsoft.NETCore.App.Ref/9.0.18/ref/net9.0').glob('*.dll'));newton=ROOT/'MAINSPT/Tools/dotnet-sdk-9.0.316/sdk/9.0.316/Newtonsoft.Json.dll'
 if not newton.exists():raise ValueError('Local test JSON reference unavailable')
 (out/'Newtonsoft.Json.dll').write_bytes(newton.read_bytes());compile('TestMetrics',['Metrics.cs','BoundedWriter.cs','TestMetrics.cs'],netrefs+[newton],True)
 subprocess.run([str(dotnet),'exec','--runtimeconfig',str(config),str(out/'TestMetrics.dll')],check=True,env=env)
 compile('TestAnimationRecoveryPolicy',['AnimationRecoveryPolicy.cs','TestAnimationRecoveryPolicy.cs'],netrefs,True)
 subprocess.run([str(dotnet),'exec','--runtimeconfig',str(config),str(out/'TestAnimationRecoveryPolicy.dll')],check=True,env=env)
 cecil=runtime/'SPT/Mono.Cecil.dll'
 (out/'Mono.Cecil.dll').write_bytes(cecil.read_bytes())
 compile('InspectAnimationContracts',['InspectAnimationContracts.cs'],netrefs+[cecil],True)
 subprocess.run([str(dotnet),'exec','--runtimeconfig',str(config),str(out/'InspectAnimationContracts.dll'),str(managed/'Assembly-CSharp.dll'),str(out/'Codex.Diagnostics.Client.dll'),str(runtime/'BepInEx/plugins/SAIN/SAIN.dll')],check=True,env=env)
 print('Host-only metrics SHA256 '+hashlib.sha256((out/'Codex.Diagnostics.Client.dll').read_bytes()).hexdigest())
if __name__=='__main__':main()
