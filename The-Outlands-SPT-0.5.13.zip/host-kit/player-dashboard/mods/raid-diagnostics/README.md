# Headless utility stability and raid diagnostics 0.4.0

This replaces the existing host-only `codex.diagnostics.client` 0.3.0 DLL at the
same installed path. Humans do not receive this plugin. Its GUID stays in the
headless role, and the matching fixed CRC policy must be regenerated/restarted
with it. Human managed files, base files and release fingerprints are unchanged.

Every five seconds the plugin publishes headless simulation FPS, average/p95/max
frame time, hitches, current bot registry counts, exact membership of
FikaDynamicAI's `_disabledBots` set, other inactive bots and active bots holding a
GoalEnemy. The latter is awareness evidence, not proof of attacks, shots or hits.
A postfix on the frozen `HostGameController.CreateBot` task counts unique
successfully created local bot instances. These are actual client objects rather
than backend-generated profiles, but created instances are not necessarily
active; registry/alive/active counts remain separate. Profile IDs only exist in a
bounded in-memory deduplication set and are never written to diagnostics.

The measurement patches preserve native tasks/results and exceptions. Counts
are read on Unity's thread. File IO/JSON serialization runs on a background
thread with a 16-snapshot queue. Percentile storage is capped at 4096 frames per
window; total frames/hitches/max still count all frames. Logs rotate through four
8 MiB files plus one bounded current snapshot under `Logs/OutlandsRaidDiagnostics`.
Old `Logs/CodexDiagnostics` files are untouched. Unity errors are counted without
copying private messages, paths, players or profiles to the dashboard.

## Cosmetic weapon utility timeouts

Inspection of the pinned game shows that `UtilityOperationEvent not found`
comes from a cosmetic utility operation that did not receive its animation
event within 2.5 seconds; the game then returns it to idle. This message alone
does not establish broken weapon assets or failed firing/reloading.

For headless Fika AI only, this version opts out of periodic cosmetic magazine
inspection and showing off a secondary weapon. The second behavior uses its
own native `CanUse` opt-out; shared bot settings are not modified. Human players,
observed teammates and ordinary client AI retain their native behavior.
Firing, ammunition, reloads, malfunctions and combat weapon selection remain
native. No callbacks are fabricated, and warnings and timeouts remain visible.

The build checks frozen callers, owner initialization, opt-out gates and state
mutations. Startup must show `Headless cosmetic utility guard active`. A later
raid must still confirm that this prevents the observed warnings; lobby startup
does not establish warning elimination. Other utility callers remain native.
The existing Capture/Enabled switch controls both measurements and this policy.

## Hitch investigation

The per-frame measurement path uses fixed storage and makes no managed
allocations. A 16-entry ring retains the latest frames of at least 100 ms with
approximate UTC ends derived from monotonic age; overflow is counted. GC/heap
counters are sampled without forcing collection. Bot creation records its
synchronous call time separately from async task time, failures and pending
work. Async elapsed time includes waits and does not prove a blocked Unity
thread. Completion threads update only locked managed counters.

The earlier 1.09-second frame coincided with a new PMC. The available logs do
not establish whether loading, GC or CPU scheduling caused it. These added
measurements support the next investigation; they do not establish a hitch fix.
Spawn caps, difficulty, activation distance and loading priority are unchanged.

Utility counters count skipped magazine-update invocations and disabled
secondary-inspection behaviors. An update might not have been due to inspect;
its counter is not the number of actual animations prevented. No identities
are recorded. The dashboard still projects only its allowlisted fresh fields.

The existing host maintenance tick projects an allowlisted, fresh snapshot into
its read-only public-state directory. `/api/diagnostics` revalidates that schema;
unknown/stale/malformed/oversized/symlinked inputs never claim current counts.
The dashboard shows unavailable counts before a raid, rather than inventing zero.
Sleeping count is unavailable if the frozen FDA set cannot be read.

Enable only on headless with `BepInEx/config/codex.diagnostics.client.cfg`:

```ini
[Capture]
Enabled = true
```

Build with the locally pinned game references:

```sh
python3 player-dashboard/mods/raid-diagnostics/build.py --output /tmp/outlands-metrics
```

Tests also cover the 16 ownership combinations and frozen native patrol
contracts, per-frame allocation, GC resets and concurrent async timing. They
cover bounded frame statistics, percentile/hitch calculations, independent
raid counters, concurrent registration deduplication, atomic snapshots, log
rotation and oversized-input refusal. Live startup must show the activation log.
Warning mitigation, hitch improvement, creation timing and overhead under combat
still need the next raid. Idle FPS is not a raid benchmark.


Version 0.5.0 adds read-only aggregate movement, faction, visible/shootable target,
weapon readiness, ammunition and native weapon-shot event counters. Raw positions,
player names and profile IDs are not written to snapshots. The player dashboard
projects only bounded numeric combat counts; faction metadata stays local.
A shot notification is not proof of a hit. Registry removals are not proof of death.

On the authoritative headless process only, the module disables the selected
SAIN preset's three distant AI-versus-AI limit flags in memory. It validates the
frozen 4.4.3 field contract before changing any field, retries after preset loading,
and never writes the saved preset, changes human client files, aim, damage,
faction relations, or the separate FDA activation range. Policy success/error
counters make a failed application visible. This addresses a confirmed enabled
limiter, not a proven cause of every stationary/non-firing bot. A new raid must
verify the behavior and performance. Existing cosmetic inspection opt-outs remain.
