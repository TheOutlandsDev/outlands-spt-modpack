using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace Codex.Diagnostics.Client
{
    public static class CombatLimitPolicy
    {
        public static void Disable(object limiter)
        {
            if (limiter == null) throw new ArgumentNullException(nameof(limiter));
            var names = new[] { "LimitAIvsAIGlobal", "LimitAIvsAIVision", "LimitAIvsAIHearing" };
            var fields = new System.Reflection.FieldInfo[names.Length];
            for (int i = 0; i < names.Length; i++) {
                fields[i] = limiter.GetType().GetField(names[i]);
                if (fields[i] == null || fields[i].FieldType != typeof(bool) || fields[i].IsStatic)
                    throw new MissingFieldException("Frozen SAIN combat limiter field changed: " + names[i]);
            }
            // Validate all fields before the first write; never touch aim, damage,
            // faction relationships, spawn caps or the saved human preset files.
            foreach (var field in fields) field.SetValue(limiter, false);
        }
    }
    public sealed class FrameWindow
    {
        private readonly float[] _values = new float[4096];
        private readonly float[] _hitchMs = new float[16];
        private readonly double[] _hitchEnd = new double[16];
        private int _samples, _frames, _hitches, _largeHitches;
        private double _total;
        private float _max;
        public void Add(float seconds) { Add(seconds, double.NaN); }
        public void Add(float seconds, double monotonicEndSeconds)
        {
            if (float.IsNaN(seconds) || float.IsInfinity(seconds) || seconds <= 0) return;
            float ms = Math.Min(seconds * 1000, 60000);
            _frames++; _total += ms; _max = Math.Max(_max, ms);
            if (ms >= 50) _hitches++;
            if (ms >= 100)
            {
                int slot = _largeHitches % _hitchMs.Length;
                _hitchMs[slot] = ms; _hitchEnd[slot] = monotonicEndSeconds; _largeHitches++;
            }
            if (_samples < _values.Length) _values[_samples++] = ms;
        }
        public object SnapshotAndReset() { return SnapshotAndReset(DateTime.UtcNow, double.NaN); }
        public object SnapshotAndReset(DateTime utcEnd, double monotonicEndSeconds)
        {
            var values = new float[_samples]; Array.Copy(_values, values, _samples); Array.Sort(values);
            int retained = Math.Min(_largeHitches, _hitchMs.Length);
            var events = new FrameHitchSnapshot[retained];
            for (int i = 0; i < retained; i++)
            {
                int slot = (_largeHitches - retained + i) % _hitchMs.Length;
                double ageSeconds = monotonicEndSeconds - _hitchEnd[slot];
                bool validAge = !double.IsNaN(ageSeconds) && !double.IsInfinity(ageSeconds) && ageSeconds >= 0
                    && ageSeconds <= (utcEnd.Ticks - DateTime.MinValue.Ticks) / (double)TimeSpan.TicksPerSecond;
                events[i] = new FrameHitchSnapshot { frame_ms = Math.Round(_hitchMs[slot], 2),
                    age_ms = validAge ? (double?)Math.Round(ageSeconds * 1000, 2) : null,
                    ended_at_utc = validAge ? new DateTime(utcEnd.Ticks - (long)(ageSeconds * TimeSpan.TicksPerSecond), DateTimeKind.Utc).ToString("O") : null };
            }
            var snapshot = new FrameSnapshot { frames = _frames, percentile_samples = _samples,
                fps = _total > 0 ? Math.Round(_frames * 1000 / _total, 2) : 0,
                avg_frame_ms = _frames > 0 ? Math.Round(_total / _frames, 2) : 0,
                p95_frame_ms = _samples > 0 ? Math.Round(values[Math.Max(0, (int)Math.Ceiling(_samples * .95) - 1)], 2) : 0,
                max_frame_ms = Math.Round(_max, 2), hitches_over_50ms = _hitches,
                hitches_at_least_100ms = _largeHitches, omitted_hitch_events = _largeHitches - retained, hitch_events = events };
            _samples = _frames = _hitches = _largeHitches = 0; _total = 0; _max = 0;
            return snapshot;
        }
    }
    public sealed class FrameSnapshot
    {
        public int frames, percentile_samples, hitches_over_50ms, hitches_at_least_100ms, omitted_hitch_events;
        public double fps, avg_frame_ms, p95_frame_ms, max_frame_ms;
        public FrameHitchSnapshot[] hitch_events;
    }
    public sealed class FrameHitchSnapshot
    {
        public double frame_ms;
        public double? age_ms;
        public string ended_at_utc;
    }
    public sealed class RuntimeCounterWindow
    {
        private int _gc0, _gc1, _gc2;
        public RuntimeCounterWindow(int gc0, int gc1, int gc2) { _gc0 = gc0; _gc1 = gc1; _gc2 = gc2; }
        private static long? Delta(int current, int previous)
        {
            // A negative input is unavailable, rather than evidence of no GC.
            return current >= 0 && previous >= 0 ? (long?)Math.Max(0L, (long)current - previous) : null;
        }
        private static bool Reset(int current, int previous) { return current >= 0 && previous >= 0 && current < previous; }
        public RuntimeCounterSnapshot Snapshot(int gc0, int gc1, int gc2, long managedBytes)
        {
            var sample = new RuntimeCounterSnapshot { gc_gen0 = Delta(gc0, _gc0),
                gc_gen1 = Delta(gc1, _gc1), gc_gen2 = Delta(gc2, _gc2),
                managed_heap_bytes = Math.Max(0L, managedBytes), counters_reset = Reset(gc0, _gc0) || Reset(gc1, _gc1) || Reset(gc2, _gc2) };
            _gc0 = gc0; _gc1 = gc1; _gc2 = gc2;
            return sample;
        }
    }
    public sealed class RuntimeCounterSnapshot
    {
        public long? gc_gen0, gc_gen1, gc_gen2;
        public long managed_heap_bytes;
        public bool counters_reset;
    }
    public sealed class BotTimingWindow
    {
        private readonly object _lock = new object();
        private long _begun, _completed, _successful, _inFlight, _maxInFlight, _syncCount, _elapsedCount;
        private double _syncTotal, _syncMax, _elapsedTotal, _elapsedMax;
        private static bool Valid(double ms) { return !double.IsNaN(ms) && !double.IsInfinity(ms) && ms >= 0; }
        public void Begin() { lock (_lock) { _begun++; _inFlight++; _maxInFlight = Math.Max(_maxInFlight, _inFlight); } }
        public void SynchronousReturned(double milliseconds)
        {
            if (!Valid(milliseconds)) return;
            lock (_lock) { _syncCount++; _syncTotal += milliseconds; _syncMax = Math.Max(_syncMax, milliseconds); }
        }
        public void Complete(double elapsedMilliseconds, bool succeeded)
        {
            lock (_lock)
            {
                // A completed task may belong to a preceding sample window.
                _completed++; if (succeeded) _successful++; if (_inFlight > 0) _inFlight--;
                if (Valid(elapsedMilliseconds)) { _elapsedCount++; _elapsedTotal += elapsedMilliseconds; _elapsedMax = Math.Max(_elapsedMax, elapsedMilliseconds); }
            }
        }
        public BotTimingSnapshot SnapshotAndReset()
        {
            lock (_lock)
            {
                var snapshot = new BotTimingSnapshot { begun_calls = _begun, completed_calls = _completed,
                    successful_calls = _successful, failed_or_cancelled_calls = _completed - _successful,
                    in_flight = _inFlight, max_in_flight = _maxInFlight, synchronous_samples = _syncCount,
                    synchronous_mean_ms = _syncCount > 0 ? Math.Round(_syncTotal / _syncCount, 2) : 0, synchronous_max_ms = Math.Round(_syncMax, 2),
                    elapsed_samples = _elapsedCount, elapsed_mean_ms = _elapsedCount > 0 ? Math.Round(_elapsedTotal / _elapsedCount, 2) : 0, elapsed_max_ms = Math.Round(_elapsedMax, 2) };
                _begun = _completed = _successful = _syncCount = _elapsedCount = 0;
                _syncTotal = _syncMax = _elapsedTotal = _elapsedMax = 0; _maxInFlight = _inFlight;
                return snapshot;
            }
        }
    }
    public sealed class BotTimingSnapshot
    {
        public long begun_calls, completed_calls, successful_calls, failed_or_cancelled_calls, in_flight, max_in_flight, synchronous_samples, elapsed_samples;
        public double synchronous_mean_ms, synchronous_max_ms, elapsed_mean_ms, elapsed_max_ms;
    }
    public sealed class CreationCounter
    {
        private readonly object _lock = new object();
        private readonly HashSet<string> _ids = new HashSet<string>(StringComparer.Ordinal);
        public void Register(string id) { if (string.IsNullOrEmpty(id)) return; lock (_lock) { if (_ids.Count < 2048) _ids.Add(id); } }
        public int Count { get { lock (_lock) return _ids.Count; } }
    }
    public static class CreationCounters
    {
        private static readonly ConditionalWeakTable<object, CreationCounter> Values = new ConditionalWeakTable<object, CreationCounter>();
        public static CreationCounter For(object host) { return Values.GetValue(host, _ => new CreationCounter()); }
    }
}
