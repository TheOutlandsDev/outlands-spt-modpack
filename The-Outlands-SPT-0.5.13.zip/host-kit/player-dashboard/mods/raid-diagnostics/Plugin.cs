using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using BepInEx;
using BepInEx.Bootstrap;
using BepInEx.Configuration;
using Comfort.Common;
using EFT;
using Fika.Core.Main.GameMode;
using Fika.Core.Main.Players;
using FikaDynamicAI.Scripts;
using HarmonyLib;
using UnityEngine;

namespace Codex.Diagnostics.Client
{
    [BepInPlugin("codex.diagnostics.client", "Outlands Headless Raid Diagnostics", "0.5.0")]
    [BepInDependency("com.fika.core", "2.2.5")]
    [BepInDependency("com.fika.headless", "1.4.13")]
    [BepInDependency("com.lacyway.fda", "1.0.1")]
    [BepInDependency("me.sol.sain", "4.4.3")]
    public sealed class Plugin : BaseUnityPlugin
    {
        private readonly FrameWindow _frames = new FrameWindow();
        private readonly string _run = Guid.NewGuid().ToString("N");
        private BoundedWriter _writer;
        private Harmony _harmony;
        private ConfigEntry<bool> _enabled;
        private float _next;
        private int _errors, _measurementErrors;
        private bool _combatNotified;
        private FikaDynamicAIManager _fda;
        private RuntimeCounterWindow _runtime;
        private static int HookErrors;
        private static long ShotEvents;
        private static readonly ConditionalWeakTable<Player, MotionSample> Motion = new ConditionalWeakTable<Player, MotionSample>();
        private sealed class MotionSample { public Vector3 Position; public bool Seen; }
        private static Type SainGlobal;
        private static bool CombatLimitsApplied;
        private static int CombatPolicyErrors;

        private static void ApplyHostCombatPolicy()
        {
            CombatLimitsApplied = false;
            if (!Chainloader.PluginInfos.ContainsKey("com.fika.headless")) return;
            try
            {
                SainGlobal = SainGlobal ?? Type.GetType("SAIN.Preset.GlobalSettings.GlobalSettingsClass, SAIN", false);
                if (SainGlobal == null) return;
                var handler = Type.GetType("SAIN.Plugin.PresetHandler, SAIN", false);
                var preset = handler?.GetField("LoadedPreset", BindingFlags.Public | BindingFlags.Static)?.GetValue(null);
                var global = preset?.GetType().GetProperty("GlobalSettings")?.GetValue(preset, null);
                if (global == null) return;
                var general = SainGlobal.GetField("General")?.GetValue(global);
                var limiter = general?.GetType().GetField("AILimit")?.GetValue(general);
                if (limiter == null) throw new MissingMemberException("Frozen SAIN AI limiter is unavailable");
                CombatLimitPolicy.Disable(limiter);
                CombatLimitsApplied = true;
            }
            catch { CombatPolicyErrors++; }
        }
        private static void OnBotShot(Player __instance)
        {
            if (__instance is FikaBot && __instance.IsAI) Interlocked.Increment(ref ShotEvents);
        }
        private static readonly ConditionalWeakTable<object, BotTimingWindow> BotTimings = new ConditionalWeakTable<object, BotTimingWindow>();
        private static readonly FieldInfo Disabled = typeof(FikaDynamicAIManager).GetField("_disabledBots", BindingFlags.Instance | BindingFlags.NonPublic);

        private sealed class BotMeasurement
        {
            public long Started;
            public BotTimingWindow Timings;
            public CreationCounter Creations;
            public int Completed;
        }

        private static double Elapsed(long start) { return (Stopwatch.GetTimestamp() - start) * 1000.0 / Stopwatch.Frequency; }
        private static int GcCount(int generation)
        {
            try { return generation <= GC.MaxGeneration ? GC.CollectionCount(generation) : -1; }
            catch { return -1; }
        }

        private void Awake()
        {
            _enabled = Config.Bind("Capture", "Enabled", false, "Record bounded headless metrics without changing gameplay.");
            if (!_enabled.Value || !Chainloader.PluginInfos.ContainsKey("com.fika.headless")) return;
            try
            {
                _writer = new BoundedWriter(Path.Combine(BepInEx.Paths.GameRootPath, "Logs", "OutlandsRaidDiagnostics"));
                _harmony = new Harmony("outlands.headless.metrics");
                var target = AccessTools.Method(typeof(HostGameController), "CreateBot", new[] { typeof(GameWorld), typeof(Profile), typeof(Vector3) });
                if (target == null || target.ReturnType != typeof(Task<LocalPlayer>)) throw new MissingMethodException("Frozen Fika CreateBot contract is unavailable.");
                _harmony.Patch(target, prefix: new HarmonyMethod(typeof(Plugin), nameof(BeginBot)),
                    postfix: new HarmonyMethod(typeof(Plugin), nameof(CreatedBot)),
                    finalizer: new HarmonyMethod(typeof(Plugin), nameof(BotFailed)));
                AnimationRecovery.Install(_harmony, message => Logger.LogInfo(message));
                var shot = AccessTools.Method(typeof(Player), "OnMakingShot", new[] { typeof(IWeapon), typeof(Vector3) });
                if (shot == null) throw new MissingMethodException("Frozen shot notification contract is unavailable");
                _harmony.Patch(shot, postfix: new HarmonyMethod(typeof(Plugin), nameof(OnBotShot)));
                ApplyHostCombatPolicy();
                _runtime = new RuntimeCounterWindow(GcCount(0), GcCount(1), GcCount(2));
                Application.logMessageReceivedThreaded += OnLog;
                _next = Time.realtimeSinceStartup + 5;
                Logger.LogInfo("Outlands headless diagnostics 0.5.0 active: bounded frame hitch, GC and bot creation timings; no profile IDs.");
            }
            catch (Exception error)
            {
                _harmony?.UnpatchSelf(); _writer?.Dispose(); _writer = null;
                Logger.LogError("Headless diagnostics unavailable: " + error.Message);
            }
        }

        private static void BeginBot(HostGameController __instance, out BotMeasurement __state)
        {
            __state = null;
            try
            {
                var measurement = new BotMeasurement { Started = Stopwatch.GetTimestamp(),
                    Timings = BotTimings.GetValue(__instance, _ => new BotTimingWindow()), Creations = CreationCounters.For(__instance) };
                measurement.Timings.Begin(); __state = measurement;
            }
            catch { Interlocked.Increment(ref HookErrors); }
        }

        private static void FinishBot(BotMeasurement measurement, bool succeeded)
        {
            if (measurement == null || Interlocked.Exchange(ref measurement.Completed, 1) != 0) return;
            try { measurement.Timings.Complete(Elapsed(measurement.Started), succeeded); }
            catch { Interlocked.Increment(ref HookErrors); }
        }

        private static void CreatedBot(Task<LocalPlayer> __result, BotMeasurement __state)
        {
            if (__state == null) return;
            try
            {
                __state.Timings.SynchronousReturned(Elapsed(__state.Started));
                if (__result == null) { FinishBot(__state, false); return; }
                _ = __result.ContinueWith(task =>
                {
                    bool succeeded = false;
                    try
                    {
                        // Only managed identity/counter reads; no Unity calls or mutations.
                        succeeded = task.Status == TaskStatus.RanToCompletion && !ReferenceEquals(task.Result, null);
                        if (succeeded) __state.Creations.Register(task.Result.ProfileId);
                    }
                    catch { Interlocked.Increment(ref HookErrors); }
                    finally { FinishBot(__state, succeeded); }
                }, CancellationToken.None, TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Default);
            }
            catch { Interlocked.Increment(ref HookErrors); FinishBot(__state, false); }
        }

        private static Exception BotFailed(Exception __exception, BotMeasurement __state)
        {
            if (__exception != null) FinishBot(__state, false);
            return __exception;
        }

        private void OnLog(string message, string stack, LogType type)
        {
            if (type == LogType.Error || type == LogType.Exception || type == LogType.Assert) Interlocked.Increment(ref _errors);
        }

        private void Update()
        {
            if (_writer == null) return;
            var now = Time.realtimeSinceStartup;
            _frames.Add(Time.unscaledDeltaTime, now);
            if (now < _next) return;
            _next = now + 5;
            ApplyHostCombatPolicy();
            if (CombatLimitsApplied && !_combatNotified) { _combatNotified = true; Logger.LogInfo("Headless AI combat policy active: SAIN distant AI-versus-AI vision/hearing limits disabled in memory; FDA activation range and saved human presets retained."); }
            try
            {
            var utc = DateTime.UtcNow;
            object raid;
            try { raid = Raid(); }
            catch { Interlocked.Increment(ref _measurementErrors); raid = new { in_raid = false, available = false }; }
            var host = Singleton<IBotGame>.Instance as HostGameController;
            _writer.Offer(new { schemaVersion = 1, checkedAtUtc = utc.ToString("O"), runId = _run,
                performance = _frames.SnapshotAndReset(utc, now), raid,
                runtime = _runtime.Snapshot(GcCount(0), GcCount(1), GcCount(2), GC.GetTotalMemory(false)),
                botCreation = host != null ? BotTimings.GetValue(host, _ => new BotTimingWindow()).SnapshotAndReset() : null,
                utilityAnimations = AnimationRecovery.Snapshot(),
                botHookErrors = Volatile.Read(ref HookErrors),
                combatPolicy = new { sain_ai_vs_ai_limits_disabled = CombatLimitsApplied, errors = CombatPolicyErrors },
                unityErrors = Volatile.Read(ref _errors), measurementErrors = Volatile.Read(ref _measurementErrors),
                droppedSnapshots = _writer.Dropped, writerErrors = _writer.Errors });
            }
            catch { Interlocked.Increment(ref _measurementErrors); }
        }

        private object Raid()
        {
            var world = Singleton<GameWorld>.Instance;
            var host = Singleton<IBotGame>.Instance as HostGameController;
            if (world == null || host == null || !host.RaidStarted)
            { _fda = null; return new { in_raid = false, available = true }; }
            if (_fda == null) _fda = UnityEngine.Object.FindObjectOfType<FikaDynamicAIManager>();
            var disabled = _fda != null && Disabled != null ? Disabled.GetValue(_fda) as HashSet<FikaBot> : null;
            int alive = 0, active = 0, sleeping = 0, other = 0, dead = 0, enemy = 0, checkedBots = 0;
            int moving = 0, measuredMotion = 0, visible = 0, shootable = 0, ready = 0, ammo = 0;
            var roles = new Dictionary<string, int>();
            foreach (var pair in host.Bots)
            {
                if (++checkedBots > 2048) break;
                var player = pair.Value;
                if (player == null || player.HealthController == null || !player.HealthController.IsAlive) { dead++; continue; }
                var owner = player.AIData?.BotOwner;
                if (owner != null && owner.IsDead) { dead++; continue; }
                alive++;
                var role = player.Profile?.Info?.Settings?.Role.ToString() ?? "unknown";
                if (roles.ContainsKey(role)) roles[role]++; else if (roles.Count < 64) roles[role] = 1;
                var motion = Motion.GetValue(player, _ => new MotionSample());
                if (motion.Seen) { measuredMotion++; if ((player.Position - motion.Position).sqrMagnitude >= 0.25f) moving++; }
                motion.Position = player.Position; motion.Seen = true;
                if (owner?.Memory?.GoalEnemy != null) {
                    if (owner.Memory.GoalEnemy.IsVisible) visible++;
                    if (owner.Memory.GoalEnemy.CanShoot) shootable++;
                }
                if (owner?.WeaponManager?.CurrentWeapon != null) {
                    try {
                        if (owner.WeaponManager.IsWeaponReady) ready++;
                        if (owner.WeaponManager.HaveBullets) ammo++;
                    } catch { /* Newly constructed/transitioning hands are unavailable in this sample. */ }
                }
                if (disabled != null && player is FikaBot fika && disabled.Contains(fika)) sleeping++;
                else if (player.gameObject.activeSelf && owner != null && owner.BotState == EBotState.Active)
                { active++; if (owner.Memory?.GoalEnemy != null) enemy++; }
                else other++;
            }
            return new { in_raid = true, available = true, map = world.LocationId,
                bot_instances_created = CreationCounters.For(host).Count, registered_bots = host.Bots.Count,
                alive_bots = alive, active_bots = active, fda_sleeping_bots = sleeping,
                sleeping_count_available = disabled != null, other_inactive_bots = other,
                dead_registered_bots = dead, active_bots_with_goal_enemy = enemy,
                registry_truncated = host.Bots.Count > 2048,
                combat = new { moving_bots = moving, motion_samples = measuredMotion,
                    bots_with_visible_enemy = visible, bots_with_shootable_enemy = shootable,
                    weapon_ready_bots = ready, bots_with_ammunition = ammo,
                    weapon_shot_events_total = Interlocked.Read(ref ShotEvents), roles } };
        }

        private void OnDestroy()
        {
            Application.logMessageReceivedThreaded -= OnLog;
            _harmony?.UnpatchSelf(); _writer?.Dispose(); _writer = null;
        }
    }
}
