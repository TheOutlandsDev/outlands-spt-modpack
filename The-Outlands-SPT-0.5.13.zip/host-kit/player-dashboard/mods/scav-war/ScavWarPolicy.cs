using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading.Tasks;
using FikaServer.Models.Fika.Routes.Headless;
using FikaServer.Services.Headless;
using FikaServer.Services;
using FikaServer.Helpers;
using SPTarkov.DI.Annotations;
using SPTarkov.Reflection.Patching;
using SPTarkov.Server.Core.DI;
using SPTarkov.Server.Core.Models.Eft.Match;
using SPTarkov.Server.Core.Models.Spt.Mod;
using SPTarkov.Server.Core.Models.Utils;

namespace Outlands.ScavWar;

public record ModMetadata : AbstractModMetadata
{
    public override string ModGuid { get; init; } = "outlands.scav-war";
    public override string Name { get; init; } = "Outlands Headless Scav War";
    public override string Author { get; init; } = "TheOutlandsDev";
    public override List<string>? Contributors { get; init; }
    public override SemanticVersioning.Version Version { get; init; } = new(1, 2, 0);
    public override SemanticVersioning.Range SptVersion { get; init; } = new("=4.0.13");
    public override List<string>? Incompatibilities { get; init; }
    public override Dictionary<string, SemanticVersioning.Range>? ModDependencies { get; init; } =
        new() { ["Fika"] = new("=2.2.4") };
    public override string? Url { get; init; }
    public override bool? IsBundleMod { get; init; } = false;
    public override string License { get; init; } = "MIT";
}

[Injectable(TypePriority = OnLoadOrder.PostSptModLoader + 1000)]
public sealed class ScavWarLoader(ISptLogger<ScavWarLoader> logger, HeadlessHelper headlessHelper, MatchService matchService) : IOnLoad
{
    private readonly HeadlessScavWarPatch _patch = new();
    private readonly HeadlessBotCapPatch _capPatch = new();

    public Task OnLoad()
    {
        _patch.Enable();
        HeadlessBotCapPatch.Resolve = session => HeadlessBotCapPatch.MatchCap(headlessHelper, matchService, session);
        HeadlessBotCapPatch.Log = message => logger.Info(message);
        _capPatch.Enable();
        if (!_patch.IsActive || !_capPatch.IsActive)
        {
            throw new InvalidOperationException("Outlands Scav War hook did not activate.");
        }

        logger.Success("[Outlands.ScavWar] Scav War is disabled for every Fika headless raid; normal Scav relations and configured infected hostility remain active.");
        logger.Success("[Outlands.ScavWar] Headless default bot-cap lookup uses the current match map limit; hook active.");
        return Task.CompletedTask;
    }
}

public sealed class HeadlessScavWarPatch : AbstractPatch
{
    protected override MethodBase GetTargetMethod() =>
        typeof(HeadlessService).GetMethod(
            nameof(HeadlessService.StartHeadlessRaid),
            new[] { typeof(string), typeof(string), typeof(StartHeadlessRequest) })
        ?? throw new MissingMethodException("Fika 2.2.4 headless start method was not found.");

    [PatchPrefix]
    public static void Prefix(StartHeadlessRequest info)
    {
        ArgumentNullException.ThrowIfNull(info);
        info.BotSettings ??= new BotSettings();
        info.BotSettings.IsScavWars = false;
    }
}
