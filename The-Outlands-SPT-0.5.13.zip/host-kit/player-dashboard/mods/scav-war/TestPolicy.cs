using System;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Loader;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading.Tasks;
using FikaServer.Models.Fika.Routes.Headless;
using FikaServer.Services.Headless;
using Outlands.ScavWar;
using SPTarkov.Server.Core.Models.Utils;
using SPTarkov.Server.Core.Callbacks;
using SPTarkov.Server.Core.Models.Common;
using System.Collections.Concurrent;
using FikaServer.Helpers;
using FikaServer.Services;
using FikaServer.Models.Fika;
using FikaServer.Models.Fika.Headless;
using SPTarkov.Server.Core.Models.Eft.Common;

internal static class Program
{
    private static async Task Main(string[] args)
    {
        string core = Path.Combine(args[0], "runtime", "SPT");
        AssemblyLoadContext.Default.Resolving += (_, name) =>
        {
            foreach (string folder in new[] { core, Path.Combine(core, "user", "mods", "fika-server") })
            {
                string file = Path.Combine(folder, name.Name + ".dll");
                if (File.Exists(file)) return AssemblyLoadContext.Default.LoadFromAssemblyPath(file);
            }
            return null;
        };
        await Run();
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private static async Task Run()
    {
        Require(HeadlessBotCapPatch.TryCap(HeadlessBotCapPatch.FallbackUrl, 32, out int cap) && cap == 32, "Headless Customs must use 32.");
        Require(HeadlessBotCapPatch.TryCap(HeadlessBotCapPatch.FallbackUrl, 14, out cap) && cap == 14, "Factory must retain its smaller map limit.");
        foreach (int? invalid in new int?[] { null, -1, 0, 65, int.MaxValue })
            Require(!HeadlessBotCapPatch.TryCap(HeadlessBotCapPatch.FallbackUrl, invalid, out _), "Unknown/invalid limits must remain native.");
        Require(!HeadlessBotCapPatch.TryCap("/singleplayer/settings/bot/maxCap/bigmap", 32, out _), "Named-map calls stay native.");
        var callback = (BotCallbacks)RuntimeHelpers.GetUninitializedObject(typeof(BotCallbacks));
        var capPatch = new HeadlessBotCapPatch();
        MongoId headless = "000000000000000000000001";
        var headlessService = new HeadlessService(DispatchProxy.Create<ISptLogger<HeadlessService>, NoOpLogger>(), null!, null!, null!, null!);
        var helper = new HeadlessHelper(null!, null!, headlessService, null!, null!);
        helper.HeadlessClients.TryAdd(headless, null!);
        var matches = (MatchService)RuntimeHelpers.GetUninitializedObject(typeof(MatchService));
        matches.Matches = new ConcurrentDictionary<MongoId, FikaMatch>();
        matches.Matches[headless] = new FikaMatch { RaidConfig = null!, LocationData = new LocationBase { Id = "bigmap", BotMax = 32 } };
        Require(HeadlessBotCapPatch.MatchCap(helper, matches, headless) == 32, "Real Fika match lookup must use its LocationData cap.");
        Require(HeadlessBotCapPatch.MatchCap(helper, matches, "000000000000000000000002") == null, "Unregistered human must not resolve a headless cap.");
        HeadlessBotCapPatch.Resolve = session => HeadlessBotCapPatch.MatchCap(helper, matches, session);
        capPatch.Enable();
        try
        {
            Require(capPatch.IsActive, "Real cap callback patch must activate.");
            Require(await callback.GetBotCap(HeadlessBotCapPatch.FallbackUrl, null!, headless) == "32", "Real callback must return the map cap without native service dependencies.");
            ValueTask<string> result = ValueTask.FromResult("native");
            Require(HeadlessBotCapPatch.Prefix(HeadlessBotCapPatch.FallbackUrl, "000000000000000000000002", ref result), "Non-headless sessions stay native.");
            HeadlessBotCapPatch.Resolve = _ => throw new InvalidOperationException();
            Require(HeadlessBotCapPatch.Prefix(HeadlessBotCapPatch.FallbackUrl, headless, ref result), "Resolver failure stays native.");
        }
        finally { capPatch.Disable(); HeadlessBotCapPatch.Resolve = null; }
        const string fixture = """
            {"headlessSessionID":"000000000000000000000001","locationId":"factory4_day",
             "metabolismDisabled":false,"botSettings":{"isScavWars":true,"botAmount":"AsOnline"},
             "wavesSettings":{"botAmount":"AsOnline","botDifficulty":"AsOnline","isBosses":true,"isTaggedAndCursed":false},
             "timeAndWeatherSettings":{"hourOfDay":18,"isRandomWeather":true},"useEvent":true}
            """;
        StartHeadlessRequest request = JsonSerializer.Deserialize<StartHeadlessRequest>(fixture)!;
        JsonNode expected = JsonNode.Parse(JsonSerializer.Serialize(request))!;
        expected["botSettings"]!["isScavWars"] = false;
        HeadlessScavWarPatch.Prefix(request);
        Require(JsonNode.DeepEquals(expected, JsonNode.Parse(JsonSerializer.Serialize(request))),
            "Policy must change only isScavWars, preserving every other serialized setting.");
        HeadlessScavWarPatch.Prefix(request);
        Require(JsonNode.DeepEquals(expected, JsonNode.Parse(JsonSerializer.Serialize(request))), "Policy must be idempotent.");

        var missing = new StartHeadlessRequest();
        HeadlessScavWarPatch.Prefix(missing);
        Require(missing.BotSettings?.IsScavWars == false, "Missing botSettings must get Scav War disabled.");
        try
        {
            HeadlessScavWarPatch.Prefix(null!);
            throw new Exception("Null request must fail before changing anything.");
        }
        catch (ArgumentNullException) { }

        var metadata = new ModMetadata();
        Require(metadata.SptVersion.IsSatisfied(new SemanticVersioning.Version(4, 0, 13)), "SPT version pin must accept 4.0.13.");
        Require(!metadata.SptVersion.IsSatisfied(new SemanticVersioning.Version(4, 0, 14)), "SPT version pin must reject a changed version.");
        Require(metadata.ModDependencies!["Fika"].IsSatisfied(new SemanticVersioning.Version(2, 2, 4)), "Fika pin must accept 2.2.4.");
        Require(!metadata.ModDependencies["Fika"].IsSatisfied(new SemanticVersioning.Version(2, 2, 5)), "Fika pin must reject a changed version.");

        // Exercise the real Harmony hook on the real Fika method. This isolated service
        // has no registered headless clients or sockets, so its normal guard returns
        // without starting a raid or accessing the running server.
        var logger = DispatchProxy.Create<ISptLogger<HeadlessService>, NoOpLogger>();
        var service = new HeadlessService(logger, null!, null!, null!, null!);
        var patch = new HeadlessScavWarPatch();
        patch.Enable();
        try
        {
            Require(patch.IsActive, "Harmony hook must be active.");
            var hooked = JsonSerializer.Deserialize<StartHeadlessRequest>(fixture)!;
            string? result = await service.StartHeadlessRaid("000000000000000000000001", "000000000000000000000002", hooked);
            Require(result == null && service.HeadlessClients.Count == 0, "Isolated hook test must not start a raid.");
            Require(hooked.BotSettings?.IsScavWars == false, "Real Fika start method must run the prefix.");
        }
        finally
        {
            patch.Disable();
        }
        Console.WriteLine("PASS: Scav War preservation, exact version pins, real Fika hook; real match map lookup, headless/human separation, bounded caps, fallback handling, and real SPT callback hook.");
    }

    private static void Require(bool condition, string message)
    {
        if (!condition) throw new Exception(message);
    }
}

public class NoOpLogger : DispatchProxy
{
    protected override object? Invoke(MethodInfo? method, object?[]? args) => null;
}
