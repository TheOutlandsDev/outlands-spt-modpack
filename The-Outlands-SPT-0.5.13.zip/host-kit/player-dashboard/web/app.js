/* Read-only browser UI. All server-supplied strings are inserted as text. */
(() => {
  'use strict';

  const POLL_INTERVAL = 5000;
  const STALE_AFTER = 20000;
  const $ = (id) => document.getElementById(id);
  const state = { data: null, lastSuccess: null, lastError: null, pending: false, timer: null, toastTimer: null };
  const numberFormat = new Intl.NumberFormat();
  const clockFormat = new Intl.DateTimeFormat(undefined, { hour: '2-digit', minute: '2-digit' });

  function element(tag, className, text) {
    const result = document.createElement(tag);
    if (className) result.className = className;
    if (text !== undefined && text !== null) result.textContent = String(text);
    return result;
  }

  function text(id, value) { $(id).textContent = value === undefined || value === null ? '—' : String(value); }
  function array(value) { return Array.isArray(value) ? value : []; }
  function validNumber(value) { return typeof value === 'number' && Number.isFinite(value); }
  function metric(id, value) { text(id, validNumber(value) ? numberFormat.format(value) : '—'); }
  function string(value, fallback = '') { return value === undefined || value === null || value === '' ? fallback : String(value); }
  function titleCase(value) { return string(value).replace(/[_-]+/g, ' ').replace(/\b\w/g, (char) => char.toUpperCase()); }
  function validTime(value) { if (!value) return null; const date = new Date(value); return Number.isNaN(date.valueOf()) ? null : date; }
  function isConnected(client) { return client?.connected === true; }

  function timeAgo(value) {
    const date = validTime(value);
    if (!date) return '—';
    const seconds = Math.max(0, Math.floor((Date.now() - date.valueOf()) / 1000));
    if (seconds < 10) return 'Just now';
    if (seconds < 60) return `${seconds}s ago`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  }

  function duration(value) {
    if (!validNumber(value)) return null;
    const seconds = Math.max(0, Math.floor(value));
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    if (days) return `${days}d ${hours}h`;
    if (hours) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
  }

  function elapsed(value) {
    const date = validTime(value);
    return date ? duration(Math.max(0, (Date.now() - date.valueOf()) / 1000)) : null;
  }

  function pill(label, tone = 'neutral') {
    const result = element('span', `status-pill ${tone}`);
    result.append(element('span', 'status-dot'), element('span', '', label));
    return result;
  }

  function playerStatus(player) {
    const status = string(player.status).toLowerCase().replace(/[_ ]/g, '-');
    if (['raid', 'in-raid', 'inraid', 'playing', 'started', 'in-game', 'ingame'].includes(status)) return { label: 'In raid', tone: 'busy' };
    if (['lobby', 'menu', 'in-menu', 'inmenu', 'hideout', 'stash'].includes(status)) return { label: status === 'hideout' ? 'Hideout' : 'In lobby', tone: 'good' };
    if (['offline', 'disconnected'].includes(status)) return { label: 'Offline', tone: 'neutral' };
    if (status === 'loading' || status === 'matching') return { label: titleCase(status), tone: 'busy' };
    if (status === 'online' || status === 'connected') return { label: 'Online', tone: 'good' };
    return { label: status ? titleCase(status) : 'Online', tone: 'good' };
  }

  function headlessState(client) {
    const raw = client.state;
    const normalized = string(raw).toLowerCase().replace(/[_ ]/g, '-');
    if (!isConnected(client)) return { label: 'Disconnected', tone: 'error', ready: false, detail: 'No active connection' };
    if (normalized === 'ready') return { label: 'Ready', tone: 'good', ready: true, detail: 'Waiting for the next raid' };
    if (raw === 2 || ['in-raid', 'inraid', 'raid', 'busy', 'playing'].includes(normalized)) return { label: 'In raid', tone: 'busy', ready: false, detail: string(client.map, 'Hosting an active raid') };
    if (normalized === 'loading') return { label: 'Loading raid', tone: 'busy', ready: false, detail: client.map ? `Preparing ${string(client.map)}` : 'Preparing the assigned raid' };
    if (['starting', 'initializing'].includes(normalized) || raw === 0) return { label: 'Starting', tone: 'busy', ready: false, detail: 'Preparing the headless client' };
    return { label: raw === undefined || raw === null ? 'Connected' : titleCase(normalized), tone: 'neutral', ready: false, detail: 'Connected to the Fika server' };
  }

  function serviceState(status) {
    const normalized = string(status).toLowerCase();
    if (['healthy', 'running', 'online', 'up', 'ready', 'ok'].includes(normalized)) return { label: normalized === 'running' ? 'Running' : 'Healthy', tone: 'good' };
    if (['degraded', 'starting', 'unhealthy', 'warning', 'restarting'].includes(normalized)) return { label: titleCase(normalized), tone: 'busy' };
    if (['stopped', 'down', 'offline', 'error', 'failed', 'exited', 'missing'].includes(normalized)) return { label: titleCase(normalized), tone: 'error' };
    return { label: titleCase(normalized) || 'Unknown', tone: 'neutral' };
  }

  function renderPlayers(players) {
    const body = $('players-body');
    body.replaceChildren();
    for (const player of players) {
      const row = element('tr');
      const nameCell = element('td');
      const identity = element('div', 'player-identity');
      const name = string(player.nickname, 'Unnamed player');
      const initials = name.replace(/[^\p{L}\p{N}]/gu, '').slice(0, 2).toUpperCase() || '?';
      const avatar = element('span', 'player-avatar', initials);
      avatar.setAttribute('aria-hidden', 'true');
      const info = element('div');
      info.append(element('span', 'player-name', name));
      const meta = [];
      if (player.level !== undefined && player.level !== null) meta.push(`Level ${string(player.level)}`);
      if (player.side) meta.push(string(player.side).toUpperCase());
      info.append(element('span', 'player-meta', meta.length ? meta.join(' · ') : 'Fika player'));
      identity.append(avatar, info);
      nameCell.append(identity);
      const statusCell = element('td');
      const status = playerStatus(player);
      statusCell.append(pill(status.label, status.tone));
      const locationCell = element('td');
      locationCell.append(element('span', 'player-location', string(player.map, status.label === 'In raid' ? 'Map not reported' : '—')));
      if (player.activity && string(player.activity).toLowerCase() !== string(player.status).toLowerCase()) locationCell.append(element('span', 'player-activity', player.activity));
      const seenCell = element('td', 'seen-column', timeAgo(player.lastSeen));
      const seen = validTime(player.lastSeen);
      if (seen) seenCell.title = seen.toLocaleString();
      row.append(nameCell, statusCell, locationCell, seenCell);
      body.append(row);
    }
    $('players-empty').classList.toggle('hidden', players.length > 0);
    text('players-empty-title', 'No players reported online');
    text('players-empty-detail', 'Players appear here as Fika reports their presence.');
    text('player-list-count', players.length);
  }

  function renderRaids(raids) {
    const list = $('raid-list');
    list.replaceChildren();
    for (const raid of raids) {
      const card = element('article', 'raid-card');
      const top = element('div', 'raid-card-top');
      const map = element('div');
      map.append(element('h3', 'raid-map', string(raid.map, 'Map not reported')));
      const members = array(raid.players);
      const subtitle = [`${members.length} ${members.length === 1 ? 'player' : 'players'}`];
      if (raid.startedAt && validTime(raid.startedAt)) subtitle.push(`Started ${clockFormat.format(validTime(raid.startedAt))}`);
      map.append(element('div', 'raid-subtitle', subtitle.join(' · ')));
      const badge = element('div');
      const status = string(raid.status, 'In raid');
      badge.append(pill(titleCase(status), 'busy'));
      const time = elapsed(raid.startedAt);
      if (time) badge.append(element('div', 'raid-card-time', `${time} elapsed`));
      top.append(map, badge);
      const bottom = element('div', 'raid-card-bottom');
      const memberList = element('div', 'raid-members');
      for (const member of members) memberList.append(element('span', 'member-chip', typeof member === 'string' ? member : string(member?.nickname, 'Unnamed player')));
      if (!members.length) memberList.append(element('span', 'raid-subtitle', 'Waiting for player details'));
      bottom.append(memberList);
      if (raid.headlessId) {
        const client = array(state.data?.headless).find((item) => item.id === raid.headlessId);
        bottom.append(element('div', 'raid-headless', `Headless · ${string(client?.name, 'Connected host')}`));
      }
      card.append(top, bottom);
      if (raid.matchStalePossible) card.append(element('p', 'raid-caveat', 'Fika may retain this session after an unclean disconnect.'));
      list.append(card);
    }
    $('raids-empty').classList.toggle('hidden', raids.length > 0);
    text('raids-empty-title', 'No active raids');
    text('raids-empty-detail', 'Raid details appear when your squad deploys.');
    text('raid-list-count', raids.length);
  }

  function renderHeadless(clients) {
    const list = $('headless-list');
    list.replaceChildren();
    for (const client of clients) {
      const card = element('article', 'headless-card');
      const top = element('div', 'headless-card-top');
      const identity = element('div', 'headless-identity');
      const status = headlessState(client);
      identity.append(element('span', 'headless-name', string(client.name, 'Fika headless')), element('span', 'headless-info', status.detail));
      const badge = element('span', `headless-status ${status.tone}`);
      badge.append(element('span', 'status-dot'), element('span', '', status.label));
      top.append(identity, badge);
      card.append(top);
      const players = array(client.players);
      if (players.length) card.append(element('div', 'headless-players', players.map((player) => typeof player === 'string' ? player : string(player?.nickname, 'Unnamed player')).join(', ')));
      list.append(card);
    }
    $('headless-empty').classList.toggle('hidden', clients.length > 0);
    text('headless-empty', 'No headless clients reported.');
    text('headless-total', `${clients.length} ${clients.length === 1 ? 'client' : 'clients'}`);
    const ready = clients.filter((client) => headlessState(client).ready).length;
    metric('headless-count', ready);
    text('headless-metric-description', clients.length ? `${ready} of ${clients.length} available to host` : 'No headless clients reported');
  }

  function renderServices(services) {
    const list = $('service-list');
    list.replaceChildren();
    for (const service of services) {
      const row = element('li', 'service-item');
      const info = element('div');
      info.append(element('div', 'service-name', string(service.name, 'Service')));
      if (service.detail) info.append(element('div', 'service-detail', service.detail));
      const status = serviceState(service.status);
      row.append(info, pill(status.label, status.tone));
      list.append(row);
    }
    $('services-empty').classList.toggle('hidden', services.length > 0);
    const states = services.map((service) => serviceState(service.status).tone);
    const tone = !states.length ? 'neutral' : states.includes('error') ? 'error' : states.includes('busy') || states.includes('neutral') ? 'busy' : 'good';
    const badge = pill(tone === 'good' ? 'Healthy' : tone === 'error' ? 'Needs attention' : tone === 'busy' ? 'Degraded' : 'Unknown', tone);
    badge.id = 'host-overall';
    $('host-overall').replaceWith(badge);
  }

  function renderActivity(activity) {
    const list = $('activity-list');
    list.replaceChildren();
    for (const event of activity.slice(0, 20)) {
      const row = element('li', 'activity-item');
      const type = string(event.type).toLowerCase();
      const tone = type.includes('raid') ? 'raid' : /leave|disconnect|offline/.test(type) ? 'leave' : /error|fail/.test(type) ? 'error' : '';
      const symbol = tone === 'raid' ? '↗' : tone === 'leave' ? '−' : tone === 'error' ? '!' : '+';
      const marker = element('span', `activity-marker ${tone}`, symbol);
      marker.setAttribute('aria-hidden', 'true');
      const time = element('time', 'activity-time', timeAgo(event.at));
      const at = validTime(event.at);
      if (at) { time.dateTime = at.toISOString(); time.title = at.toLocaleString(); }
      row.append(marker, element('span', 'activity-message', string(event.message, titleCase(type) || 'Server activity')), time);
      list.append(row);
    }
    $('activity-empty').classList.toggle('hidden', activity.length > 0);
  }

  function renderConnection(server) {
    const url = string(server.backendUrl);
    $('launcher-url').value = url;
    $('copy-url').disabled = !url;
    text('server-name', string(server.name, 'node-01'));
    text('server-version', string(server.version, 'SPT / Fika'));
    const uptime = duration(server.uptimeSeconds);
    text('host-uptime', uptime ? `Up ${uptime}` : '');
    const management = $('dockhand-link');
    let safe = null;
    try { const parsed = new URL(server.managementUrl); if (['http:', 'https:'].includes(parsed.protocol)) safe = parsed.href; } catch { /* No management link was reported. */ }
    management.classList.toggle('hidden', !safe);
    if (safe) management.href = safe;
    else management.removeAttribute('href');
  }

  function render(data) {
    const players = array(data.players);
    const raids = array(data.raids);
    const summary = data.summary && typeof data.summary === 'object' ? data.summary : {};
    metric('online-count', validNumber(summary.onlinePlayers) ? summary.onlinePlayers : Array.isArray(data.players) ? players.length : null);
    metric('in-raid-count', validNumber(summary.inRaidPlayers) ? summary.inRaidPlayers : Array.isArray(data.players) ? players.filter((player) => playerStatus(player).label === 'In raid').length : null);
    metric('raid-count', validNumber(summary.activeRaids) ? summary.activeRaids : Array.isArray(data.raids) ? raids.length : null);
    renderPlayers(players);
    renderRaids(raids);
    renderHeadless(array(data.headless));
    renderServices(array(data.services));
    renderActivity(array(data.activity));
    renderConnection(data.server && typeof data.server === 'object' ? data.server : {});
    renderFreshness();
  }

  function renderFreshness() {
    const updated = validTime(state.data?.updatedAt) || state.lastSuccess;
    const stale = state.data?.stale === true || Boolean(state.lastError) || Boolean(updated && Date.now() - updated.valueOf() > STALE_AFTER);
    const errorList = array(state.data?.errors).map((item) => typeof item === 'string' ? item : string(item?.message, item?.detail)).filter(Boolean);
    const badge = $('connection-badge');
    badge.className = `status-pill ${!state.data ? state.lastError ? 'error' : 'neutral' : stale ? 'busy' : 'good'}`;
    text('connection-label', !state.data ? state.lastError ? 'Unavailable' : 'Connecting' : stale ? 'Data delayed' : 'Live');
    text('last-updated', updated ? `Updated ${timeAgo(updated)}` : state.lastError ? 'Waiting for the server' : 'Waiting for the first update');
    $('last-updated').title = updated ? updated.toLocaleString() : '';
    const hasNotice = Boolean(state.lastError) || state.data?.stale === true || errorList.length > 0 || stale;
    $('error-banner').classList.toggle('hidden', !hasNotice);
    if (state.lastError) {
      text('error-title', state.data ? 'Live updates interrupted' : 'Unable to reach the dashboard server');
      text('error-detail', state.data ? 'Showing the last received status. Retrying automatically every 5 seconds.' : 'No live player data is available yet. Retrying automatically every 5 seconds.');
    } else if (errorList.length) {
      text('error-title', 'Some server information is unavailable');
      text('error-detail', errorList.join(' · '));
    } else if (stale) {
      text('error-title', 'Waiting for fresh server data');
      text('error-detail', 'These values may be out of date. The dashboard is checking for an update.');
    }
  }

  function renderMaintenance(data) {
    const fresh = data && data.stale === false;
    text('maintenance-state', fresh ? titleCase(data.state) : 'Status unavailable');
    text('maintenance-message', fresh ? string(data.message, 'Existing raids finish before maintenance starts.') : 'The maintenance worker has not reported a fresh status.');
    const next = fresh ? validTime(data.nextRestartAtUtc) : null;
    const formatter = new Intl.DateTimeFormat(undefined, { timeZone: 'America/New_York', weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit', timeZoneName: 'short' });
    text('maintenance-next', next ? `Next: ${formatter.format(next)}` : '');
  }

  let contentSelection = null;
  let lastContentData = null;
  let contentRenderKey = null;
  function renderContent(data) {
    const names = { bigmap: 'Customs', woods: 'Woods', shoreline: 'Shoreline', interchange: 'Interchange', rezervbase: 'Reserve', lighthouse: 'Lighthouse', tarkovstreets: 'Streets', sandbox: 'Ground Zero', sandbox_high: 'Ground Zero 21+', laboratory: 'Labs', factory4_day: 'Factory', factory4_night: 'Factory night' };
    const maps = (values) => array(values).map((value) => names[value] || value).join(' + ');
    lastContentData = data;
    const renderKey = JSON.stringify([data?.available, data?.day, data?.nextSevenDays, data?.maps, data?.rolloverPending, contentSelection]);
    if (renderKey === contentRenderKey) return;
    contentRenderKey = renderKey;
    for (const id of ['content-days', 'content-operations', 'content-goals']) $(id).replaceChildren();
    for (const id of ['content-briefing', 'content-challenges']) $(id).classList.add('hidden');
    if (!data?.available) {
      text('content-title', 'Content calendar');
      text('content-detail', 'Waiting for the server to publish its active theme.');
      text('content-infection', '');
      text('content-mode', 'Unavailable');
      $('content-mode').className = 'status-pill neutral';
      text('content-activation', 'Waiting for fresh event status. No scheduled bonuses are confirmed active.');
      return;
    }
    const days = [data.day, ...array(data.nextSevenDays)];
    const selected = days.find(day => day.date === contentSelection) || data.day;
    const preview = selected.date !== data.day.date;
    const weekday = value => new Intl.DateTimeFormat(undefined, {weekday:'short', month:'short', day:'numeric', timeZone:'UTC'}).format(new Date(`${value}T12:00:00Z`));
    text('content-title', selected.theme);
    text('content-mode', preview ? 'Scheduled preview' : data.rolloverPending ? 'Active · rollover waiting' : 'Active now');
    $('content-mode').className = `status-pill ${preview || data.rolloverPending ? 'busy' : 'good'}`;
    text('content-detail', `${weekday(selected.date)} · ${maps(selected.hotspots)} · Halloween stays active. Scav War is off; Scavs fight infected AI.`);
    text('content-activation', preview ? 'This is a forecast. It activates after that day’s idle maintenance at 5 AM Eastern; active raids finish first.' : data.rolloverPending ? 'The previous plan remains active while maintenance waits. Forecast bonuses are not active yet.' : 'Active settings remain fixed until the next idle restart at 5 AM Eastern. Bot caps and AI aim settings stay unchanged.');
    for (const [index, day] of days.entries()) {
      const button = element('button', 'content-day');
      button.type = 'button'; button.setAttribute('aria-pressed', String(day.date === selected.date));
      button.append(element('span', 'calendar-date', index === 0 ? `Active · ${weekday(day.date)}` : weekday(day.date)), element('strong', '', day.theme), element('span', 'calendar-maps', maps(day.hotspots)));
      button.addEventListener('click', () => { contentSelection = day.date; renderContent(lastContentData); });
      $('content-days').append(button);
    }
    if (selected.briefing) {
      $('content-briefing').classList.remove('hidden');
      text('content-campaign', `CAMPAIGN PHASE · ${selected.campaign}`);
      text('content-story', selected.briefing);
    }
    const percentage = value => Number(value.toFixed(2)).toLocaleString(undefined, {maximumFractionDigits:2});
    for (const operation of array(selected.operations)) {
      const card = element('article', 'operation-card');
      card.append(element('div', 'eyebrow', `${operation.role} · ${names[operation.map] || operation.map}`), element('h3', '', operation.title));
      const effects = operation.modifiers;
      const list = element('ul', 'operation-effects');
      const effectRows = [
        `Existing PMC wave chance +${effects.pmcChanceBonus} percentage points`,
        `Eligible later PMC waves up to ${effects.pmcAdvanceSeconds}s earlier`,
        `Timed Scav windows up to ${effects.scavAdvanceSeconds}s earlier, when present`,
        `Location loot chance +${percentage((effects.lootMultiplier - 1) * 100)}%`
      ];
      if (effects.bossChanceBonus > 0) effectRows.push(`Enabled boss wave chance +${effects.bossChanceBonus} percentage points`);
      effectRows.forEach(value => list.append(element('li', '', value))); card.append(list);
      const applied = !preview && data.maps?.[operation.map];
      if (applied) card.append(element('p', 'small operation-applied', `Applied at startup: ${applied.pmcWavesAdjusted} PMC waves · ${applied.scavWavesAdjusted} Scav windows · ${applied.bossWavesAdjusted} boss waves adjusted. Infection ${applied.infection}% · AI cap ${applied.botCap}.`));
      else card.append(element('p', 'small operation-applied', `Planned hotspot infection ${selected.infection}%. Actual adjusted-wave counts appear after activation.`));
      card.append(element('p', 'small muted', 'Spawn chances and caps do not guarantee an encounter. Loot bonuses affect existing location chance; no guaranteed items.'));
      $('content-operations').append(card);
    }
    if (array(selected.challenges).length) {
      $('content-challenges').classList.remove('hidden');
      selected.challenges.forEach(goal => $('content-goals').append(element('li', '', goal)));
    }
    const rates = Object.entries(data.maps || {}).filter(([key, row]) => row.hotspot || key === 'sandbox').map(([key, row]) => `${names[key] || key}: ${row.infection}%`);
    text('content-infection', preview ? `Planned hotspot infection: ${selected.infection}%. Ground Zero keeps its protected baseline. Select Active to see current rates.` : `Active infection: ${rates.join(' · ')}. Matching Remote Quests 1.0.3 includes infected-kill Scav loyalty and revenge guards; the Scav gameplay test remains pending.`);
  }

  async function refreshExtras(signal) {
    await Promise.allSettled([
      (async () => {
        let data;
        try {
          const response = await fetch('/api/diagnostics', { cache: 'no-store', signal });
          if (response.ok) data = await response.json();
        } catch {}
        const good = data?.available === true && data.stale === false;
        const raid = good ? data.raid : null;
        text('diagnostics-state', !good ? 'Waiting for fresh headless measurements.' : raid.in_raid ? `Measuring ${(({bigmap:'Customs',factory4_day:'Factory',factory4_night:'Factory night',interchange:'Interchange',laboratory:'Labs',labyrinth:'Labyrinth',lighthouse:'Lighthouse',rezervbase:'Reserve',sandbox:'Ground Zero',sandbox_high:'Ground Zero 21+',shoreline:'Shoreline',tarkovstreets:'Streets',woods:'Woods'})[raid.map] || 'this map')} · updates every few seconds` : 'Headless ready; waiting to measure the next raid.');
        text('diag-fps', good ? `${data.performance.fps} FPS` : '—');
        text('diag-p95', good ? `${data.performance.p95_frame_ms} ms` : '—');
        text('diag-alive', raid?.in_raid ? raid.alive_bots : '—');
        text('diag-active', raid?.in_raid ? raid.active_bots : '—');
        text('diag-sleeping', raid?.in_raid && raid.sleeping_count_available ? raid.fda_sleeping_bots : '—');
        text('diag-targets', raid?.in_raid ? raid.active_bots_with_goal_enemy : '—');
        text('diagnostics-detail', raid?.in_raid ? `Bot instances created: ${raid.bot_instances_created}. Other inactive: ${raid.other_inactive_bots}. ${raid.combat ? `Moving since last sample: ${raid.combat.moving_bots}/${raid.combat.motion_samples}. Visible targets: ${raid.combat.bots_with_visible_enemy}. Shootable targets: ${raid.combat.bots_with_shootable_enemy}. Weapons ready: ${raid.combat.weapon_ready_bots}; with ammo: ${raid.combat.bots_with_ammunition}. Weapon-shot events this host run: ${raid.combat.weapon_shot_events_total}. ` : ''}Unity errors this run: ${data.unityErrors}. Targets and shots do not confirm hits.` : 'Simulation rate measures the headless host. Raid AI counts appear after deployment; idle performance does not predict raid performance.');
      })(),
      (async () => {
        try {
          const response = await fetch('/api/client-update', { cache: 'no-store', signal });
          if (!response.ok) throw new Error('Update status unavailable');
          const data = await response.json();
          $('client-update-notice').classList.toggle('hidden', !data.available);
          text('client-update-title', data.changed ? `Client update · ${data.version}` : `Approved client pack · ${data.version}`);
          text('client-update-message', data.message);
        } catch {
          $('client-update-notice').classList.remove('hidden');
          text('client-update-title', 'Verify your client before playing');
          text('client-update-message', 'Close the game and SPT Launcher, then run Play Outlands to check for updates.');
        }
      })(),
      (async () => {
        try {
          const response = await fetch('/api/content', { cache: 'no-store', signal });
          if (!response.ok) throw new Error('Content status unavailable');
          renderContent(await response.json());
        } catch { renderContent(null); }
      })(),
      (async () => {
        try {
          const response = await fetch('/api/maintenance', { cache: 'no-store', signal });
          if (!response.ok) throw new Error('Maintenance status unavailable');
          renderMaintenance(await response.json());
        } catch { renderMaintenance(null); }
      })(),
      (async () => {
        try {
          const response = await fetch('/downloads/client-manifest.json', { cache: 'no-store', signal });
          if (!response.ok) throw new Error('Client bundle unavailable');
          const manifest = await response.json();
          if (manifest.schemaVersion !== 1 || typeof manifest.bundleVersion !== 'string' || !Array.isArray(manifest.packages)) throw new Error('Invalid client manifest');
          const count = manifest.packages.reduce((sum, pkg) => sum + (Array.isArray(pkg?.files) ? pkg.files.length : 0), 0);
          text('client-bundle-status', `Approved pack: ${String(manifest.packages[0]?.version || manifest.bundleVersion).slice(0, 60)} · ${count} managed files. Game, SPT, and Fika compatibility is checked before launch.`);
        } catch { text('client-bundle-status', 'Client bundle information is temporarily unavailable.'); }
      })()
    ]);
  }

  async function refresh() {
    if (state.pending) return;
    state.pending = true;
    $('refresh-button').setAttribute('aria-busy', 'true');
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 8000);
    const extras = refreshExtras(controller.signal);
    try {
      const response = await fetch('/api/status', { cache: 'no-store', signal: controller.signal, headers: { Accept: 'application/json' } });
      if (!response.ok) throw new Error(`Status endpoint returned ${response.status}`);
      const data = await response.json();
      if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error('Invalid status response');
      state.data = data;
      state.lastSuccess = new Date();
      state.lastError = null;
      render(data);
    } catch (error) {
      state.lastError = error;
      renderFreshness();
      if (!state.data) {
        text('players-empty-title', 'Waiting for server data');
        text('players-empty-detail', 'Player presence will appear when the dashboard reconnects.');
      }
    } finally {
      await extras;
      window.clearTimeout(timeout);
      state.pending = false;
      $('refresh-button').setAttribute('aria-busy', 'false');
    }
  }

  function toast(message) {
    window.clearTimeout(state.toastTimer);
    $('toast').textContent = message;
    $('toast').classList.add('visible');
    state.toastTimer = window.setTimeout(() => $('toast').classList.remove('visible'), 2800);
  }

  const raidMetricDescription = $('in-raid-count').nextElementSibling;
  if (raidMetricDescription) raidMetricDescription.textContent = 'Reported by Fika';

  $('refresh-button').addEventListener('click', refresh);
  $('copy-url').addEventListener('click', async () => {
    const input = $('launcher-url');
    if (!input.value) return;
    try {
      await navigator.clipboard.writeText(input.value);
      toast('Launcher address copied');
    } catch {
      input.focus();
      input.select();
      toast('Address selected. Press Ctrl+C to copy.');
    }
  });
  document.querySelectorAll('.main-nav a').forEach((link) => {
    link.addEventListener('click', () => {
      document.querySelectorAll('.main-nav a').forEach((item) => item.classList.toggle('active', item === link));
    });
  });
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refresh(); });
  window.setInterval(refresh, POLL_INTERVAL);
  window.setInterval(() => {
    renderFreshness();
    if (state.data && !document.hidden) {
      renderPlayers(array(state.data.players));
      renderRaids(array(state.data.raids));
      renderActivity(array(state.data.activity));
    }
  }, 10000);
  refresh();
})();
