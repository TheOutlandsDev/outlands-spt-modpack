Outlands public bootstrap 1.3.0 — installer 0.5.0 baseline

Install the matching 0.5.0 Client build first. This bootstrap verifies 351 managed
files and 27 base dependencies, including the matching WTT patcher. A base
dependency mismatch stops launch: rerun the full matching installer to repair it.
Obtain the approved host's server-profile.json privately; the example is inert.

PLAY OUTLANDS PUBLIC BOOTSTRAP 1.2.0

1. Request Outlands access through https://discord.gg/cNqhhUdFW .
2. Install Tailscale and wait for the maintainer to approve access. Do not post
   device identities, invites, auth keys, connection profiles or logs publicly.
3. Obtain the matching legitimate SPT/EFT/Fika base and approved client pack from
   the host's instructions. The generic public 0.4.0 installer is not a verified
   exact match for the hosted baseline and includes extra/different plugins.
4. Extract this ZIP. Place server-profile.json supplied privately by the approved
   host beside Install Play Outlands.cmd, or in the installed updater folder.
   server-profile.example.json is documentation, not a connection profile.
5. Run Install Play Outlands.cmd, selecting your existing SPT folder. Use the
   Play Outlands desktop shortcut with Tailscale connected and the game/launchers
   closed. It checks the approved client pack before opening SPT Launcher.

No Administrator rights, VPN enrollment, firewall change or server account is
created. Failed profile, compatibility, hash or extra-DLL checks stop launch.
Profiles, saves and personal settings are not updated. Base game libraries are
verified, never downloaded. Keep the installed Outlands Client Updater folder.

Self-hosters must generate their own reviewed policy and update manifest, provide
an HTTPS Tailscale origin in their own server-profile.json, and share that only
with their approved players. Do not use another host's network or fixed hashes.

This source bootstrap has offline/fixture checks. Windows setup and a fresh
shared raid still need testing. Third-party mods and game files are not bundled.
