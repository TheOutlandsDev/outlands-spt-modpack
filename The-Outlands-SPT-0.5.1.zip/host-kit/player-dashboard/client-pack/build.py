#!/usr/bin/env python3
"""Build a curated human-client mod pack locally; vendor payloads never go to GitHub."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
from datetime import datetime, timezone
import zipfile

SOURCE = Path(__file__).resolve().parent
WORKSPACE = SOURCE.parents[1]
PACKAGE_ID = "outlands-client-pack"
VERSION = "2026.10.24.2"
LIMITS = {"files": 500, "fileBytes": 128 * 1024 * 1024,
          "expandedBytes": 512 * 1024 * 1024, "zipBytes": 256 * 1024 * 1024}
EXCLUDED_ROOTS = frozenset(("spt", "fika", "fikadynamicai", "codexdiagnostics"))
PINS = {
    "EscapeFromTarkov_Data/Managed/Assembly-CSharp.dll": "faef6f0b9f142f9d047495ec3dccfd5d6974ac048368dc7045955cf54b117982",
    "BepInEx/plugins/spt/spt-core.dll": "2b223747ec8e6b84947d96aac4ff3875cbdf6e130f0d1932399cfff8d382c4f3",
    "BepInEx/plugins/Fika/Fika.Core.dll": "6b56f43ac9fe6296537be8fbfe2f78da36da73842540602687ba9baba51f938b",
}
SENSITIVE = frozenset(("apikey", "password", "passwd", "secret", "token", "authorization",
                       "accesstoken", "refreshtoken", "clientsecret", "fikaapikey", "cookie", "sessionid", "phpsessid"))


class Refused(ValueError):
    pass


def canonical(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def safe_relative(relative):
    if not isinstance(relative, str) or not relative or len(relative) >= 240:
        raise Refused("Unsafe client path")
    if relative.startswith("/") or re.search(r'[\\<>:"|?*\x00-\x1f]', relative):
        raise Refused("Unsafe client path")
    for part in relative.split("/"):
        if (not part or part in (".", "..") or part.endswith((".", " ")) or
                re.match(r"^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)", part, re.I)):
            raise Refused("Unsafe Windows client path")
    return relative


def ordinary(runtime, relative):
    safe_relative(relative)
    path = runtime / relative
    cursor = path
    while cursor != runtime.parent:
        if cursor.is_symlink():
            raise Refused("Symlinked source path refused: " + relative)
        if cursor == runtime:
            break
        cursor = cursor.parent
    if not path.is_file() or not path.resolve().is_relative_to(runtime.resolve()):
        raise Refused("Expected ordinary source file: " + relative)
    return path


def jsonc(text):
    """Remove comments outside JSON strings; reject ambiguous/unparseable config."""
    result, quoted, escaped, index = [], False, False, 0
    while index < len(text):
        char = text[index]
        if quoted:
            result.append(char)
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                quoted = False
            index += 1
        elif char == '"':
            quoted = True
            result.append(char)
            index += 1
        elif text[index:index + 2] == "//":
            end = text.find("\n", index)
            index = len(text) if end < 0 else end
        elif text[index:index + 2] == "/*":
            end = text.find("*/", index + 2)
            if end < 0:
                raise Refused("Unterminated JSON comment")
            result.append(" ")
            index = end + 2
        else:
            result.append(char)
            index += 1
    return json.loads("".join(result))


def credential_scan(relative, data, secrets=()):
    if any(secret and secret in data for secret in secrets):
        raise Refused("Private credential content detected in client payload: " + relative)
    if Path(relative).suffix.lower() not in (".json", ".jsonc", ".cfg", ".yaml", ".yml", ".ini"):
        return
    try:
        text = data.decode("utf-8-sig")
        if Path(relative).suffix.lower() in (".json", ".jsonc"):
            value = jsonc(text)
            def walk(item):
                if isinstance(item, dict):
                    for key, value in item.items():
                        normalized = re.sub(r"[^a-z]", "", str(key).lower())
                        if normalized in SENSITIVE and value not in (None, "", False, [], {}):
                            raise Refused("Credential-bearing configuration refused: " + relative)
                        walk(value)
                elif isinstance(item, list):
                    for value in item:
                        walk(value)
            walk(value)
        else:
            for line in text.splitlines():
                match = re.match(r"\s*([\w.-]+)\s*[:=]\s*(.*?)\s*$", line)
                if match and re.sub(r"[^a-z]", "", match[1].lower()) in SENSITIVE and match[2].strip('"\' '):
                    raise Refused("Credential-bearing configuration refused: " + relative)
    except (UnicodeError, json.JSONDecodeError) as error:
        raise Refused("Unparseable client configuration: " + relative) from error


def row(runtime, relative, secrets=(), scan=False):
    path = ordinary(runtime, relative)
    size = path.stat().st_size
    if size <= 0 or size > LIMITS["fileBytes"]:
        raise Refused("Client file exceeds its nonempty size contract: " + relative)
    data = path.read_bytes()
    if len(data) != size:
        raise Refused("Source changed while reading: " + relative)
    if scan:
        credential_scan(relative, data, secrets)
    return {"path": relative, "size": size, "sha256": hashlib.sha256(data).hexdigest()}


def selected(runtime):
    plugins = runtime / "BepInEx/plugins"
    if plugins.is_symlink() or not plugins.is_dir():
        raise Refused("Expected an ordinary BepInEx plugins folder")
    result, seen = [], set()
    for path in sorted(plugins.rglob("*")):
        if path.is_symlink():
            raise Refused("Symlink in plugin inventory")
        if not path.is_file():
            continue
        relative = path.relative_to(plugins)
        if relative.parts[0].casefold() in EXCLUDED_ROOTS or path.suffix.casefold() == ".pdb":
            continue
        target = safe_relative("BepInEx/plugins/" + relative.as_posix())
        if target.casefold() in seen:
            raise Refused("Windows case-colliding client paths")
        seen.add(target.casefold())
        result.append(target)
    if not result or len(result) > LIMITS["files"]:
        raise Refused("Client file count is outside the approved limit")
    return sorted(result)


def base_paths(runtime):
    files = {"EscapeFromTarkov.exe", "EscapeFromTarkov_Data/Managed/Assembly-CSharp.dll",
             "BepInEx/plugins/Fika/Fika.Core.dll"}
    for relative, pattern in (("BepInEx/core", "*.dll"), ("BepInEx/patchers", "**/*.dll"),
                              ("BepInEx/plugins/spt", "**/*.dll")):
        folder = runtime / relative
        if folder.is_symlink() or not folder.is_dir():
            raise Refused("Expected base dependency folder: " + relative)
        for path in folder.glob(pattern):
            files.add(path.relative_to(runtime).as_posix())
    return sorted(files)


def inventory(runtime, secrets=(), curated_at=None):
    managed = [row(runtime, relative, secrets, True) for relative in selected(runtime)]
    if sum(value["size"] for value in managed) > LIMITS["expandedBytes"]:
        raise Refused("Expanded client pack exceeds its size limit")
    base = [row(runtime, relative) for relative in base_paths(runtime)]
    return {"schemaVersion": 1, "packageId": PACKAGE_ID, "packageVersion": VERSION,
            "curatedAtUtc": curated_at or datetime.now(timezone.utc).isoformat(),
            "selection": {"pluginRoot": "BepInEx/plugins", "excludedRoots": sorted(EXCLUDED_ROOTS),
                "excludedExtensions": [".pdb"], "personalBepInExConfigIncluded": False,
                "modLocalGameplayConfigIncluded": True}, "managedFiles": managed, "baseFiles": base}


def validate(runtime, approved, secrets=()):
    if (not isinstance(approved, dict) or approved.get("schemaVersion") != 1 or
            approved.get("packageId") != PACKAGE_ID or approved.get("packageVersion") != VERSION):
        raise Refused("Unsupported curated inventory")
    current = inventory(runtime, secrets, approved.get("curatedAtUtc"))
    if current != approved:
        raise Refused("Runtime inventory changed; review and explicitly recurate the source inventory")
    return current


def verify_pins(runtime):
    for relative, expected in PINS.items():
        if row(runtime, relative)["sha256"] != expected:
            raise Refused("Pinned SPT/EFT/Fika compatibility mismatch: " + relative)
    lock = json.loads((runtime.parent / "linux/version-lock.json").read_text())
    for key, version in (("SPT", "4.0.13"), ("EFT", "0.16.9.40087"), ("Fika.Core", "2.2.5")):
        if lock.get("versions", {}).get(key) != version:
            raise Refused("Runtime version-lock mismatch")


def build(runtime, approved, output, secrets=()):
    validate(runtime, approved, secrets)
    output.mkdir(parents=True, exist_ok=True)
    if output.is_symlink():
        raise Refused("Symlinked output folder refused")
    archive = output / (PACKAGE_ID + ".zip")
    if archive.is_symlink():
        raise Refused("Symlinked archive target refused")
    temporary = output / (PACKAGE_ID + ".building.zip")
    if temporary.exists():
        raise Refused("A previous build temporary already exists")
    try:
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as target:
            for value in approved["managedFiles"]:
                data = ordinary(runtime, value["path"]).read_bytes()
                credential_scan(value["path"], data, secrets)
                if len(data) != value["size"] or hashlib.sha256(data).hexdigest() != value["sha256"]:
                    raise Refused("Source changed during packaging: " + value["path"])
                info = zipfile.ZipInfo(value["path"], (2026, 10, 23, 0, 0, 0))
                info.create_system = 3
                info.external_attr = 0o100644 << 16
                info.compress_type = zipfile.ZIP_DEFLATED
                target.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=6)
        if temporary.stat().st_size > LIMITS["zipBytes"]:
            raise Refused("Client ZIP exceeds its size limit")
        with zipfile.ZipFile(temporary) as source:
            if source.namelist() != [value["path"] for value in approved["managedFiles"]]:
                raise Refused("Archive membership mismatch")
            for value in approved["managedFiles"]:
                data = source.read(value["path"])
                if len(data) != value["size"] or hashlib.sha256(data).hexdigest() != value["sha256"]:
                    raise Refused("Archive content verification failed")
        os.replace(temporary, archive)
    finally:
        if temporary.exists():
            temporary.unlink()
    payload = {"id": PACKAGE_ID, "version": VERSION, "url": "/downloads/" + archive.name,
               "size": archive.stat().st_size, "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
               "files": approved["managedFiles"]}
    manifest = {"schemaVersion": 1, "channel": "node-01", "bundleVersion": VERSION,
        "generatedAtUtc": approved["curatedAtUtc"], "compatibility": {"sptVersion": "4.0.13",
        "eftVersion": "0.16.9.40087", "fikaVersion": "2.2.5",
        "files": [{"path": path, "sha256": digest} for path, digest in PINS.items()]}, "packages": [payload]}
    policy = {"schemaVersion": 1, "updaterVersion": "1.1.0", "channel": "node-01",
              "managedPaths": [value["path"] for value in approved["managedFiles"]],
              "baseFiles": [{"path": value["path"], "sha256": value["sha256"]} for value in approved["baseFiles"]]}
    for name, value in (("client-manifest.json", manifest), ("client-policy.json", policy)):
        path = output / name
        if path.is_symlink():
            raise Refused("Symlinked metadata target refused")
        path.write_bytes(canonical(value))
    (output / (PACKAGE_ID + ".sha256")).write_text(payload["sha256"] + "  " + archive.name + "\n")
    return manifest, policy


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runtime", type=Path, default=WORKSPACE / "runtime")
    parser.add_argument("--inventory", type=Path, default=SOURCE / "inventory.json")
    parser.add_argument("--curate", action="store_true", help="Explicitly snapshot the reviewed source inventory; does not build a ZIP")
    parser.add_argument("--output", type=Path, help="Local output folder; never use a GitHub publication directory")
    args = parser.parse_args()
    runtime = args.runtime.absolute()
    verify_pins(runtime)
    secret_path = WORKSPACE / "player-dashboard/deployment/fika_api_key"
    secrets = [secret_path.read_bytes().strip()] if secret_path.is_file() else []
    if args.curate:
        if args.inventory.is_symlink():
            raise Refused("Symlinked inventory refused")
        approved = inventory(runtime, secrets)
        args.inventory.write_bytes(canonical(approved))
        print("Curated " + str(len(approved["managedFiles"])) + " managed files and " +
              str(len(approved["baseFiles"])) + " base verification files. Review inventory.json before building.")
        return 0
    if args.output is None:
        parser.error("Use --output for a local build, or --curate for explicit inventory review")
    approved = json.loads(args.inventory.read_text())
    manifest, _ = build(runtime, approved, args.output.absolute(), secrets)
    package = manifest["packages"][0]
    print(json.dumps({"package": package["id"], "version": package["version"],
        "files": len(package["files"]), "expandedBytes": sum(value["size"] for value in package["files"]),
        "zipBytes": package["size"], "zipSha256": package["sha256"], "baseFiles": len(approved["baseFiles"])}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
