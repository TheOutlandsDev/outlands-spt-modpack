# 0.5.1 — scheduled content and infected AI safety

Client managed baseline 2026.10.24.2 retains the same 351 paths and 27 base
contracts. Remote Quests 1.0.2 adds exact infected-role loyalty/revenge guards.
The fixed validator now accepts required shared rules on the headless role:
41 human and 44 headless plugins are required. The host can no longer omit the
shared zombie guard. Both scopes still refuse extra, missing or changed DLLs.

SelfHost adds Outlands Live Content DLL and reviewed settings (2508 files total).
The module schedules seven themes/weekly-shifting hotspots after idle maintenance.
It normalizes infection and reciprocal Scav/infected hostility on all 12 map
variants, limits crowds, keeps existing bot caps, and makes generated PMC waves
respect those caps. Ground Zero remains lightly infected. Economy modifiers
are capped at 3% location loot chance; profiles/trade prices are not reset.

0.5.0 clients receive the managed change by using Play Outlands. New players and
pre-0.5 users run the complete 0.5.1 Client installer once for the matching WTT
base patcher. The public bootstrap policy is unchanged at 1.3.0.

# 0.5.1 — hosted baseline alignment

Client and SelfHost share one canonical lock. Client installs 351 managed plugin,
asset and local gameplay files, Fika Core and four author patchers (356 files).
The updater verifies those 351 managed files and 27 base dependencies separately.
SelfHost installs 2,508 mod/configuration files, including the same human client
files, headless-only plugins, fixed role validation, remote quest acceptance with
local turn-ins, Scav War and the existing repaired Flea Simulator.

NarcoNet is placed in its actual client/server roots. The obsolete human plugin
and preset inventory is removed from the new lock. Known exact 0.4.0 leftovers
can be quarantined into verified backups during an applied install; unknown or
modified extra DLLs stop installation. No unrecognized files are deleted.

Raw gameplay settings preserve node-01 bytes. Eleven base configuration leaf
changes reproduce its complete weather/seasonal JSON behavior: autumn, Halloween
and zombies. Host-specific network addresses, API keys and headless accounts
must be configured independently. Profiles, relationship databases, generated
Fika scripts, caches and economy/player state are never distributed.

Five unmodified WTT DLLs are built locally from pinned author sources. Their
common reproducible hashes replace the previous node-01 binaries only during an
idle backed-up activation. The new patcher matches all 13 original methods and
runtime types/attributes, ignoring declaration order. Existing Armory/Backport
source proof files describe the other four builds. This does not establish a
successful new multiplayer playtest.

One repaired MIT Flea Simulator DLL is included with its corresponding repaired
source and the upstream MIT license. Other third-party binaries/assets download
from pinned sources; the installer never supplies retail game or base SPT files.
