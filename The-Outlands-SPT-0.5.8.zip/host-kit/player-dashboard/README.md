# node-01 player dashboard

Read-only SPT/Fika host dashboard running on node-01. It shows reported player
presence, current raid membership and map, headless readiness, service health,
and observed join/leave/activity changes. The browser refreshes every five
seconds. Empty and stale states stay explicit; no example players are shown.

Private live dashboard: **https://your-server.your-tailnet.ts.net:8446/**

Local dashboard: **http://127.0.0.1:3010/**

SPT launcher server URL: **https://127.0.0.1:6969**

All remote access requires membership and access permission in the host's
Tailscale network. Dockhand remains local at http://127.0.0.1:3000/containers.
The link in this dashboard is for use on node-01 itself.

## Desktop shortcuts

Run `python3 desktop/install-shortcuts.py` as the normal Ubuntu desktop user
to install three shortcuts on the desktop and in the applications menu:

- **SPT Players and Raids** opens the private live player dashboard.
- **SPT Server Metrics** opens Dockhand's per-container CPU, memory, health,
  and restart view on node-01.
- **SPT Live Logs** opens grouped backend and headless logs. It resolves the
  current container IDs on each launch so it survives container recreations.

They use the configured default browser and do not start, stop, or restart game
services. Metrics and logs are local administrative views for use on node-01;
the player dashboard remains available to permitted Tailscale devices.

## Runtime and data

The backend uses Python's standard library; the frontend uses local HTML/CSS/JS
with no CDN dependencies. Docker runs it as UID 1000 with a read-only root
filesystem and no Linux capabilities. It has no Docker socket, game files,
profile inventories, or Wine mounts. It reads a local config and a separate
Fika API key file, both ignored by Git and excluded from the build context.
The key is never sent to the browser or returned by the dashboard API.

The current integration targets SPT 4.0.13, Fika Server 2.2.4, Fika Core 2.2.5,
and Fika Headless 1.4.13. It does not upgrade or modify the game deployment.

The source APIs are `/fika/presence/get`, `/fika/api/players`,
`/fika/headless/get`, `/fika/api/headless`, `/singleplayer/settings/version`,
and the read-only **POST `{}`** callback `/fika/location/raids`. The latter
returns an empty body on GET in this server version. The browser only calls
the dashboard's same-origin GET `/api/status` endpoint.

Fika presence is a server-reported WebSocket list. An abnormal disconnect can
leave a record until Fika handles its close; the activity timestamp is not a
heartbeat. Headless clients are excluded from player totals. Raid membership
comes from the live match list rather than the headless client's accumulating
player array. Fika's numeric match status 2 also means headless loading is
complete; the match remains active until the source removes it. Existing raids
at dashboard startup have no invented start timestamp. The activity feed is
observed in memory and resets when this dashboard restarts.
The player raid counter uses the same reported activity as the player rows,
so a lingering session cannot inflate it. An assigned headless that has not
reported IN_RAID is shown as loading, and questionable retained sessions carry
a warning rather than being treated as confirmed player connectivity.

Upstream failures retain last successful data and display a stale warning.
`/healthz` checks dashboard process responsiveness; `/api/status` reports source
freshness and service health separately.

## Private client updates and version checks

The Squad connection card offers **Update and Play** for Windows. Extract the
updater ZIP and run `Install Play Outlands.cmd`, selecting the existing matching
SPT folder if prompted. It creates a **Play Outlands** desktop shortcut and stores
the updater in that game folder. Close the game and launchers, then use the
shortcut each time. It verifies base game/SPT/Fika files,
syncs the approved human client modpack with backups, checks for extra plugin, core, and patcher
DLLs, and opens the existing SPT launcher only after validation succeeds.
Unknown plugins are reported for manual removal; they are never deleted.
A mismatched base installation needs the matching legitimate installation before
syncing. Personal `BepInEx/config` settings, profiles, saves, and headless plugins
are outside the human pack. The manual **Remote Quests 1.0.1** download remains
available for reference; that patch alone is insufficient for full validation.

The curated snapshot contains 351 managed mod files and 27 verification-only
base files. Both full file SHA256 verification in the updater and fixed plugin
GUID/CRC32C checks at the Fika connection are required. The server has separate
human/headless policies; humans cannot load host-only plugins. Native Fika
required/optional lists stay empty so the custom policy supplies the baseline
without learning hashes from a first client. NarcoNet also excludes the host-only
AI plugin, diagnostics, and headless files from human sync; its remaining
advertised DLLs and overlapping files match the approved snapshot. This prevents accidental version
mismatches; it does not authenticate untrusted client reports or establish that
every mod behaves correctly in a raid.

The private Tailscale dashboard serves six exact download filenames: the legacy
patch ZIP/checksum, `client-manifest.json`, `outlands-client-pack.zip`, and the
updater ZIP/checksum. The full modpack is available **only through the tailnet**;
GitHub receives authored updater code, the authored updater ZIP, and hash/path
metadata. Vendor/game payloads are excluded from GitHub publication. A dedicated
read-only `deployment/downloads/` directory mount supports atomic replacement
without a dashboard restart. There is no listing, upload, or arbitrary file route.

Limits are 256 MiB for the full pack, 16 MiB for the legacy patch, 2 MiB for the
updater, 1 MiB for the manifest, and 512 bytes for checksums. GET streams files in
bounded chunks; HEAD returns the same headers without reading a response body.
Missing, oversized, symlinked, and special files return 404. Dashboard images
contain only the six dashboard source files; release artifacts and secrets are
separate mounts.

After reviewing a changed canonical client pack, curate its inventory deliberately
and publish a matching updater policy. Ordinary publication refuses inventory
drift rather than approving whatever happens to be installed:

```sh
python3 client-pack/build.py --curate
python3 ops/publish-client-bundle.py --bundle-version 2026.10.23.1 --check
python3 ops/publish-client-bundle.py --bundle-version 2026.10.23.1
```

The publisher validates the curated files and pinned base contracts, packages the
reviewed updater source/policy, and stages artifacts atomically with the manifest
last. It never upgrades games or changes services. A policy-changing mod release
also requires regenerating the server baseline and a controlled idle restart.
See [client pack inventory](client-pack/README.md), [Windows updater](client-updater/README.md),
and [fixed server policy](mods/client-pack-policy/README.md).

## Announced daily maintenance

The separate host worker schedules **5:00 AM America/New_York** maintenance and
native in-game warnings at 30, 15, 5, and 1 minute. It waits indefinitely for all
reported raids to finish. An expiring server admission gate pauses new headless
starts while existing raids and joins continue. Missing or stale game/guard data
defers a restart. Direct player-hosted admission is outside the gate's scope;
this deployment uses **Headless Host**.

After repeated fresh idle checks, it stops headless then backend, verifies a
private backup of quiescent profiles/configs, starts the same existing containers,
and checks for a healthy backend and Ready headless. No game/mod/image upgrades
or automatic profile rollback occur. Its systemd user timer survives reboot and
logout through the existing linger setting and does not depend on Codex.

The dashboard has only GET `/api/maintenance`, a sanitized bounded projection
from a dedicated read-only public-state directory. It never receives the Docker
socket, worker state, control lease, or backup contents. A missing admission
module acknowledgement displays `activation_required`; the worker defers a restart
until the guard reports a fresh acknowledgement. The module loads at backend startup. See [worker installation and recovery](maintenance/README.md) and
[server admission source](mods/maintenance/README.md).

## Run on this host

From this source folder, create local config from the adjacent SPT runtime:

```bash
python3 configure-local.py
python3 deploy-local.py
```

`configure-local.py` writes mode-0600 files in ignored `deployment/` and `.env`.
It never prints the Fika key. `deploy-local.py` stages an explicit source-only
build context under the host's `containers/` folder and generates the local
Compose stack there. Dockhand can manage that context through its existing
mount; local secret files stay outside its filesystem mounts. Docker mounts
those two specific files only into the dashboard container.

For a separate host, create `deployment/config.json` from `config.example.json`,
put its Fika API key in `deployment/fika_api_key` with owner-only permissions,
then use `docker compose up -d --build` from this folder. Bind the dashboard
to loopback and put a private Tailscale Serve proxy in front of it:

```bash
sudo tailscale serve --bg --https=8446 http://127.0.0.1:3010
```

See [private hosting policy](ops/NETWORK.md) before enabling incoming traffic.
On node-01, its dedicated firewall accepts only TCP 6969, UDP 25565, and TCP
8446 on `tailscale0`; other incoming tailnet services remain blocked. The SPT
HTTP/WebSocket listener itself binds only to the Tailscale IPv4 address.

## Verify and maintain

### Halloween, zombies, and autumn

The local-only helper `ops/halloween.py` applies this host's SPT 4.0.13 event
settings. It does not run in the dashboard container and has no HTTP controls.
Halloween and autumn remain active until the saved backup is restored. The
infection settings cover 12 map variants, including both Factories and both
Ground Zero level ranges; Labyrinth is excluded. Existing infection amounts
and event settings are retained except Customs and Interchange have a 50%
infection minimum and Ground Zero level 21+ has a 25% minimum. SPT randomizes
the live infection percentage from each minimum up to 100% at server startup.
Other seasonal events are disabled while this profile is active.

First confirm in the dashboard that there are no players or raids and the
headless client is ready. From `/home/node-01/Desktop/SPT-ON-NODE`, stop the
headless client first, then the backend, before applying:

```bash
./containers/docker.sh compose -f containers/stacks/spt-fika/compose.yaml stop headless backend
python3 player-dashboard/ops/halloween.py
./containers/docker.sh compose -f containers/stacks/spt-fika/compose.yaml up -d --no-build
```

The helper refuses while either game container is running, checks the version
lock, and prints a unique backup directory under `linux/backups/halloween-UTC-*`.
That mode-0700 directory contains both original raw files and their SHA-256
manifest. Config replacements are atomic and preserve file modes. An already
applied configuration creates no additional backup. Keep backups on node-01.

To restore, check for an idle host again, stop both game containers as above,
then pass the exact printed backup directory and restart:

```bash
python3 player-dashboard/ops/halloween.py --restore /absolute/path/to/linux/backups/halloween-UTC-directory
./containers/docker.sh compose -f containers/stacks/spt-fika/compose.yaml up -d --no-build
```

Restore validates the backup's expected filenames, version, and file hashes
before replacing either config. The helper never starts or stops containers.

### Tactical co-op baseline

For the first 2–3 player test, select **Use Headless Host**, AI
amount/difficulty **As Online**, bosses on, and Tagged and Cursed off.
The local **Outlands Headless Scav War** server mod automatically applies
Scav War to every Fika headless raid. Players do not need a client plugin
or to tick the checkbox. SPT 4.0.13 may still display that checkbox unticked;
the server policy changes the headless request before Fika sends it to the
host. This policy forces Scav War on; it does not affect client-hosted raids.
See [policy source, tests, and removal](mods/scav-war/README.md).

The headless host uses FikaDynamicAI 1.0.1 with a 350 m range, **High** scan
rate, and **Ignore Sniper = true**. High checks every 120 frames, about two
seconds at the configured 60 FPS cap, instead of Low's 600 frames. Sniper
scavs remain active at distance. Other AI beyond 350 m from every living
human is disabled, so distant Scav War fights pause until someone approaches.
This is a performance tradeoff; the expanded range needs an actual outdoor raid
benchmark. Outlands.ScavWar 1.1.0 resolves the headless bot-cap fallback through
the current Fika match, rather than applying the stock default of 18 to every
map. The original local config is backed up under
`linux/backups/tactical-ai-UTC-*` with its SHA-256 manifest.

Keep the existing SAIN custom preset, LootingBots limits, population tuning,
60 FPS headless cap, and Medium network send rate for the first test. Native
boss/event spawning can exceed ordinary AI limits, including during the
zombie event. This modded progression requires **Ground Zero first**. Test a
two-player Ground Zero raid, verify extraction and saved progress, then launch
the next location allowed by the mod before adjusting spawn counts or
difficulty. Idle container health and CPU use cannot establish
in-raid simulation performance or prove extraction/profile saving.

References: [SPT pre-raid defaults](https://github.com/sp-tarkov/modules/blob/4.0.13/project/SPT.Custom/Patches/SetPreRaidSettingsScreenDefaultsPatch.cs),
[FikaDynamicAI 1.0.1](https://github.com/Lacyway/FikaDynamicAI/blob/1.0.1/Scripts/FikaDynamicAIManager.cs).

### Remote trader quests

The optional Outlands Remote Quests client patch lets a location-disabled,
otherwise unlocked and unbanned trader open in **Tasks** mode. Players can accept
new eligible quests remotely. Required items, completed quests, and repeatable
rerolls must be handled where that trader is active. Client controls and a server
guard enforce this policy without changing quest progress or trader flags.
Trade and Services tabs remain inaccessible while that trader is inactive;
ordinary local trader behavior remains unchanged. Install the patch on each
Windows player's SPT client and restart the game. See
[client patch source and installation](mods/remote-quests/README.md).
See [server enforcement and removal](mods/local-quest-turnins/README.md).

### Dashboard source checks

Run from the `player-dashboard` source folder:

```bash
python3 -m unittest discover -s tests -v
python3 source_manifest.py > .publication-manifest.json
```

Tests cover presence/match normalization, headless exclusions, stale-source
handling without false leave events, secret redaction, and the restricted HTTP
surface. A dashboard HTTP check is separate from a remote game/raid test.

The owner chose the private `TheOutlandsDev/OUTLANDS-DEV-LAB` repository.
Reviewed source lives under
`systems/node-01/home/node-01/Desktop/SPT-ON-NODE/player-dashboard/`.
After changes, review the exact `source_manifest.py` allowlist, test and inspect
the live UI, then publish the source and update its bounded catalog manifest
with the connected GitHub tools. Preserve unrelated repository history and
verify remote blob hashes. Local `AGENTS.md` carries this maintenance rule.
This is source version control; deployment secrets, game files, profiles,
operational logs, screenshots, and runtime state stay on the host.

## Upstream behavior references

- [Fika v2.2.4 presence service](https://github.com/project-fika/Fika-Server-CSharp/blob/v2.2.4/FikaServer/Services/PresenceService.cs)
- [Notification WebSocket lifecycle](https://github.com/project-fika/Fika-Server-CSharp/blob/v2.2.4/FikaServer/WebSockets/NotificationWebSocket.cs)
- [Raid listing](https://github.com/project-fika/Fika-Server-CSharp/blob/v2.2.4/FikaServer/Controllers/LocationController.cs)
- [Match lifecycle](https://github.com/project-fika/Fika-Server-CSharp/blob/v2.2.4/FikaServer/Services/MatchService.cs)
- [Headless lifecycle](https://github.com/project-fika/Fika-Server-CSharp/blob/v2.2.4/FikaServer/Services/Headless/HeadlessService.cs)

## Live content calendar

/api/content is a read-only, bounded projection of the authored live-content
module. The existing host maintenance worker projects status every tick; no
calendar controls or secrets cross into the dashboard. Halloween stays active
daily; themes/hotspots rotate at the 5 AM Eastern idle maintenance boundary.
The 1.1.0 operations board includes primary/secondary briefings, a four-phase
weekly campaign, an interactive seven-day forecast, bounded encounter/loot
modifiers, and optional self-assessed squad challenges. It reports actual startup
wave adjustments, marks delayed rollover, and never claims generated waves prove
live combat. Challenges do not create quests or automatic rewards. No write API
or client-file change is introduced. Event DLL/settings are included in daily
quiescent recovery checkpoints.
See mods/live-content/README.md. The managed Remote Quests 1.0.3 DLL also carries
five-role infected AI loyalty/revenge guards; headless and human clients must
run the current shared client rules. Approved clients receive the managed update
through Play Outlands. A base patcher upgrade still requires installer 0.5.x once.

## Moderate spawn preset (2026-10-24)

ops/spawn-preset.json adjusts the existing population mod only. Effective AI
caps gain four on larger maps, two on Factory/Ground Zero: Reserve 30→34, Customs
28→32, Woods 33→37, Ground Zero 17→19 (high-level 18→20). Eligible ordinary Scav
waves gain one slot, bounded by group caps of four on small maps and up to five
on larger ones. Disabled zero-slot waves remain disabled. PMC timing/chances,
AI difficulty, bosses, zombies and economy retain their existing settings.

ops/spawn_preset.py prepares one config without writing it, verifies semantic
fingerprints and refuses unrelated edits. Applying twice cannot compound the
increase. Activation uses the idle admission guard, verified backups, rollback
and original game containers. Clients relaunch after activation to refresh
cached raid settings; all 351 managed files and 27 base pins remain unchanged.
Caps are ceilings, not promises of an exact visible population.

Client-file publications queue an in-game Fika announcement instructing players
to finish their raid, close both Escape from Tarkov and SPT Launcher, and run
Play Outlands. The overview retains the same reminder from `/api/client-update`.
Content identity covers all managed files, including configs/assets; routine
restarts do not trigger a false update notice. The existing maintenance worker
handles durable retry without adding a separate scheduler. Native Fika validation
is retained across normal backend restarts; changed releases require fresh client
startup validation before new headless raid starts/joins. Full SHA256 verification
still belongs to Play Outlands. See `mods/client-pack-policy/README.md` for the
precise enforcement limits and first-install relaunch requirement.

The overview now includes `/api/diagnostics`: bounded, identity-free headless
frame times and actual bot-registry/FikaDynamicAI sleep counts. Idle performance
and enemy awareness are explicitly distinguished from combat behavior. Metrics
have freshness checks and disk/queue limits; no gameplay mod is added to humans.
See `mods/raid-diagnostics/README.md` for verification limits.

Manual encrypted off-node backup tools and safe state restoration live under
`maintenance/`. Keys, plaintext state, encrypted archives and upload receipts
remain private; only source/tests are published. The daily local backup file list
includes Fika's nested server configuration and the host diagnostics DLL.

The checkpoint also protects `SPT/user/certs`. When sealing an older checkpoint
that predates this coverage, the encrypted envelope includes
`server-tls-certificate.pfx` as a supplement. During recovery copy that decrypted
supplement to `runtime/SPT/user/certs/certificate.pfx` in the isolated restored
installation. Never publish the certificate or recovery key in the source repo.
The recovery key must remain separate from the Drive backup. Cloud copies are
manual; no cloud-upload schedule is installed.

The player page at `/play/` separates first-time Client installation from the
existing Play Outlands shortcut. It uses the current public release metadata in
`web/release.json` and the existing read-only status/download endpoints. Update
that release metadata together with public downloads. Hub integration source at
`hub-integration/` prepares private Homepage links and optional exact redirects;
it changes no game listeners, access grants or proxy configuration by itself.
