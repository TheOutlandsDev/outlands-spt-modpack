# Daily announced maintenance

This host-only Python standard-library worker checks a daily **5:00 AM
America/New_York** schedule. Eastern daylight-saving changes are calculated with
the IANA time zone. A systemd user timer checks every 15 seconds, survives logout
and reboot through the host's existing user linger setting, and needs no Codex
session. It never upgrades SPT, EFT, Fika, third-party mods, or Docker images.

Warnings use Fika's native notification route at 30, 15, 5, and 1 minute. Late
startup skips older warnings instead of sending a burst. A restart without a
previous successful warning is skipped, as is an overdue cycle that never began
draining. There is no automatic catch-up restart after boot. Once draining has
begun, existing raids may finish with **no deadline**; new raids stay paused.
When every raid has finished, a final native notice precedes stopping; a failed
final notice defers the stop. A best-effort completion notice follows readiness.
Its failure cannot turn a verified successful restart into a failure. A delayed
cycle that finishes on a later local day prevents a second restart that day.

The server admission module must first be installed and activated while idle.
Until a fresh acknowledgement reports it loaded, status is `activation_required`
and the worker cannot announce or stop game services. Activation is a separate
operator step; the installer does not restart games.

## Admission and idle checks

The server module reads `runtime/SPT/user/mods/zzz-OutlandsMaintenance/control.json`
and writes `ack.json` beside it. A UUID lease lasts 90 seconds, refreshed every
10 seconds during long maintenance operations and every timer tick while waiting.
Only a fresh acknowledgement with the same UUID, `draining: true`, and an integer
`inFlightAdmissions: 0` permits a restart. An admission that began before the
lease must finish before the worker can stop games. Invalid API data or
acknowledgement fails closed.

The worker queries three fresh direct sources: the expected headless WebSocket
must be connected and READY, its player list empty and current match absent;
its `RequesterSessionID` and `HasNotifiedRequester` fields must both be absent or
null (Fika omits null JSON properties), covering the admission-to-loading gap
before a match is registered;
`POST /fika/location/raids` must return an empty list; presence must report no
player in a raid. Loading, an unrecognized state, a retained match, or unavailable
data defers maintenance. It requires three idle observations over at least 30
seconds, then rechecks immediately before stopping. The admission gate closes
the race between observing idle and a new headless raid starting. This deployment
uses Headless Host. The admission gate does not support direct player-hosted
raids; raw matches/presence still defer maintenance for them, but new direct-host
admissions cannot receive the same race guarantee. Use Headless Host throughout.

## Stop, backup, and recovery

Before the first stop, private durable state records maintenance intent and both
existing container/image IDs. Headless stops first (45-second grace), then the
backend (90-second SIGINT grace). A forced-kill exit or OOM prevents claiming a
clean backup. The worker snapshots stopped profiles and configs, the authored
mod binaries if present, version-lock and Compose metadata into a private
`linux/backups/daily-*/state.tar.gz`, then reads every archive entry back and
checks its hash against the manifest. Game assets, dependencies, and Wine are
excluded. Backups can contain credentials/profile information and stay local.

The **same existing containers** start again: backend healthy first, then
headless. This preserves the Dockhand-adopted Compose stack and recorded image
IDs; it never pulls, builds, recreates containers, calls Compose down, or enables
the old native services. Readiness requires both healthy, SPT 4.0.13, and the
expected headless READY with fresh idle sources. The total start deadline is ten
minutes. The admission lease is released only after readiness; otherwise it
expires safely. Interrupted maintenance is recovered on the following tick by
starting the same recorded containers. Profiles are never automatically rolled
back, and intentionally stopped services do not trigger recovery without this
worker's prior durable intent. Successful recovery remains a failed/interrupted
maintenance result, rather than claiming that its backup/restart completed.

Private state and its single-instance lock live in ignored
`deployment/maintenance/`. Only a bounded status projection lives in
`deployment/public-state/maintenance.json`. Mount that directory read-only for
the dashboard; it contains no socket, control channel, API key, or profiles.

The existing worker also preserves native warning evidence every tick and before
and after a controlled headless stop. Fika prunes older native log folders at
startup, so the private copy lives outside `runtime/Logs`, in
`deployment/maintenance/native-log-archive/`. It keeps at most eight native
sessions, two error files per session, and the last 512 KiB per file (8 MiB of
payload plus bounded metadata). Truncation is recorded honestly. Original logs
are read only; unchanged copies are not rewritten. Symlinks and special files
are refused. Directories are mode 0700 and files 0600. Neither the dashboard nor
GitHub receives this archive. This is local diagnostic retention, not a recovery
checkpoint or an off-node backup. Unexpected crashes or log pruning between
ticks can still lose recent warnings; capture errors are reported in the worker
journal without blocking scheduled maintenance.

## Review, install, and verify

From this source directory, run isolated tests; they do not call the live server,
send notifications, or stop containers:

```sh
python3 -m unittest -v test_maintenance.py
python3 install.py
```

After reviewing the units, install as node-01, without sudo:

```sh
python3 install.py --install
systemctl --user status node01-spt-maintenance.timer
journalctl --user -u node01-spt-maintenance.service -n 30
```

The existing `containers/docker.sh` pins the local Unix Docker socket and uses
`sg docker` for the older desktop session's group membership. Do not add
`NoNewPrivileges=yes` to this user service while it needs that group transition.
The dashboard never receives the Docker socket. Disable future checks with
`systemctl --user disable --now node01-spt-maintenance.timer`; a running operation
should normally finish, and its durable recovery state must be retained.

Client-content updates also use this existing worker. `client_updates.py` compares
managed path/size/SHA256 identities, queues a durable Fika notice after committed
publication, and retries delivery on later ticks while the backend is restarting.
Successful delivery is deduplicated; ordinary daily restarts and server-only or
transport-only publications do not create a client-update warning. A crash after
manifest commit is recovered from the previous durable identity. The read-only
public projection contains no session records. No Codex monitoring automation is
created. Run `ops/publish-client-bundle.py` for coordinated publications, retaining
the required idle activation procedure for changed DLL policies.

## Recovery and manual encrypted copies

Quiescent checkpoints now explicitly include Fika's nested
`fika-server/assets/configs/fika.jsonc` and the installed host diagnostics DLL,
in addition to existing profiles/configs and authored server mods. These private
files remain local or inside an encrypted backup; they never enter GitHub source.

`recovery.py --checkpoint CHECKPOINT --output NEW_FOLDER` validates the archive
hash, exact regular-file membership, path/size bounds and every member SHA256
before restoring any data. It refuses existing destinations. It restores saved
state, not retail game/vendor assets. Reconstruct the pinned build first, then
overlay verified state in staging and review host network paths before activation.

Drive copies are manual by the owner's choice. Existing daily local backups stay
scheduled; no cloud-upload timer or Codex monitor is installed. Run:

```sh
python3 player-dashboard/maintenance/encrypted_backup.py --create-key
python3 player-dashboard/maintenance/encrypted_backup.py --prepare-latest
```

GnuPG seals the verified checkpoint manifest and archive together in standard
OpenPGP AES256 format, then decrypts and compares the result before accepting the
outbox entry. The generated owner-only recovery key is never passed in argv or
uploaded. Copy `deployment/backups/Outlands-Recovery-Key.txt` to an independent
safe device/password manager. An encrypted backup is unusable after disk loss
if its only recovery key remains on node-01. Never publish the key or outbox.

Upload only the `.tar.gpg` named by the validated outbox `latest.json` to the
owner's private backup folder. Verify a downloaded copy's SHA256 against
`encryptedSha256`, and authenticate/decrypt it before extracting. The private
manifest stays inside encryption. A manual upload receipt is local evidence;
preparing an outbox is not confirmation that an off-node copy exists.

For independent recovery, `gpg --output recovered-checkpoint.tar --decrypt BACKUP`
prompts for the recovery key. Its authenticated output contains only
`manifest.json` and `state.tar.gz`; extract these to a private staging checkpoint,
then run `recovery.py`. Never extract an unverified archive over a live server.
The original checkpoint is a rollback snapshot from the recorded time, not a
replacement for later saves.
