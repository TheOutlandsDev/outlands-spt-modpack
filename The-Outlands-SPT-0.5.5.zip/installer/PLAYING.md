# Join or self-host

Use the 0.5.5 installer and lock together with your own legitimate SPT 4.0.13 /
EFT 0.16.9.40087. Do not substitute a latest mod version. Close your launcher/game
before installation or updates. Start the SPT launcher once and close it so its
settings exist before configuring a backend.

## Approved Outlands players

1. Request approval at https://discord.gg/cNqhhUdFW and connect your approved
   Tailscale device. This package does not distribute Tailscale enrollment keys.
2. Run Start-Outlands.cmd, choose Client and your separate compatible SPT folder.
   Download, then preview/apply the verified installation. Run Verify afterward.
3. Obtain the host's private connection JSON (schema 1, `backend_url`, optional
   `webapp_url`). Choose C in the installer to apply it with verified backups.
   Keep your own server account; existing launcher credentials are preserved.
4. Obtain the separate updater `server-profile.json` (schemaVersion 1 and the
   host's private HTTPS update `origin`). Put it beside the included public
   updater's scripts and run Install Play Outlands.cmd for your game folder.
   Do not rename the inert example and expect it to connect.
5. Use the Play Outlands shortcut thereafter. Its updater checks the managed
   files, all 27 base dependencies, unknown DLLs and the private host manifest
   before opening your launcher. If a base patcher changes, rerun this release's
   full Client installer; the updater reports the mismatch and stops.
6. Use your own account and allow required bundles to synchronize. Test Ground
   Zero first for this progression, then a shared raid and extraction/save.

Use Headless Host for the maintained host. Anyone hosting a player-hosted raid
uses their own Tailscale adapter/IP in Fika Network settings. No public Internet
port-forward or Funnel is required. Backend access and raid UDP are separate
network paths; device approval is required for both.

## Independent SelfHost

Install SelfHost into your own compatible separate SPT folder dedicated to the
backend and headless account. To play as a human on that PC, install Client into
a second compatible SPT folder; do not launch a human profile from the headless
folder. This includes all
Client files and current server/headless plugins; headless-only plugins must not
be copied to human PCs. Use the included public host-kit source for the dashboard,
Docker/Compose and 5 AM Eastern drain-and-restart scheduler, if desired. The timer
is deployed separately; installing the maintenance plugin alone does not create
an OS schedule. Review paths and time zone for your own host.

Configure your own Fika backend addresses/listening interfaces, API key, headless
profile and script settings in `SPT/user/mods/fika-server/assets/configs/fika.jsonc`.
The public defaults use loopback and no headless profiles. Generate your own API
key and create a headless account using Fika's normal setup; supply a legitimate
retail EFT installation for its ownership check. Use your own HeadlessConfig,
Tailscale device approvals, UDP binding and certificate configuration. Keep all
profiles and credentials private. Public templates contain no working Outlands
connection values or player state.

The supplied fixed plugin policy has separate human and headless roles. Headless
requires Fika.Headless, Dynamic AI and diagnostics; shared Remote Quests 1.0.2 rules are also required on
headless because they include infected AI safety. Regenerate the inventory/policy together if you intentionally change
plugins, and give all players your matching updater policy and manifest. NarcoNet
excludes host-only files from human synchronization. Never let a first joining
client define the server's baseline.

After setting network/profile identity, strict file auditing will report those
intentional configuration changes. Review them; do not change gameplay/plugin
hashes to make the audit quiet. Test backend startup, headless readiness, a fresh
remote join, bundle transfer, a shared Ground Zero extraction/save and a second
raid. File equality alone does not prove those gameplay checks.
