# Outlands public host kit

Original Outlands source for approved multiplayer clients and independent hosts.
MIT applies to authored code and documentation. Game/SPT/Fika/vendor assemblies,
third-party mod payloads, profiles, private connection profiles and credentials
are not included. Existing plugin GUIDs and the historical `node-01` protocol
channel remain unchanged for compatibility.

## Players

Request access at https://discord.gg/cNqhhUdFW and follow
[the join guide](../docs/JOIN-OUTLANDS.md). Public source is available to everyone;
access to the hosted game is approved separately. Obtain the matching legitimate
SPT 4.0.13 / EFT 0.16.9.40087 baseline. Do not install host-only plugins on players.

[Download the public Play Outlands bootstrap](https://github.com/TheOutlandsDev/outlands-spt-modpack/raw/refs/heads/main/Play-Outlands-Public-1.3.0.zip).
It requires `server-profile.json` supplied privately by the approved host and the
host's matching local policy. The included example is inert. The included policy
identifies the active hosted baseline: 351 managed files and 27 verification-only files.
Wrong base libraries and extra DLLs stop launch rather than being silently fixed.

The complete 0.5.1 installer contains all current authored modules and matching policies. The earlier standalone five-DLL ZIP is a historical snapshot; use the current installer for this baseline.

## Independent self-host setup

1. Follow [SelfHost setup](../docs/SELF-HOSTING.md). Install a compatible legitimate
   game/SPT baseline and public modpack into a folder named `runtime` beside this
   README, or use your own workspace layout and set `OUTLANDS_WORKSPACE` for builds.
   Preserve the supported SPT directory layout and keep retail EFT separate.
2. Supply your own .NET 9 SDK/reference pack, matching game assemblies and Fika
   server 2.2.4. These sources were compiled with SDK 9.0.316, net9.0 reference pack
   9.0.18 and .NET/ASP.NET runtime 9.0.17. Obtain them from Microsoft/SPT/Fika;
   do not copy or publish another host's runtime or Wine prefix.
3. Point `OUTLANDS_DOTNET_SDK` at the SDK root containing `sdk/9.0.316` and `packs`.
   Point `OUTLANDS_DOTNET` at your matching dotnet executable. With no overrides,
   build helpers use `.build/dotnet-sdk-9.0.316` under this workspace. Python 3.10+
   is required by the helper scripts. A complete SDK is a build prerequisite;
   building does not install plugins or start the game.
4. Build the modules against your own `runtime`, inspect output, and copy only the
   authored plugin DLL to its documented folder. Module READMEs describe behavior.
   Example from this folder:

   ```sh
   python3 player-dashboard/mods/scav-war/build.py --output /tmp/outlands-scav-war --test
   python3 player-dashboard/mods/remote-quests/build.py --output /tmp/outlands-remote-quests
   python3 player-dashboard/mods/local-quest-turnins/build.py --output /tmp/outlands-local-quests --test
   python3 player-dashboard/mods/maintenance/build.py --output /tmp/outlands-maintenance --test
   python3 player-dashboard/mods/client-pack-policy/build.py --output /tmp/outlands-client-policy --test
   ```

   On Windows use `py -3` and a normal local output folder instead of `/tmp`.
   Build/test output can contain separately licensed reference DLLs; publish only
   reviewed authored deliverables, not whole output folders.
5. Curate **your own** human-client baseline with `player-dashboard/client-pack/build.py`.
   Regenerate `client-policy.json`, update manifest and fixed role CRC32C policy
   together. Read its README before changing the inventory. The checked-in hosted
   inventory matches unmodified 0.5.1. Rebuilt or modified files require recuration. Native Fika
   required/optional lists remain empty when the fixed validation callback is used.
6. Provide your players an HTTPS Tailscale update origin in a private
   `server-profile.json`; keep the public example unchanged. Review the optional
   NarcoNet exclusions so headless-only plugins are never offered to humans.
   Do not distribute the assembled vendor pack publicly; retain authors' terms.
7. Configure the read-only dashboard from your own runtime, local API key and
   backend address; `config.example.json` uses loopback examples. Its Compose
   service binds loopback. Proxy it only within your own tailnet. Admin consoles
   and Docker sockets must not be exposed to players.
8. The maintenance source uses 5 AM America/New_York, native warnings, an expiring
   new-headless-raid gate, indefinite waiting for observed raids, verified state
   backups and same-container restarts. It covers headless hosting; it cannot
   drain arbitrary new player-hosted raids. Review paths/container names before
   installing its user timer, and run its fixture tests first.

The included Ubuntu 26.04 Dockerfiles/Compose are a community Linux reference,
not an official Fika Linux installer. Set `OUTLANDS_ROOT` to this host-kit folder,
supply your own Linux dotnet runtime under `linux/dotnet`, initialize a legitimate
Wine/retail-EFT prefix at `linux/prefix`, create the three lock files and configure
`runtime/HeadlessConfig.json` yourself. Container defaults use UID/GID 1000 and
historical container names. Review permissions and configure your own Tailscale
bindings before starting. Do not run a second backend against the same profiles.
No game, dotnet runtime, Wine prefix or credentials are contained in this kit.

## Gameplay and verification

The hosted style is 2–3 players, steady tactical fights, headless Scav War,
Halloween/autumn and zombies, and remote quest acceptance with local turn-ins.
Use Ground Zero first for this modded progression. See [gameplay profile](GAMEPLAY.md).
The 0.5.1 installer uses the canonical hosted mod inventory. Private player state
is excluded. Regenerate both the installer and host policy before changing hashes.

Offline compilation/file checks, live idle checks and a completed multiplayer
raid are different evidence. Windows COM setup, fresh approved-client update,
first remote asset delivery, two-player Ground Zero extraction/save persistence
and a subsequent raid remain required acceptance tests. See VALIDATION.md.

## 0.5.1 live calendar and zombie guards

The active managed baseline is 2026.10.24.2. Shared client rules 1.0.2 are required
on both the human and headless roles; the path/GUID are retained for automatic
managed updates. The server-only calendar keeps Halloween active daily, rotates
hotspots and small theme bonuses, and applies after the existing idle daily
restart. The dashboard exposes /api/content as a bounded read-only view.
See player-dashboard/mods/live-content/README.md and ../../docs/MOD-RESEARCH-2026-10-24.md.
