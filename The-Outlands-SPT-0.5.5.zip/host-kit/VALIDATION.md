# Public host-kit validation scope

The 0.5.1 Client/SelfHost download and hosted baseline 2026.10.24.2 use the same
351 human managed files and 27 verification-only base files. Five pinned WTT
source builds are now deployed on node-01. Both existing containers returned
healthy; headless reached idle Ready after the controlled, backed-up cutover.

Independent Client (356) and SelfHost (2508) assemblies were checked against every
locked size/hash without installed-mod imports. Client backup/quarantine/refusal
fixtures, actual updater full-pack verification, gameplay patch idempotence and
actual role-policy fixtures passed. The separately assembled SelfHost backend
started on loopback without importing live profiles. See installer/VALIDATION.json
and this folder's VALIDATION.json for precise scope.

Four host identity configuration templates are sanitized deliberately. Operators
supply their own addresses, headless profile, API key and host path. The original
Flea Simulator repair is the named MIT binary exception, with source and notice.
Other vendor/game payloads, profiles, private connection data and logs are absent.

A Ready idle headless is not a multiplayer test. Native Windows shortcut COM,
fresh Windows installation/first-connect asset transfer and a two-player Ground
Zero extraction/save/second-raid test remain pending.
