#!/usr/bin/env python3
"""Open node-01's player dashboard, resource metrics, or current live logs."""
import argparse
import json
import shutil
import subprocess
import urllib.parse
import urllib.request

MANAGEMENT = 'http://127.0.0.1:3000'
PLAYERS = 'https://node-01.taild80c86.ts.net:8446/'
ENVIRONMENT = 1


def view_url(view):
    if view == 'players':
        return PLAYERS
    if view == 'metrics':
        return MANAGEMENT + '/containers?env=' + str(ENVIRONMENT)
    query = {'env': str(ENVIRONMENT)}
    try:
        # Resolve IDs on each launch; Docker recreations change them.
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(MANAGEMENT + '/api/containers?env=1&all=true', timeout=4) as response:
            containers = json.load(response)
        wanted = ('node01-spt-backend', 'node01-fika-headless')
        ids = {row.get('name', '').lstrip('/'): row.get('id') for row in containers}
        selected = [ids[name] for name in wanted if ids.get(name)]
        if selected:
            query.update(containers=','.join(selected), stack='spt-fika')
        else:
            return MANAGEMENT + '/containers?env=' + str(ENVIRONMENT)
    except (OSError, ValueError, TypeError, AttributeError):
        # Show container state instead of opening an empty/stale log selection.
        return MANAGEMENT + '/containers?env=' + str(ENVIRONMENT)
    return MANAGEMENT + '/logs?' + urllib.parse.urlencode(query, safe=',')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('view', choices=('players', 'metrics', 'logs'))
    parser.add_argument('--print-url', action='store_true', help='Resolve the destination without opening a browser')
    args = parser.parse_args()
    url = view_url(args.view)
    if args.print_url:
        print(url)
        return
    command = [shutil.which('xdg-open'), url] if shutil.which('xdg-open') else [shutil.which('gio'), 'open', url]
    if not command[0]:
        raise SystemExit('No desktop URL opener is installed.')
    raise SystemExit(subprocess.run(command, check=False).returncode)


if __name__ == '__main__':
    main()
