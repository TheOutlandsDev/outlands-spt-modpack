# Client update announcements and release checks — 0.5.4

Whenever a committed server publication changes any of the 351 managed client
paths, sizes or SHA256 hashes, its durable outbox queues this Fika notification:

> Client files changed (version). Finish your current raid, then close Escape
> from Tarkov AND SPT Launcher and run Play Outlands before your next raid.

The dashboard keeps these instructions visible. The existing maintenance worker
retries failed notification delivery; successful delivery is deduplicated. A
routine restart, ZIP transport change or server-only update creates no false
client-update warning. There is no extra Codex monitor or public control endpoint.

Outlands.ClientPackPolicy 1.2.0 records each authenticated session's successful
native Fika DLL report against the current managed-content identity. The private
bounded records survive an unchanged daily restart. Changed client content makes
existing records stale: new headless starts and raid joins are refused with update
instructions until the game starts fresh and validates again. Existing raid
traffic/saves and reconnects to the same active match remain available. Never
publish or redistribute validated-sessions.json; fresh installs start without it.

Play Outlands performs the full managed-file SHA256 verification before launch.
The admission record is not a hash report from a running game's config files, a
cryptographic process identity, or anti-cheat. Manually reopening correct DLLs
with old config files could still pass native Fika checking; always use Play
Outlands. No client is force-closed and no profile data is changed.

Hosts use the included matching policy/owner-layer and authored source. Generate
the fixed policy and preflight downloads before changing a DLL baseline, wait
for all raids to finish, back up, and restart the matched backend/headless pair.
Publish with host-kit/player-dashboard/ops/publish-client-bundle.py; it moves the
release fingerprint before the sync manifest and queues the notice after commit.
The first guard installation requires one fresh game startup because prior
servers did not retain native validation records. See the included policy README.

This is a server/dashboard update: client pack 2026.10.24.3, sync bundle
2026.10.24.4, Remote Quests 1.0.3 and all 351 managed/27 base hashes are unchanged.
Matching existing players close game/launcher and use Play Outlands normally;
new players use the complete Client installer. SelfHost has two changed server
files and the improved host-kit. Client/SelfHost counts remain 356/2508.

Verified: 52 backend/publisher/notice tests, 25 maintenance tests, 49 policy,
real-Harmony callback and frozen-client refusal-contract checks, and isolated
backend startup. Exact Windows update dialog rendering and a release transition
with two human players remain to be tested. The 0.5.3 AI/insurance gameplay checks
remain outstanding where documented; no new combat performance claim is made.

# 0.5.3 — headless bot limits and insurance navigation

The headless host had no MainPlayer, causing SPT 4.0.13 to choose the default
18-bot limit on every map. Outlands.ScavWar 1.1.0 resolves this exact fallback
request using the registered headless session's current Fika match map cap.
Human/named-map calls and missing match state keep their native behavior.
The existing map caps and wave timing remain unchanged.

FikaDynamicAI range is 350 metres, formerly 175, with High scanning and snipers
exempt. More distant fights can continue; actual outdoor performance needs a
raid benchmark. The existing SAIN hearing/sight/accuracy settings stay unchanged.

Outlands Remote Quests 1.0.3 skips the insurance step before constructing its
empty trader dropdown when no insurer is available. It follows the native Next
path and retains map/access-key checks. Available insurers retain normal UI.
No insurance is purchased and no trader flags or profile data are edited.

Client pack 2026.10.24.3 changes one managed DLL. Close the game and launcher,
then use Play Outlands to sync before launching. Base EFT/SPT/Fika dependencies
are unchanged. New players use the complete 0.5.3 Client installer; independent
hosts use its matching SelfHost choice. Both require legitimate game files.

Tests cover real Fika match lookup, real SPT callback patching, native insurance
call sites, navigation with real Harmony, and existing quest/zombie guards.
Windows insurance UI and new outdoor combat pacing still need player testing.

# 0.5.2 — moderate AI spawns and individual-file sync

The existing population-mod settings gain four effective AI slots on larger
maps, two on Factory/Ground Zero, and one regular Scav per eligible wave where
group caps allow. Reserve 30→34, Customs 28→32, Woods 33→37, Ground Zero 17→19.
PMC timing/chances, AI difficulty, boss events, zombies, economy, base SPT configs
and client DLLs are unchanged. See docs/SPAWN-PRESET.md. The one owned server
config is verified by hash and included in the matching SelfHost lock.

The complete package includes Play Outlands 1.4.0 for individual-file sync.
Client baseline remains 2026.10.24.2 with 351 managed and 27 verified base files.
Existing matching clients need no new DLLs; relaunch after activation to refresh
cached raid settings. Activation waits for all raids, backs up state, and restarts
the original containers. Real raid performance after the increase needs testing.

# 0.5.1 — scheduled content and infected AI safety

Client managed baseline 2026.10.24.2 retains the same 351 paths and 27 base
contracts. Remote Quests 1.0.2 adds exact infected-role loyalty/revenge guards.
The fixed validator now accepts required shared rules on the headless role:
41 human and 44 headless plugins are required. The host can no longer omit the
shared zombie guard. Both scopes still refuse extra, missing or changed DLLs.

SelfHost adds Outlands Live Content DLL and reviewed settings (2508 files total).
The module schedules seven themes/weekly-shifting hotspots after idle maintenance.
It normalizes infection and reciprocal Scav/infected hostility on all 12 map
variants, limits crowds, keeps existing bot caps, and makes generated PMC waves
respect those caps. Ground Zero remains lightly infected. Economy modifiers
are capped at 3% location loot chance; profiles/trade prices are not reset.

0.5.0 clients receive the managed change by using Play Outlands. New players and
pre-0.5 users run the complete 0.5.1 Client installer once for the matching WTT
base patcher. The public bootstrap policy is unchanged at 1.3.0.

# 0.5.1 — hosted baseline alignment

Client and SelfHost share one canonical lock. Client installs 351 managed plugin,
asset and local gameplay files, Fika Core and four author patchers (356 files).
The updater verifies those 351 managed files and 27 base dependencies separately.
SelfHost installs 2,508 mod/configuration files, including the same human client
files, headless-only plugins, fixed role validation, remote quest acceptance with
local turn-ins, Scav War and the existing repaired Flea Simulator.

NarcoNet is placed in its actual client/server roots. The obsolete human plugin
and preset inventory is removed from the new lock. Known exact 0.4.0 leftovers
can be quarantined into verified backups during an applied install; unknown or
modified extra DLLs stop installation. No unrecognized files are deleted.

Raw gameplay settings preserve node-01 bytes. Eleven base configuration leaf
changes reproduce its complete weather/seasonal JSON behavior: autumn, Halloween
and zombies. Host-specific network addresses, API keys and headless accounts
must be configured independently. Profiles, relationship databases, generated
Fika scripts, caches and economy/player state are never distributed.

Five unmodified WTT DLLs are built locally from pinned author sources. Their
common reproducible hashes replace the previous node-01 binaries only during an
idle backed-up activation. The new patcher matches all 13 original methods and
runtime types/attributes, ignoring declaration order. Existing Armory/Backport
source proof files describe the other four builds. This does not establish a
successful new multiplayer playtest.

One repaired MIT Flea Simulator DLL is included with its corresponding repaired
source and the upstream MIT license. Other third-party binaries/assets download
from pinned sources; the installer never supplies retail game or base SPT files.
