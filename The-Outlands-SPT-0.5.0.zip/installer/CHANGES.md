# 0.5.0 — hosted baseline alignment

Client and SelfHost share one canonical lock. Client installs 351 managed plugin,
asset and local gameplay files, Fika Core and four author patchers (356 files).
The updater verifies those 351 managed files and 27 base dependencies separately.
SelfHost installs 2,506 mod/configuration files, including the same human client
files, headless-only plugins, fixed role validation, remote quest acceptance with
local turn-ins, Scav War and the existing repaired Flea Simulator.

NarcoNet is placed in its actual client/server roots. The obsolete human plugin
and preset inventory is removed from the new lock. Known exact 0.4.0 leftovers
can be quarantined into verified backups during an applied install; unknown or
modified extra DLLs stop installation. No unrecognized files are deleted.

Raw gameplay settings preserve node-01 bytes. Eleven base configuration leaf
changes reproduce its complete weather/seasonal JSON behavior: autumn, Halloween
and zombies. Host-specific network addresses, API keys and headless accounts
must be configured independently. Profiles, relationship databases, generated
Fika scripts, caches and economy/player state are never distributed.

Five unmodified WTT DLLs are built locally from pinned author sources. Their
common reproducible hashes replace the previous node-01 binaries only during an
idle backed-up activation. The new patcher matches all 13 original methods and
runtime types/attributes, ignoring declaration order. Existing Armory/Backport
source proof files describe the other four builds. This does not establish a
successful new multiplayer playtest.

One repaired MIT Flea Simulator DLL is included with its corresponding repaired
source and the upstream MIT license. Other third-party binaries/assets download
from pinned sources; the installer never supplies retail game or base SPT files.
