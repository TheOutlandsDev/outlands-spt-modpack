OUTLANDS AUTHORED POLICIES - 2026-10-24

These five original DLLs match the maintained deployment bytes. Dependencies
are not bundled: use SPT 4.0.13 / Fika server author release 2.2.4; Remote Quests
requires the matching EFT 0.16.9.40087 / Fika Core 2.2.5 client.

Review source and module READMEs before manually installing any module. Do not
blindly copy this ZIP over an existing setup. The client-pack-policy DLL needs
a generated policy.json for YOUR exact human/headless plugin baseline before it
can load. The maintenance gate alone does not install a scheduler. Remote Quests
and LocalQuestTurnIns should be used together for accept-only remote questing.

This is original policy/plugin code, NOT a full Client or SelfHost modpack. No
game/vendor libraries, runtime configuration, credentials, saves or player
profiles are bundled. Exact matching of these authored DLLs does not establish
that the public 0.4.0 reconstruction matches the maintained server.

Source/docs: https://github.com/TheOutlandsDev/outlands-spt-modpack/blob/main/Outlands-Public-Source-2026.10.24.zip
Access/community: https://discord.gg/cNqhhUdFW
