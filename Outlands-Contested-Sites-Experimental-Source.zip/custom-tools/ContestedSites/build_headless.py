#!/usr/bin/env python3
"""Compile the headless BigBrain objective against compatible local game DLLs."""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--spt-root", type=Path, default=ROOT / "runtime")
    parser.add_argument("--sdk-root", type=Path, default=ROOT / "MAINSPT/Tools/dotnet-sdk-9.0.316")
    parser.add_argument("--dotnet", type=Path, default=ROOT / "linux/dotnet/dotnet")
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    runtime = args.spt_root.resolve()
    sdk = args.sdk_root.resolve()
    dotnet = args.dotnet.resolve()
    subprocess.run(["python3", str(HERE / "verify.py"), "--spt-root", str(runtime)], check=True)

    managed = runtime / "EscapeFromTarkov_Data/Managed"
    refs = [managed / name for name in (
        "mscorlib.dll", "System.dll", "System.Core.dll", "netstandard.dll", "System.Runtime.dll", "Assembly-CSharp.dll",
        "UnityEngine.dll", "UnityEngine.CoreModule.dll", "UnityEngine.AIModule.dll",
        "Comfort.dll", "Newtonsoft.Json.dll")]
    refs += [runtime / name for name in (
        "BepInEx/core/BepInEx.dll", "BepInEx/plugins/DrakiaXYZ-BigBrain.dll")]
    if any(not path.is_file() for path in refs):
        raise SystemExit("Pinned game/BigBrain references unavailable")

    runtimeconfig = output / "compiler.runtimeconfig.json"
    runtimeconfig.write_text(json.dumps({"runtimeOptions": {
        "tfm": "net9.0", "framework": {"name": "Microsoft.NETCore.App", "version": "9.0.17"}}}))
    dll = output / "Outlands.ContestedSites.Headless.dll"
    arguments = ["-nologo", "-langversion:latest", "-deterministic+", "-nostdlib+",
                 "-target:library", "-out:" + str(dll)]
    arguments += ["-r:" + str(path) for path in refs]
    arguments.append(str(HERE / "headless/src/Plugin.cs"))
    response = output / "headless.rsp"
    response.write_text("\n".join('"' + arg + '"' for arg in arguments))
    subprocess.run([str(dotnet), "exec", "--runtimeconfig", str(runtimeconfig),
                    str(sdk / "sdk/9.0.316/Roslyn/bincore/csc.dll"), "@" + str(response)],
                   check=True, env=dict(os.environ, COMPlus_ReadyToRun="0"))
    staged = output / "BepInEx/plugins/Outlands.ContestedSites.Headless"
    staged.mkdir(parents=True, exist_ok=True)
    shutil.copy2(dll, staged / dll.name)
    shutil.copy2(HERE / "headless/config.json", staged / "config.json")
    print("Outlands.ContestedSites.Headless SHA256", hashlib.sha256(dll.read_bytes()).hexdigest())


if __name__ == "__main__":
    main()
