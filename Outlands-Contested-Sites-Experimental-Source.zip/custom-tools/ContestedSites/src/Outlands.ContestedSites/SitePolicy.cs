using System;
using System.Collections.Generic;
using System.Linq;
using SPTarkov.Server.Core.Models.Eft.Common;

namespace Outlands.ContestedSites;

internal static class SitePolicy
{
    internal static LooseLoot BoostLoot(LooseLoot loot, ISet<string> ids, double floor)
    {
        if (loot.Spawnpoints is null) return loot;
        return loot with
        {
            Spawnpoints = loot.Spawnpoints.Select(point => ids.Contains(point.LocationId ?? "")
                ? point with { Probability = Math.Max(point.Probability ?? 0, floor) }
                : point).ToArray()
        };
    }

    internal static BossLocationSpawn? SelectWave(IEnumerable<BossLocationSpawn> waves, string zone) =>
        waves.Where(w => string.Equals(w.BossName, "pmcUSEC", StringComparison.OrdinalIgnoreCase)
                && w.BossChance > 0 && w.Time is >= 120 and <= 900
                && (w.SpawnMode ?? []).Contains("pve", StringComparer.OrdinalIgnoreCase)
                && (w.BossZone ?? "").Split(',').Any(z => string.Equals(z.Trim(), zone, StringComparison.OrdinalIgnoreCase)))
            .OrderBy(w => w.Time).FirstOrDefault();
}
