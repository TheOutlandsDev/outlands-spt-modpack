using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using SPTarkov.DI.Annotations;
using SPTarkov.Server.Core.Models.Eft.Common;
using SPTarkov.Server.Core.Models.Spt.Config;
using SPTarkov.Server.Core.Servers;
using SPTarkov.Server.Core.Services;
using SPTarkov.Server.Core.Utils.Logger;

namespace Outlands.ContestedSites;

public sealed class SitesConfig
{
    public bool Enabled { get; set; }
    public string Map { get; set; } = "bigmap";
    public string ActiveSiteId { get; set; } = "";
    public double LootProbabilityFloor { get; set; } = 0.65;
    public List<SupplySite> Sites { get; set; } = [];
}

public sealed class SupplySite
{
    public string Id { get; set; } = "";
    public string Zone { get; set; } = "";
    public List<string> LootLocationIds { get; set; } = [];
}

[Injectable]
public sealed class ContestedSitesService(
    DatabaseService database,
    ConfigServer configServer,
    SptLogger<ContestedSitesService> logger)
{
    private bool applied;

    public void Apply()
    {
        if (applied) return;
        applied = true;

        try
        {
            var path = Path.Combine(
                Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) ?? AppContext.BaseDirectory,
                "config", "config.json");
            if (!File.Exists(path))
            {
                logger.Warning("Outlands Contested Sites config is missing; feature inactive.", null);
                return;
            }

            var config = JsonSerializer.Deserialize<SitesConfig>(
                File.ReadAllText(path), new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            if (config?.Enabled != true)
            {
                logger.Info("Outlands Contested Sites is disabled by config.", null);
                return;
            }
            if (config.Sites is null || config.Sites.Count == 0 || config.LootProbabilityFloor is <= 0 or > 1)
                throw new InvalidDataException("Invalid site list or loot probability floor.");

            var locations = database.GetLocations().GetDictionary();
            if (!locations.TryGetValue(config.Map, out var location) || location.Base is null || location.LooseLoot is null)
                throw new InvalidDataException("Configured map or loose-loot data is unavailable.");

            // The headless objective must target the same site. A fixed ID is
            // required while the paired client plugin is being evaluated.
            var site = config.Sites.SingleOrDefault(s => s.Id == config.ActiveSiteId)
                ?? throw new InvalidDataException("Configured active site ID is missing or ambiguous.");
            var validZones = (location.Base.OpenZones ?? "").Split(',', StringSplitOptions.RemoveEmptyEntries)
                .Select(z => z.Trim()).ToHashSet(StringComparer.OrdinalIgnoreCase);
            if (string.IsNullOrWhiteSpace(site.Id) || string.IsNullOrWhiteSpace(site.Zone)
                || site.LootLocationIds is null || !validZones.Contains(site.Zone)
                || !(location.Base.SpawnPointParams ?? [])
                    .Any(p => string.Equals(p.BotZoneName, site.Zone, StringComparison.OrdinalIgnoreCase)
                        && (p.Categories ?? []).Contains("BotPmc")))
                throw new InvalidDataException($"Site {site.Id} has no valid PMC spawn zone.");

            var ids = site.LootLocationIds.ToHashSet(StringComparer.Ordinal);
            if (ids.Count is < 2 or > 4)
                throw new InvalidDataException($"Site {site.Id} must select two to four unique native loot points.");
            var original = location.LooseLoot.Value;
            if (original?.Spawnpoints is null || original.Spawnpoints.Count(p => ids.Contains(p.LocationId ?? "")) != ids.Count)
                throw new InvalidDataException($"Site {site.Id} loot points do not match the installed map data.");

            var configWaves = configServer.GetConfig<PmcConfig>().CustomPmcWaves;
            var target = configWaves.TryGetValue(config.Map, out var waves)
                ? SitePolicy.SelectWave(waves, site.Zone) : null;
            if (target is null)
                throw new InvalidDataException($"Site {site.Id} has no compatible existing PMC reinforcement wave.");

            // LazyLoad deserializes and applies transformers on each raid request.
            // Reuse the original item templates, placements and native generator.
            location.LooseLoot.AddTransformer(loot => SitePolicy.BoostLoot(loot!, ids, config.LootProbabilityFloor));

            // SPT copies configured PMC waves into each generated raid location.
            // Retarget one config wave; no wave, bot, chance or timing is added.
            target.BossZone = site.Zone;
            logger.Success($"Outlands Contested Sites active: {site.Id}, {ids.Count} native loot points, one existing PMC reinforcement routed to {site.Zone}.", null);
        }
        catch (Exception ex)
        {
            logger.Error("Outlands Contested Sites validation failed; feature inactive.", ex);
        }
    }

}
