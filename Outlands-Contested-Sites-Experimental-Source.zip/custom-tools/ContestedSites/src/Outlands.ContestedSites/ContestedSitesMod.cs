using System;
using System.Reflection;
using System.Threading.Tasks;
using SPTarkov.DI.Annotations;
using SPTarkov.Reflection.Patching;
using SPTarkov.Server.Core.Models.External;
using SPTarkov.Server.Core.Services;
using SPTarkov.Server.Core.Utils.Logger;

namespace Outlands.ContestedSites;

[Injectable]
public sealed class ContestedSitesMod(
    ContestedSitesService sites,
    SptLogger<ContestedSitesMod> logger) : IOnWebAppBuildModAsync
{
    public Task OnWebAppBuildAsync()
    {
        ContestedSitesPostDbPatch.Configure(sites.Apply);
        new ContestedSitesPostDbPatch().Enable();
        logger.Info("Outlands Contested Sites installed post-database patch.", null);
        return Task.CompletedTask;
    }
}

internal sealed class ContestedSitesPostDbPatch : AbstractPatch
{
    private static Action? apply;

    public ContestedSitesPostDbPatch() : base("outlands.contested-sites.post-db") { }

    public static void Configure(Action action) => apply = action;

    protected override MethodBase GetTargetMethod() =>
        typeof(PostDbLoadService).GetMethod(
            nameof(PostDbLoadService.PerformPostDbLoadActions),
            BindingFlags.Instance | BindingFlags.Public)!;

    [PatchPostfix]
    public static void PatchPostfix() => apply?.Invoke();
}
