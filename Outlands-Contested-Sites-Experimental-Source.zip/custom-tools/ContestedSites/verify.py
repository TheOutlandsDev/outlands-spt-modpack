#!/usr/bin/env python3
"""Validate authored sites against the pinned SPT map and PMC wave data."""
import json
import math
import argparse
from pathlib import Path

HERE = Path(__file__).resolve().parent
DEFAULT_SPT_ROOT = HERE.parents[3] / "runtime"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--server-config", type=Path, default=HERE / "config/config.json")
    parser.add_argument("--headless-config", type=Path, default=HERE / "headless/config.json")
    parser.add_argument("--spt-root", type=Path, default=DEFAULT_SPT_ROOT,
                        help="Compatible SPT/EFT installation root")
    args = parser.parse_args()
    runtime = args.spt_root.resolve()
    config = json.loads(args.server_config.read_text())
    assert config["map"] == "bigmap"
    active_id = config["activeSiteId"]
    assert active_id == "factory-side-supply", "headless plugin currently supports factory-side-supply only"
    assert len([s for s in config["sites"] if s["id"] == active_id]) == 1
    headless = json.loads(args.headless_config.read_text())
    assert headless["map"] == config["map"]
    assert headless["activeSiteId"] == active_id
    assert config["enabled"] == headless["enabled"], "backend/headless enable flags must agree"
    assert 1 <= headless["maxAssignedPmcs"] <= 4
    assert 20 <= headless["activationRadiusMeters"] <= 200
    assert 30 <= headless["searchSecondsMin"] <= headless["searchSecondsMax"] <= 300
    assert 0 < config["lootProbabilityFloor"] <= 1
    base = json.loads((runtime / "SPT/SPT_Data/database/locations/bigmap/base.json").read_text())
    loose = json.loads((runtime / "SPT/SPT_Data/database/locations/bigmap/looseLoot.json").read_text())
    pmc = json.loads((runtime / "SPT/SPT_Data/configs/pmc.json").read_text())
    loot_by_id = {point["locationId"]: point for point in loose["spawnpoints"]}
    assert len(loot_by_id) == len(loose["spawnpoints"]), "loot location IDs must be unique"
    zones = set(base["OpenZones"].split(","))

    for site in config["sites"]:
        assert site["zone"] in zones
        ids = site["lootLocationIds"]
        assert 2 <= len(ids) <= 4 and len(ids) == len(set(ids))
        spawn_positions = [p["Position"] for p in base["SpawnPointParams"]
                           if p.get("BotZoneName") == site["zone"]
                           and "BotPmc" in p.get("Categories", [])]
        assert spawn_positions, site["id"]
        matching_waves = [w for w in pmc["customPmcWaves"]["bigmap"]
                          if w.get("BossName") == "pmcUSEC"
                          and 120 <= w.get("Time", -1) <= 900
                          and site["zone"] in w.get("BossZone", "").split(",")]
        assert matching_waves, site["id"]
        for location_id in ids:
            point = loot_by_id[location_id]
            assert not point["template"].get("IsContainer", False)
            position = point["template"]["Position"]
            distance = min(math.dist((position["x"], position["z"]),
                                    (spawn["x"], spawn["z"])) for spawn in spawn_positions)
            assert distance < 45, (site["id"], location_id, distance)
        if site["id"] == active_id:
            goal = headless["goal"]
            assert min(math.dist((goal["x"], goal["y"], goal["z"]),
                                 (loot_by_id[item]["template"]["Position"]["x"],
                                  loot_by_id[item]["template"]["Position"]["y"],
                                  loot_by_id[item]["template"]["Position"]["z"]))
                       for item in ids) < 4
            departure = headless["departureGoal"]
            assert any(math.dist((departure["x"], departure["y"], departure["z"]),
                                 (spawn["x"], spawn["y"], spawn["z"])) < 4
                       for spawn in spawn_positions)
            assert math.dist((goal["x"], goal["z"]),
                             (departure["x"], departure["z"])) >= 30
        print(f'{site["id"]}: {len(ids)} loot points, valid PMC zone, reinforcement wave')


if __name__ == "__main__":
    main()
