using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using BepInEx;
using BepInEx.Bootstrap;
using Comfort.Common;
using DrakiaXYZ.BigBrain.Brains;
using EFT;
using Newtonsoft.Json;
using UnityEngine;
using UnityEngine.AI;

namespace Outlands.ContestedSites.Headless
{
    internal sealed class SitePoint
    {
        public float X { get; set; }
        public float Y { get; set; }
        public float Z { get; set; }

        public Vector3 ToVector3() { return new Vector3(X, Y, Z); }
    }

    internal sealed class ObjectiveConfig
    {
        public bool Enabled { get; set; }
        public string Map { get; set; }
        public string ActiveSiteId { get; set; }
        public SitePoint Goal { get; set; }
        public SitePoint DepartureGoal { get; set; }
        public float ActivationRadiusMeters { get; set; }
        public int MaxAssignedPmcs { get; set; }
        public float ArrivalRadiusMeters { get; set; }
        public float SearchSecondsMin { get; set; }
        public float SearchSecondsMax { get; set; }
        public float TravelTimeoutSeconds { get; set; }
        public float DepartureTimeoutSeconds { get; set; }
    }

    [BepInPlugin("outlands.contested-sites.headless", "Outlands Contested Sites Headless", "0.1.0")]
    [BepInDependency("com.fika.headless", "1.4.13")]
    [BepInDependency("xyz.drakia.bigbrain", "1.4.0")]
    [BepInDependency("me.sol.sain", "4.4.3")]
    [BepInDependency("me.skwizzy.lootingbots")]
    public sealed class Plugin : BaseUnityPlugin
    {
        internal static ObjectiveConfig Settings;
        private static Plugin instance;

        internal static void Record(string eventName)
        {
            if (instance != null) instance.Logger.LogInfo("Supply objective: " + eventName);
        }

        private void Awake()
        {
            instance = this;
            if (!Chainloader.PluginInfos.ContainsKey("com.fika.headless")) return;
            try
            {
                var path = Path.Combine(Path.GetDirectoryName(GetType().Assembly.Location), "config.json");
                var config = JsonConvert.DeserializeObject<ObjectiveConfig>(File.ReadAllText(path));
                if (config == null || !config.Enabled) return;
                if (config.Map != "bigmap" || config.ActiveSiteId != "factory-side-supply"
                    || config.Goal == null || config.DepartureGoal == null
                    || config.ActivationRadiusMeters < 20 || config.ActivationRadiusMeters > 200
                    || config.MaxAssignedPmcs < 1 || config.MaxAssignedPmcs > 4
                    || config.ArrivalRadiusMeters < 2 || config.ArrivalRadiusMeters > 15
                    || config.SearchSecondsMin < 30 || config.SearchSecondsMax > 300
                    || config.SearchSecondsMin > config.SearchSecondsMax
                    || config.TravelTimeoutSeconds < 60 || config.TravelTimeoutSeconds > 300
                    || config.DepartureTimeoutSeconds < 30 || config.DepartureTimeoutSeconds > 180)
                    throw new InvalidDataException("Invalid or unsupported objective configuration.");

                Settings = config;
                BrainManager.AddCustomLayer(typeof(SiteLayer), new List<string> { "PmcBear", "PmcUsec" }, 10,
                    new List<WildSpawnType> { WildSpawnType.pmcBEAR, WildSpawnType.pmcUSEC });
                Logger.LogInfo("Customs PMC supply objective registered for " + config.ActiveSiteId);
            }
            catch (Exception ex)
            {
                Settings = null;
                Logger.LogError("Supply objective inactive: " + ex.Message);
            }
        }
    }

    internal sealed class SiteLayer : CustomLayer
    {
        private static readonly ConditionalWeakTable<BotOwner, SiteLayer> Layers = new ConditionalWeakTable<BotOwner, SiteLayer>();
        private static readonly ConditionalWeakTable<GameWorld, HashSet<BotOwner>> Assignments =
            new ConditionalWeakTable<GameWorld, HashSet<BotOwner>>();
        private float startedAt = -1;
        private float arrivedAt = -1;
        private float departingAt = -1;
        private float searchDuration;
        private bool complete;
        private bool failed;
        private Vector3 destination;
        private bool hasDestination;
        private Vector3 departureDestination;

        public SiteLayer(BotOwner owner, int priority) : base(owner, priority)
        {
            Layers.Remove(owner);
            Layers.Add(owner, this);
        }

        internal static SiteLayer For(BotOwner owner)
        {
            SiteLayer layer;
            return Layers.TryGetValue(owner, out layer) ? layer : null;
        }

        public override string GetName() { return "Outlands.SupplySite"; }

        public override bool IsActive()
        {
            var cfg = Plugin.Settings;
            var world = Singleton<GameWorld>.Instance;
            if (cfg == null || world == null || world.LocationId != cfg.Map || complete || failed
                || BotOwner == null || BotOwner.BotState != EBotState.Active || BotOwner.Profile == null
                || BotOwner.GetPlayer == null || !BotOwner.GetPlayer.HealthController.IsAlive
                || (BotOwner.BotFollower != null && BotOwner.BotFollower.HaveBoss)
                || BotOwner.Memory == null || BotOwner.Memory.HaveEnemy)
                return false;
            if (BotOwner.Profile.Side != EPlayerSide.Bear && BotOwner.Profile.Side != EPlayerSide.Usec)
                return false;
            if (startedAt < 0 && Vector3.Distance(BotOwner.Position, cfg.Goal.ToVector3()) > cfg.ActivationRadiusMeters)
            {
                complete = true;
                return false;
            }
            if (startedAt < 0 && !TryClaim(world, BotOwner, cfg.MaxAssignedPmcs))
            {
                complete = true;
                return false;
            }
            if (startedAt >= 0 && arrivedAt < 0 && Time.time - startedAt > cfg.TravelTimeoutSeconds)
            {
                failed = true;
                Plugin.Record("travel timed out");
                return false;
            }
            if (departingAt >= 0 && Time.time - departingAt > cfg.DepartureTimeoutSeconds)
            {
                failed = true;
                Plugin.Record("departure timed out");
                return false;
            }
            // Let LootingBots or SAIN's ordinary peace behavior use the native
            // loot while the site is being searched. We resume for departure.
            if (arrivedAt >= 0 && departingAt < 0 && Time.time - arrivedAt < searchDuration)
                return false;
            return true;
        }

        public override void Start()
        {
            if (startedAt >= 0) return;
            startedAt = Time.time;
            var cfg = Plugin.Settings;
            var hit = new NavMeshHit();
            if (cfg == null || !NavMesh.SamplePosition(cfg.Goal.ToVector3(), out hit, 12f, NavMesh.AllAreas))
            {
                failed = true;
                Plugin.Record("site has no NavMesh point");
                return;
            }
            destination = hit.position;
            hasDestination = true;
            var seed = StableHash(BotOwner.ProfileId);
            searchDuration = cfg.SearchSecondsMin + (seed % 1000) / 999f * (cfg.SearchSecondsMax - cfg.SearchSecondsMin);
        }

        public override Action GetNextAction()
        {
            return new Action(typeof(SiteAction), "supply-site-" + (arrivedAt >= 0 ? "search" : "travel"));
        }

        public override bool IsCurrentActionEnding()
        {
            return complete || failed || (arrivedAt >= 0 && departingAt < 0
                && Time.time - arrivedAt < searchDuration);
        }

        internal void Tick()
        {
            if (!hasDestination || failed || complete) return;
            var cfg = Plugin.Settings;
            if (cfg == null) return;
            if (arrivedAt < 0 && Vector3.Distance(BotOwner.Position, destination) <= cfg.ArrivalRadiusMeters)
            {
                arrivedAt = Time.time;
                BotOwner.StopMove();
                Plugin.Record("PMC arrived at site");
            }
            if (arrivedAt >= 0)
            {
                if (departingAt < 0 && Time.time - arrivedAt < searchDuration)
                    return;
                if (departingAt < 0)
                {
                    var exitHit = new NavMeshHit();
                    if (!NavMesh.SamplePosition(cfg.DepartureGoal.ToVector3(), out exitHit, 12f, NavMesh.AllAreas))
                    {
                        failed = true;
                        Plugin.Record("departure has no NavMesh point");
                        return;
                    }
                    departureDestination = exitHit.position;
                    departingAt = Time.time;
                    BotOwner.StopMove();
                    Plugin.Record("PMC departing site");
                }
                if (Vector3.Distance(BotOwner.Position, departureDestination) <= cfg.ArrivalRadiusMeters)
                {
                    complete = true;
                    Plugin.Record("PMC completed site objective");
                    return;
                }
            }
            if (BotOwner.HasPathAndNotComplete) return;
            BotOwner.Mover.Sprint(false, true);
            BotOwner.SetTargetMoveSpeed(1f);
            if (BotOwner.GoToPoint(departingAt >= 0 ? departureDestination : destination,
                    false, -1f, true, false, true, false, false)
                != NavMeshPathStatus.PathComplete)
            {
                failed = true;
                Plugin.Record("PMC path unavailable");
            }
        }

        private static uint StableHash(string value)
        {
            uint hash = 2166136261;
            foreach (char ch in value ?? "") hash = (hash ^ ch) * 16777619;
            return hash;
        }

        private static bool TryClaim(GameWorld world, BotOwner owner, int limit)
        {
            var owners = Assignments.GetValue(world, _ => new HashSet<BotOwner>());
            if (owners.Contains(owner)) return true;
            if (owners.Count >= limit) return false;
            owners.Add(owner);
            return true;
        }
    }

    internal sealed class SiteAction : CustomLogic
    {
        public SiteAction(BotOwner owner) : base(owner) { }

        public override void Update(CustomLayer.ActionData data)
        {
            var layer = SiteLayer.For(BotOwner);
            layer?.Tick();
        }
    }
}
