#!/usr/bin/env python3
"""Build an enabled paired test package without changing the game installation."""
import argparse
import json
import shutil
import subprocess
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
POLICY_GUID = "outlands.contested-sites.headless"


def crc32c(data: bytes) -> str:
    value = 0xffffffff
    for byte in data:
        value ^= byte
        for _ in range(8):
            value = (value >> 1) ^ (0x82f63b78 if value & 1 else 0)
    return str((value ^ 0xffffffff) & 0xffffffff)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--spt-root", type=Path, default=ROOT / "runtime")
    parser.add_argument("--sdk-root", type=Path, default=ROOT / "MAINSPT/Tools/dotnet-sdk-9.0.316")
    parser.add_argument("--dotnet", type=Path, default=ROOT / "linux/dotnet/dotnet")
    args = parser.parse_args()
    output = args.output.resolve()
    runtime = args.spt_root.resolve()
    if output == runtime or runtime in output.parents:
        raise SystemExit("Refusing to stage into the live runtime")
    if output.exists() and any(output.iterdir()):
        raise SystemExit("Output directory must be empty")
    build_args = ["--spt-root", str(runtime), "--sdk-root", str(args.sdk_root.resolve()),
                  "--dotnet", str(args.dotnet.resolve())]

    with tempfile.TemporaryDirectory(prefix="outlands-contested-build-") as temp:
        temp = Path(temp)
        server = temp / "server"
        headless = temp / "headless"
        subprocess.run(["python3", str(HERE / "build.py"), "--output", str(server), *build_args], check=True)
        subprocess.run(["python3", str(HERE / "build_headless.py"), "--output", str(headless), *build_args], check=True)
        server_src = server / "SPT/user/mods/zzz-OutlandsContestedSites"
        headless_src = headless / "BepInEx/plugins/Outlands.ContestedSites.Headless"
        server_dst = output / "SPT/user/mods/zzz-OutlandsContestedSites"
        headless_dst = output / "BepInEx/plugins/Outlands.ContestedSites.Headless"
        shutil.copytree(server_src, server_dst)
        shutil.copytree(headless_src, headless_dst)

    server_config = server_dst / "config/config.json"
    headless_config = headless_dst / "config.json"
    for path in (server_config, headless_config):
        config = json.loads(path.read_text())
        config["enabled"] = True
        path.write_text(json.dumps(config, indent=2) + "\n")

    dll = headless_dst / "Outlands.ContestedSites.Headless.dll"
    policy_hint = {
        "guid": POLICY_GUID,
        "crc32c": crc32c(dll.read_bytes()),
        "role": "headless-only",
        "narcoNetHostOnlyExclusion": "BepInEx/plugins/Outlands.ContestedSites.Headless",
    }
    (output / "HEADLESS-POLICY-HINT.json").write_text(json.dumps(policy_hint, indent=2) + "\n")

    subprocess.run(["python3", str(HERE / "verify.py"),
                    "--server-config", str(server_config),
                    "--headless-config", str(headless_config),
                    "--spt-root", str(runtime)], check=True)
    print("Ready test package:", output, "headless CRC32C:", policy_hint["crc32c"])


if __name__ == "__main__":
    main()
