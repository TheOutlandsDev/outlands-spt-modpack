#!/usr/bin/env python3
"""Build the server module against a compatible SPT 4.0.13 installation."""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--spt-root", type=Path, default=ROOT / "runtime")
    parser.add_argument("--sdk-root", type=Path, default=ROOT / "MAINSPT/Tools/dotnet-sdk-9.0.316")
    parser.add_argument("--dotnet", type=Path, default=ROOT / "linux/dotnet/dotnet")
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)

    runtime = args.spt_root.resolve()
    sdk = args.sdk_root.resolve()
    dotnet = args.dotnet.resolve()
    reference_dir = sdk / "packs/Microsoft.NETCore.App.Ref/9.0.18/ref/net9.0"
    references = sorted(reference_dir.glob("*.dll"))
    references += [runtime / "SPT" / name for name in (
        "SPTarkov.Common.dll", "SPTarkov.DI.dll", "SPTarkov.Reflection.dll",
        "SPTarkov.Server.Core.dll", "SemanticVersioning.dll", "0Harmony.dll")]
    if not references or any(not path.is_file() for path in references):
        raise SystemExit("Pinned .NET/SPT references unavailable; no module built")

    subprocess.run(["python3", str(HERE / "verify.py"), "--spt-root", str(runtime)], check=True)
    runtimeconfig = output / "compiler.runtimeconfig.json"
    runtimeconfig.write_text(json.dumps({"runtimeOptions": {
        "tfm": "net9.0", "framework": {
            "name": "Microsoft.NETCore.App", "version": "9.0.17"}}}))
    dll = output / "Outlands.ContestedSites.dll"
    sources = sorted((HERE / "src/Outlands.ContestedSites").glob("*.cs"))
    env = dict(os.environ, COMPlus_ReadyToRun="0")
    def compile(name, sources, executable=False):
        arguments = ["-nologo", "-langversion:latest", "-nullable:enable", "-deterministic+", "-nostdlib+",
                     "-target:" + ("exe" if executable else "library"), "-out:" + str(output / (name + ".dll"))]
        arguments += ["-r:" + str(path) for path in references]
        arguments += [str(path) for path in sources]
        response = output / (name + ".rsp")
        response.write_text("\n".join('"' + arg + '"' for arg in arguments))
        subprocess.run([str(dotnet), "exec", "--runtimeconfig", str(runtimeconfig),
                        str(sdk / "sdk/9.0.316/Roslyn/bincore/csc.dll"), "@" + str(response)],
                       check=True, env=env)

    compile("Outlands.ContestedSites", sources)
    test = HERE / "tests/TestSitePolicy.cs"
    compile("TestSitePolicy", [HERE / "src/Outlands.ContestedSites/SitePolicy.cs", test], executable=True)
    for path in references[len(list(reference_dir.glob("*.dll"))):]:
        shutil.copy2(path, output / path.name)
    subprocess.run([str(dotnet), "exec", "--runtimeconfig", str(runtimeconfig),
                    str(output / "TestSitePolicy.dll")], check=True, env=env)
    staged = output / "SPT/user/mods/zzz-OutlandsContestedSites"
    (staged / "config").mkdir(parents=True, exist_ok=True)
    shutil.copy2(dll, staged / dll.name)
    shutil.copy2(HERE / "config/config.json", staged / "config/config.json")
    print("Outlands.ContestedSites SHA256", hashlib.sha256(dll.read_bytes()).hexdigest())


if __name__ == "__main__":
    main()
