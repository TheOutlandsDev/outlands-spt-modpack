using System;
using System.Collections.Generic;
using System.Linq;
using Outlands.ContestedSites;
using SPTarkov.Server.Core.Models.Eft.Common;

internal static class TestSitePolicy
{
    private static void Require(bool condition, string message)
    {
        if (!condition) throw new Exception(message);
    }

    private static void Main()
    {
        var selected = new Spawnpoint { LocationId = "selected", Probability = 0.02 };
        var existingHigh = new Spawnpoint { LocationId = "high", Probability = 0.9 };
        var unrelated = new Spawnpoint { LocationId = "other", Probability = 0.11 };
        var original = new LooseLoot { Spawnpoints = [selected, existingHigh, unrelated] };
        var boosted = SitePolicy.BoostLoot(original, new HashSet<string> { "selected", "high" }, 0.65);
        var points = boosted.Spawnpoints!.ToArray();
        Require(points[0].Probability == 0.65, "selected native loot must be boosted");
        Require(points[1].Probability == 0.9, "already valuable native loot must not be lowered");
        Require(ReferenceEquals(points[2], unrelated), "unrelated loot must be untouched");
        Require(selected.Probability == 0.02, "source loot must not be mutated");
        Require(boosted.SpawnpointsForced == original.SpawnpointsForced, "forced loot must be unchanged");

        var scav = new BossLocationSpawn { BossName = "assault", BossChance = 100, Time = 360,
            BossZone = "ZoneFactorySide", SpawnMode = ["pve"] };
        var zombie = new BossLocationSpawn { BossName = "infectedAssault", BossChance = 100, Time = 360,
            BossZone = "ZoneFactorySide", SpawnMode = ["pve"] };
        var disabled = new BossLocationSpawn { BossName = "pmcUSEC", BossChance = 0, Time = 360,
            BossZone = "ZoneFactorySide", SpawnMode = ["pve"] };
        var opening = new BossLocationSpawn { BossName = "pmcUSEC", BossChance = 100, Time = 30,
            BossZone = "ZoneFactorySide", SpawnMode = ["pve"] };
        var reinforcement = new BossLocationSpawn { BossName = "pmcUSEC", BossChance = 70, Time = 360,
            BossZone = "ZoneFactorySide,ZoneOldAZS", SpawnMode = ["pve"] };
        var picked = SitePolicy.SelectWave([scav, zombie, disabled, opening, reinforcement], "ZoneFactorySide");
        Require(ReferenceEquals(picked, reinforcement), "only existing mid-raid PMC wave may be selected");
        Require(SitePolicy.SelectWave([scav, zombie, disabled, opening], "ZoneFactorySide") is null,
            "no compatible PMC wave must leave site inactive");
        Console.WriteLine("Contested Sites policy checks passed");
    }
}
