# Outlands Contested Sites (experimental)

This is an optional, source-only SPT/Fika add-on for a first Customs raid test. It
is **not part of the 0.5.14 Client/SelfHost release**. Both source configs are
disabled by default. Startup and compilation have been checked on the maintained
host, but a real multiplayer raid has not yet validated PMC movement, combat,
looting, synchronization, or performance.

The server module selects `factory-side-supply`, raises three native loose-loot
point probabilities to at least 0.65, and routes one existing USEC reinforcement
wave through its PMC zone. It creates no extra bot wave or zombie. The Fika
headless-only BigBrain layer can direct up to three nearby PMCs toward that site.
After arrival it yields for two to four minutes so LootingBots can use native loot,
then attempts departure. SAIN combat and extraction priorities can take control.

## Build a paired test package

Use a legitimate compatible SPT 4.0.13 / EFT 0.16.9.40087 installation, Fika
Headless 1.4.13, BigBrain 1.4.0, SAIN 4.4.3, and LootingBots. Supply your own .NET
SDK 9.0.316, including the 9.0.18 reference pack. The build scripts use only
local references and do not download or redistribute game or third-party DLLs.

From a clone of this repository:

```sh
python3 custom-tools/ContestedSites/prepare_test.py \
  --spt-root /path/to/your/compatible-spt \
  --sdk-root /path/to/dotnet-sdk-9.0.316 \
  --dotnet /path/to/dotnet \
  --output /path/to/empty/staging-folder
```

The command validates the installed Customs map and PMC wave data, compiles both
modules, runs the server policy test, and stages an **enabled** pair under
`SPT/user/mods/zzz-OutlandsContestedSites/` and
`BepInEx/plugins/Outlands.ContestedSites.Headless/`. It also writes
`HEADLESS-POLICY-HINT.json` with the new plugin's CRC32C and NarcoNet host-only
exclusion path. Review and add those values to your own server role policy; the
script does not overwrite your policy or NarcoNet configuration. Keep the headless
plugin out of human clients.

At a verified idle boundary, back up your settings, install the server module on
the backend and the plugin on the Fika headless host, apply your reviewed host-only
policy changes, then restart backend followed by headless. To turn the feature
off, disable **both** configs and restart. To remove it, restore your prior policy
and NarcoNet settings and remove the two added mod folders at an idle boundary.

## Raid acceptance

In a shared Customs Fika raid, observe a PMC approach the site, loot or patrol
during the search window, fight or take cover when threatened, and depart. Check
the other player's synchronization, headless `Supply objective:` logs, bot count,
FPS, and BigBrain/SAIN exceptions. A successful build or healthy startup alone
does not establish these outcomes.
