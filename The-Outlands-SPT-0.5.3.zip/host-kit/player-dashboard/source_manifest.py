#!/usr/bin/env python3
"""Describe the exact source allowlist for private GitHub publication."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE_FILES = (
    '.dockerignore', '.gitignore', 'AGENTS.md', 'Dockerfile', 'README.md',
    'app.py', 'content_status.py', 'tests/test_content.py', 'compose.yaml', 'config.example.json', 'configure-local.py',
    'deploy-local.py', 'source_manifest.py', 'tests/test_app.py',
    'web/index.html', 'web/styles.css', 'web/app.js',
    'ops/NETWORK.md', 'ops/enable-private-hosting.sh', 'ops/halloween.py',
    'ops/node01-spt-tailnet.service', 'ops/tailnet-firewall.nft',
    'desktop/open-view.py', 'desktop/install-shortcuts.py',
    'desktop/icons/players.svg', 'desktop/icons/metrics.svg', 'desktop/icons/logs.svg',
    'mods/scav-war/README.md', 'mods/scav-war/ScavWarPolicy.cs',
    'mods/scav-war/TestPolicy.cs', 'mods/scav-war/build.py',
    'mods/scav-war/HeadlessBotCap.cs',
    'mods/remote-quests/README.md', 'mods/remote-quests/RemoteQuestsPlugin.cs',
    'mods/remote-quests/QuestAccessPolicy.cs', 'mods/remote-quests/TestPolicy.cs',
    'mods/remote-quests/InspectContracts.cs', 'mods/remote-quests/build.py',
    'mods/remote-quests/TestUiStubs.cs', 'mods/remote-quests/TestNavigation.cs',
    'mods/remote-quests/TurnInPatches.cs', 'mods/remote-quests/TestTurnIns.cs',
    'mods/remote-quests/INSTALL.txt', 'mods/remote-quests/ZombieSafetyPatches.cs',
    'mods/remote-quests/TestZombieSafety.cs',
    'mods/remote-quests/InsuranceSkipPatches.cs', 'mods/remote-quests/TestInsurance.cs',
    'mods/live-content/LiveContent.cs', 'mods/live-content/TestPolicy.cs',
    'mods/live-content/build.py', 'mods/live-content/settings.json', 'mods/live-content/README.md',
    'mods/local-quest-turnins/README.md', 'mods/local-quest-turnins/LocalQuestTurnIns.cs',
    'mods/local-quest-turnins/TestPolicy.cs', 'mods/local-quest-turnins/build.py',
    'ops/publish-client-bundle.py', 'tests/test_client_bundle.py',
    'ops/spawn_preset.py', 'ops/spawn-preset.json', 'tests/test_spawn_preset.py',
    'ops/configure-narconet-client-policy.py', 'tests/test_narconet_policy.py',
    'client-updater/Update-Outlands.ps1', 'client-updater/Outlands Client Updater.cmd',
    'client-updater/Update and Play.cmd', 'client-updater/README.txt',
    'client-updater/Install Play Outlands.cmd', 'client-updater/Install-PlayOutlands.ps1',
    'client-updater/README.md', 'client-updater/tests.ps1', 'client-updater/tests-shortcut.ps1', 'client-updater/tests-sync.ps1',
    'client-updater/client-policy.json',
    'client-pack/build.py', 'client-pack/test_pack.py', 'client-pack/README.md',
    'client-pack/inventory.json',
    'mods/client-pack-policy/ClientPackPolicy.cs', 'mods/client-pack-policy/TestPolicy.cs',
    'mods/client-pack-policy/InspectPlugins.cs', 'mods/client-pack-policy/build.py',
    'mods/client-pack-policy/generate.py', 'mods/client-pack-policy/scan.py',
    'mods/client-pack-policy/README.md',
    'maintenance/engine.py', 'maintenance/worker.py', 'maintenance/install.py',
    'maintenance/README.md', 'maintenance/test_maintenance.py',
    'mods/maintenance/Maintenance.cs', 'mods/maintenance/TestPolicy.cs',
    'mods/maintenance/build.py', 'mods/maintenance/README.md',
)


def manifest():
    rows = []
    for relative in SOURCE_FILES:
        path = ROOT / relative
        if path.is_symlink() or not path.is_file():
            raise ValueError('Expected ordinary source file missing: ' + relative)
        data = path.read_bytes()
        data.decode('utf-8')
        rows.append(dict(path=relative, bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                         gitBlobSha=hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(),
                         gitMode='100755' if path.stat().st_mode & 0o111 else '100644'))
    return rows


if __name__ == '__main__':
    print(json.dumps({'schemaVersion': 1, 'repository': 'TheOutlandsDev/OUTLANDS-DEV-LAB',
                      'visibility': 'private', 'files': manifest()}, indent=2))
